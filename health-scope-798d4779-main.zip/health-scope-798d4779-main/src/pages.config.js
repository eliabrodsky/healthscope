import Dashboard from './pages/Dashboard';
import Assessments from './pages/Assessments';
import DataUpload from './pages/DataUpload';
import AssessmentDashboard from './pages/AssessmentDashboard';
import CreateAssessmentWizard from './pages/CreateAssessmentWizard';
import Home from './pages/Home';
import InitialDataLoader from './pages/InitialDataLoader';
import PublicAssessmentView from './pages/PublicAssessmentView';
import DataManagement from './pages/DataManagement';
import TestSimple from './pages/TestSimple';
import PresentationBuilder from './pages/PresentationBuilder';
import PublicPortfolio from './pages/PublicPortfolio';
import UserProfile from './pages/UserProfile';
import CompetitorAnalysis from './pages/CompetitorAnalysis';
import RegionalAnalysis from './pages/RegionalAnalysis';
import AIChat from './pages/AIChat';
import About from './pages/About';
import Pricing from './pages/Pricing';
import Support from './pages/Support';
import Features from './pages/Features';
import FqhcAssessment from './pages/FqhcAssessment';
import __Layout from './Layout.jsx';


export const PAGES = {
    "Dashboard": Dashboard,
    "Assessments": Assessments,
    "DataUpload": DataUpload,
    "AssessmentDashboard": AssessmentDashboard,
    "CreateAssessmentWizard": CreateAssessmentWizard,
    "Home": Home,
    "InitialDataLoader": InitialDataLoader,
    "PublicAssessmentView": PublicAssessmentView,
    "DataManagement": DataManagement,
    "TestSimple": TestSimple,
    "PresentationBuilder": PresentationBuilder,
    "PublicPortfolio": PublicPortfolio,
    "UserProfile": UserProfile,
    "CompetitorAnalysis": CompetitorAnalysis,
    "RegionalAnalysis": RegionalAnalysis,
    "AIChat": AIChat,
    "About": About,
    "Pricing": Pricing,
    "Support": Support,
    "Features": Features,
    "FqhcAssessment": FqhcAssessment,
}

export const pagesConfig = {
    mainPage: "Home",
    Pages: PAGES,
    Layout: __Layout,
};