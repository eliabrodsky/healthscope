import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Sparkles, Send, Loader2, MessageSquare, Paperclip, X, Map as MapIcon, Save, Pin, Trash2, History } from "lucide-react";
import { toast } from "sonner";
import ReactMarkdown from "react-markdown";
import ChatMapViewer from "../components/chat/ChatMapViewer";
import GooglePlacesEnricher from "../components/data/GooglePlacesEnricher";
import GooglePlacesWarningDialog from "../components/data/GooglePlacesWarningDialog";

export default function AIChat() {
  const [assessments, setAssessments] = useState([]);
  const [selectedAssessment, setSelectedAssessment] = useState(null);
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingAssessments, setIsLoadingAssessments] = useState(true);
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [isUploading, setIsUploading] = useState(false);
  const [savedChats, setSavedChats] = useState([]);
  const [currentChatId, setCurrentChatId] = useState(null);
  const [showSavedChats, setShowSavedChats] = useState(false);
  const messagesEndRef = useRef(null);
  const fileInputRef = useRef(null);
  const [showPlacesEnricher, setShowPlacesEnricher] = useState(false);
  const [showPlacesWarning, setShowPlacesWarning] = useState(false);

  useEffect(() => {
    loadAssessments();
    loadSavedChats();
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const loadAssessments = async () => {
    try {
      const data = await base44.entities.Assessment.filter({
        status: { $in: ['published', 'building'] }
      }, '-created_date', 50);
      setAssessments(data || []);
    } catch (error) {
      console.error('Error loading assessments:', error);
      toast.error('Failed to load assessments');
    } finally {
      setIsLoadingAssessments(false);
    }
  };

  const loadSavedChats = async () => {
    try {
      const chats = await base44.entities.ChatConversation.list('-last_message_at', 50);
      setSavedChats(chats || []);
    } catch (error) {
      console.error('Error loading saved chats:', error);
    }
  };

  const saveCurrentChat = async () => {
    if (!selectedAssessment || messages.length <= 1) {
      toast.error('No conversation to save');
      return;
    }

    try {
      const chatData = {
        title: `Chat - ${selectedAssessment.title} - ${new Date().toLocaleDateString()}`,
        assessment_id: selectedAssessment.id,
        assessment_title: selectedAssessment.title,
        messages: messages.map(m => ({
          role: m.role,
          content: m.content,
          timestamp: new Date().toISOString()
        })),
        last_message_at: new Date().toISOString()
      };

      if (currentChatId) {
        await base44.entities.ChatConversation.update(currentChatId, chatData);
        toast.success('Chat updated!');
      } else {
        const saved = await base44.entities.ChatConversation.create(chatData);
        setCurrentChatId(saved.id);
        toast.success('Chat saved!');
      }
      await loadSavedChats();
    } catch (error) {
      console.error('Error saving chat:', error);
      toast.error('Failed to save chat');
    }
  };

  const togglePinChat = async (chatId) => {
    try {
      const chat = savedChats.find(c => c.id === chatId);
      await base44.entities.ChatConversation.update(chatId, { is_pinned: !chat.is_pinned });
      await loadSavedChats();
      toast.success(chat.is_pinned ? 'Unpinned' : 'Pinned!');
    } catch (error) {
      toast.error('Failed to update');
    }
  };

  const deleteChat = async (chatId) => {
    if (!confirm('Delete this chat?')) return;
    try {
      await base44.entities.ChatConversation.delete(chatId);
      if (currentChatId === chatId) {
        setCurrentChatId(null);
      }
      await loadSavedChats();
      toast.success('Chat deleted');
    } catch (error) {
      toast.error('Failed to delete');
    }
  };

  const loadChat = (chat) => {
    const assessment = assessments.find(a => a.id === chat.assessment_id);
    if (assessment) {
      setSelectedAssessment(assessment);
      setMessages(chat.messages || []);
      setCurrentChatId(chat.id);
      setShowSavedChats(false);
    } else {
      toast.error('Assessment not found');
    }
  };

  const [activeMap, setActiveMap] = useState(null);

  const suggestedQuestions = [
    "What are the key health needs in this region?",
    "Summarize the demographic trends",
    "Which areas have the highest uninsured rates?",
    "Show me top FQHCs and their service areas",
    "Show me a map of competitors in this area",
    "What FQHC workforce data is available?",
    "Compare clinical quality measures for FQHCs",
    "Search for schools and non-profits nearby"
  ];

  const handleSelectAssessment = (assessmentId) => {
    const assessment = assessments.find(a => a.id === assessmentId);
    setSelectedAssessment(assessment);
    setCurrentChatId(null);
    setMessages([{
      role: 'assistant',
      content: `Hello! I'm your AI assistant for the "${assessment.title}" assessment. I have access to all the data and insights from this assessment. What would you like to know?`
    }]);
    setUploadedFiles([]);
    setActiveMap(null);
  };

  const handleFileUpload = async (event) => {
    const files = Array.from(event.target.files);
    if (files.length === 0) return;

    setIsUploading(true);
    try {
      const uploadPromises = files.map(async (file) => {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        return { name: file.name, url: file_url };
      });
      
      const uploadedFileData = await Promise.all(uploadPromises);
      setUploadedFiles(prev => [...prev, ...uploadedFileData]);
      toast.success(`${files.length} file(s) uploaded successfully`);
    } catch (error) {
      console.error('Error uploading files:', error);
      toast.error('Failed to upload files');
    } finally {
      setIsUploading(false);
    }
  };

  const removeFile = (index) => {
    setUploadedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleSuggestedQuestion = (question) => {
    setInputMessage(question);
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim() || !selectedAssessment) return;

    const userMessage = inputMessage.trim();
    setInputMessage("");
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setIsLoading(true);

    // Add loading status message
    const loadingMessageId = Date.now();
    setMessages(prev => [...prev, { 
      role: 'assistant', 
      content: '🔍 Analyzing assessment data...', 
      isLoading: true,
      id: loadingMessageId 
    }]);

    try {
      // Check if this is a map request
      const mapKeywords = ['map', 'show me', 'visualize', 'display on map', 'plot'];
      const isMapRequest = mapKeywords.some(keyword => userMessage.toLowerCase().includes(keyword));

      if (isMapRequest) {
        // Handle map generation
        setMessages(prev => prev.map(msg => 
          msg.id === loadingMessageId 
            ? { ...msg, content: '🗺️ Generating map...' }
            : msg
        ));

        try {
          const mapResponse = await base44.functions.invoke('chatGenerateMap', {
            prompt: userMessage,
            assessmentId: selectedAssessment.id
          });

          if (mapResponse.data?.success) {
            setActiveMap(mapResponse.data.mapData);
            setMessages(prev => prev.filter(msg => msg.id !== loadingMessageId));
            setMessages(prev => [...prev, { 
              role: 'assistant', 
              content: `Here's your map: **${mapResponse.data.mapData.title}**\n\nI've generated an interactive map based on your request. You can see ${mapResponse.data.mapData.markers?.length || 0} locations plotted.`,
              hasMap: true
            }]);
            setIsLoading(false);
            return;
          }
        } catch (mapError) {
          console.error('Map generation failed, falling back to text response:', mapError);
        }
      }

      // Build comprehensive assessment context
      const censusData = selectedAssessment.processed_data?.census_data || {};
      const zipCodes = selectedAssessment.geography?.zcta_codes || selectedAssessment.geography?.zip_codes || [];
      const orgs = selectedAssessment.organizations || [];
      
      // Calculate summary stats
      const totalPop = Object.values(censusData).reduce((sum, d) => sum + (d.population || 0), 0);
      const avgIncome = Object.values(censusData).reduce((sum, d) => sum + (d.medianIncome || 0), 0) / Math.max(Object.keys(censusData).length, 1);
      const avgPoverty = Object.values(censusData).reduce((sum, d) => sum + (d.povertyRate || 0), 0) / Math.max(Object.keys(censusData).length, 1);
      const avgUninsured = Object.values(censusData).reduce((sum, d) => sum + (d.uninsuredRate || 0), 0) / Math.max(Object.keys(censusData).length, 1);

      // Update loading status
      setMessages(prev => prev.map(msg => 
        msg.id === loadingMessageId 
          ? { ...msg, content: '📊 Processing demographic data...' }
          : msg
      ));

      await new Promise(resolve => setTimeout(resolve, 500));

      const assessmentContext = `
Assessment: ${selectedAssessment.title}
Description: ${selectedAssessment.description || 'N/A'}

Geography:
- Location: ${selectedAssessment.geography?.city || 'N/A'}, ${selectedAssessment.geography?.state || 'N/A'}
- ZIP Codes: ${zipCodes.length} ZCTAs
- County: ${selectedAssessment.geography?.county || 'N/A'}

Demographics Summary:
- Total Population: ${totalPop.toLocaleString()}
- Average Median Income: $${Math.round(avgIncome).toLocaleString()}
- Average Poverty Rate: ${avgPoverty.toFixed(1)}%
- Average Uninsured Rate: ${avgUninsured.toFixed(1)}%

Healthcare Providers:
- Total Organizations: ${orgs.length}
- FQHCs: ${orgs.filter(o => o.type === 'fqhc').length}
- Hospitals: ${orgs.filter(o => o.type === 'hospital').length}
- Clinics: ${orgs.filter(o => o.type === 'clinic').length}

Data Sources: ${selectedAssessment.data_sources?.join(', ') || 'N/A'}
      `.trim();

      // Update loading status
      setMessages(prev => prev.map(msg => 
        msg.id === loadingMessageId 
          ? { ...msg, content: '🤖 Generating insights...' }
          : msg
      ));

      const fileUrls = uploadedFiles.length > 0 ? uploadedFiles.map(f => f.url) : undefined;
      
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an AI assistant helping analyze a community health needs assessment. Here is the assessment data:

${assessmentContext}

User question: ${userMessage}

Available Data Sources:
- FQHC API: Complete UDS data for all US FQHCs (2022-2024) including:
  * Grantee info (name, address, BHCMIS ID, grant number)
  * All clinic sites with hours and location types
  * Service area by ZIP code (patients by payer type per ZIP)
  * Patient demographics (age, race, ethnicity, special populations)
  * Workforce FTEs (physicians, NPs, dental, behavioral health)
  * Clinical quality measures (HTN control, diabetes, screenings)
  * Financials (revenue by source, expenses, cost per patient)
- CMS Medicare: Hospital discharge and payment data
- Census ACS: Demographics, income, poverty, insurance by ZCTA

Instructions:
1. Provide a helpful, specific answer based on the assessment data above
2. Use data from the context to support your answer with specific numbers
3. Be concise but informative
4. If the question is about FQHCs, mention you can pull detailed data including service area by ZIP, workforce, clinical quality, and financials
5. If user wants a map, tell them to try phrases like "show me a map of..." or "map of competitors"
6. For FQHC-specific questions, mention available data: patients by ZIP, payer mix, demographics, workforce FTEs, clinical measures, revenue

After your answer, recommend ONE relevant visual from these options (in JSON format at the end):
{
  "visual": "demographic_bar_chart" | "provider_pie_chart" | "zip_map" | "poverty_map" | "competitor_map" | "fqhc_service_area" | "none",
  "reason": "brief explanation why this visual helps"
}`,
        add_context_from_internet: false,
        file_urls: fileUrls
      });

      // Remove loading message and add actual response
      setMessages(prev => prev.filter(msg => msg.id !== loadingMessageId));

      // Try to extract visual recommendation
      let visualRecommendation = null;
      let cleanResponse = response;
      try {
        const jsonMatch = response.match(/\{[\s\S]*"visual"[\s\S]*\}/);
        if (jsonMatch) {
          visualRecommendation = JSON.parse(jsonMatch[0]);
          cleanResponse = response.replace(jsonMatch[0], '').trim();
        }
      } catch (e) {
        // No visual recommendation found
      }

      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: cleanResponse,
        visual: visualRecommendation 
      }]);
    } catch (error) {
      console.error('Error sending message:', error);
      toast.error('Failed to get AI response');
      setMessages(prev => prev.filter(msg => msg.id !== loadingMessageId));
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: 'Sorry, I encountered an error. Please try again.' 
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <div className="bg-white rounded-xl p-6 border-2 border-emerald-500 shadow-sm">
          <div className="flex items-start gap-4">
            <div className="flex-shrink-0">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/a5cc7faf7_ai-icon.png"
                alt="AI Chat"
                className="w-16 h-16"
              />
            </div>
            <div className="flex-1">
              <h1 className="text-3xl font-bold mb-2 text-gray-900">AI Assessment Chat</h1>
              <p className="text-gray-600 text-sm leading-relaxed">
                Ask questions about your community health assessments. Access complete FQHC data (patients, sites, 
                demographics, workforce, clinical quality, financials), competitor analysis, and demographic insights.
              </p>
            </div>
          </div>
        </div>

        {/* Assessment Selector and Saved Chats */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <Card className="lg:col-span-2">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Select Assessment</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoadingAssessments ? (
                <div className="flex items-center justify-center py-4">
                  <Loader2 className="w-6 h-6 animate-spin text-emerald-600" />
                </div>
              ) : (
                <Select onValueChange={handleSelectAssessment} value={selectedAssessment?.id}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose an assessment to chat about..." />
                  </SelectTrigger>
                  <SelectContent>
                    {assessments.map(assessment => (
                      <SelectItem key={assessment.id} value={assessment.id}>
                        {assessment.title}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base flex items-center gap-2">
                  <History className="w-4 h-4" />
                  Saved Chats
                </CardTitle>
                <Button variant="ghost" size="sm" onClick={() => setShowSavedChats(!showSavedChats)}>
                  {showSavedChats ? 'Hide' : 'Show'}
                </Button>
              </div>
            </CardHeader>
            {showSavedChats && (
              <CardContent className="pt-0">
                {savedChats.length === 0 ? (
                  <p className="text-sm text-gray-500">No saved chats</p>
                ) : (
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {savedChats
                      .sort((a, b) => (b.is_pinned ? 1 : 0) - (a.is_pinned ? 1 : 0))
                      .slice(0, 10)
                      .map(chat => (
                        <div 
                          key={chat.id} 
                          className={`p-2 rounded-lg border text-sm cursor-pointer hover:bg-gray-50 ${
                            chat.is_pinned ? 'border-emerald-300 bg-emerald-50' : 'border-gray-200'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex-1 truncate" onClick={() => loadChat(chat)}>
                              {chat.is_pinned && <Pin className="w-3 h-3 inline mr-1 text-emerald-600" />}
                              <span className="font-medium">{chat.assessment_title}</span>
                            </div>
                            <div className="flex gap-1">
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-6 w-6"
                                onClick={(e) => { e.stopPropagation(); togglePinChat(chat.id); }}
                              >
                                <Pin className={`w-3 h-3 ${chat.is_pinned ? 'text-emerald-600' : 'text-gray-400'}`} />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-6 w-6"
                                onClick={(e) => { e.stopPropagation(); deleteChat(chat.id); }}
                              >
                                <Trash2 className="w-3 h-3 text-gray-400" />
                              </Button>
                            </div>
                          </div>
                          <p className="text-xs text-gray-500 truncate">{chat.messages?.length || 0} messages</p>
                        </div>
                      ))}
                  </div>
                )}
              </CardContent>
            )}
          </Card>
        </div>

        {/* Chat Area */}
        {selectedAssessment ? (
          <Card className="h-[600px] flex flex-col">
            <CardHeader className="border-b">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <MessageSquare className="w-5 h-5" />
                  Chat: {selectedAssessment.title}
                </CardTitle>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={saveCurrentChat}
                  disabled={messages.length <= 1}
                  className="gap-1"
                >
                  <Save className="w-4 h-4" />
                  {currentChatId ? 'Update' : 'Save'}
                </Button>
              </div>
            </CardHeader>
            <CardContent className="flex-1 overflow-y-auto p-6 space-y-4">
              {messages.map((message, index) => (
                <div
                  key={index}
                  className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[80%] rounded-lg px-4 py-3 ${
                      message.role === 'user'
                        ? 'bg-emerald-600 text-white'
                        : message.isLoading 
                        ? 'bg-blue-50 border border-blue-200 text-blue-700'
                        : 'bg-gray-100 text-gray-900'
                    }`}
                  >
                    {message.role === 'user' ? (
                      <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                    ) : message.isLoading ? (
                      <div className="flex items-center gap-2">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <p className="text-sm">{message.content}</p>
                      </div>
                    ) : (
                      <div>
                        <ReactMarkdown 
                          className="text-sm prose prose-sm max-w-none [&>*:first-child]:mt-0 [&>*:last-child]:mb-0 [&_strong]:font-semibold [&_ul]:list-disc [&_ul]:ml-4 [&_ol]:list-decimal [&_ol]:ml-4 [&_li]:my-1"
                        >
                          {message.content}
                        </ReactMarkdown>
                        {message.visual && message.visual.visual !== 'none' && (
                          <div className="mt-4 pt-3 border-t border-gray-300">
                            <div className="bg-gradient-to-r from-emerald-50 to-blue-50 p-4 rounded-lg border border-emerald-200">
                              <p className="text-xs font-semibold text-gray-700 mb-2">📊 Recommended Visual:</p>
                              <p className="text-xs text-gray-600 mb-3">{message.visual.reason}</p>
                              {message.visual.visual.includes('map') ? (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => setInputMessage(`Show me a ${message.visual.visual.replace(/_/g, ' ')}`)}
                                  className="text-xs"
                                >
                                  <MapIcon className="w-3 h-3 mr-1" />
                                  Generate this map
                                </Button>
                              ) : (
                                <div className="flex items-center gap-2 text-xs text-emerald-700 font-medium">
                                  <Sparkles className="w-3 h-3" />
                                  <span>View "{message.visual.visual.replace(/_/g, ' ')}" in the Assessment Dashboard</span>
                                </div>
                              )}
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              ))}
              
              {/* Active Map Display */}
              {activeMap && (
                <ChatMapViewer 
                  mapData={activeMap} 
                  onClose={() => setActiveMap(null)} 
                />
              )}
              
              {/* Google Places Enricher in Chat */}
              {showPlacesEnricher && selectedAssessment && (
                <div className="bg-gray-50 rounded-lg p-4 border">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-semibold text-gray-900">Google Places Search</h4>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowPlacesEnricher(false)}
                    >
                      Close
                    </Button>
                  </div>
                  <GooglePlacesEnricher
                    latitude={selectedAssessment.geography?.latitude}
                    longitude={selectedAssessment.geography?.longitude}
                    onResultsFound={(results) => {
                      setMessages(prev => [...prev, {
                        role: 'assistant',
                        content: `Found ${results.length} places from Google Places API:\n\n${results.slice(0, 5).map(r => `• **${r.name}** - ${r.address}`).join('\n')}${results.length > 5 ? `\n\n...and ${results.length - 5} more` : ''}`
                      }]);
                    }}
                    onEnrichComplete={(enrichedPlaces) => {
                      setMessages(prev => [...prev, {
                        role: 'assistant',
                        content: `Enriched ${enrichedPlaces.length} places with detailed information (phone, website, hours).`
                      }]);
                    }}
                  />
                </div>
              )}
              
              <GooglePlacesWarningDialog
                open={showPlacesWarning}
                onOpenChange={setShowPlacesWarning}
                onConfirm={() => {
                  setShowPlacesWarning(false);
                  setShowPlacesEnricher(true);
                }}
              />

              {messages.length === 1 && (
                <div className="space-y-3 mt-6">
                  <p className="text-sm text-gray-600 font-medium">Suggested questions:</p>
                  <div className="grid gap-2">
                    {suggestedQuestions.map((question, index) => (
                      <button
                        key={index}
                        onClick={() => {
                          if (question.toLowerCase().includes('schools') || question.toLowerCase().includes('non-profits')) {
                            setShowPlacesWarning(true);
                          } else {
                            handleSuggestedQuestion(question);
                          }
                        }}
                        className={`text-left text-sm text-gray-700 bg-gray-50 hover:bg-gray-100 border border-gray-200 rounded-lg px-4 py-3 transition-colors ${
                          question.toLowerCase().includes('map') ? 'border-emerald-200 bg-emerald-50' : 
                          question.toLowerCase().includes('schools') ? 'border-amber-200 bg-amber-50' : ''
                        }`}
                      >
                        {question.toLowerCase().includes('map') && <MapIcon className="w-4 h-4 inline mr-2 text-emerald-600" />}
                        {question.toLowerCase().includes('schools') && <span className="text-amber-600 mr-2">🔍</span>}
                        {question}
                        {question.toLowerCase().includes('schools') && (
                          <span className="ml-2 text-xs text-amber-600">(5 tokens)</span>
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </CardContent>
            <div className="border-t p-4">
              {uploadedFiles.length > 0 && (
                <div className="mb-3 flex flex-wrap gap-2">
                  {uploadedFiles.map((file, index) => (
                    <div key={index} className="flex items-center gap-2 bg-gray-100 rounded-lg px-3 py-2 text-sm">
                      <Paperclip className="w-4 h-4 text-gray-600" />
                      <span className="text-gray-700">{file.name}</span>
                      <button
                        onClick={() => removeFile(index)}
                        className="text-gray-500 hover:text-gray-700"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
              <div className="flex gap-2">
                <input
                  ref={fileInputRef}
                  type="file"
                  multiple
                  onChange={handleFileUpload}
                  className="hidden"
                  accept=".pdf,.png,.jpg,.jpeg,.csv,.xlsx"
                />
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isUploading}
                  className="flex-shrink-0"
                >
                  {isUploading ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Paperclip className="w-4 h-4" />
                  )}
                </Button>
                <Input
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Ask a question about this assessment..."
                  disabled={isLoading}
                  className="flex-1"
                />
                <Button
                  onClick={handleSendMessage}
                  disabled={isLoading || !inputMessage.trim()}
                  className="bg-emerald-600 hover:bg-emerald-700"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </Card>
        ) : (
          <Card>
            <CardContent className="py-12 text-center">
              <MessageSquare className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">Select an assessment to start chatting</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}