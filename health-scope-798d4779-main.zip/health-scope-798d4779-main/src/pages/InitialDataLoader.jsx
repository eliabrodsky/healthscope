import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { toast } from 'sonner';
import { Loader2, Database, CheckCircle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import {
    Table,
    TableBody,
    TableHead,
    TableHeader,
    TableRow,
    TableCell
} from "@/components/ui/table";

const statesToLoad = [
    { name: "Alabama", abbr: "AL" }, { name: "Alaska", abbr: "AK" }, { name: "Arizona", abbr: "AZ" }, { name: "Arkansas", abbr: "AR" },
    { name: "California", abbr: "CA" }, { name: "Colorado", abbr: "CO" }, { name: "Connecticut", abbr: "CT" }, { name: "Delaware", abbr: "DE" },
    { name: "Florida", abbr: "FL" }, { name: "Georgia", abbr: "GA" }, { name: "Hawaii", abbr: "HI" }, { name: "Idaho", abbr: "ID" },
    { name: "Illinois", abbr: "IL" }, { name: "Indiana", abbr: "IN" }, { name: "Iowa", abbr: "IA" }, { name: "Kansas", abbr: "KS" },
    { name: "Kentucky", abbr: "KY" }, { name: "Louisiana", abbr: "LA" }, { name: "Maine", abbr: "ME" }, { name: "Maryland", abbr: "MD" },
    { name: "Massachusetts", abbr: "MA" }, { name: "Michigan", abbr: "MI" }, { name: "Minnesota", abbr: "MN" }, { name: "Mississippi", abbr: "MS" },
    { name: "Missouri", abbr: "MO" }, { name: "Montana", abbr: "MT" }, { name: "Nebraska", abbr: "NE" }, { name: "Nevada", abbr: "NV" },
    { name: "New Hampshire", abbr: "NH" }, { name: "New Jersey", abbr: "NJ" }, { name: "New Mexico", abbr: "NM" }, { name: "New York", abbr: "NY" },
    { name: "North Carolina", abbr: "NC" }, { name: "North Dakota", abbr: "ND" }, { name: "Ohio", abbr: "OH" }, { name: "Oklahoma", abbr: "OK" },
    { name: "Oregon", abbr: "OR" }, { name: "Pennsylvania", abbr: "PA" }, { name: "Rhode Island", abbr: "RI" }, { name: "South Carolina", abbr: "SC" },
    { name: "South Dakota", abbr: "SD" }, { name: "Tennessee", abbr: "TN" }, { name: "Texas", abbr: "TX" }, { name: "Utah", abbr: "UT" },
    { name: "Vermont", abbr: "VT" }, { name: "Virginia", abbr: "VA" }, { name: "Washington", abbr: "WA" }, { name: "West Virginia", abbr: "WV" },
    { name: "Wisconsin", abbr: "WI" }, { name: "Wyoming", abbr: "WY" }, { name: "District of Columbia", abbr: "DC" }
];

const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

function StateRow({ state, status, loading, onLoadData, onUploadCsv, uploading }) {
    const fileInputRef = useRef(null);
    const stateStatus = status[state.abbr];
    const isComplete = stateStatus?.boundariesLoaded && stateStatus?.demographicsLoaded;
    const isLoadingThis = loading[state.abbr];
    const isUploadingThis = uploading === state.abbr;
    const totalPopulation = stateStatus?.totalPopulation || 0;

    return (
        <TableRow className={isLoadingThis ? "bg-blue-50" : ""}>
            <TableCell className="font-medium">
                <div>
                    <div className="font-semibold">{state.name}</div>
                    {totalPopulation > 0 && (
                        <div className="text-xs text-gray-500">
                            Pop: {totalPopulation.toLocaleString()}
                        </div>
                    )}
                </div>
            </TableCell>
            <TableCell>
                {isComplete ? (
                    <Badge className="bg-green-100 text-green-800">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Complete
                    </Badge>
                ) : stateStatus?.boundariesLoaded ? (
                    <Badge variant="outline" className="text-amber-700 border-amber-300">
                        Boundaries Only
                    </Badge>
                ) : (
                    <Badge variant="outline" className="text-gray-500">
                        Not Loaded
                    </Badge>
                )}
                {stateStatus?.boundaryCount > 0 && (
                    <div className="text-xs text-gray-500 mt-1">
                        {stateStatus.boundaryCount} ZCTAs
                    </div>
                )}
            </TableCell>
            <TableCell>
                <input
                    ref={fileInputRef}
                    type="file"
                    accept=".csv,.txt"
                    onChange={(e) => {
                        if (e.target.files?.[0]) {
                            onUploadCsv(state, e.target.files[0]);
                            fileInputRef.current.value = '';
                        }
                    }}
                    disabled={isUploadingThis}
                    className="text-xs w-full file:mr-2 file:py-1 file:px-2 file:rounded file:border-0 file:text-xs file:bg-emerald-100 file:text-emerald-700 hover:file:bg-emerald-200 disabled:opacity-50"
                />
            </TableCell>
            <TableCell>
                <Button
                    onClick={() => onLoadData(state)}
                    disabled={isLoadingThis || isUploadingThis}
                    size="sm"
                    className="bg-emerald-600 hover:bg-emerald-700"
                >
                    {isLoadingThis ? (
                        <>
                            <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                            Loading...
                        </>
                    ) : (
                        'Load Data'
                    )}
                </Button>
            </TableCell>
        </TableRow>
    );
}

export default function InitialDataLoader() {
    const [loading, setLoading] = useState({});
    const [status, setStatus] = useState({});
    const [selectedLetter, setSelectedLetter] = useState('A');
    const [uploadingCsv, setUploadingCsv] = useState(null);

    const loadStatus = async () => {
        try {
            const statusRecords = await base44.entities.StateDataStatus.list();
            const allDemographics = await base44.entities.ZipDemographics.list();
            
            const statusMap = {};
            
            for (const record of statusRecords) {
                const stateDemographics = allDemographics.filter(d => d.state_abbr === record.state_abbr);
                const totalPopulation = stateDemographics.reduce((sum, d) => sum + (d.population || 0), 0);
                
                statusMap[record.state_abbr] = {
                    boundariesLoaded: record.boundaries_complete || false,
                    demographicsLoaded: record.demographics_complete || false,
                    boundaryCount: record.boundary_count || 0,
                    demographicsCount: record.demographics_count || 0,
                    totalPopulation: totalPopulation,
                    isLoading: record.loading_status !== 'idle'
                };
            }
            
            setStatus(statusMap);
        } catch (error) {
            console.error("Error loading status:", error);
        }
    };

    useEffect(() => {
        loadStatus();
    }, []);

    useEffect(() => {
        if (Object.keys(loading).length === 0) return;
        
        const interval = setInterval(() => {
            loadStatus();
        }, 3000);

        return () => clearInterval(interval);
    }, [loading]);

    const loadStateData = async (state) => {
        setLoading(prev => ({ ...prev, [state.abbr]: true }));
        const toastId = `loading-${state.abbr}`;
        
        const stateStatus = status[state.abbr];
        const hasBoundaries = stateStatus?.boundariesLoaded || false;
        const hasDemographics = stateStatus?.demographicsLoaded || false;

        let boundariesJustLoaded = false;

        try {
            // Load boundaries only if not already loaded
            if (!hasBoundaries) {
                toast.loading(`Loading boundaries for ${state.name}... (this may take 1-2 minutes for large states)`, { id: toastId });
                
                try {
                    const boundaryResponse = await base44.functions.invoke('loadStateBoundaries', {
                        stateAbbr: state.abbr,
                        stateName: state.name
                    });

                    if (!boundaryResponse?.data?.success) {
                        throw new Error(boundaryResponse?.data?.error || 'Boundary loading failed');
                    }
                    boundariesJustLoaded = true;
                    
                    // Wait for database to commit and refresh status
                    await new Promise(resolve => setTimeout(resolve, 2000));
                    await loadStatus();
                } catch (boundaryError) {
                    // If 502 or timeout, show helpful message
                    if (boundaryError.message?.includes('502') || boundaryError.message?.includes('timeout')) {
                        throw new Error(`${state.name} boundary data is very large. Try loading it again, or the process may be continuing in the background. Check status after 2-3 minutes.`);
                    }
                    throw boundaryError;
                }
            }

            // Load demographics only if not already loaded
            if (!hasDemographics) {
                // Only proceed if boundaries were already loaded or just loaded successfully
                if (!hasBoundaries && !boundariesJustLoaded) {
                    throw new Error('Boundaries must be loaded first. Please refresh and try again.');
                }

                toast.loading(`Loading demographics for ${state.name}...`, { id: toastId });
                
                try {
                    const demoResponse = await base44.functions.invoke('loadDemographicsSimple', {
                        stateAbbr: state.abbr,
                        stateName: state.name
                    });

                    if (!demoResponse?.data?.success) {
                        throw new Error(demoResponse?.data?.error || 'Demographics loading failed');
                    }
                } catch (demoError) {
                    // Handle 409 specifically - boundaries not ready yet
                    if (demoError.response?.status === 409 || demoError.message?.includes('409')) {
                        console.log(`${state.name} boundaries not ready, will complete demographics separately`);
                        toast.warning(`${state.name} boundaries loaded. Demographics will need to be loaded separately - click "Load Data" again in 1 minute.`, { 
                            id: toastId, 
                            duration: 8000 
                        });
                        return; // Exit gracefully, don't throw error
                    }
                    throw demoError;
                }
            }

            if (!hasBoundaries && !hasDemographics) {
                toast.success(`${state.name} loaded successfully!`, { id: toastId, duration: 5000 });
            } else if (!hasDemographics) {
                toast.success(`Demographics loaded for ${state.name}!`, { id: toastId, duration: 5000 });
            } else if (!hasBoundaries) {
                toast.success(`Boundaries loaded for ${state.name}!`, { id: toastId, duration: 5000 });
            } else {
                toast.info(`${state.name} already has all data loaded`, { id: toastId, duration: 3000 });
            }

            // Trigger state summary precomputation after successful load
            if (!hasBoundaries || !hasDemographics) {
                base44.functions.invoke('precomputeStateSummary', { 
                    state_abbr: state.abbr 
                }).catch(err => console.error('Failed to precompute state summary:', err));
            }

            setTimeout(() => loadStatus(), 2000);
        } catch (error) {
            console.error(`Error loading ${state.name}:`, error);
            toast.error(`Error loading ${state.name}: ${error.message}`, { id: toastId, duration: 10000 });
        } finally {
            setLoading(prev => {
                const newLoading = { ...prev };
                delete newLoading[state.abbr];
                return newLoading;
            });
        }
    };

    const handleCsvUpload = async (state, file) => {
        if (!file) return;

        setUploadingCsv(state.abbr);
        const toastId = `csv-upload-${state.abbr}`;
        toast.loading(`Uploading CSV for ${state.name}...`, { id: toastId });

        try {
            const csvText = await file.text();
            
            const response = await base44.functions.invoke('loadZctaCrosswalk', {
                csvText: csvText,
                stateAbbr: state.abbr
            });

            if (response?.data?.success) {
                toast.success(response.data.message, { id: toastId, duration: 5000 });
                setTimeout(() => loadStatus(), 1000);
            } else {
                throw new Error(response?.data?.error || 'Upload failed');
            }
        } catch (error) {
            console.error('CSV upload error:', error);
            toast.error(`Upload failed: ${error.message}`, { id: toastId, duration: 8000 });
        } finally {
            setUploadingCsv(null);
        }
    };

    const filteredStates = statesToLoad.filter(state => 
        state.name.toUpperCase().startsWith(selectedLetter)
    );

    return (
        <div className="min-h-screen bg-gray-50 p-6">
            <div className="max-w-7xl mx-auto space-y-6">
                {/* Header */}
                <div className="bg-white rounded-xl p-6 border-2 border-emerald-500 shadow-sm">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0">
                      <img 
                        src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/53b543203_loaddata.png"
                        alt="Data Loader"
                        className="w-20 h-20"
                      />
                    </div>
                    <div className="flex-1">
                      <h1 className="text-3xl font-bold mb-2 text-gray-900">State Data Loader</h1>
                      <p className="text-gray-600 text-sm leading-relaxed">
                        Load boundaries and demographics, or upload population CSV
                      </p>
                    </div>
                  </div>
                </div>

                <Card>
                    <CardHeader>
                        <div className="flex items-center justify-between">
                            <div>
                                <CardTitle className="flex items-center gap-2">
                                    <Database className="w-6 h-6" />
                                    State-by-State Loading
                                </CardTitle>
                                <CardDescription>
                                    Select a state below to load its data
                                </CardDescription>
                            </div>
                            <Button onClick={loadStatus} variant="outline" size="sm">
                                Refresh
                            </Button>
                        </div>
                    </CardHeader>
                    <CardContent>
                        <div className="mb-6 flex flex-wrap gap-2">
                            {alphabet.map(letter => {
                                const count = statesToLoad.filter(s => s.name.toUpperCase().startsWith(letter)).length;
                                return (
                                    <Button
                                        key={letter}
                                        onClick={() => setSelectedLetter(letter)}
                                        variant={selectedLetter === letter ? "default" : "outline"}
                                        size="sm"
                                        disabled={count === 0}
                                        className={selectedLetter === letter ? "bg-emerald-600 hover:bg-emerald-700" : ""}
                                    >
                                        {letter} {count > 0 && `(${count})`}
                                    </Button>
                                );
                            })}
                        </div>

                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>State</TableHead>
                                    <TableHead>Status</TableHead>
                                    <TableHead>Upload CSV</TableHead>
                                    <TableHead>Actions</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {filteredStates.map((state) => (
                                    <StateRow
                                        key={state.abbr}
                                        state={state}
                                        status={status}
                                        loading={loading}
                                        uploading={uploadingCsv}
                                        onLoadData={loadStateData}
                                        onUploadCsv={handleCsvUpload}
                                    />
                                ))}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}