import React from "react";

export default function TestSimple() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">✅ App is Working!</h1>
        <p className="text-gray-600">If you can see this, the app is loading correctly.</p>
      </div>
    </div>
  );
}