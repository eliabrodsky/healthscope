import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Lightbulb, 
  ThumbsUp, 
  Send, 
  TrendingUp,
  CheckCircle,
  Clock,
  XCircle,
  Loader2,
  Sparkles,
  Upload
} from "lucide-react";
import { toast } from "sonner";

export default function Features() {
  const [requests, setRequests] = useState([]);
  const [filteredRequests, setFilteredRequests] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [user, setUser] = useState(null);
  const [formData, setFormData] = useState({
    title: "",
    category: "new_feature",
    description: ""
  });

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    let filtered = requests;

    if (categoryFilter !== "all") {
      filtered = filtered.filter(r => r.category === categoryFilter);
    }

    if (statusFilter !== "all") {
      filtered = filtered.filter(r => r.status === statusFilter);
    }

    setFilteredRequests(filtered);
  }, [requests, categoryFilter, statusFilter]);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [currentUser, requestsData] = await Promise.all([
        base44.auth.me(),
        base44.entities.FeatureRequest.list('-upvotes', 100)
      ]);
      setUser(currentUser);
      setRequests(requestsData || []);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      await base44.entities.FeatureRequest.create({
        ...formData,
        upvoted_by: [user.email]
      });
      toast.success('Feature request submitted! Thank you for helping improve HealthScope.');
      setFormData({
        title: "",
        category: "new_feature",
        description: ""
      });
      loadData();
    } catch (error) {
      console.error('Error submitting request:', error);
      toast.error('Failed to submit feature request');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUpvote = async (request) => {
    if (!user) return;

    const hasUpvoted = request.upvoted_by?.includes(user.email);
    
    try {
      const newUpvotedBy = hasUpvoted
        ? request.upvoted_by.filter(email => email !== user.email)
        : [...(request.upvoted_by || []), user.email];

      await base44.entities.FeatureRequest.update(request.id, {
        upvotes: newUpvotedBy.length,
        upvoted_by: newUpvotedBy
      });
      
      loadData();
    } catch (error) {
      console.error('Error upvoting:', error);
      toast.error('Failed to upvote');
    }
  };

  const getStatusIcon = (status) => {
    const icons = {
      under_review: <Clock className="w-4 h-4" />,
      planned: <Sparkles className="w-4 h-4" />,
      in_progress: <TrendingUp className="w-4 h-4" />,
      shipped: <CheckCircle className="w-4 h-4" />,
      declined: <XCircle className="w-4 h-4" />
    };
    return icons[status];
  };

  const getStatusColor = (status) => {
    const colors = {
      under_review: "bg-gray-50 text-gray-700 border-gray-200",
      planned: "bg-purple-50 text-purple-700 border-purple-200",
      in_progress: "bg-blue-50 text-blue-700 border-blue-200",
      shipped: "bg-green-50 text-green-700 border-green-200",
      declined: "bg-red-50 text-red-700 border-red-200"
    };
    return colors[status];
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-purple-50 to-blue-50 p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div className="bg-white rounded-xl p-6 border-2 border-emerald-500 shadow-sm">
          <div className="flex items-start gap-4">
            <div className="w-16 h-16 bg-emerald-100 rounded-2xl flex items-center justify-center">
              <Lightbulb className="w-8 h-8 text-emerald-600" />
            </div>
            <div className="flex-1">
              <h1 className="text-3xl font-bold mb-2">Feature Requests & Roadmap</h1>
              <p className="text-gray-600">
                Share your ideas and vote on features you'd like to see. Your feedback shapes the future of HealthScope.
              </p>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Submit Request */}
          <Card className="border-2 border-gray-200">
            <CardHeader>
              <CardTitle>Submit Feature Request</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">Category</label>
                  <Select value={formData.category} onValueChange={(value) => setFormData({...formData, category: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="new_feature">New Feature</SelectItem>
                      <SelectItem value="improvement">Improvement</SelectItem>
                      <SelectItem value="data_source_request">Data Source Request</SelectItem>
                      <SelectItem value="integration">Integration</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">Title</label>
                  <Input
                    placeholder="What feature would you like to see?"
                    value={formData.title}
                    onChange={(e) => setFormData({...formData, title: e.target.value})}
                    required
                  />
                </div>

                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">Description</label>
                  <Textarea
                    placeholder="Describe the feature and why it would be valuable..."
                    value={formData.description}
                    onChange={(e) => setFormData({...formData, description: e.target.value})}
                    className="h-32"
                    required
                  />
                </div>

                <Button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="w-full bg-emerald-600 hover:bg-emerald-700"
                >
                  {isSubmitting ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Send className="w-4 h-4 mr-2" />
                  )}
                  Submit Request
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Filter & Stats */}
          <div className="space-y-6">
            <Card className="border-2 border-purple-300 bg-gradient-to-br from-purple-50 to-white">
              <CardHeader>
                <CardTitle className="text-lg">Community Roadmap</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-white rounded-lg border-2 border-purple-200">
                    <div className="text-3xl font-bold text-purple-600">{requests.filter(r => r.status === 'planned').length}</div>
                    <p className="text-sm text-gray-600">Planned</p>
                  </div>
                  <div className="text-center p-4 bg-white rounded-lg border-2 border-blue-200">
                    <div className="text-3xl font-bold text-blue-600">{requests.filter(r => r.status === 'in_progress').length}</div>
                    <p className="text-sm text-gray-600">In Progress</p>
                  </div>
                  <div className="text-center p-4 bg-white rounded-lg border-2 border-green-200">
                    <div className="text-3xl font-bold text-green-600">{requests.filter(r => r.status === 'shipped').length}</div>
                    <p className="text-sm text-gray-600">Shipped</p>
                  </div>
                  <div className="text-center p-4 bg-white rounded-lg border-2 border-gray-200">
                    <div className="text-3xl font-bold text-gray-600">{requests.filter(r => r.status === 'under_review').length}</div>
                    <p className="text-sm text-gray-600">Under Review</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Filters */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Filters</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">Category</label>
                  <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      <SelectItem value="new_feature">New Feature</SelectItem>
                      <SelectItem value="improvement">Improvement</SelectItem>
                      <SelectItem value="data_source_request">Data Source</SelectItem>
                      <SelectItem value="integration">Integration</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">Status</label>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="under_review">Under Review</SelectItem>
                      <SelectItem value="planned">Planned</SelectItem>
                      <SelectItem value="in_progress">In Progress</SelectItem>
                      <SelectItem value="shipped">Shipped</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Feature Requests List */}
        <Card>
          <CardHeader>
            <CardTitle>All Requests ({filteredRequests.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8">
                <Loader2 className="w-8 h-8 animate-spin text-emerald-600 mx-auto" />
              </div>
            ) : filteredRequests.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Lightbulb className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                <p>No feature requests match your filters</p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredRequests.map((request) => (
                  <div key={request.id} className="p-4 bg-gray-50 rounded-lg border-2 border-gray-200 hover:border-emerald-400 transition-all">
                    <div className="flex items-start gap-4">
                      <button
                        onClick={() => handleUpvote(request)}
                        className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-all ${
                          request.upvoted_by?.includes(user?.email)
                            ? 'bg-emerald-100 text-emerald-700'
                            : 'bg-white text-gray-600 hover:bg-gray-100'
                        }`}
                      >
                        <ThumbsUp className="w-5 h-5" />
                        <span className="text-sm font-bold">{request.upvotes || 0}</span>
                      </button>

                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-2">
                          <h4 className="font-semibold text-gray-900 text-lg">{request.title}</h4>
                          <Badge className={getStatusColor(request.status)}>
                            {getStatusIcon(request.status)}
                            <span className="ml-1">{request.status.replace('_', ' ')}</span>
                          </Badge>
                        </div>
                        <p className="text-gray-700 mb-3">{request.description}</p>
                        <div className="flex items-center gap-3 text-sm">
                          <Badge variant="outline" className="capitalize">
                            {request.category.replace('_', ' ')}
                          </Badge>
                          <span className="text-gray-500">
                            by {request.created_by?.split('@')[0]} • {new Date(request.created_date).toLocaleDateString()}
                          </span>
                        </div>
                        {request.admin_response && (
                          <div className="mt-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
                            <p className="text-sm font-medium text-blue-900 mb-1">Team Response:</p>
                            <p className="text-sm text-gray-700">{request.admin_response}</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}