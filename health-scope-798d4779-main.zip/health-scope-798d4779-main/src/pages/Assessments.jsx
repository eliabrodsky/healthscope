import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Plus,
  Search,
  Map as MapIcon,
  Grid3x3,
  List,
  Trash2,
  Loader2,
  MapPin,
  Calendar,
  User,
} from "lucide-react";
import { toast } from "sonner";

import AssessmentCard from "../components/assessments/AssessmentCard";

export default function AssessmentsPage() {
  const [assessments, setAssessments] = useState([]);
  const [filteredAssessments, setFilteredAssessments] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [viewMode, setViewMode] = useState("list");
  const [selectedIds, setSelectedIds] = useState(new Set());
  const [isDeleting, setIsDeleting] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    loadAssessments();
  }, []);

  useEffect(() => {
    let filtered = assessments;

    if (searchTerm) {
      filtered = filtered.filter(assessment =>
        assessment.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (assessment.geography?.state && assessment.geography.state.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    if (statusFilter !== "all") {
      filtered = filtered.filter(assessment => assessment.status === statusFilter);
    }

    setFilteredAssessments(filtered);
  }, [assessments, searchTerm, statusFilter]);

  const loadAssessments = async () => {
    setIsLoading(true);
    try {
      // Only fetch essential fields for list view - exclude large processed_data
      const data = await base44.entities.Assessment.list('-created_date', 50);
      
      // Simple dedup without heavy processing
      const seen = new Set();
      const uniqueAssessments = (data || []).filter(a => {
        if (seen.has(a.id)) return false;
        seen.add(a.id);
        return true;
      });
      
      setAssessments(uniqueAssessments);
    } catch (error) {
      console.error('Error loading assessments:', error);
      toast.error('Failed to load assessments');
      setAssessments([]);
    }
    setIsLoading(false);
  };

  const handleEditAssessment = (assessment) => {
    navigate(createPageUrl(`CreateAssessmentWizard?id=${assessment.id}`));
  };
  
  const handleCreateNew = () => {
    navigate(createPageUrl("CreateAssessmentWizard"));
  };

  const toggleSelection = (id) => {
    const newSelected = new Set(selectedIds);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedIds(newSelected);
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === filteredAssessments.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredAssessments.map(a => a.id)));
    }
  };

  const handleBulkDelete = async () => {
    if (selectedIds.size === 0) return;

    const confirmed = confirm(
      `Are you sure you want to delete ${selectedIds.size} assessment${selectedIds.size > 1 ? 's' : ''}? This action cannot be undone.`
    );

    if (!confirmed) return;

    setIsDeleting(true);
    const deleteToastId = 'bulk-delete';
    toast.loading(`Deleting ${selectedIds.size} assessments...`, { id: deleteToastId });

    try {
      const deletePromises = Array.from(selectedIds).map(id =>
        base44.entities.Assessment.delete(id)
      );

      await Promise.all(deletePromises);

      toast.success(`Successfully deleted ${selectedIds.size} assessment${selectedIds.size > 1 ? 's' : ''}!`, {
        id: deleteToastId
      });

      setSelectedIds(new Set());
      await loadAssessments();
    } catch (error) {
      console.error('Error deleting assessments:', error);
      toast.error('Failed to delete some assessments', { id: deleteToastId });
    } finally {
      setIsDeleting(false);
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      draft: "bg-yellow-50 text-yellow-700 border-yellow-200",
      published: "bg-emerald-50 text-emerald-700 border-emerald-200",
      archived: "bg-gray-50 text-gray-700 border-gray-200"
    };
    return colors[status] || colors.draft;
  };

  const formatLocation = (geography) => {
    if (!geography) return 'No location';
    const parts = [geography.city, geography.state, geography.county].filter(Boolean);
    return parts.join(', ') || 'No location';
  };

  return (
    <div className="min-h-screen p-4 md:p-8 bg-gray-50">
      <div className="max-w-7xl mx-auto">

        {/* Header with Icon */}
        <div className="bg-white rounded-xl p-6 border-2 border-emerald-500 shadow-sm mb-8">
          <div className="flex items-start gap-4">
            <div className="flex-shrink-0">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/2320f625f_assessment.png"
                alt="Assessments"
                className="w-20 h-20"
              />
            </div>
            <div className="flex-1">
              <h1 className="text-3xl font-bold mb-2 text-gray-900">Health Assessments</h1>
              <p className="text-gray-600 text-sm leading-relaxed">
                Create and manage comprehensive community health needs assessments. Define service areas, load demographic data, 
                analyze competitors, and publish interactive dashboards for stakeholders.
              </p>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <div>
            <p className="text-gray-600 mt-2">
              {assessments.length} total assessment{assessments.length !== 1 ? 's' : ''}
              {selectedIds.size > 0 && ` • ${selectedIds.size} selected`}
            </p>
          </div>

          <div className="flex gap-2 w-full md:w-auto">
            {selectedIds.size > 0 && (
              <Button
                onClick={handleBulkDelete}
                disabled={isDeleting}
                variant="destructive"
                className="flex-1 md:flex-initial"
              >
                {isDeleting ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Trash2 className="w-4 h-4 mr-2" />
                )}
                Delete {selectedIds.size}
              </Button>
            )}
            
            <Button
              onClick={handleCreateNew}
              className="flex-1 md:flex-initial bg-emerald-500 hover:bg-emerald-600 text-white shadow-sm"
            >
              <Plus className="w-5 h-5 mr-2 stroke-1" />
              New Assessment
            </Button>
          </div>
        </div>

        {/* Filters and View Toggle */}
        <Card className="border-gray-200 shadow-sm mb-6">
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row gap-4">
              {/* Search */}
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 stroke-1" />
                <Input
                  placeholder="Search assessments..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-white border-gray-300 text-gray-900 placeholder:text-gray-500"
                />
              </div>

              {/* Status Filter */}
              <div className="flex gap-2 overflow-x-auto">
                {['all', 'draft', 'published', 'archived'].map((status) => (
                  <Button
                    key={status}
                    variant={statusFilter === status ? "default" : "outline"}
                    size="sm"
                    onClick={() => setStatusFilter(status)}
                    className={statusFilter === status
                      ? "bg-emerald-500 hover:bg-emerald-600 text-white whitespace-nowrap"
                      : "border-gray-300 text-gray-700 hover:bg-gray-50 whitespace-nowrap"
                    }
                  >
                    {status.charAt(0).toUpperCase() + status.slice(1)}
                  </Button>
                ))}
              </div>

              {/* View Mode Toggle */}
              <div className="flex gap-1 border border-gray-300 rounded-lg p-1 h-9">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setViewMode('grid')}
                  className={`h-7 ${viewMode === 'grid' ? 'bg-gray-100' : ''}`}
                >
                  <Grid3x3 className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setViewMode('list')}
                  className={`h-7 ${viewMode === 'list' ? 'bg-gray-100' : ''}`}
                >
                  <List className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Select All (only in list view) */}
        {viewMode === 'list' && filteredAssessments.length > 0 && !isLoading && (
          <div className="flex items-center gap-3 mb-3 px-2">
            <Checkbox
              checked={selectedIds.size === filteredAssessments.length && filteredAssessments.length > 0}
              onCheckedChange={toggleSelectAll}
              className="h-4 w-4"
            />
            <span className="text-sm text-gray-600">
              Select all ({filteredAssessments.length})
            </span>
          </div>
        )}

        {/* Content */}
        {isLoading ? (
          <div className="min-h-[300px] flex items-center justify-center">
            <div className="bg-white p-8 rounded-2xl shadow-xl flex flex-col items-center border border-slate-100">
              <div className="relative">
                <div className="w-16 h-16 border-4 border-emerald-100 border-t-emerald-500 rounded-full animate-spin"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <MapIcon className="w-6 h-6 text-emerald-600" />
                </div>
              </div>
              <h3 className="mt-6 text-lg font-bold text-slate-900">Loading Assessments</h3>
              <p className="text-slate-500 mt-2">Fetching your assessments...</p>
            </div>
          </div>
        ) : filteredAssessments.length > 0 ? (
          viewMode === 'grid' ? (
            // Grid View
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredAssessments.map((assessment) => (
                <div key={assessment.id} className="relative">
                  <div className="absolute top-3 left-3 z-10">
                    <Checkbox
                      checked={selectedIds.has(assessment.id)}
                      onCheckedChange={() => toggleSelection(assessment.id)}
                      className="bg-white border-2 shadow-sm h-4 w-4"
                    />
                  </div>
                  <AssessmentCard
                    assessment={assessment}
                    onUpdate={loadAssessments}
                    onEdit={handleEditAssessment}
                    hasCheckbox={true}
                  />
                </div>
              ))}
            </div>
          ) : (
            // List View
            <div className="space-y-2">
              {filteredAssessments.map((assessment) => (
                <Card key={assessment.id} className="border-gray-200 shadow-sm hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4">
                      {/* Checkbox */}
                      <Checkbox
                        checked={selectedIds.has(assessment.id)}
                        onCheckedChange={() => toggleSelection(assessment.id)}
                        className="h-4 w-4"
                      />

                      {/* Title and Location */}
                      <div className="flex-1 min-w-0">
                        <Link
                          to={createPageUrl(`AssessmentDashboard?id=${assessment.id}`)}
                          className="font-semibold text-gray-900 hover:text-emerald-600 transition-colors block truncate"
                        >
                          {assessment.title}
                        </Link>
                        <div className="flex items-center gap-4 mt-1 text-sm text-gray-600">
                          <div className="flex items-center gap-1">
                            <MapPin className="w-3 h-3" />
                            <span className="truncate">{formatLocation(assessment.geography)}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            <span>{new Date(assessment.created_date).toLocaleDateString()}</span>
                          </div>
                          {assessment.created_by && (
                            <div className="flex items-center gap-1">
                              <User className="w-3 h-3" />
                              <span className="truncate">{assessment.created_by.split('@')[0]}</span>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Status Badge */}
                      <Badge className={getStatusColor(assessment.status)}>
                        {assessment.status}
                      </Badge>

                      {/* Data Sources Count */}
                      {assessment.data_sources && assessment.data_sources.length > 0 && (
                        <div className="hidden sm:flex items-center gap-1 text-sm text-gray-600">
                          <MapIcon className="w-4 h-4" />
                          <span>{assessment.data_sources.length} sources</span>
                        </div>
                      )}

                      {/* Actions */}
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEditAssessment(assessment)}
                        >
                          Edit
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => navigate(createPageUrl(`AssessmentDashboard?id=${assessment.id}`))}
                          className="bg-emerald-500 text-white hover:bg-emerald-600 border-0"
                        >
                          View
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )
        ) : (
          <Card className="border-gray-200 shadow-sm">
            <CardContent className="text-center py-12">
              <MapIcon className="w-16 h-16 text-gray-300 mx-auto mb-4 stroke-1" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                {assessments.length === 0 ? "No assessments created yet" : "No assessments match your filters"}
              </h3>
              <p className="text-gray-600 mb-6">
                {assessments.length === 0
                  ? "Start by creating your first community health assessment"
                  : "Try adjusting your search terms or filters"
                }
              </p>
              {assessments.length === 0 && (
                <Button
                  onClick={handleCreateNew}
                  className="w-full sm:w-auto bg-emerald-500 hover:bg-emerald-600 text-white"
                >
                  <Plus className="w-5 h-5 mr-2 stroke-1" />
                  Create Your First Assessment
                </Button>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}