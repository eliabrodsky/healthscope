import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { 
    Database, 
    MapPin, 
    Building2, 
    Loader2, 
    FileText, 
    Upload, 
    CheckCircle,
    AlertCircle,
    FileJson,
    ImageIcon,
    FileArchive
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

// State definitions
const stateDefinitions = [
    { name: "Alabama", abbr: "AL" },
    { name: "Alaska", abbr: "AK" },
    { name: "Arizona", abbr: "AZ" },
    { name: "Arkansas", abbr: "AR" },
    { name: "California", abbr: "CA" },
    { name: "Colorado", abbr: "CO" },
    { name: "Connecticut", abbr: "CT" },
    { name: "Delaware", abbr: "DE" },
    { name: "Florida", abbr: "FL" },
    { name: "Georgia", abbr: "GA" },
    { name: "Hawaii", abbr: "HI" },
    { name: "Idaho", abbr: "ID" },
    { name: "Illinois", abbr: "IL" },
    { name: "Indiana", abbr: "IN" },
    { name: "Iowa", abbr: "IA" },
    { name: "Kansas", abbr: "KS" },
    { name: "Kentucky", abbr: "KY" },
    { name: "Louisiana", abbr: "LA" },
    { name: "Maine", abbr: "ME" },
    { name: "Maryland", abbr: "MD" },
    { name: "Massachusetts", abbr: "MA" },
    { name: "Michigan", abbr: "MI" },
    { name: "Minnesota", abbr: "MN" },
    { name: "Mississippi", abbr: "MS" },
    { name: "Missouri", abbr: "MO" },
    { name: "Montana", abbr: "MT" },
    { name: "Nebraska", abbr: "NE" },
    { name: "Nevada", abbr: "NV" },
    { name: "New Hampshire", abbr: "NH" },
    { name: "New Jersey", abbr: "NJ" },
    { name: "New Mexico", abbr: "NM" },
    { name: "New York", abbr: "NY" },
    { name: "North Carolina", abbr: "NC" },
    { name: "North Dakota", abbr: "ND" },
    { name: "Ohio", abbr: "OH" },
    { name: "Oklahoma", abbr: "OK" },
    { name: "Oregon", abbr: "OR" },
    { name: "Pennsylvania", abbr: "PA" },
    { name: "Rhode Island", abbr: "RI" },
    { name: "South Carolina", abbr: "SC" },
    { name: "South Dakota", abbr: "SD" },
    { name: "Tennessee", abbr: "TN" },
    { name: "Texas", abbr: "TX" },
    { name: "Utah", abbr: "UT" },
    { name: "Vermont", abbr: "VT" },
    { name: "Virginia", abbr: "VA" },
    { name: "Washington", abbr: "WA" },
    { name: "West Virginia", abbr: "WV" },
    { name: "Wisconsin", abbr: "WI" },
    { name: "Wyoming", abbr: "WY" },
    { name: "District of Columbia", abbr: "DC" },
];

function DataCard({ icon: Icon, title, description, count, isLoading, linkUrl }) {
    return (
        <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                    <Icon className="w-5 h-5 text-emerald-600" />
                    {title}
                </CardTitle>
                <CardDescription>{description}</CardDescription>
            </CardHeader>
            <CardContent>
                {isLoading ? (
                    <div className="flex items-center gap-2 text-gray-500">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        <span>Loading...</span>
                    </div>
                ) : (
                    <div className="space-y-3">
                        <div className="text-3xl font-bold text-emerald-600">
                            {count?.toLocaleString() || 0}
                        </div>
                        {linkUrl && (
                            <Link 
                                to={linkUrl} 
                                className="text-sm text-emerald-600 hover:text-emerald-700 hover:underline inline-block"
                            >
                                View details →
                            </Link>
                        )}
                    </div>
                )}
            </CardContent>
        </Card>
    );
}

export default function DataManagement() {
    const [boundaryCount, setBoundaryCount] = useState(0);
    const [demographicsCount, setDemographicsCount] = useState(0);
    const [organizationsCount, setOrganizationsCount] = useState(0);
    const [uploadsCount, setUploadsCount] = useState(0);
    const [cdcCount, setCdcCount] = useState(0);
    const [isLoading, setIsLoading] = useState(true);
    const [loadedStates, setLoadedStates] = useState([]);
    const [uploadedFiles, setUploadedFiles] = useState([]);
    const [isLoadingUploads, setIsLoadingUploads] = useState(true);

    useEffect(() => {
        const loadData = async () => {
            setIsLoading(true);
            try {
                // Fetch counts with smaller limits to avoid timeouts
                const [boundaries, demographics, organizations, uploads, cdc, statusRecords] = await Promise.all([
                    base44.entities.ZctaBoundary.list('', 1).catch(() => []),
                    base44.entities.ZipDemographics.list('', 1).catch(() => []),
                    base44.entities.Organization.list('', 100).catch(() => []),
                    base44.entities.DataUpload.list('', 100).catch(() => []),
                    base44.entities.CdcHealthData.list('', 1).catch(() => []),
                    base44.entities.StateDataStatus.list().catch(() => [])
                ]);

                // For entities with large datasets, use status records for accurate counts
                const statesData = statusRecords || [];
                const totalBoundaries = statesData.reduce((sum, s) => sum + (s.boundary_count || 0), 0);
                const totalDemographics = statesData.reduce((sum, s) => sum + (s.demographics_count || 0), 0);
                const totalCdc = statesData.reduce((sum, s) => sum + (s.cdc_count || 0), 0);

                setBoundaryCount(totalBoundaries || boundaries.length);
                setDemographicsCount(totalDemographics || demographics.length);
                setOrganizationsCount(organizations.length);
                setUploadsCount(uploads.length);
                setCdcCount(totalCdc || cdc.length);

                // Process loaded states
                const statesWithData = statusRecords
                    .filter(record => 
                        record.boundaries_complete || 
                        record.demographics_complete || 
                        (record.boundary_count && record.boundary_count > 0)
                    )
                    .map(record => {
                        const stateDef = stateDefinitions.find(s => s.abbr === record.state_abbr);
                        return {
                            abbr: record.state_abbr,
                            name: stateDef?.name || record.state_name || record.state_abbr,
                            boundariesComplete: record.boundaries_complete || false,
                            demographicsComplete: record.demographics_complete || false,
                            boundaryCount: record.boundary_count || 0,
                            demographicsCount: record.demographics_count || 0
                        };
                    })
                    .sort((a, b) => a.name.localeCompare(b.name));

                setLoadedStates(statesWithData);

                // Process uploaded files
                const filesWithDetails = uploads.map(upload => ({
                    ...upload,
                    uploadedDate: new Date(upload.created_date)
                })).sort((a, b) => b.uploadedDate - a.uploadedDate);

                setUploadedFiles(filesWithDetails);

            } catch (error) {
                console.error("Error loading data:", error);
            } finally {
                setIsLoading(false);
                setIsLoadingUploads(false);
            }
        };

        loadData();
    }, []);

    const getFileIcon = (fileType) => {
        switch (fileType) {
            case 'pdf':
                return FileText;
            case 'json':
                return FileJson;
            case 'zip':
                return FileArchive;
            case 'image':
                return ImageIcon;
            default:
                return Upload;
        }
    };

    const getFileTypeColor = (fileType) => {
        switch (fileType) {
            case 'pdf':
                return 'bg-red-100 text-red-800';
            case 'json':
                return 'bg-orange-100 text-orange-800';
            case 'zip':
                return 'bg-purple-100 text-purple-800';
            case 'image':
                return 'bg-blue-100 text-blue-800';
            case 'csv':
            case 'excel':
                return 'bg-green-100 text-green-800';
            default:
                return 'bg-gray-100 text-gray-800';
        }
    };

    const formatDate = (date) => {
        return new Intl.DateTimeFormat('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        }).format(date);
    };

    return (
        <div className="min-h-screen bg-gray-50 p-6">
            <div className="max-w-7xl mx-auto space-y-6">
                
                {/* Header */}
                <div className="bg-white rounded-xl p-6 border-2 border-emerald-500 shadow-sm">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0">
                      <img 
                        src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/0c1309d5b_data-storage.png"
                        alt="Data Management"
                        className="w-20 h-20"
                      />
                    </div>
                    <div className="flex-1">
                      <h1 className="text-3xl font-bold text-gray-900 mb-2">Data Management</h1>
                      <p className="text-gray-600 text-sm leading-relaxed">
                        Overview of all data loaded into the system
                      </p>
                    </div>
                  </div>
                </div>

                {/* Available Data Sources Info */}
                <Card className="bg-gradient-to-r from-emerald-50 to-green-50 border-emerald-200">
                    <CardHeader>
                        <CardTitle className="text-lg">Available Data Sources</CardTitle>
                        <CardDescription className="text-gray-700">
                            Integrated sources ready to use in your assessments
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
                            <div>
                                <strong className="text-gray-900">US Census Bureau</strong>
                                <p className="text-gray-600">ACS 5-Year demographic data</p>
                            </div>
                            <div>
                                <strong className="text-gray-900">Census TIGER</strong>
                                <p className="text-gray-600">ZCTA boundary shapefiles</p>
                            </div>
                            <div>
                                <strong className="text-gray-900">CDC PLACES</strong>
                                <p className="text-gray-600">County health indicators</p>
                            </div>
                            <div>
                                <strong className="text-gray-900">HRSA</strong>
                                <p className="text-gray-600">FQHC directory</p>
                            </div>
                            <div>
                                <strong className="text-gray-900">OpenStreetMap</strong>
                                <p className="text-gray-600">Healthcare facility locations</p>
                            </div>
                            <div>
                                <strong className="text-gray-900">Custom Uploads</strong>
                                <p className="text-gray-600">CSV, Excel, PDF processing</p>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                {/* Data Summary Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <DataCard
                        icon={MapPin}
                        title="ZCTA Boundaries"
                        description="Geographic boundary polygons for ZIP Code Tabulation Areas"
                        count={boundaryCount}
                        isLoading={isLoading}
                        linkUrl={createPageUrl("InitialDataLoader")}
                    />
                    
                    <DataCard
                        icon={Database}
                        title="Demographics Data"
                        description="Census population, income, poverty, and insurance data"
                        count={demographicsCount}
                        isLoading={isLoading}
                        linkUrl={createPageUrl("InitialDataLoader")}
                    />
                    
                    <DataCard
                        icon={Building2}
                        title="Healthcare Organizations"
                        description="FQHCs, hospitals, clinics, and other healthcare facilities"
                        count={organizationsCount}
                        isLoading={isLoading}
                    />

                    <DataCard
                        icon={Upload}
                        title="Custom Data Uploads"
                        description="User-uploaded files and processed data"
                        count={uploadsCount}
                        isLoading={isLoading}
                        linkUrl={createPageUrl("DataUpload")}
                    />

                    <DataCard
                        icon={Database}
                        title="CDC PLACES Health Data"
                        description="County-level chronic disease prevalence and health measures"
                        count={cdcCount}
                        isLoading={isLoading}
                        linkUrl={createPageUrl("InitialDataLoader")}
                    />
                </div>

                {/* Loaded States */}
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <MapPin className="w-5 h-5" />
                            Loaded States ({loadedStates.length})
                        </CardTitle>
                        <CardDescription>
                            States with boundary or demographic data loaded
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        {isLoading ? (
                            <div className="flex items-center gap-2 text-gray-500">
                                <Loader2 className="w-4 h-4 animate-spin" />
                                <span>Loading state data...</span>
                            </div>
                        ) : loadedStates.length === 0 ? (
                            <div className="text-center py-8 text-gray-500">
                                <MapPin className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                                <p>No state data loaded yet</p>
                                <Link 
                                    to={createPageUrl("InitialDataLoader")}
                                    className="text-emerald-600 hover:text-emerald-700 text-sm mt-2 inline-block"
                                >
                                    Load state data →
                                </Link>
                            </div>
                        ) : (
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                                {loadedStates.map((state) => (
                                    <div 
                                        key={state.abbr}
                                        className="border border-gray-200 rounded-lg p-3 hover:shadow-md transition-shadow"
                                    >
                                        <div className="mb-2">
                                            <div className="flex items-center justify-between mb-2">
                                                <h3 className="font-semibold text-gray-900">
                                                    {state.name}
                                                </h3>
                                                <p className="text-xs text-gray-500">{state.abbr}</p>
                                            </div>
                                            <div className="flex gap-1 flex-wrap">
                                                {state.boundariesComplete && (
                                                    <Badge className="bg-emerald-100 text-emerald-800 text-xs">
                                                        <CheckCircle className="w-3 h-3 mr-1" />
                                                        Boundaries
                                                    </Badge>
                                                )}
                                                {state.demographicsComplete && (
                                                    <Badge className="bg-blue-100 text-blue-800 text-xs">
                                                        <CheckCircle className="w-3 h-3 mr-1" />
                                                        Demographics
                                                    </Badge>
                                                )}
                                            </div>
                                        </div>
                                        <div className="space-y-1 text-xs text-gray-600">
                                            {state.boundaryCount > 0 && (
                                                <div className="flex justify-between">
                                                    <span>ZCTAs:</span>
                                                    <span className="font-medium">{state.boundaryCount.toLocaleString()}</span>
                                                </div>
                                            )}
                                            {state.demographicsCount > 0 && (
                                                <div className="flex justify-between">
                                                    <span>Demographics:</span>
                                                    <span className="font-medium">{state.demographicsCount.toLocaleString()}</span>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </CardContent>
                </Card>

                {/* Custom Data Uploads */}
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Upload className="w-5 h-5" />
                            Custom Data Uploads ({uploadedFiles.length})
                        </CardTitle>
                        <CardDescription>
                            User-uploaded files and their processing status
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        {isLoadingUploads ? (
                            <div className="flex items-center gap-2 text-gray-500">
                                <Loader2 className="w-4 h-4 animate-spin" />
                                <span>Loading uploaded files...</span>
                            </div>
                        ) : uploadedFiles.length === 0 ? (
                            <div className="text-center py-8 text-gray-500">
                                <Upload className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                                <p>No custom data uploaded yet</p>
                                <Link 
                                    to={createPageUrl("DataUpload")}
                                    className="text-emerald-600 hover:text-emerald-700 text-sm mt-2 inline-block"
                                >
                                    Upload data →
                                </Link>
                            </div>
                        ) : (
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>File</TableHead>
                                        <TableHead>Type</TableHead>
                                        <TableHead>Source</TableHead>
                                        <TableHead>Status</TableHead>
                                        <TableHead>Uploaded</TableHead>
                                        <TableHead>Uploaded By</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {uploadedFiles.map((file) => {
                                        const FileIcon = getFileIcon(file.file_type);
                                        return (
                                            <TableRow key={file.id}>
                                                <TableCell className="font-medium">
                                                    <div className="flex items-center gap-2">
                                                        <FileIcon className="w-4 h-4 text-gray-500" />
                                                        <a 
                                                            href={file.file_url} 
                                                            target="_blank" 
                                                            rel="noopener noreferrer"
                                                            className="hover:text-emerald-600 hover:underline"
                                                        >
                                                            {file.filename}
                                                        </a>
                                                    </div>
                                                </TableCell>
                                                <TableCell>
                                                    <Badge className={getFileTypeColor(file.file_type)}>
                                                        {file.file_type?.toUpperCase() || 'UNKNOWN'}
                                                    </Badge>
                                                </TableCell>
                                                <TableCell className="text-sm text-gray-600">
                                                    {file.data_source || 'Custom Upload'}
                                                </TableCell>
                                                <TableCell>
                                                    {file.processed ? (
                                                        <Badge className="bg-green-100 text-green-800">
                                                            <CheckCircle className="w-3 h-3 mr-1" />
                                                            Processed
                                                        </Badge>
                                                    ) : (
                                                        <Badge className="bg-gray-100 text-gray-800">
                                                            <AlertCircle className="w-3 h-3 mr-1" />
                                                            Uploaded
                                                        </Badge>
                                                    )}
                                                </TableCell>
                                                <TableCell className="text-sm text-gray-600">
                                                    {formatDate(file.uploadedDate)}
                                                </TableCell>
                                                <TableCell className="text-sm text-gray-600">
                                                    {file.created_by || 'Unknown'}
                                                </TableCell>
                                            </TableRow>
                                        );
                                    })}
                                </TableBody>
                            </Table>
                        )}
                    </CardContent>
                </Card>

            </div>
        </div>
    );
}