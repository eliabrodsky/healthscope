import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Map,
  Users,
  BarChart3,
  Building,
  ChevronRight,
  Check,
  Zap,
  Globe,
  Shield,
  TrendingUp,
  Heart,
  Activity,
  Target,
  Sparkles } from
"lucide-react";

const features = [
{
  icon: Map,
  title: "Interactive Geographic Mapping",
  description: "Visualize community health data with ZIP code-level precision and boundary mapping."
},
{
  icon: Users,
  title: "Census Demographics",
  description: "Access real-time population, income, and health insurance data from the US Census Bureau."
},
{
  icon: Building,
  title: "Competitor Analysis",
  description: "Map and analyze healthcare facilities, FQHCs, hospitals, and clinics in your service area."
},
{
  icon: BarChart3,
  title: "Market Intelligence",
  description: "Identify service gaps, underserved populations, and growth opportunities."
},
{
  icon: Sparkles,
  title: "AI-Powered Insights",
  description: "Get intelligent recommendations and automated data analysis using advanced AI."
},
{
  icon: Globe,
  title: "Public Dashboards",
  description: "Share interactive dashboards publicly with customizable access controls."
}];


const useCases = [
{
  title: "Community Health Assessments",
  description: "Comprehensive health needs analysis for grant applications and strategic planning.",
  icon: Heart
},
{
  title: "FQHC Planning & Expansion",
  description: "Data-driven site selection and service area analysis for federally qualified health centers.",
  icon: Building
},
{
  title: "Market Gap Analysis",
  description: "Identify underserved populations and healthcare deserts in your region.",
  icon: Target
},
{
  title: "Competitive Intelligence",
  description: "Track competitor locations, services, and market share in real-time.",
  icon: TrendingUp
}];


const accountTypes = [
{
  title: "Health Leaders",
  description: "FQHCs, hospital systems, and public health departments conducting community health assessments",
  icon: Activity,
  benefits: ["Unlimited assessments", "Real Census data", "AI analysis", "Public sharing"]
},
{
  title: "Consultants & Researchers",
  description: "Healthcare consultants and researchers analyzing community health needs",
  icon: Users,
  benefits: ["Multi-client support", "Export capabilities", "White-label reports", "API access"]
},
{
  title: "Government & Nonprofits",
  description: "State and local health departments tracking community health outcomes",
  icon: Globe,
  benefits: ["Grant writing support", "Compliance reporting", "Data security", "Team collaboration"]
}];


// Animated map marker component
const MapMarker = ({ x, y, delay }) =>
<div
  className="absolute w-3 h-3 bg-emerald-500 rounded-full animate-pulse shadow-lg"
  style={{
    left: `${x}%`,
    top: `${y}%`,
    animationDelay: `${delay}ms`,
    animationDuration: '2s'
  }} />;



export default function HomePage() {
  const [activeSlide, setActiveSlide] = useState(0);
  const [recentAssessments, setRecentAssessments] = useState([]);
  const [isLoadingAssessments, setIsLoadingAssessments] = useState(true);

  useEffect(() => {
    const loadPublicAssessments = async () => {
      try {
        // RLS allows reading assessments where published_settings.is_public is true
        const assessments = await base44.entities.Assessment.filter({
          status: 'published',
          'published_settings.is_public': true
        }, '-created_date', 6);
        setRecentAssessments(assessments || []);
      } catch (error) {
        console.error('Error loading assessments:', error);
        setRecentAssessments([]);
      } finally {
        setIsLoadingAssessments(false);
      }
    };
    loadPublicAssessments();
  }, []);

  const toolShowcases = [
  {
    title: "Interactive Geographic Mapping",
    description: "Assemble data into meaningful and interactive maps with ZIP code-level precision and color-coded demographics",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/64db16712_slide1-maps1.jpg"
  },
  {
    title: "Healthcare Provider Analysis",
    description: "Compare healthcare providers in a defined region - hospitals, FQHCs, clinics, and identify service gaps",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/553064cad_slide2-competitors.jpg"
  },
  {
    title: "AI-Powered Insights",
    description: "Leverage AI to gain insights and analyze trends - discover patterns, identify underserved areas, and get intelligent recommendations",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/8ba4a9d8f_ai-assistant.jpg"
  },
  {
    title: "Export & Share Dashboards",
    description: "Export your findings into dashboards and presentations to share with stakeholders, funders, and community partners",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/6c383a581_insights.jpg"
  }];


  const handleLogin = () => {
    base44.auth.redirectToLogin(createPageUrl("Dashboard"));
  };

  const handleSignup = () => {
    base44.auth.redirectToLogin(createPageUrl("Dashboard"));
  };

  // Auto-advance carousel
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveSlide((prev) => (prev + 1) % toolShowcases.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [toolShowcases.length]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Navigation */}
      <nav className="border-b border-gray-200 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4 md:py-5">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-emerald-500 rounded-lg flex items-center justify-center">
                <BarChart3 className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">HealthScope</span>
            </div>
            <div className="flex items-center gap-4">
              <a href={createPageUrl("About")} className="text-gray-600 hover:text-gray-900 font-medium">
                About
              </a>
              <Button variant="ghost" onClick={handleLogin}>
                Log In
              </Button>
              <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={handleSignup}>
                Get Started Free
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-emerald-50 via-white to-green-50 pt-12 pb-24">
        {/* Background Map Image */}
        <div
          className="absolute inset-0 bg-cover bg-center opacity-10"
          style={{
            backgroundImage: 'url(https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/205a2e328_13DC13F7-1958-4BE2-94E3-52364BFD4AE9.png)',
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }} />

        
        {/* Animated background map pattern */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-30">
          <svg className="absolute inset-0 w-full h-full" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="map-grid" width="100" height="100" patternUnits="userSpaceOnUse">
                <path d="M 100 0 L 0 0 0 100" fill="none" stroke="rgb(16, 185, 129)" strokeWidth="0.5" opacity="0.3" />
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#map-grid)" />
          </svg>
          
          {/* Pulsating dots */}
          <MapMarker x={15} y={25} delay={0} />
          <MapMarker x={70} y={35} delay={500} />
          <MapMarker x={45} y={55} delay={1000} />
          <MapMarker x={85} y={70} delay={1500} />
          <MapMarker x={25} y={80} delay={2000} />
          <MapMarker x={60} y={20} delay={2500} />
        </div>
        
        <style>{`
          @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
          }
          
          .animate-float {
            animation: float 3s ease-in-out infinite;
          }
        `}</style>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative py-12 md:py-16">
          <div className="text-center mb-12">
            <Badge className="mb-4 bg-emerald-100 text-emerald-800 border-emerald-200">
              🚀 Now with Real-Time Census API Integration
            </Badge>
            <h1 className="text-5xl sm:text-6xl font-bold text-gray-900 mb-6 leading-tight">
              Transform Community Health
              <span className="block text-emerald-600 mt-2">Data Into Action</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
              The most powerful platform for community health assessments, market analysis, and strategic planning. 
              Built for FQHCs, health systems, and public health leaders.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center w-full max-w-md mx-auto">
              <Button size="lg" className="bg-emerald-600 hover:bg-emerald-700 text-lg px-8 w-full sm:w-auto" onClick={handleSignup}>
                Start Free Assessment
                <ChevronRight className="ml-2 w-5 h-5" />
              </Button>
              <Button size="lg" variant="outline" className="text-lg px-8 w-full sm:w-auto">
                Watch Demo
              </Button>
            </div>
          </div>

          {/* Social Proof */}
          <div className="mt-16 flex items-center justify-center gap-8 flex-wrap text-sm text-gray-600">
            <div className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-emerald-600" />
              <span>Verified Data</span>
            </div>
            <div className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-emerald-600" />
              <span>Custom Uploads</span>
            </div>
            <div className="flex items-center gap-2">
              <Check className="w-5 h-5 text-emerald-600" />
              <span>AI-enabled</span>
            </div>
          </div>
        </div>
      </section>

      {/* Trusted Data Sources */}
      <section className="py-16 bg-white border-y border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-center text-sm text-gray-500 mb-8">TRUSTED DATA SOURCES</p>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-8 items-center justify-items-center">
            <div className="text-center group">
              <div className="h-16 flex items-center justify-center mx-auto mb-3">
                <img
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/d84369728_censuslogo.jpg"
                  alt="US Census Bureau"
                  className="h-12 w-auto object-contain grayscale group-hover:grayscale-0 transition-all duration-300" />

              </div>
              <p className="font-semibold text-gray-700 text-sm">US Census Bureau</p>
              <p className="text-xs text-gray-500">ACS 5-Year Data</p>
            </div>
            <div className="text-center group">
              <div className="h-16 flex items-center justify-center mx-auto mb-3">
                <img
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/ea62d8f35_HRSA_Logo.jpg"
                  alt="HRSA"
                  className="h-12 w-auto object-contain grayscale group-hover:grayscale-0 transition-all duration-300" />

              </div>
              <p className="font-semibold text-gray-700 text-sm">HRSA</p>
              <p className="text-xs text-gray-500">FQHC Directory</p>
            </div>
            <div className="text-center group">
              <div className="h-16 flex items-center justify-center mx-auto mb-3">
                <img
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/f1dac43f7_cdc-logo.jpg"
                  alt="CDC"
                  className="h-12 w-auto object-contain grayscale group-hover:grayscale-0 transition-all duration-300" />

              </div>
              <p className="font-semibold text-gray-700 text-sm">CDC</p>
              <p className="text-xs text-gray-500">PLACES Data</p>
            </div>
            <div className="text-center group">
              <div className="h-16 flex items-center justify-center mx-auto mb-3">
                <img
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/faaeaaaf9_openstreetmapslogo.png"
                  alt="OpenStreetMap"
                  className="h-12 w-auto object-contain grayscale group-hover:grayscale-0 transition-all duration-300" />

              </div>
              <p className="font-semibold text-gray-700 text-sm">OpenStreetMap</p>
              <p className="text-xs text-gray-500">Healthcare Facilities</p>
            </div>
            <div className="text-center group">
              <div className="h-16 flex items-center justify-center mx-auto mb-3">
                <img
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/70776d510_Datagov_logo.png"
                  alt="Data.gov"
                  className="h-12 w-auto object-contain grayscale group-hover:grayscale-0 transition-all duration-300" />

              </div>
              <p className="font-semibold text-gray-700 text-sm">Data.gov</p>
              <p className="text-xs text-gray-500">Geographic Boundaries</p>
            </div>
          </div>
        </div>
      </section>

      {/* Tool Showcases - Carousel */}
      <section className="py-20 bg-gradient-to-b from-white to-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Powerful Analytics Tools</h2>
            <p className="text-xl text-gray-600">Everything you need for data-driven healthcare decisions</p>
          </div>

          <div className="relative flex items-center gap-8">
            {/* Previous Arrow */}
            <button
              onClick={() => setActiveSlide((prev) => (prev - 1 + toolShowcases.length) % toolShowcases.length)}
              className="flex-shrink-0 p-2 hover:opacity-70 transition-opacity hidden lg:block">

              <ChevronRight className="w-10 h-10 text-gray-600 rotate-180" />
            </button>

            {/* Carousel */}
            <div className="flex-1 relative">

            {toolShowcases.map((tool, index) =>
              <div
                key={index}
                className={`transition-opacity duration-500 ${
                index === activeSlide ? 'opacity-100' : 'opacity-0 absolute inset-0 pointer-events-none'}`
                }>

                <Card className="overflow-hidden border-gray-200 shadow-xl">
                  <div className="grid md:grid-cols-2 gap-0 h-[400px]">
                    <div className="p-8 flex flex-col justify-center bg-gradient-to-br from-emerald-50 to-white h-full">
                      <Badge className="w-fit mb-4 bg-emerald-600 text-white">Featured Tool</Badge>
                      <h3 className="text-3xl font-bold text-gray-900 mb-4">{tool.title}</h3>
                      <p className="text-lg text-gray-600 mb-6">{tool.description}</p>
                      <Button className="w-fit bg-emerald-600 hover:bg-emerald-700" onClick={handleSignup}>
                        Try It Now <ChevronRight className="ml-2 w-4 h-4" />
                      </Button>
                    </div>
                    <div className="relative h-full">
                      <img
                        src={tool.image}
                        alt={tool.title}
                        className="absolute inset-0 w-full h-full object-cover" />

                    </div>
                  </div>
                </Card>
              </div>
              )}

              {/* Carousel Indicators */}
              <div className="flex justify-center gap-2 mt-6">
                {toolShowcases.map((_, index) =>
                <button
                  key={index}
                  onClick={() => setActiveSlide(index)}
                  className={`w-2 h-2 rounded-full transition-all ${
                  index === activeSlide ? 'bg-emerald-600 w-8' : 'bg-gray-300'}`
                  } />

                )}
              </div>
            </div>

            {/* Next Arrow */}
            <button
              onClick={() => setActiveSlide((prev) => (prev + 1) % toolShowcases.length)}
              className="flex-shrink-0 p-2 hover:opacity-70 transition-opacity hidden lg:block">

              <ChevronRight className="w-10 h-10 text-gray-600" />
            </button>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Everything You Need in One Platform
            </h2>
            <p className="text-xl text-gray-600">
              Comprehensive tools for community health assessment and strategic planning
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) =>
            <Card key={index} className="border-gray-200 hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center mb-4">
                    <feature.icon className="w-6 h-6 text-emerald-600" />
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{feature.description}</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </section>

      {/* Use Cases */}
      <section className="py-20 bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Built for Health Leaders</h2>
            <p className="text-xl text-gray-600">Trusted by organizations making data-driven health decisions</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {useCases.map((useCase, index) =>
            <Card key={index} className="border-gray-200 hover:border-emerald-200 transition-colors">
                <CardHeader>
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-emerald-50 rounded-lg flex items-center justify-center flex-shrink-0">
                      <useCase.icon className="w-6 h-6 text-emerald-600" />
                    </div>
                    <div>
                      <CardTitle className="text-xl mb-2">{useCase.title}</CardTitle>
                      <CardDescription className="text-base">{useCase.description}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
              </Card>
            )}
          </div>
        </div>
      </section>

      {/* Who It's For */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Perfect For</h2>
            <p className="text-xl text-gray-600">Organizations of all sizes making community health decisions</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {accountTypes.map((type, index) =>
            <Card key={index} className="border-gray-200 hover:shadow-xl transition-all">
                <CardHeader>
                  <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center mb-4">
                    <type.icon className="w-6 h-6 text-emerald-600" />
                  </div>
                  <CardTitle className="text-xl mb-2">{type.title}</CardTitle>
                  <CardDescription className="text-gray-600">{type.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {type.benefits.map((benefit, idx) =>
                  <li key={idx} className="flex items-center gap-2 text-sm text-gray-700">
                        <Check className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                        <span>{benefit}</span>
                      </li>
                  )}
                  </ul>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </section>

      {/* Recent Assessments Preview */}
      <section className="py-20 bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">See What's Possible</h2>
            <p className="text-xl text-gray-600">Recent community health assessments created on HealthScope</p>
          </div>

          {isLoadingAssessments ? (
            <div className="grid md:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="border-gray-200">
                  <CardHeader>
                    <div className="h-4 w-3/4 bg-gray-200 rounded animate-pulse mb-2" />
                    <div className="h-3 w-1/2 bg-gray-200 rounded animate-pulse" />
                  </CardHeader>
                  <CardContent>
                    <div className="h-32 bg-gray-200 rounded animate-pulse" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : recentAssessments.length > 0 ? (
            <div className="grid md:grid-cols-3 gap-6">
              {recentAssessments.map((assessment) => {
                const location = assessment.geography?.city && assessment.geography?.state
                  ? `${assessment.geography.city}, ${assessment.geography.state}`
                  : 'Assessment';
                const zipCount = assessment.geography?.zcta_codes?.length || assessment.geography?.zip_codes?.length || 0;
                const mapPreview = assessment.processed_data?.map_preview || assessment.processed_data?.trimmed_geojson_preview;
                
                return (
                  <a
                    key={assessment.id}
                    href={createPageUrl(`PublicAssessmentView?id=${assessment.id}`)}
                    className="block"
                  >
                    <Card className="border-gray-200 hover:shadow-lg transition-all hover:border-emerald-200 cursor-pointer h-full">
                      <CardHeader>
                        <div className="flex items-center gap-2 mb-2">
                          <Map className="w-5 h-5 text-emerald-600" />
                          <CardTitle className="text-lg line-clamp-1">{assessment.title || location}</CardTitle>
                        </div>
                        {assessment.description && (
                          <p className="text-sm text-gray-600 line-clamp-2 mb-2">{assessment.description}</p>
                        )}
                        <div className="flex gap-2 text-xs text-gray-500">
                          <span>{zipCount} ZIP codes</span>
                          {assessment.created_by && (
                            <>
                              <span>•</span>
                              <span>By {assessment.created_by.split('@')[0]}</span>
                            </>
                          )}
                        </div>
                      </CardHeader>
                      <CardContent>
                        {mapPreview ? (
                          <div className="h-32 rounded-lg overflow-hidden bg-gray-100">
                            <img 
                              src={mapPreview} 
                              alt={`${location} map`}
                              className="w-full h-full object-cover"
                            />
                          </div>
                        ) : (
                          <div className="h-32 bg-gradient-to-br from-emerald-100 to-green-50 rounded-lg flex items-center justify-center">
                            <Map className="w-16 h-16 text-emerald-300" />
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </a>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-12">
              <Map className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">No public assessments available yet</p>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-emerald-600 to-green-700 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-4">Ready to Transform Your Community Health Analysis?</h2>
          <p className="text-xl text-emerald-100 mb-8">
            Join healthcare leaders using HealthScope to make data-driven decisions
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center w-full max-w-md mx-auto">
            <Button size="lg" className="bg-white text-emerald-600 hover:bg-gray-100 text-lg px-8 w-full sm:w-auto" onClick={handleSignup}>
              Start Free Assessment
              <ChevronRight className="ml-2 w-5 h-5" />
            </Button>
            <Button size="lg" variant="outline" className="bg-zinc-400 text-white px-8 text-lg font-medium rounded-md inline-flex items-center justify-center gap-2 whitespace-nowrap ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:text-accent-foreground h-11 border-white hover:bg-emerald-700 w-full sm:w-auto">
              Schedule Demo
            </Button>
          </div>
          <p className="mt-6 text-sm text-emerald-100">No credit card required • Free forever plan available</p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center">
                  <BarChart3 className="w-4 h-4 text-white" />
                </div>
                <span className="text-white font-bold">HealthScope</span>
              </div>
              <p className="text-sm">
                Empowering health leaders with data-driven insights for better community health outcomes.
              </p>
            </div>
            
            <div>
              <h3 className="text-white font-semibold mb-4">Product</h3>
              <ul className="space-y-2 text-sm">
                <li><a href={createPageUrl("Features")} className="hover:text-white">Features</a></li>
                <li><a href={createPageUrl("Pricing")} className="hover:text-white">Pricing</a></li>
                <li><a href={createPageUrl("Dashboard")} className="hover:text-white">Dashboard</a></li>
                <li><a href={createPageUrl("Assessments")} className="hover:text-white">Assessments</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-white font-semibold mb-4">Resources</h3>
              <ul className="space-y-2 text-sm">
                <li><a href={createPageUrl("About")} className="hover:text-white">About</a></li>
                <li><a href={createPageUrl("Support")} className="hover:text-white">Support</a></li>
                <li><a href={createPageUrl("Features")} className="hover:text-white">Feature Requests</a></li>
                <li><a href={createPageUrl("PublicPortfolio")} className="hover:text-white">Public Assessments</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-white font-semibold mb-4">Company</h3>
              <ul className="space-y-2 text-sm">
                <li><a href={createPageUrl("About")} className="hover:text-white">About</a></li>
                <li><a href="https://undercurrentlabs.ai" target="_blank" rel="noopener noreferrer" className="hover:text-white">Undercurrent Labs.AI</a></li>
                <li><a href={createPageUrl("Pricing")} className="hover:text-white">Pricing</a></li>
                <li><a href={createPageUrl("Support")} className="hover:text-white">Contact</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-sm text-center md:text-left">
              <p>© 2025 HealthScope. All rights reserved.</p>
              <p className="mt-1">
                Powered by{" "}
                <a 
                  href="https://undercurrentlabs.ai" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-emerald-400 hover:text-emerald-300 font-semibold transition-colors"
                >
                  Undercurrent Labs.AI
                </a>
              </p>
            </div>
            <div className="flex gap-6">
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="hover:text-white">Twitter</a>
              <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="hover:text-white">LinkedIn</a>
              <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="hover:text-white">GitHub</a>
            </div>
          </div>
        </div>
      </footer>
    </div>);

}