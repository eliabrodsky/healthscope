import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Coins, 
  Sparkles, 
  TrendingUp, 
  Gift, 
  CreditCard,
  CheckCircle,
  Loader2,
  Upload,
  BarChart3,
  Building2,
  Users,
  FileText
} from "lucide-react";
import { toast } from "sonner";

export default function Pricing() {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [transactions, setTransactions] = useState([]);
  const [isPurchasing, setIsPurchasing] = useState(false);

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    setIsLoading(true);
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
      
      const txns = await base44.entities.TokenTransaction.filter(
        { user_email: currentUser.email },
        '-created_date',
        20
      );
      setTransactions(txns || []);
    } catch (error) {
      console.error('Error loading user data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePurchaseTokens = async (amount) => {
    setIsPurchasing(true);
    toast.info('Token purchase coming soon - Stripe integration pending');
    setIsPurchasing(false);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-12 h-12 animate-spin text-emerald-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-emerald-50 to-teal-50 p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center">
          <Badge className="bg-emerald-100 text-emerald-700 border-emerald-300 mb-4">
            <Coins className="w-3 h-3 mr-2" />
            Tokens & Pricing
          </Badge>
          <h1 className="text-4xl font-bold mb-4">Simple, Flexible Access with Tokens</h1>
          <p className="text-gray-600 text-lg max-w-3xl mx-auto">
            Start with 100 free tokens to explore HealthScope. Use tokens for assessments, analyses, and reports. 
            Purchase more anytime or earn tokens by contributing valuable data.
          </p>
        </div>

        {/* Current Balance */}
        <Card className="border-2 border-emerald-500 bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-2xl">
          <CardContent className="p-8">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-emerald-100 text-sm mb-2">Your Current Balance</p>
                <div className="text-6xl font-bold mb-2">{user?.token_balance || 0}</div>
                <p className="text-emerald-100">Available Tokens</p>
              </div>
              <div className="text-right">
                <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center mb-3">
                  <Coins className="w-10 h-10" />
                </div>
                <div className="space-y-1 text-sm text-emerald-100">
                  <p>Purchased: {user?.total_tokens_purchased || 0}</p>
                  <p>Earned: {user?.total_tokens_earned || 0}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Pricing Plans */}
        <div className="grid md:grid-cols-3 gap-6">
          <Card className="border-2 hover:border-emerald-400 transition-all hover:shadow-xl">
            <CardContent className="p-6 text-center">
              <div className="w-16 h-16 bg-emerald-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Gift className="w-8 h-8 text-emerald-600" />
              </div>
              <h3 className="text-2xl font-bold mb-2">Free Starter</h3>
              <div className="text-4xl font-bold text-emerald-600 mb-2">100</div>
              <p className="text-gray-600 mb-6">tokens at signup</p>
              <Badge variant="outline" className="mb-4">Already applied to your account</Badge>
              <p className="text-sm text-gray-600">Perfect for trying out the platform</p>
            </CardContent>
          </Card>

          <Card className="border-2 border-emerald-500 hover:border-emerald-600 transition-all shadow-lg hover:shadow-2xl relative">
            <Badge className="absolute top-4 right-4 bg-emerald-500 text-white">Popular</Badge>
            <CardContent className="p-6 text-center">
              <div className="w-16 h-16 bg-emerald-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <CreditCard className="w-8 h-8 text-emerald-600" />
              </div>
              <h3 className="text-2xl font-bold mb-2">Token Pack</h3>
              <div className="text-4xl font-bold text-emerald-600 mb-2">100</div>
              <p className="text-gray-600 mb-6">tokens for $10</p>
              <Button 
                onClick={() => handlePurchaseTokens(100)}
                disabled={isPurchasing}
                className="w-full bg-emerald-600 hover:bg-emerald-700 mb-4"
              >
                {isPurchasing ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <CreditCard className="w-4 h-4 mr-2" />
                )}
                Purchase 100 Tokens
              </Button>
              <p className="text-sm text-gray-600">~20 assessments or analyses</p>
            </CardContent>
          </Card>

          <Card className="border-2 hover:border-emerald-400 transition-all hover:shadow-xl">
            <CardContent className="p-6 text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-2xl font-bold mb-2">Earn Tokens</h3>
              <div className="text-4xl font-bold text-purple-600 mb-2">10</div>
              <p className="text-gray-600 mb-6">tokens per contribution</p>
              <Button 
                variant="outline"
                className="w-full mb-4 border-2 border-purple-500 text-purple-600 hover:bg-purple-50"
              >
                <Upload className="w-4 h-4 mr-2" />
                Contribute Data
              </Button>
              <p className="text-sm text-gray-600">Upload CHNAs, financials, or datasets</p>
            </CardContent>
          </Card>
        </div>

        {/* Token Usage */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-emerald-600" />
              How Tokens Work
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="text-center p-4 bg-gradient-to-br from-blue-50 to-white rounded-xl border-2 border-blue-200">
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mx-auto mb-3">
                  <BarChart3 className="w-6 h-6 text-blue-600" />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Assessment</h4>
                <div className="text-3xl font-bold text-blue-600 mb-1">5</div>
                <p className="text-sm text-gray-600">tokens per run</p>
              </div>
              <div className="text-center p-4 bg-gradient-to-br from-emerald-50 to-white rounded-xl border-2 border-emerald-200">
                <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center mx-auto mb-3">
                  <Building2 className="w-6 h-6 text-emerald-600" />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Competitor Analysis</h4>
                <div className="text-3xl font-bold text-emerald-600 mb-1">5</div>
                <p className="text-sm text-gray-600">tokens per analysis</p>
              </div>
              <div className="text-center p-4 bg-gradient-to-br from-purple-50 to-white rounded-xl border-2 border-purple-200">
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-3">
                  <Users className="w-6 h-6 text-purple-600" />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Regional Analysis</h4>
                <div className="text-3xl font-bold text-purple-600 mb-1">5</div>
                <p className="text-sm text-gray-600">tokens per analysis</p>
              </div>
              <div className="text-center p-4 bg-gradient-to-br from-amber-50 to-white rounded-xl border-2 border-amber-200">
                <div className="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center mx-auto mb-3">
                  <FileText className="w-6 h-6 text-amber-600" />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">Presentation Export</h4>
                <div className="text-3xl font-bold text-amber-600 mb-1">5</div>
                <p className="text-sm text-gray-600">tokens per export</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Transaction History */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Transactions</CardTitle>
          </CardHeader>
          <CardContent>
            {transactions.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Coins className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                <p>No transactions yet</p>
              </div>
            ) : (
              <div className="space-y-2">
                {transactions.map((txn) => (
                  <div key={txn.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                        txn.amount > 0 ? 'bg-green-100' : 'bg-red-100'
                      }`}>
                        {txn.type === 'purchase' ? <CreditCard className="w-5 h-5 text-green-600" /> :
                         txn.type === 'reward_contribution' ? <Gift className="w-5 h-5 text-green-600" /> :
                         txn.type === 'grant_signup' ? <Sparkles className="w-5 h-5 text-green-600" /> :
                         <Coins className="w-5 h-5 text-red-600" />}
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900">{txn.description}</p>
                        <p className="text-sm text-gray-600">{new Date(txn.created_date).toLocaleString()}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`text-lg font-bold ${txn.amount > 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {txn.amount > 0 ? '+' : ''}{txn.amount}
                      </p>
                      <p className="text-sm text-gray-500">Balance: {txn.balance_after}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Earn Tokens */}
        <Card className="border-2 border-purple-300 bg-gradient-to-br from-purple-50 to-white">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Gift className="w-6 h-6 text-purple-600" />
              Earn Free Tokens
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-gray-700">
              Upload high-quality CHNAs, hospital financials, or regional datasets that don't yet exist in our library 
              and make them public to earn <strong>10 tokens</strong> per approved dataset.
            </p>
            <div className="bg-purple-50 p-4 rounded-lg border-2 border-purple-200">
              <h4 className="font-semibold text-gray-900 mb-3">Eligible Data Types:</h4>
              <div className="grid md:grid-cols-2 gap-3">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-purple-600" />
                  <span className="text-sm">Community Health Needs Assessments (CHNAs)</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-purple-600" />
                  <span className="text-sm">Hospital or clinic financial reports</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-purple-600" />
                  <span className="text-sm">Local population or utilization datasets</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-purple-600" />
                  <span className="text-sm">Regional health statistics and research data</span>
                </div>
              </div>
            </div>
            <Button className="w-full bg-purple-600 hover:bg-purple-700">
              <Upload className="w-4 h-4 mr-2" />
              Upload Dataset to Earn Tokens
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}