import React, { useState, useEffect, useMemo } from "react";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Building2,
  Search,
  MapPin,
  TrendingUp,
  Users,
  Loader2,
  ArrowRight,
  AlertCircle,
  BarChart3,
  RefreshCw,
  CheckCircle,
  Database,
  Target,
  Save,
  FileText,
  ExternalLink,
  Plus,
  Grid3x3,
  List,
  Trash2,
  Calendar,
  User
} from "lucide-react";
import CompetitorDetailView from "../components/competitor_analysis/CompetitorDetailView";
import CompetitorComparisonView from "../components/competitor_analysis/CompetitorComparisonView";
import CompetitorBubbleChart from "../components/competitor_analysis/CompetitorBubbleChart";
import CompetitorAIInsights from "../components/competitor_analysis/CompetitorAIInsights";
import MarketShareMap from "../components/competitor_analysis/MarketShareMap";
import DownloadableTable from "../components/competitor_analysis/DownloadableTable";
import GooglePlacesEnricher from "../components/data/GooglePlacesEnricher";
import GooglePlacesWarningDialog from "../components/data/GooglePlacesWarningDialog";

export default function CompetitorAnalysis() {
  const [assessments, setAssessments] = useState([]);
  const [savedAnalyses, setSavedAnalyses] = useState([]);
  const [filteredAnalyses, setFilteredAnalyses] = useState([]);
  const [selectedAnalysis, setSelectedAnalysis] = useState(null);
  const [selectedAssessment, setSelectedAssessment] = useState(null);
  const [competitors, setCompetitors] = useState([]);
  const [selectedCompetitor, setSelectedCompetitor] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [view, setView] = useState("list");
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [viewMode, setViewMode] = useState("list");
  const [selectedIds, setSelectedIds] = useState(new Set());
  const [isDeleting, setIsDeleting] = useState(false);
  const [selectedForComparison, setSelectedForComparison] = useState([]);
  const [currentStep, setCurrentStep] = useState(1);
  const [dataLoaded, setDataLoaded] = useState(false);
  const [noAccessZips, setNoAccessZips] = useState([]);
  const [dataSources, setDataSources] = useState([]);
  const [showPlacesEnricher, setShowPlacesEnricher] = useState(false);
  const [showPlacesWarning, setShowPlacesWarning] = useState(false);

  useEffect(() => {
    loadInitialData();
  }, []);

  useEffect(() => {
    let filtered = savedAnalyses;

    if (searchTerm) {
      filtered = filtered.filter(analysis =>
        analysis.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (analysis.assessment_title && analysis.assessment_title.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }

    if (statusFilter !== "all") {
      filtered = filtered.filter(analysis => analysis.status === statusFilter);
    }

    setFilteredAnalyses(filtered);
  }, [savedAnalyses, searchTerm, statusFilter]);

  const loadInitialData = async () => {
    setIsLoading(true);
    try {
      const [assessmentsData, analysesData] = await Promise.all([
        base44.entities.Assessment.list('-updated_date', 50),
        base44.entities.CompetitorAnalysis.list('-updated_date', 50)
      ]);
      setAssessments(assessmentsData || []);
      setSavedAnalyses(analysesData || []);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadCompetitors = async () => {
    if (!selectedAssessment) return;
    
    setIsLoading(true);
    const sources = [];
    
    try {
      const orgs = selectedAssessment.organizations || [];
      
      let enriched = orgs.map(org => {
        const siteCount = org.sites?.length || 1;
        const patientVolume = org.patient_volume || 0;
        
        return {
          ...org,
          total_sites: siteCount,
          total_patients: patientVolume,
          patients_per_site: siteCount > 0 ? Math.round(patientVolume / siteCount) : 0,
          service_area_zips: org.sites?.map(s => s.zip_code).filter(Boolean) || [],
          data_source: 'Assessment Data'
        };
      });

      const hospitals = enriched.filter(o => o.type === 'hospital');
      const fqhcs = enriched.filter(o => o.type === 'fqhc');
      const clinics = enriched.filter(o => o.type === 'clinic');

      try {
        // Enrich Hospitals from CMS data and web sources
        if (hospitals.length > 0) {
          toast.loading(`Enriching ${hospitals.length} hospitals...`, { id: 'enrich-hospitals' });
          const hospitalResponse = await base44.functions.invoke('enrichHospitalData', { 
            hospitals: hospitals.slice(0, 10),
            assessmentId: selectedAssessment?.id
          });
          
          if (hospitalResponse?.data?.success) {
            let enrichedCount = 0;
            let invalidCount = 0;
            
            hospitalResponse.data.enriched.forEach(enrichedHospital => {
              const idx = enriched.findIndex(e => e.id === enrichedHospital.organization_id);
              if (idx !== -1) {
                if (enrichedHospital.is_valid && enrichedHospital.annual_patients > 0) {
                  enriched[idx] = { 
                    ...enriched[idx], 
                    ...enrichedHospital,
                    total_patients: enrichedHospital.annual_patients,
                    total_revenue: enrichedHospital.revenue || 0,
                    patients_per_site: Math.round(enrichedHospital.annual_patients / (enriched[idx].total_sites || 1)),
                    data_source: enrichedHospital.source || 'CMS/Web Data',
                    data_confidence: enrichedHospital.confidence,
                    has_valid_data: true
                  };
                  enrichedCount++;
                } else {
                  // Mark as invalid data
                  enriched[idx] = {
                    ...enriched[idx],
                    has_valid_data: false,
                    data_error: enrichedHospital.validation_message || 'No patient data available',
                    data_source: 'Data Unavailable'
                  };
                  invalidCount++;
                }
              }
            });
            
            sources.push({
              source: 'CMS Medicare + Web Search',
              type: 'hospital',
              count: enrichedCount,
              fields: ['annual_patients', 'beds', 'revenue', 'admissions']
            });
            
            if (invalidCount > 0) {
              toast.warning(`Enriched ${enrichedCount} hospitals. ${invalidCount} have missing data.`, { id: 'enrich-hospitals' });
            } else {
              toast.success(`Enriched ${enrichedCount} hospitals`, { id: 'enrich-hospitals' });
            }
            
            // Show warning for hospitals with no data
            if (hospitalResponse.data.warning) {
              console.warn('Hospital enrichment warning:', hospitalResponse.data.warning);
            }
          } else {
            toast.error('Hospital enrichment failed', { id: 'enrich-hospitals' });
          }
        }

        // Enrich FQHCs from FQHC API (UDS data)
        if (fqhcs.length > 0) {
          toast.loading(`Enriching ${fqhcs.length} FQHCs from UDS...`, { id: 'enrich-fqhcs' });
          const fqhcResponse = await base44.functions.invoke('enrichFqhcData', { 
            fqhcs: fqhcs.slice(0, 15),
            year: 2023
          });
          
          if (fqhcResponse?.data?.success) {
            let enrichedCount = 0;
            let invalidCount = 0;
            
            fqhcResponse.data.enriched.forEach(enrichedFqhc => {
              const idx = enriched.findIndex(e => e.id === enrichedFqhc.organization_id);
              if (idx !== -1) {
                if (enrichedFqhc.is_valid && enrichedFqhc.total_patients > 0) {
                  enriched[idx] = { 
                    ...enriched[idx], 
                    ...enrichedFqhc,
                    total_patients: enrichedFqhc.total_patients,
                    payer_mix: enrichedFqhc.payer_mix,
                    patients_per_site: Math.round(enrichedFqhc.total_patients / (enriched[idx].total_sites || 1)),
                    data_source: 'FQHC API (UDS 2023)',
                    has_valid_data: true
                  };
                  enrichedCount++;
                } else {
                  enriched[idx] = {
                    ...enriched[idx],
                    has_valid_data: false,
                    data_error: enrichedFqhc.validation_message || 'No UDS data available',
                    data_source: 'Data Unavailable'
                  };
                  invalidCount++;
                }
              }
            });
            
            sources.push({
              source: 'FQHC API (UDS 2023)',
              type: 'fqhc',
              count: enrichedCount,
              fields: ['total_patients', 'payer_mix', 'service_area_zips', 'medicaid_patients']
            });
            
            if (invalidCount > 0) {
              toast.warning(`Enriched ${enrichedCount} FQHCs. ${invalidCount} have missing data.`, { id: 'enrich-fqhcs' });
            } else {
              toast.success(`Enriched ${enrichedCount} FQHCs`, { id: 'enrich-fqhcs' });
            }
          } else {
            toast.error('FQHC enrichment failed', { id: 'enrich-fqhcs' });
          }
        }

        // Enrich Clinics from web
        if (clinics.length > 0) {
          toast.loading(`Enriching ${clinics.length} clinics...`, { id: 'enrich-clinics' });
          const clinicResponse = await base44.functions.invoke('enrichClinicData', { 
            clinics: clinics.slice(0, 10) 
          });
          
          if (clinicResponse?.data?.success) {
            let enrichedCount = 0;
            clinicResponse.data.enriched.forEach(enrichedClinic => {
              const idx = enriched.findIndex(e => e.id === enrichedClinic.organization_id);
              if (idx !== -1 && enrichedClinic.estimated_annual_patients > 0) {
                enriched[idx] = { 
                  ...enriched[idx], 
                  ...enrichedClinic,
                  total_patients: enrichedClinic.estimated_annual_patients,
                  patients_per_site: Math.round(enrichedClinic.estimated_annual_patients / (enriched[idx].total_sites || 1)),
                  data_source: 'Web Search'
                };
                enrichedCount++;
              }
            });
            sources.push({
              source: 'Web Search',
              type: 'clinic',
              count: enrichedCount,
              fields: ['estimated_annual_patients', 'services']
            });
            toast.success(`Enriched ${enrichedCount} clinics`, { id: 'enrich-clinics' });
          } else {
            toast.dismiss('enrich-clinics');
          }
        }
      } catch (enrichError) {
        console.warn('Error enriching competitor data:', enrichError);
        toast.error('Some data enrichment failed');
      }

      // Calculate service area ZIPs
      enriched = enriched.map(comp => {
        const allZips = [...new Set([
          ...(comp.service_area_zips || []),
          ...(comp.sites?.map(s => s.zip_code).filter(Boolean) || []),
          comp.zip_code
        ].filter(Boolean))];
        
        return {
          ...comp,
          service_area_zips: allZips
        };
      });
      
      setCompetitors(enriched);
      setDataSources(sources);
      
    } catch (error) {
      console.error('Error loading competitors:', error);
      toast.error('Failed to load competitor data');
    } finally {
      setIsLoading(false);
    }
  };

  const dominantCompetitor = useMemo(() => {
    if (competitors.length === 0) return null;
    return competitors.reduce((max, c) => 
      (c.total_patients || 0) > (max.total_patients || 0) ? c : max
    );
  }, [competitors]);

  const steps = [
    { id: 1, name: 'Select Assessment', icon: MapPin },
    { id: 2, name: 'Load Data', icon: Database },
    { id: 3, name: 'Visualize', icon: BarChart3 },
    { id: 4, name: 'Analyze', icon: Target },
    { id: 5, name: 'Review & Save', icon: Save },
  ];

  const handleLoadAllData = async () => {
    setIsLoading(true);
    setDataLoaded(false);
    
    try {
      await loadCompetitors();
      setDataLoaded(true);
      setCurrentStep(3);
    } catch (error) {
      console.error('Data loading error:', error);
      toast.error('Failed to load data');
    } finally {
      setIsLoading(false);
    }
  };

  const identifyNoAccessZips = () => {
    const zipCodes = selectedAssessment?.processed_data?.zcta_codes || 
                    selectedAssessment?.geography?.zcta_codes || [];
    const censusData = selectedAssessment?.processed_data?.census_data || {};
    
    const noAccess = zipCodes.filter(zip => {
      const hasCompetitor = competitors.some(c => 
        (c.service_area_zips || []).includes(zip)
      );
      return !hasCompetitor;
    }).map(zip => ({
      zip_code: zip,
      population: censusData[zip]?.population || 0
    }));
    
    setNoAccessZips(noAccess);
  };

  const toggleSelection = (id) => {
    const newSelected = new Set(selectedIds);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedIds(newSelected);
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === filteredAnalyses.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredAnalyses.map(a => a.id)));
    }
  };

  const handleBulkDelete = async () => {
    if (selectedIds.size === 0) return;

    const confirmed = confirm(
      `Are you sure you want to delete ${selectedIds.size} analysis${selectedIds.size > 1 ? 'es' : ''}? This action cannot be undone.`
    );

    if (!confirmed) return;

    setIsDeleting(true);
    toast.loading(`Deleting ${selectedIds.size} analyses...`, { id: 'bulk-delete' });

    try {
      const deletePromises = Array.from(selectedIds).map(id =>
        base44.entities.CompetitorAnalysis.delete(id)
      );

      await Promise.all(deletePromises);

      toast.success(`Successfully deleted ${selectedIds.size} analysis${selectedIds.size > 1 ? 'es' : ''}!`, {
        id: 'bulk-delete'
      });

      setSelectedIds(new Set());
      await loadInitialData();
    } catch (error) {
      console.error('Error deleting analyses:', error);
      toast.error('Failed to delete some analyses', { id: 'bulk-delete' });
    } finally {
      setIsDeleting(false);
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      draft: "bg-yellow-50 text-yellow-700 border-yellow-200",
      published: "bg-emerald-50 text-emerald-700 border-emerald-200"
    };
    return colors[status] || colors.draft;
  };

  if (isLoading && view === 'list') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="bg-white p-8 rounded-2xl shadow-xl flex flex-col items-center border border-slate-100">
          <div className="relative">
            <div className="w-16 h-16 border-4 border-emerald-100 border-t-emerald-500 rounded-full animate-spin"></div>
            <div className="absolute inset-0 flex items-center justify-center">
              <Building2 className="w-6 h-6 text-emerald-600" />
            </div>
          </div>
          <h3 className="mt-6 text-lg font-bold text-slate-900">Loading Analyses</h3>
          <p className="text-slate-500 mt-2">Fetching competitor analyses...</p>
        </div>
      </div>
    );
  }

  if (view === "detail" && selectedCompetitor) {
    return (
      <CompetitorDetailView
        competitor={selectedCompetitor}
        assessment={selectedAssessment}
        onBack={() => {
          setView("wizard");
          setSelectedCompetitor(null);
        }}
      />
    );
  }

  if (view === "compare" && selectedForComparison.length >= 2) {
    return (
      <CompetitorComparisonView
        competitors={selectedForComparison}
        assessment={selectedAssessment}
        onBack={() => setView("wizard")}
        onRemoveCompetitor={(id) => {
          setSelectedForComparison(prev => prev.filter(c => c.id !== id));
          if (selectedForComparison.length <= 2) {
            setView("wizard");
          }
        }}
      />
    );
  }

  // List View
  if (view === "list") {
    return (
      <div className="min-h-screen p-4 md:p-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="bg-white rounded-xl p-6 border-2 border-emerald-500 shadow-sm mb-8">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0">
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/f985cab57_competitoranalysis.png"
                  alt="Competitor Analysis"
                  className="w-20 h-20"
                />
              </div>
              <div className="flex-1">
                <h1 className="text-3xl font-bold mb-2 text-gray-900">Competitor Analysis</h1>
                <p className="text-gray-600 text-sm leading-relaxed">
                  Deep dive into healthcare organizations operating in your region. Compare patient volumes, service locations, 
                  and market presence to identify competitive dynamics and partnership opportunities.
                </p>
              </div>
            </div>
          </div>

          {/* Count and Actions */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
            <div>
              <p className="text-gray-600 mt-2">
                {savedAnalyses.length} total analysis{savedAnalyses.length !== 1 ? 'es' : ''}
                {selectedIds.size > 0 && ` • ${selectedIds.size} selected`}
              </p>
            </div>

            <div className="flex gap-2 w-full md:w-auto">
              {selectedIds.size > 0 && (
                <Button
                  onClick={handleBulkDelete}
                  disabled={isDeleting}
                  variant="destructive"
                  className="flex-1 md:flex-initial"
                >
                  {isDeleting ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Trash2 className="w-4 h-4 mr-2" />
                  )}
                  Delete {selectedIds.size}
                </Button>
              )}
              
              <Button
                onClick={() => {
                  setView('wizard');
                  setCurrentStep(1);
                  setDataLoaded(false);
                  setSelectedAssessment(null);
                  setCompetitors([]);
                }}
                className="flex-1 md:flex-initial bg-emerald-500 hover:bg-emerald-600 text-white shadow-sm"
              >
                <Plus className="w-5 h-5 mr-2 stroke-1" />
                New Analysis
              </Button>
            </div>
          </div>

          {/* Filters and View Toggle */}
          <Card className="border-gray-200 shadow-sm mb-6">
            <CardContent className="p-4">
              <div className="flex flex-col md:flex-row gap-4">
                {/* Search */}
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 stroke-1" />
                  <Input
                    placeholder="Search analyses..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 bg-white border-gray-300 text-gray-900 placeholder:text-gray-500"
                  />
                </div>

                {/* Status Filter */}
                <div className="flex gap-2 overflow-x-auto">
                  {['all', 'draft', 'published'].map((status) => (
                    <Button
                      key={status}
                      variant={statusFilter === status ? "default" : "outline"}
                      size="sm"
                      onClick={() => setStatusFilter(status)}
                      className={statusFilter === status
                        ? "bg-emerald-500 hover:bg-emerald-600 text-white whitespace-nowrap"
                        : "border-gray-300 text-gray-700 hover:bg-gray-50 whitespace-nowrap"
                      }
                    >
                      {status.charAt(0).toUpperCase() + status.slice(1)}
                    </Button>
                  ))}
                </div>

                {/* View Mode Toggle */}
                <div className="flex gap-1 border border-gray-300 rounded-lg p-1 h-9">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setViewMode('grid')}
                    className={`h-7 ${viewMode === 'grid' ? 'bg-gray-100' : ''}`}
                  >
                    <Grid3x3 className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setViewMode('list')}
                    className={`h-7 ${viewMode === 'list' ? 'bg-gray-100' : ''}`}
                  >
                    <List className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Select All (only in list view) */}
          {viewMode === 'list' && filteredAnalyses.length > 0 && !isLoading && (
            <div className="flex items-center gap-3 mb-3 px-2">
              <Checkbox
                checked={selectedIds.size === filteredAnalyses.length && filteredAnalyses.length > 0}
                onCheckedChange={toggleSelectAll}
                className="h-4 w-4"
              />
              <span className="text-sm text-gray-600">
                Select all ({filteredAnalyses.length})
              </span>
            </div>
          )}

          {/* Content */}
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 text-emerald-500 animate-spin" />
            </div>
          ) : filteredAnalyses.length > 0 ? (
            viewMode === 'list' ? (
              // List View
              <div className="space-y-3">
                {filteredAnalyses.map((analysis) => (
                  <Card key={analysis.id} className="border-gray-200 shadow-sm hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      {/* Mobile Layout */}
                      <div className="md:hidden space-y-3">
                        <div className="flex items-start gap-3">
                          <Checkbox
                            checked={selectedIds.has(analysis.id)}
                            onCheckedChange={() => toggleSelection(analysis.id)}
                            className="h-4 w-4 mt-1 flex-shrink-0"
                          />
                          <div className="flex-1 min-w-0">
                            <div className="font-semibold text-gray-900 line-clamp-2">
                              {analysis.title}
                            </div>
                            <div className="flex items-center gap-1 mt-1 text-sm text-gray-600">
                              <MapPin className="w-3 h-3 flex-shrink-0" />
                              <span className="truncate">{analysis.assessment_title}</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2 flex-wrap">
                            <Badge className={getStatusColor(analysis.status)}>
                              {analysis.status}
                            </Badge>
                            <span className="text-xs text-gray-500">
                              {new Date(analysis.created_date).toLocaleDateString()}
                            </span>
                          </div>
                          <div className="flex gap-2 flex-shrink-0">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => toast.info('Edit functionality coming soon')}
                            >
                              Edit
                            </Button>
                            <Button
                              size="sm"
                              onClick={() => {
                                setSelectedAnalysis(analysis);
                                setView('view');
                              }}
                              className="bg-emerald-500 text-white hover:bg-emerald-600"
                            >
                              View
                            </Button>
                          </div>
                        </div>
                      </div>

                      {/* Desktop Layout */}
                      <div className="hidden md:flex items-center gap-4">
                        <Checkbox
                          checked={selectedIds.has(analysis.id)}
                          onCheckedChange={() => toggleSelection(analysis.id)}
                          className="h-4 w-4 flex-shrink-0"
                        />

                        <div className="flex-1 min-w-0">
                          <div className="font-semibold text-gray-900 truncate">
                            {analysis.title}
                          </div>
                          <div className="flex items-center gap-3 mt-1 text-sm text-gray-600 flex-wrap">
                            <div className="flex items-center gap-1">
                              <MapPin className="w-3 h-3 flex-shrink-0" />
                              <span className="truncate max-w-[200px]">{analysis.assessment_title}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Calendar className="w-3 h-3 flex-shrink-0" />
                              <span className="whitespace-nowrap">{new Date(analysis.created_date).toLocaleDateString()}</span>
                            </div>
                            {analysis.created_by && (
                              <div className="flex items-center gap-1">
                                <User className="w-3 h-3 flex-shrink-0" />
                                <span className="truncate max-w-[100px]">{analysis.created_by.split('@')[0]}</span>
                              </div>
                            )}
                          </div>
                        </div>

                        <Badge className={`${getStatusColor(analysis.status)} flex-shrink-0`}>
                          {analysis.status}
                        </Badge>

                        <div className="hidden lg:flex items-center gap-1 text-sm text-gray-600 flex-shrink-0">
                          <Building2 className="w-4 h-4" />
                          <span className="whitespace-nowrap">{analysis.competitors?.length || 0} competitors</span>
                        </div>

                        <div className="flex gap-2 flex-shrink-0">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => toast.info('Edit functionality coming soon')}
                          >
                            Edit
                          </Button>
                          <Button
                            size="sm"
                            onClick={() => {
                              setSelectedAnalysis(analysis);
                              setView('view');
                            }}
                            className="bg-emerald-500 text-white hover:bg-emerald-600"
                          >
                            View
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              // Grid View
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredAnalyses.map(analysis => (
                  <Card key={analysis.id} className="hover:shadow-lg transition-shadow relative">
                    <div className="absolute top-3 left-3 z-10">
                      <Checkbox
                        checked={selectedIds.has(analysis.id)}
                        onCheckedChange={() => toggleSelection(analysis.id)}
                        className="bg-white border-2 shadow-sm h-4 w-4"
                      />
                    </div>
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex-1 mt-6">
                          <CardTitle className="text-lg mb-2">{analysis.title}</CardTitle>
                          <div className="flex gap-2 flex-wrap">
                            <Badge className={getStatusColor(analysis.status)}>
                              {analysis.status}
                            </Badge>
                            <Badge variant="outline">
                              {analysis.competitors?.length || 0} competitors
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="text-sm text-gray-600">
                        <p className="flex items-center gap-2">
                          <MapPin className="w-4 h-4" />
                          {analysis.assessment_title}
                        </p>
                        {analysis.underserved_zips?.length > 0 && (
                          <p className="flex items-center gap-2 mt-2">
                            <AlertCircle className="w-4 h-4 text-amber-600" />
                            {analysis.underserved_zips.length} underserved ZIPs
                          </p>
                        )}
                      </div>
                      <div className="flex gap-2">
                        <Button 
                          onClick={() => toast.info('Edit functionality coming soon')}
                          variant="outline"
                          className="flex-1"
                          size="sm"
                        >
                          Edit
                        </Button>
                        <Button 
                          onClick={() => {
                            setSelectedAnalysis(analysis);
                            setView('view');
                          }}
                          className="flex-1 bg-emerald-600 hover:bg-emerald-700"
                          size="sm"
                        >
                          View
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )
          ) : (
            <Card className="border-gray-200 shadow-sm">
              <CardContent className="text-center py-12">
                <Building2 className="w-16 h-16 text-gray-300 mx-auto mb-4 stroke-1" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  {savedAnalyses.length === 0 ? "No analyses created yet" : "No analyses match your filters"}
                </h3>
                <p className="text-gray-600 mb-6">
                  {savedAnalyses.length === 0
                    ? "Start by creating your first competitor analysis"
                    : "Try adjusting your search terms or filters"
                  }
                </p>
                {savedAnalyses.length === 0 && (
                  <Button
                    onClick={() => {
                      setView('wizard');
                      setCurrentStep(1);
                    }}
                    className="w-full sm:w-auto bg-emerald-500 hover:bg-emerald-600 text-white"
                  >
                    <Plus className="w-5 h-5 mr-2 stroke-1" />
                    Create Your First Analysis
                  </Button>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    );
  }

  // Wizard View
  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="bg-white rounded-xl p-6 border-2 border-emerald-500 shadow-sm">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0">
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/f985cab57_competitoranalysis.png"
                  alt="Competitor Analysis"
                  className="w-20 h-20"
                />
              </div>
              <div className="flex-1">
                <h1 className="text-3xl font-bold mb-2 text-gray-900">Competitor Analysis Wizard</h1>
                <p className="text-gray-600 text-sm leading-relaxed">
                  Deep dive into healthcare organizations operating in your region. Compare patient volumes, service locations, 
                  and market presence to identify competitive dynamics and partnership opportunities.
                </p>
              </div>
            </div>
            <Button 
              variant="outline"
              onClick={() => setView('list')}
            >
              <ArrowRight className="w-4 h-4 mr-2 rotate-180" />
              Back to List
            </Button>
          </div>
        </div>

        {/* Wizard Progress */}
        <Card className="p-6">
          <div className="flex justify-between items-center">
            {steps.map((step, index) => (
              <React.Fragment key={step.id}>
                <div className="flex items-center gap-3">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
                    currentStep > step.id ? 'bg-emerald-500 text-white' : 
                    currentStep === step.id ? 'bg-emerald-500 text-white ring-4 ring-emerald-100' : 
                    'bg-gray-200 text-gray-500'
                  }`}>
                    {currentStep > step.id ? <CheckCircle className="w-6 h-6" /> : <step.icon className="w-6 h-6" />}
                  </div>
                  <div className="hidden md:block">
                    <p className="text-xs text-gray-500">Step {step.id}</p>
                    <p className="font-semibold text-sm">{step.name}</p>
                  </div>
                </div>
                {index < steps.length - 1 && (
                  <div className={`flex-1 h-1 mx-4 rounded ${
                    currentStep > step.id ? 'bg-emerald-500' : 'bg-gray-200'
                  }`} />
                )}
              </React.Fragment>
            ))}
          </div>
        </Card>

        {/* Step 1: Assessment Selection */}
        {currentStep === 1 && (
          <Card>
            <CardHeader>
              <CardTitle>Step 1: Select Assessment</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">
                  Choose an assessment to analyze competitors
                </label>
                <Select
                  value={selectedAssessment?.id}
                  onValueChange={(id) => {
                    const assessment = assessments.find(a => a.id === id);
                    setSelectedAssessment(assessment);
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select an assessment..." />
                  </SelectTrigger>
                  <SelectContent>
                    {assessments.map(a => (
                      <SelectItem key={a.id} value={a.id}>
                        {a.title} - {a.geography?.city}, {a.geography?.state}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              {selectedAssessment && (
                <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                  <p className="text-sm text-gray-700">
                    <strong>Selected:</strong> {selectedAssessment.title}
                  </p>
                  <p className="text-sm text-gray-600 mt-1">
                    {selectedAssessment.organizations?.length || 0} organizations found
                  </p>
                </div>
              )}
              <div className="flex justify-end">
                <Button 
                  onClick={() => setCurrentStep(2)} 
                  disabled={!selectedAssessment}
                  className="bg-emerald-600 hover:bg-emerald-700"
                >
                  Next: Load Data
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Step 2: Load Data */}
        {currentStep === 2 && (
          <Card>
            <CardHeader>
              <CardTitle>Step 2: Load Competitor Data</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-600">
                Load comprehensive data for all competitors including patient volumes, services, financials, and more from HRSA UDS, web sources, and public databases.
              </p>
              
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200 space-y-2 text-sm">
                <p className="font-semibold text-gray-900">Data Sources:</p>
                <ul className="list-disc list-inside space-y-1 text-gray-700">
                  <li><strong>FQHCs:</strong> UDS 2021-2024 (patients by ZIP, payer mix, demographics, workforce, clinical quality, financials)</li>
                  <li><strong>Hospitals:</strong> CMS Medicare data + web search (admissions, beds, revenue)</li>
                  <li><strong>Clinics:</strong> AI-powered web extraction</li>
                  <li><strong>Google Places:</strong> Schools, non-profits, and other entities (5 tokens/search)</li>
                </ul>
              </div>
              
              {/* Google Places Toggle */}
              <div className="bg-amber-50 p-4 rounded-lg border border-amber-200">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold text-amber-900">Google Places Enrichment</p>
                    <p className="text-sm text-amber-700">Search for schools, non-profits, and community organizations</p>
                  </div>
                  <Button
                    variant="outline"
                    onClick={() => setShowPlacesWarning(true)}
                    className="border-amber-300 text-amber-700 hover:bg-amber-100"
                  >
                    Enable (5 tokens)
                  </Button>
                </div>
                
                {showPlacesEnricher && selectedAssessment && (
                  <div className="mt-4 pt-4 border-t border-amber-200">
                    <GooglePlacesEnricher
                      latitude={selectedAssessment.geography?.latitude}
                      longitude={selectedAssessment.geography?.longitude}
                      onResultsFound={(results) => {
                        toast.success(`Found ${results.length} places`);
                      }}
                      onEnrichComplete={(enrichedPlaces) => {
                        const newCompetitors = enrichedPlaces.map(place => ({
                          id: `gp_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                          name: place.name,
                          type: 'other',
                          address: place.address,
                          coordinates: place.coordinates,
                          source: 'Google Places',
                          total_sites: 1
                        }));
                        setCompetitors(prev => [...prev, ...newCompetitors]);
                        toast.success(`Added ${newCompetitors.length} organizations`);
                      }}
                    />
                  </div>
                )}
              </div>
              
              <GooglePlacesWarningDialog
                open={showPlacesWarning}
                onOpenChange={setShowPlacesWarning}
                onConfirm={() => {
                  setShowPlacesWarning(false);
                  setShowPlacesEnricher(true);
                }}
              />

              {dataLoaded && dataSources.length > 0 && (
                <div className="bg-green-50 border-2 border-green-200 rounded-lg p-4">
                  <h4 className="font-semibold text-green-900 mb-3 flex items-center gap-2">
                    <CheckCircle className="w-5 h-5" />
                    Data Loaded Successfully
                  </h4>
                  <div className="space-y-2">
                    {dataSources.map((source, idx) => (
                      <div key={idx} className="flex items-center justify-between p-2 bg-white rounded border border-green-200">
                        <div>
                          <p className="text-sm font-medium text-gray-900">{source.source}</p>
                          <Badge className="mt-1 capitalize text-xs">{source.type}</Badge>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-bold text-green-700">{source.count}</p>
                          <p className="text-xs text-gray-600">enriched</p>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="mt-3 pt-3 border-t border-green-200">
                    <p className="text-sm text-gray-700">
                      <strong>Not loaded:</strong> {competitors.filter(c => (c.total_patients || 0) === 0).length} competitors missing data
                    </p>
                  </div>
                </div>
              )}

              <Button 
                onClick={handleLoadAllData} 
                disabled={isLoading}
                className="w-full bg-emerald-600 hover:bg-emerald-700"
                size="lg"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Loading Data...
                  </>
                ) : dataLoaded ? (
                  <>
                    <RefreshCw className="w-5 h-5 mr-2" />
                    Reload Data
                  </>
                ) : (
                  <>
                    <Database className="w-5 h-5 mr-2" />
                    Load All Competitor Data
                  </>
                )}
              </Button>
              <div className="flex justify-between pt-4">
                <Button variant="outline" onClick={() => setCurrentStep(1)}>
                  Back
                </Button>
                {dataLoaded && (
                  <Button onClick={() => setCurrentStep(3)} className="bg-emerald-600 hover:bg-emerald-700">
                    Continue to Visualize
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Step 3: Visualize */}
        {currentStep === 3 && dataLoaded && (
          <>
            <Card>
              <CardHeader>
                <CardTitle>Step 3: Charts, Tables & Maps</CardTitle>
              </CardHeader>
            </Card>

            {/* Data Quality Warning */}
            {competitors.some(c => c.has_valid_data === false) && (
              <Card className="border-2 border-amber-300 bg-amber-50">
                <CardContent className="py-4">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="w-5 h-5 text-amber-600 mt-0.5" />
                    <div>
                      <p className="font-semibold text-amber-900">Data Quality Notice</p>
                      <p className="text-sm text-amber-800 mt-1">
                        {competitors.filter(c => c.has_valid_data === false).length} competitor(s) have missing or invalid patient data. 
                        Results for these organizations may be incomplete.
                      </p>
                      <div className="mt-2 flex flex-wrap gap-2">
                        {competitors.filter(c => c.has_valid_data === false).slice(0, 5).map(c => (
                          <Badge key={c.id} variant="outline" className="bg-white text-amber-700 border-amber-300">
                            {c.name}
                          </Badge>
                        ))}
                        {competitors.filter(c => c.has_valid_data === false).length > 5 && (
                          <Badge variant="outline" className="bg-white text-amber-700 border-amber-300">
                            +{competitors.filter(c => c.has_valid_data === false).length - 5} more
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Summary Stats */}
            <div className="grid md:grid-cols-4 gap-6">
              <Card className="bg-gradient-to-br from-blue-50 to-white border-blue-200">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-gray-600">Total Competitors</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-emerald-600 bg-clip-text text-transparent">
                    {competitors.length}
                  </div>
                  {competitors.some(c => c.has_valid_data === false) && (
                    <p className="text-xs text-amber-600 mt-1">
                      {competitors.filter(c => c.has_valid_data !== false).length} with valid data
                    </p>
                  )}
                </CardContent>
              </Card>
              <Card className="bg-gradient-to-br from-emerald-50 to-white border-emerald-200">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-gray-600">Total Sites</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
                    {competitors.reduce((sum, c) => sum + (c.total_sites || 0), 0)}
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-gradient-to-br from-purple-50 to-white border-purple-200">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-gray-600">Total Patients</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                    {competitors.filter(c => c.has_valid_data !== false).reduce((sum, c) => sum + (c.total_patients || 0), 0).toLocaleString()}
                  </div>
                  <p className="text-xs text-gray-500 mt-1">From validated sources only</p>
                </CardContent>
              </Card>
              <Card className="bg-gradient-to-br from-amber-50 to-white border-amber-200">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-gray-600">Dominant Player</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-sm font-bold text-gray-900 truncate">
                    {dominantCompetitor?.name || 'N/A'}
                  </div>
                  {dominantCompetitor?.total_patients > 0 && (
                    <p className="text-xs text-gray-500 mt-1">
                      {dominantCompetitor.total_patients.toLocaleString()} patients
                    </p>
                  )}
                </CardContent>
              </Card>
            </div>

            <CompetitorBubbleChart competitors={competitors} />
            <MarketShareMap competitors={competitors} assessment={selectedAssessment} />
            
            {/* Data Sources Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5" />
                  Data Sources & Coverage
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {dataSources.length > 0 ? (
                  <>
                    <div className="grid md:grid-cols-3 gap-4">
                      {dataSources.map((source, idx) => (
                        <div key={idx} className="p-4 bg-gradient-to-br from-blue-50 to-white rounded-lg border-2 border-blue-200">
                          <div className="flex items-start justify-between mb-2">
                            <div>
                              <p className="font-semibold text-gray-900 text-sm">{source.source}</p>
                              <Badge className="mt-1 capitalize">{source.type}</Badge>
                            </div>
                            <div className="text-right">
                              <p className="text-2xl font-bold text-blue-600">{source.count}</p>
                              <p className="text-xs text-gray-600">enriched</p>
                            </div>
                          </div>
                          <div className="mt-3 pt-3 border-t border-blue-100">
                            <p className="text-xs text-gray-600 mb-1">Data fields:</p>
                            <div className="flex flex-wrap gap-1">
                              {source.fields.slice(0, 3).map((field, i) => (
                                <Badge key={i} variant="outline" className="text-xs">
                                  {field.replace(/_/g, ' ')}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h4 className="font-semibold text-gray-900 mb-3">Coverage by Competitor Type</h4>
                      <div className="space-y-2">
                        {['hospital', 'fqhc', 'clinic'].map(type => {
                          const total = competitors.filter(c => c.type === type).length;
                          const enriched = competitors.filter(c => c.type === type && c.total_patients > 0).length;
                          const percentage = total > 0 ? Math.round((enriched / total) * 100) : 0;
                          
                          return (
                            <div key={type} className="flex items-center gap-3">
                              <div className="w-24 text-sm font-medium text-gray-700 capitalize">{type}s</div>
                              <div className="flex-1 bg-gray-200 rounded-full h-6 overflow-hidden">
                                <div 
                                  className={`h-full flex items-center justify-end pr-2 text-xs font-semibold text-white transition-all ${
                                    percentage > 60 ? 'bg-green-500' : percentage > 30 ? 'bg-yellow-500' : 'bg-red-500'
                                  }`}
                                  style={{ width: `${percentage}%` }}
                                >
                                  {percentage > 15 && `${percentage}%`}
                                </div>
                              </div>
                              <div className="w-20 text-sm text-gray-600 text-right">
                                {enriched}/{total}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                      <h4 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
                        <Database className="w-4 h-4" />
                        External Data Sources
                      </h4>
                      <ul className="space-y-2 text-sm">
                        <li className="flex items-start gap-2">
                          <ExternalLink className="w-4 h-4 text-blue-600 mt-0.5" />
                          <div>
                            <strong className="text-gray-900">FQHC API (BigQuery):</strong>
                            <span className="text-gray-700 ml-1">Complete UDS data for all FQHCs (2022-2024) - grantee info, sites, service area by ZIP, patient demographics, workforce, clinical quality, and financials</span>
                          </div>
                        </li>
                        <li className="flex items-start gap-2">
                          <ExternalLink className="w-4 h-4 text-blue-600 mt-0.5" />
                          <div>
                            <strong className="text-gray-900">CMS Medicare Data:</strong>
                            <span className="text-gray-700 ml-1">Hospital inpatient charges, discharges, and payments from public Medicare claims</span>
                          </div>
                        </li>
                        <li className="flex items-start gap-2">
                          <ExternalLink className="w-4 h-4 text-blue-600 mt-0.5" />
                          <div>
                            <strong className="text-gray-900">AI Web Search:</strong>
                            <span className="text-gray-700 ml-1">Clinic data extracted from healthcare directories and organizational websites</span>
                          </div>
                        </li>
                      </ul>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-8">
                    <Database className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                    <p className="text-gray-600">No external data sources loaded yet</p>
                    <p className="text-sm text-gray-500 mt-1">Load data in Step 2 to see enrichment sources</p>
                  </div>
                )}
              </CardContent>
            </Card>

            <DownloadableTable competitors={competitors} assessment={selectedAssessment} />

            <div className="flex justify-between">
              <Button variant="outline" onClick={() => setCurrentStep(2)}>Back</Button>
              <Button onClick={() => {
                setCurrentStep(4);
                identifyNoAccessZips();
              }} className="bg-emerald-600 hover:bg-emerald-700">
                Next: Analysis
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </>
        )}

        {/* Step 4: AI Analysis */}
        {currentStep === 4 && (
          <>
            <Card>
              <CardHeader>
                <CardTitle>Step 4: Competitive Analysis & Service Gaps</CardTitle>
              </CardHeader>
            </Card>
            
            <CompetitorAIInsights competitors={competitors} assessment={selectedAssessment} />

            {/* No Access ZIPs */}
            <Card className="border-2 border-amber-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 text-amber-600" />
                  ZIP Codes with No Provider Access
                </CardTitle>
              </CardHeader>
              <CardContent>
                {noAccessZips.length === 0 ? (
                  <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                    <p className="text-green-800 font-medium">✓ All ZIP codes have at least one provider!</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="bg-amber-50 p-4 rounded-lg border border-amber-200">
                      <p className="text-sm text-amber-900 font-semibold mb-2">
                        ⚠ {noAccessZips.length} ZIP codes lack healthcare provider coverage
                      </p>
                      <p className="text-sm text-gray-700">
                        Total underserved population: {noAccessZips.reduce((sum, z) => sum + z.population, 0).toLocaleString()}
                      </p>
                    </div>
                    <div className="grid md:grid-cols-3 gap-3">
                      {noAccessZips.slice(0, 12).map(zip => (
                        <div key={zip.zip_code} className="p-3 bg-white rounded-lg border-2 border-amber-300 hover:shadow-md transition-shadow">
                          <p className="font-semibold text-gray-900">ZIP {zip.zip_code}</p>
                          <p className="text-sm text-gray-600">Pop: {zip.population.toLocaleString()}</p>
                          <Badge className="mt-2 bg-amber-100 text-amber-800">Underserved</Badge>
                        </div>
                      ))}
                    </div>
                    {noAccessZips.length > 12 && (
                      <p className="text-sm text-gray-500 mt-2">
                        ...and {noAccessZips.length - 12} more underserved ZIP codes
                      </p>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="flex justify-between">
              <Button variant="outline" onClick={() => setCurrentStep(3)}>Back</Button>
              <Button onClick={() => setCurrentStep(5)} className="bg-emerald-600 hover:bg-emerald-700">
                Next: Review & Save
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </>
        )}

        {/* Step 5: Review & Save */}
        {currentStep === 5 && (
          <Card>
            <CardHeader>
              <CardTitle>Step 5: Review & Save Analysis</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-gradient-to-br from-green-50 to-emerald-50 p-6 rounded-lg border-2 border-green-200">
                <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                  Analysis Complete!
                </h3>
                <div className="grid md:grid-cols-2 gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>Analyzed <strong>{competitors.length}</strong> competitors</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>Loaded data from HRSA & web sources</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>Generated interactive visualizations</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>Identified <strong>{noAccessZips.length}</strong> underserved ZIPs</span>
                  </div>
                </div>
              </div>
              <Button 
                className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700" 
                size="lg" 
                onClick={async () => {
                  try {
                    const newAnalysis = await base44.entities.CompetitorAnalysis.create({
                      title: `${selectedAssessment.title} - Competitor Analysis`,
                      assessment_id: selectedAssessment.id,
                      assessment_title: selectedAssessment.title,
                      competitors: competitors,
                      underserved_zips: noAccessZips.map(z => z.zip_code),
                      data_sources: dataSources,
                      status: 'draft'
                    });
                    toast.success('Competitor analysis saved!');
                    await loadInitialData();
                    setView('list');
                    setCurrentStep(1);
                    setDataLoaded(false);
                    setSelectedAssessment(null);
                    setCompetitors([]);
                  } catch (error) {
                    console.error('Failed to save:', error);
                    toast.error('Failed to save analysis');
                  }
                }}
              >
                <Save className="w-5 h-5 mr-2" />
                Save Competitor Analysis
              </Button>
              <div className="flex justify-between pt-4">
                <Button variant="outline" onClick={() => setCurrentStep(4)}>Back</Button>
                <Button variant="outline" onClick={() => setView('list')}>
                  Back to List
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}