import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Plus, Eye, Trash2, MapPin, Calendar, Edit, EyeOff, Search, Grid3x3, List, Loader2, User } from "lucide-react";
import { toast } from "sonner";
import { createPageUrl } from "@/utils";
import RegionalAnalysisWizard from "../components/regional_analysis/RegionalAnalysisWizard";
import RegionalAnalysisView from "../components/regional_analysis/RegionalAnalysisView";

export default function RegionalAnalysis() {
  const [analyses, setAnalyses] = useState([]);
  const [filteredAnalyses, setFilteredAnalyses] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showWizard, setShowWizard] = useState(false);
  const [selectedAnalysis, setSelectedAnalysis] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [viewMode, setViewMode] = useState("list");
  const [selectedIds, setSelectedIds] = useState(new Set());
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    loadAnalyses();
  }, []);

  useEffect(() => {
    let filtered = analyses;

    if (searchTerm) {
      filtered = filtered.filter(analysis =>
        analysis.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        analysis.assessment_title?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (statusFilter !== "all") {
      filtered = filtered.filter(analysis => analysis.status === statusFilter);
    }

    setFilteredAnalyses(filtered);
  }, [analyses, searchTerm, statusFilter]);

  const loadAnalyses = async () => {
    setIsLoading(true);
    try {
      const data = await base44.entities.RegionalAnalysis.list('-created_date', 100);
      setAnalyses(data || []);
    } catch (error) {
      console.error('Error loading analyses:', error);
      toast.error('Failed to load regional analyses');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (!confirm('Are you sure you want to delete this regional analysis?')) return;
    
    try {
      await base44.entities.RegionalAnalysis.delete(id);
      toast.success('Regional analysis deleted');
      loadAnalyses();
    } catch (error) {
      console.error('Error deleting analysis:', error);
      toast.error('Failed to delete analysis');
    }
  };

  const handleWizardComplete = () => {
    setShowWizard(false);
    loadAnalyses();
  };

  const toggleSelection = (id) => {
    const newSelected = new Set(selectedIds);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedIds(newSelected);
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === filteredAnalyses.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredAnalyses.map(a => a.id)));
    }
  };

  const handleBulkDelete = async () => {
    if (selectedIds.size === 0) return;

    const confirmed = confirm(
      `Are you sure you want to delete ${selectedIds.size} analysis${selectedIds.size > 1 ? 'es' : ''}? This action cannot be undone.`
    );

    if (!confirmed) return;

    setIsDeleting(true);
    toast.loading(`Deleting ${selectedIds.size} analyses...`, { id: 'bulk-delete' });

    try {
      const deletePromises = Array.from(selectedIds).map(id =>
        base44.entities.RegionalAnalysis.delete(id)
      );

      await Promise.all(deletePromises);

      toast.success(`Successfully deleted ${selectedIds.size} analysis${selectedIds.size > 1 ? 'es' : ''}!`, {
        id: 'bulk-delete'
      });

      setSelectedIds(new Set());
      await loadAnalyses();
    } catch (error) {
      console.error('Error deleting analyses:', error);
      toast.error('Failed to delete some analyses', { id: 'bulk-delete' });
    } finally {
      setIsDeleting(false);
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      draft: "bg-yellow-50 text-yellow-700 border-yellow-200",
      published: "bg-emerald-50 text-emerald-700 border-emerald-200"
    };
    return colors[status] || colors.draft;
  };

  if (showWizard) {
    return <RegionalAnalysisWizard onComplete={handleWizardComplete} onCancel={() => setShowWizard(false)} />;
  }

  if (selectedAnalysis) {
    return (
      <RegionalAnalysisView 
        analysis={selectedAnalysis} 
        onBack={() => setSelectedAnalysis(null)}
        onEdit={() => {
          setSelectedAnalysis(null);
          setShowWizard(true);
        }}
        onDelete={async () => {
          if (!confirm('Are you sure you want to delete this regional analysis?')) return;
          try {
            await base44.entities.RegionalAnalysis.delete(selectedAnalysis.id);
            toast.success('Regional analysis deleted');
            setSelectedAnalysis(null);
            loadAnalyses();
          } catch (error) {
            console.error('Error deleting analysis:', error);
            toast.error('Failed to delete analysis');
          }
        }}
        onUnpublish={async () => {
          if (!confirm('Unpublish this regional analysis?')) return;
          try {
            await base44.entities.RegionalAnalysis.update(selectedAnalysis.id, { status: 'draft' });
            toast.success('Regional analysis unpublished');
            setSelectedAnalysis(null);
            loadAnalyses();
          } catch (error) {
            console.error('Error unpublishing analysis:', error);
            toast.error('Failed to unpublish analysis');
          }
        }}
      />
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8 bg-gray-50">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-xl p-6 border-2 border-emerald-500 shadow-sm mb-8">
          <div className="flex items-start gap-4">
            <div className="flex-shrink-0">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/3142a027d_dataanalysis.png"
                alt="Regional Analysis"
                className="w-20 h-20"
              />
            </div>
            <div className="flex-1">
              <h1 className="text-3xl font-bold mb-2 text-gray-900">Regional Analysis</h1>
              <p className="text-gray-600 text-sm leading-relaxed">
                Compare demographics, health indicators, and FQHC data across ZIP codes. 
                Includes Census ACS data, CDC health indicators, and complete UDS FQHC data 
                (service areas, workforce, clinical quality, financials).
              </p>
            </div>
          </div>
        </div>

        {/* Count and Actions */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <div>
            <p className="text-gray-600 mt-2">
              {analyses.length} total analysis{analyses.length !== 1 ? 'es' : ''}
              {selectedIds.size > 0 && ` • ${selectedIds.size} selected`}
            </p>
          </div>

          <div className="flex gap-2 w-full md:w-auto">
            {selectedIds.size > 0 && (
              <Button
                onClick={handleBulkDelete}
                disabled={isDeleting}
                variant="destructive"
                className="flex-1 md:flex-initial"
              >
                {isDeleting ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Trash2 className="w-4 h-4 mr-2" />
                )}
                Delete {selectedIds.size}
              </Button>
            )}
            
            <Button
              onClick={() => setShowWizard(true)}
              className="flex-1 md:flex-initial bg-emerald-500 hover:bg-emerald-600 text-white shadow-sm"
            >
              <Plus className="w-5 h-5 mr-2 stroke-1" />
              New Analysis
            </Button>
          </div>
        </div>

        {/* Filters and View Toggle */}
        <Card className="border-gray-200 shadow-sm mb-6">
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row gap-4">
              {/* Search */}
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 stroke-1" />
                <Input
                  placeholder="Search analyses..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-white border-gray-300 text-gray-900 placeholder:text-gray-500"
                />
              </div>

              {/* Status Filter */}
              <div className="flex gap-2 overflow-x-auto">
                {['all', 'draft', 'published'].map((status) => (
                  <Button
                    key={status}
                    variant={statusFilter === status ? "default" : "outline"}
                    size="sm"
                    onClick={() => setStatusFilter(status)}
                    className={statusFilter === status
                      ? "bg-emerald-500 hover:bg-emerald-600 text-white whitespace-nowrap"
                      : "border-gray-300 text-gray-700 hover:bg-gray-50 whitespace-nowrap"
                    }
                  >
                    {status.charAt(0).toUpperCase() + status.slice(1)}
                  </Button>
                ))}
              </div>

              {/* View Mode Toggle */}
              <div className="flex gap-1 border border-gray-300 rounded-lg p-1 h-9">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setViewMode('grid')}
                  className={`h-7 ${viewMode === 'grid' ? 'bg-gray-100' : ''}`}
                >
                  <Grid3x3 className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setViewMode('list')}
                  className={`h-7 ${viewMode === 'list' ? 'bg-gray-100' : ''}`}
                >
                  <List className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Select All (only in list view) */}
        {viewMode === 'list' && filteredAnalyses.length > 0 && !isLoading && (
          <div className="flex items-center gap-3 mb-3 px-2">
            <Checkbox
              checked={selectedIds.size === filteredAnalyses.length && filteredAnalyses.length > 0}
              onCheckedChange={toggleSelectAll}
              className="h-4 w-4"
            />
            <span className="text-sm text-gray-600">
              Select all ({filteredAnalyses.length})
            </span>
          </div>
        )}

        {/* Content */}
        {isLoading ? (
          <div className="min-h-[300px] flex items-center justify-center">
            <div className="bg-white p-8 rounded-2xl shadow-xl flex flex-col items-center border border-slate-100">
              <div className="relative">
                <div className="w-16 h-16 border-4 border-emerald-100 border-t-emerald-500 rounded-full animate-spin"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <MapPin className="w-6 h-6 text-emerald-600" />
                </div>
              </div>
              <h3 className="mt-6 text-lg font-bold text-slate-900">Loading Analyses</h3>
              <p className="text-slate-500 mt-2">Fetching regional analyses...</p>
            </div>
          </div>
        ) : filteredAnalyses.length > 0 ? (
          viewMode === 'list' ? (
            // List View
            <div className="space-y-2">
              {filteredAnalyses.map((analysis) => (
                <Card key={analysis.id} className="border-gray-200 shadow-sm hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4">
                      {/* Checkbox */}
                      <Checkbox
                        checked={selectedIds.has(analysis.id)}
                        onCheckedChange={() => toggleSelection(analysis.id)}
                        className="h-4 w-4"
                      />

                      {/* Title and Info */}
                      <div className="flex-1 min-w-0">
                        <div className="font-semibold text-gray-900 truncate">
                          {analysis.title || 'Regional Analysis'}
                        </div>
                        <div className="flex items-center gap-3 mt-1 text-sm text-gray-600 flex-wrap">
                          <div className="flex items-center gap-1">
                            <MapPin className="w-3 h-3 flex-shrink-0" />
                            <span className="truncate max-w-[180px]">{analysis.assessment_title}</span>
                          </div>
                          <div className="hidden sm:flex items-center gap-1">
                            <Calendar className="w-3 h-3 flex-shrink-0" />
                            <span className="whitespace-nowrap">{new Date(analysis.created_date).toLocaleDateString()}</span>
                          </div>
                          {analysis.created_by && (
                            <div className="hidden md:flex items-center gap-1">
                              <User className="w-3 h-3 flex-shrink-0" />
                              <span className="truncate max-w-[100px]">{analysis.created_by.split('@')[0]}</span>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Status Badge */}
                      <Badge className={getStatusColor(analysis.status)}>
                        {analysis.status}
                      </Badge>

                      {/* Stats - Hidden on mobile for cleaner layout */}
                      <div className="hidden lg:flex items-center gap-1 text-sm text-gray-600">
                        <MapPin className="w-4 h-4" />
                        <span>{analysis.zip_codes?.length || 0} ZIPs</span>
                      </div>

                      {analysis.demographics_summary && (
                        <div className="hidden xl:block text-sm text-gray-600">
                          Pop: {(analysis.demographics_summary.total_population || 0).toLocaleString()}
                        </div>
                      )}

                      {/* Actions */}
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setSelectedAnalysis(analysis);
                            setShowWizard(true);
                          }}
                        >
                          Edit
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setSelectedAnalysis(analysis)}
                          className="bg-emerald-500 text-white hover:bg-emerald-600 border-0"
                        >
                          View
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            // Grid View
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredAnalyses.map(analysis => (
                <Card key={analysis.id} className="hover:shadow-lg transition-shadow relative">
                  <div className="absolute top-3 left-3 z-10">
                    <Checkbox
                      checked={selectedIds.has(analysis.id)}
                      onCheckedChange={() => toggleSelection(analysis.id)}
                      className="bg-white border-2 shadow-sm h-4 w-4"
                    />
                  </div>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1 mt-6">
                        <CardTitle className="text-lg mb-2">{analysis.title || 'Regional Analysis'}</CardTitle>
                        <div className="flex gap-2 flex-wrap">
                          <Badge className={getStatusColor(analysis.status)}>
                            {analysis.status}
                          </Badge>
                          <Badge variant="outline">
                            {analysis.zip_codes?.length || 0} ZIPs
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="text-sm text-gray-600">
                      <p className="flex items-center gap-2">
                        <MapPin className="w-4 h-4" />
                        {analysis.assessment_title}
                      </p>
                      {analysis.demographics_summary && (
                        <div className="mt-2 space-y-1">
                          <p>Pop: {(analysis.demographics_summary.total_population || 0).toLocaleString()}</p>
                          <p>Median Income: ${Math.abs(analysis.demographics_summary.avg_income || 0).toLocaleString()}</p>
                        </div>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        onClick={() => {
                          setSelectedAnalysis(analysis);
                          setShowWizard(true);
                        }}
                        variant="outline"
                        className="flex-1"
                        size="sm"
                      >
                        Edit
                      </Button>
                      <Button 
                        onClick={() => setSelectedAnalysis(analysis)}
                        className="flex-1 bg-emerald-600 hover:bg-emerald-700"
                        size="sm"
                      >
                        View
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )
        ) : (
          <Card className="border-gray-200 shadow-sm">
            <CardContent className="text-center py-12">
              <MapPin className="w-16 h-16 text-gray-300 mx-auto mb-4 stroke-1" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                {analyses.length === 0 ? "No analyses created yet" : "No analyses match your filters"}
              </h3>
              <p className="text-gray-600 mb-6">
                {analyses.length === 0
                  ? "Start by creating your first regional analysis"
                  : "Try adjusting your search terms or filters"
                }
              </p>
              {analyses.length === 0 && (
                <Button
                  onClick={() => setShowWizard(true)}
                  className="w-full sm:w-auto bg-emerald-500 hover:bg-emerald-600 text-white"
                >
                  <Plus className="w-5 h-5 mr-2 stroke-1" />
                  Create Your First Analysis
                </Button>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}