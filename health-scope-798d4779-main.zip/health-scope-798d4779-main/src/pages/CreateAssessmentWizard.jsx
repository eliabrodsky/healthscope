import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { ArrowLeft, ArrowRight, CheckCircle, Database, Map, LayoutDashboard, Flag, MapPin, Building } from 'lucide-react';
import { toast, Toaster } from 'sonner';

import Step1Geography from '../components/wizard/Step1_Geography';
import Step2LoadBoundaries from '../components/wizard/Step2_LoadBoundaries';
import Step3LoadDemographics from '../components/wizard/Step4_LoadDemographics';
import Step4LoadCompetitors from '../components/wizard/Step3_LoadCompetitors';
import Step5LoadCities from '../components/wizard/Step5_LoadCities';
import Step6DashboardTiles from '../components/wizard/Step6_DashboardTiles';
import Step7Review from '../components/wizard/Step7_Review';

const steps = [
  { id: 1, name: 'Define Region', icon: MapPin },
  { id: 2, name: 'Load Boundaries', icon: Map },
  { id: 3, name: 'Load Demographics', icon: Database },
  { id: 4, name: 'Load Healthcare Providers', icon: Building },
  { id: 5, name: 'Load Cities', icon: Building },
  { id: 6, name: 'Dashboard Layout', icon: LayoutDashboard },
  { id: 7, name: 'Review & Publish', icon: Flag },
];

const initialFormData = {
  title: "",
  description: "",
  geography: {
    country: "United States",
    state: "",
    county: "",
    city: "",
    zcta_codes: [],
    radius_miles: "",
    radius_center: "",
    latitude: null,
    longitude: null,
    community_areas: []
  },
  processed_data: {
      zcta_codes: [],
      source: "initial_setup",
      boundaries_loaded: false,
      competitors_loaded: false,
      demographics_loaded: false
  },
  data_sources: [],
  uploaded_files: [],
  organizations: [],
  elements_included: ["map", "population_demographics", "community_needs", "competitors", "ai_chat"],
  status: "draft"
};

export default function CreateAssessmentWizard() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const assessmentId = searchParams.get('id');

  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState(initialFormData);
  const [isLoading, setIsLoading] = useState(!!assessmentId);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (assessmentId) {
      base44.entities.Assessment.get(assessmentId).then(data => {
        const loadedData = {
          ...initialFormData,
          ...data,
          geography: {
            ...initialFormData.geography,
            ...(data.geography || {}),
            zcta_codes: data.geography?.zcta_codes || data.geography?.zip_codes || [],
            community_areas: data.geography?.community_areas || []
          },
          processed_data: {
            ...initialFormData.processed_data,
            ...(data.processed_data || {}),
            zcta_codes: data.processed_data?.zcta_codes || data.processed_data?.zip_codes || []
          },
          data_sources: data.data_sources || [],
          uploaded_files: data.uploaded_files || [],
          organizations: data.organizations || [],
          elements_included: data.elements_included || []
        };
        setFormData(loadedData);
        setIsLoading(false);
      }).catch(err => {
        console.error("Failed to load assessment", err);
        setIsLoading(false);
        toast.error("Could not load the assessment to edit.");
        navigate(createPageUrl("Assessments"));
      });
    }
  }, [assessmentId, navigate]);

  const handleNext = () => {
    if (currentStep === 1) {
      if (!formData.geography?.city || !formData.geography?.state) {
        toast.error("Please define your region with city and state before continuing.");
        return;
      }
    } else if (currentStep === 2) {
      if (!formData.processed_data?.boundaries_loaded || !formData.geography.zcta_codes || formData.geography.zcta_codes.length === 0) {
        toast.error("Please load ZCTA boundaries before continuing.");
        return;
      }
    } else if (currentStep === 3) {
      if (!formData.processed_data?.demographics_loaded) {
        toast.warning("Demographics not loaded. You can continue, but your dashboard will have limited data.");
      }
    } else if (currentStep === 4) {
      if (!formData.processed_data?.competitors_loaded || formData.organizations.length === 0) {
        toast.warning("No healthcare providers loaded. You can continue, but consider adding providers for better insights.");
      }
    } else if (currentStep === 5) {
      if (!formData.processed_data?.cities_loaded) {
        toast.warning("City data not loaded. You can continue, but consider loading city data for better insights.");
      }
    }
    
    setCurrentStep(prev => Math.min(prev + 1, steps.length));
  };

  const handlePrev = () => setCurrentStep(prev => Math.max(prev - 1, 1));

  const updateFormData = (newData) => {
    setFormData(prev => ({ ...prev, ...newData }));
  };

  const saveProgress = async () => {
    // Removed automatic draft saving - only save when publishing
  };

  const handleSubmit = async () => {
    setIsSaving(true);

    try {
      // Check and deduct tokens for new assessments (5 tokens)
      if (!assessmentId) {
        const tokenResult = await base44.functions.invoke('spendTokens', {
          action_type: 'assessment',
          description: `Published assessment: ${formData.title || formData.geography?.city || 'New Assessment'}`
        });
        
        if (!tokenResult?.data?.success) {
          toast.error(tokenResult?.data?.error || 'Insufficient tokens. You need 5 tokens to publish an assessment.');
          setIsSaving(false);
          return;
        }
        
        toast.info(`5 tokens deducted. New balance: ${tokenResult.data.newBalance}`);
      }

      const defaultTitle = formData.geography?.city && formData.geography?.state
        ? `${formData.geography.city}, ${formData.geography.state} Health Assessment ${new Date().getFullYear()}`
        : `Health Assessment ${new Date().toLocaleDateString()}`;

      const cleanGeography = {};
      Object.entries(formData.geography).forEach(([key, value]) => {
        if (value !== undefined && value !== null && value !== '') {
          if (key === 'radius_center' && typeof value !== 'string') {
            cleanGeography[key] = String(value);
          } else {
            cleanGeography[key] = value;
          }
        }
      });

      if (!cleanGeography.radius_center && cleanGeography.city && cleanGeography.state) {
        cleanGeography.radius_center = `${cleanGeography.city}, ${cleanGeography.state}`;
      }

      const dataToSubmit = {
        title: formData.title || defaultTitle,
        description: formData.description || `Comprehensive health assessment for ${formData.geography?.city || 'selected area'}, ${formData.geography?.state || ''}.`,
        geography: cleanGeography,
        processed_data: {
          ...(formData.processed_data || {}),
          zcta_codes: formData.geography?.zcta_codes || [],
          source: 'wizard_creation',
          boundaries_loaded: formData.processed_data?.boundaries_loaded || false,
          competitors_loaded: formData.processed_data?.competitors_loaded || false,
          demographics_loaded: formData.processed_data?.demographics_loaded || false,
        },
        data_sources: formData.data_sources || [],
        uploaded_files: formData.uploaded_files || [],
        organizations: formData.organizations || [],
        elements_included: formData.elements_included || ["map", "population_demographics", "community_needs", "competitors", "ai_chat"],
        status: "published"
      };

      console.log("Submitting assessment data:", dataToSubmit);

      let savedAssessment;
      if (assessmentId) {
        await base44.entities.Assessment.update(assessmentId, dataToSubmit);
        savedAssessment = { id: assessmentId, ...dataToSubmit };
        toast.success(`Assessment "${savedAssessment.title}" has been updated!`);
      } else {
        savedAssessment = await base44.entities.Assessment.create(dataToSubmit);
        toast.success(`Assessment "${savedAssessment.title}" has been published!`);
      }
      
      navigate(createPageUrl(`AssessmentDashboard?id=${savedAssessment.id}`));

    } catch (error) {
      console.error("Failed to save assessment", error);
      toast.error(`Save failed: ${error.message || "Unknown error"}`);
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading && assessmentId) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center mx-auto mb-4 animate-pulse">
            <Map className="w-4 h-4 text-white" />
          </div>
          <p className="text-gray-600">Loading assessment...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4 sm:p-6 md:p-8">
      <Toaster position="top-center" richColors />
      <div className="max-w-6xl mx-auto">
        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">
            {assessmentId ? 'Edit Health Assessment' : 'Create New Health Assessment'}
          </h1>
          <p className="text-gray-600 mb-6">Complete each step to build a comprehensive, data-rich dashboard.</p>

          {/* Stepper */}
          <div className="border-b border-gray-200 pb-6 mb-6">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              {steps.map((step, index) => (
                <React.Fragment key={step.id}>
                  <div className="flex items-center gap-3 w-full">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 flex-shrink-0 ${
                      currentStep > step.id ? 'bg-emerald-500 text-white' : 
                      currentStep === step.id ? 'bg-emerald-500 text-white ring-4 ring-emerald-100' : 
                      'bg-gray-100 text-gray-500'
                    }`}>
                      {currentStep > step.id ? <CheckCircle className="w-5 h-5" /> : <step.icon className="w-5 h-5" />}
                    </div>
                    <div className="flex-grow">
                      <p className="text-xs text-gray-500">Step {step.id}</p>
                      <p className="font-medium text-sm text-gray-800">{step.name}</p>
                    </div>
                  </div>
                  {index < steps.length - 1 && (
                    <>
                      <div className="hidden md:flex-1 md:h-px md:bg-gray-200 md:mx-4"></div>
                      <div className="md:hidden h-6 w-px bg-gray-200 ml-5 my-2"></div>
                    </>
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>

          <div className="min-h-[400px] mb-8">
            {currentStep === 1 && <Step1Geography formData={formData} updateFormData={updateFormData} />}
            {currentStep === 2 && <Step2LoadBoundaries formData={formData} updateFormData={updateFormData} assessmentId={assessmentId} />}
            {currentStep === 3 && <Step3LoadDemographics formData={formData} updateFormData={updateFormData} assessmentId={assessmentId} />}
            {currentStep === 4 && <Step4LoadCompetitors formData={formData} updateFormData={updateFormData} assessmentId={assessmentId} />}
            {currentStep === 5 && <Step5LoadCities formData={formData} updateFormData={updateFormData} />}
            {currentStep === 6 && <Step6DashboardTiles formData={formData} updateFormData={updateFormData} />}
            {currentStep === 7 && <Step7Review formData={formData} updateFormData={updateFormData} />}
          </div>

          <div className="flex justify-between items-center pt-8 border-t border-gray-200 mt-8 pb-24 md:pb-8">
            <Button variant="outline" onClick={handlePrev} disabled={currentStep === 1}>
              <ArrowLeft className="w-4 h-4 mr-2"/> Previous
            </Button>
            {currentStep < steps.length ? (
              <Button onClick={handleNext} className="bg-emerald-600 hover:bg-emerald-700">
                Next <ArrowRight className="w-4 h-4 ml-2"/>
              </Button>
            ) : (
              <Button onClick={handleSubmit} disabled={isSaving} className="bg-emerald-600 hover:bg-emerald-700">
                {isSaving ? 'Publishing...' : 'Publish Dashboard'}
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}