import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { Plus, Search, Grid3x3, List, Trash2, Loader2, MapPin, Calendar, User, FileText, ArrowRight } from "lucide-react";
import PresentationEditor from "../components/presentation/PresentationEditor";
import PresentationViewer from "../components/presentation/PresentationViewer";

export default function PresentationBuilder() {
  const [presentations, setPresentations] = useState([]);
  const [filteredPresentations, setFilteredPresentations] = useState([]);
  const [assessments, setAssessments] = useState([]);
  const [selectedAssessment, setSelectedAssessment] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [view, setView] = useState("list");
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [viewMode, setViewMode] = useState("list");
  const [selectedIds, setSelectedIds] = useState(new Set());
  const [isDeleting, setIsDeleting] = useState(false);
  const [currentStep, setCurrentStep] = useState(1);
  const [editingPresentation, setEditingPresentation] = useState(null);
  const [viewingPresentation, setViewingPresentation] = useState(null);
  const [previewPresentation, setPreviewPresentation] = useState(null);

  useEffect(() => {
    loadInitialData();
  }, []);

  useEffect(() => {
    let filtered = presentations;

    if (searchTerm) {
      filtered = filtered.filter(p =>
        p.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.assessment_title?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (statusFilter !== "all") {
      filtered = filtered.filter(p => p.status === statusFilter);
    }

    setFilteredPresentations(filtered);
  }, [presentations, searchTerm, statusFilter]);

  const loadInitialData = async () => {
    setIsLoading(true);
    try {
      const [presentationsData, assessmentsData] = await Promise.all([
        base44.entities.Presentation.list('-updated_date', 50),
        base44.entities.Assessment.list('-created_date', 50)
      ]);
      setPresentations(presentationsData || []);
      const nonDraftAssessments = (assessmentsData || []).filter(a => a.status !== 'draft');
      setAssessments(nonDraftAssessments);
    } catch (error) {
      console.error('Error loading data:', error);
      toast.error('Failed to load data');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectAssessment = async (assessment) => {
    setSelectedAssessment(assessment);
    setCurrentStep(2);
    setView('wizard');
  };

  const toggleSelection = (id) => {
    const newSelected = new Set(selectedIds);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedIds(newSelected);
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === filteredPresentations.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredPresentations.map(p => p.id)));
    }
  };

  const handleBulkDelete = async () => {
    if (selectedIds.size === 0) return;

    const confirmed = confirm(
      `Are you sure you want to delete ${selectedIds.size} presentation${selectedIds.size > 1 ? 's' : ''}? This action cannot be undone.`
    );

    if (!confirmed) return;

    setIsDeleting(true);
    toast.loading(`Deleting ${selectedIds.size} presentations...`, { id: 'bulk-delete' });

    try {
      const deletePromises = Array.from(selectedIds).map(id =>
        base44.entities.Presentation.delete(id)
      );

      await Promise.all(deletePromises);

      toast.success(`Successfully deleted ${selectedIds.size} presentation${selectedIds.size > 1 ? 's' : ''}!`, {
        id: 'bulk-delete'
      });

      setSelectedIds(new Set());
      await loadInitialData();
    } catch (error) {
      console.error('Error deleting presentations:', error);
      toast.error('Failed to delete some presentations', { id: 'bulk-delete' });
    } finally {
      setIsDeleting(false);
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      draft: "bg-yellow-50 text-yellow-700 border-yellow-200",
      published: "bg-emerald-50 text-emerald-700 border-emerald-200"
    };
    return colors[status] || colors.draft;
  };

  const handleSavePresentation = async () => {
    try {
      await base44.entities.Presentation.create({
        title: `${selectedAssessment.title} - Presentation`,
        assessment_id: selectedAssessment.id,
        assessment_title: selectedAssessment.title,
        slides: [],
        template: 'standard',
        status: 'draft'
      });
      toast.success('Presentation saved!');
      await loadInitialData();
      setView('list');
      setCurrentStep(1);
      setSelectedAssessment(null);
    } catch (error) {
      console.error('Failed to save:', error);
      toast.error('Failed to save presentation');
    }
  };

  const handleEditPresentation = (presentation) => {
    setEditingPresentation(presentation);
  };

  const handleViewPresentation = (presentation) => {
    setViewingPresentation(presentation);
  };

  const handleSaveEdit = async (updatedData) => {
    try {
      await base44.entities.Presentation.update(editingPresentation.id, updatedData);
      toast.success('Presentation updated successfully!');
      await loadInitialData();
      setEditingPresentation(null);
    } catch (error) {
      console.error('Failed to save:', error);
      toast.error('Failed to save presentation');
    }
  };

  const handlePreview = (presentation) => {
    setPreviewPresentation(presentation);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-emerald-600 mx-auto mb-4" />
          <p className="text-gray-600">Loading presentations...</p>
        </div>
      </div>
    );
  }

  // List View
  if (view === "list") {
    return (
      <div className="min-h-screen p-4 md:p-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="bg-white rounded-xl p-6 border-2 border-emerald-500 shadow-sm mb-8">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0">
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/95e1a1ace_presentation.png"
                  alt="Presentation Builder"
                  className="w-20 h-20"
                />
              </div>
              <div className="flex-1">
                <h1 className="text-3xl font-bold mb-2 text-gray-900">Presentation Builder</h1>
                <p className="text-gray-600 text-sm leading-relaxed">
                  Transform your assessment data into professional slide decks. Generate AI-powered insights, charts, and narratives 
                  to effectively communicate community health findings to stakeholders and grant reviewers.
                </p>
              </div>
            </div>
          </div>

          {/* Count and Actions */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
            <div>
              <p className="text-gray-600 mt-2">
                {presentations.length} total presentation{presentations.length !== 1 ? 's' : ''}
                {selectedIds.size > 0 && ` • ${selectedIds.size} selected`}
              </p>
            </div>

            <div className="flex gap-2 w-full md:w-auto">
              {selectedIds.size > 0 && (
                <Button
                  onClick={handleBulkDelete}
                  disabled={isDeleting}
                  variant="destructive"
                  className="flex-1 md:flex-initial"
                >
                  {isDeleting ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Trash2 className="w-4 h-4 mr-2" />
                  )}
                  Delete {selectedIds.size}
                </Button>
              )}
              
              <Button
                onClick={() => {
                  setView('wizard');
                  setCurrentStep(1);
                  setSelectedAssessment(null);
                }}
                className="flex-1 md:flex-initial bg-emerald-500 hover:bg-emerald-600 text-white shadow-sm"
              >
                <Plus className="w-5 h-5 mr-2 stroke-1" />
                New Presentation
              </Button>
            </div>
          </div>

          {/* Filters and View Toggle */}
          <Card className="border-gray-200 shadow-sm mb-6">
            <CardContent className="p-4">
              <div className="flex flex-col md:flex-row gap-4">
                {/* Search */}
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 stroke-1" />
                  <Input
                    placeholder="Search presentations..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 bg-white border-gray-300 text-gray-900 placeholder:text-gray-500"
                  />
                </div>

                {/* Status Filter */}
                <div className="flex gap-2 overflow-x-auto">
                  {['all', 'draft', 'published'].map((status) => (
                    <Button
                      key={status}
                      variant={statusFilter === status ? "default" : "outline"}
                      size="sm"
                      onClick={() => setStatusFilter(status)}
                      className={statusFilter === status
                        ? "bg-emerald-500 hover:bg-emerald-600 text-white whitespace-nowrap"
                        : "border-gray-300 text-gray-700 hover:bg-gray-50 whitespace-nowrap"
                      }
                    >
                      {status.charAt(0).toUpperCase() + status.slice(1)}
                    </Button>
                  ))}
                </div>

                {/* View Mode Toggle */}
                <div className="flex gap-1 border border-gray-300 rounded-lg p-1 h-9">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setViewMode('grid')}
                    className={`h-7 ${viewMode === 'grid' ? 'bg-gray-100' : ''}`}
                  >
                    <Grid3x3 className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setViewMode('list')}
                    className={`h-7 ${viewMode === 'list' ? 'bg-gray-100' : ''}`}
                  >
                    <List className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Select All (only in list view) */}
          {viewMode === 'list' && filteredPresentations.length > 0 && !isLoading && (
            <div className="flex items-center gap-3 mb-3 px-2">
              <Checkbox
                checked={selectedIds.size === filteredPresentations.length && filteredPresentations.length > 0}
                onCheckedChange={toggleSelectAll}
                className="h-4 w-4"
              />
              <span className="text-sm text-gray-600">
                Select all ({filteredPresentations.length})
              </span>
            </div>
          )}

          {/* Content */}
          {filteredPresentations.length > 0 ? (
            viewMode === 'list' ? (
              // List View
              <div className="space-y-2">
                {filteredPresentations.map((presentation) => (
                  <Card key={presentation.id} className="border-gray-200 shadow-sm hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-4">
                        <Checkbox
                          checked={selectedIds.has(presentation.id)}
                          onCheckedChange={() => toggleSelection(presentation.id)}
                          className="h-4 w-4"
                        />

                        <div className="flex-1 min-w-0">
                          <div className="font-semibold text-gray-900 truncate">
                            {presentation.title}
                          </div>
                          <div className="flex items-center gap-4 mt-1 text-sm text-gray-600">
                            <div className="flex items-center gap-1">
                              <MapPin className="w-3 h-3" />
                              <span className="truncate">{presentation.assessment_title}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              <span>{new Date(presentation.created_date).toLocaleDateString()}</span>
                            </div>
                            {presentation.created_by && (
                              <div className="flex items-center gap-1">
                                <User className="w-3 h-3" />
                                <span className="truncate">{presentation.created_by.split('@')[0]}</span>
                              </div>
                            )}
                          </div>
                        </div>

                        <Badge className={getStatusColor(presentation.status)}>
                          {presentation.status}
                        </Badge>

                        <div className="hidden sm:flex items-center gap-1 text-sm text-gray-600">
                          <FileText className="w-4 h-4" />
                          <span>{presentation.slides?.length || 0} slides</span>
                        </div>

                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleEditPresentation(presentation)}
                          >
                            Edit
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleViewPresentation(presentation)}
                            className="bg-emerald-500 text-white hover:bg-emerald-600 border-0"
                          >
                            View
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              // Grid View
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredPresentations.map(presentation => (
                  <Card key={presentation.id} className="hover:shadow-lg transition-shadow relative">
                    <div className="absolute top-3 left-3 z-10">
                      <Checkbox
                        checked={selectedIds.has(presentation.id)}
                        onCheckedChange={() => toggleSelection(presentation.id)}
                        className="bg-white border-2 shadow-sm h-4 w-4"
                      />
                    </div>
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex-1 mt-6">
                          <CardTitle className="text-lg mb-2">{presentation.title}</CardTitle>
                          <div className="flex gap-2 flex-wrap">
                            <Badge className={getStatusColor(presentation.status)}>
                              {presentation.status}
                            </Badge>
                            <Badge variant="outline">
                              {presentation.slides?.length || 0} slides
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="text-sm text-gray-600">
                        <p className="flex items-center gap-2">
                          <MapPin className="w-4 h-4" />
                          {presentation.assessment_title}
                        </p>
                      </div>
                      <div className="flex gap-2">
                        <Button 
                          onClick={() => handleEditPresentation(presentation)}
                          variant="outline"
                          className="flex-1"
                          size="sm"
                        >
                          Edit
                        </Button>
                        <Button 
                          onClick={() => handleViewPresentation(presentation)}
                          className="flex-1 bg-emerald-600 hover:bg-emerald-700"
                          size="sm"
                        >
                          View
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )
          ) : (
            <Card className="border-gray-200 shadow-sm">
              <CardContent className="text-center py-12">
                <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4 stroke-1" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  {presentations.length === 0 ? "No presentations created yet" : "No presentations match your filters"}
                </h3>
                <p className="text-gray-600 mb-6">
                  {presentations.length === 0
                    ? "Start by creating your first presentation"
                    : "Try adjusting your search terms or filters"
                  }
                </p>
                {presentations.length === 0 && (
                  <Button
                    onClick={() => {
                      setView('wizard');
                      setCurrentStep(1);
                    }}
                    className="w-full sm:w-auto bg-emerald-500 hover:bg-emerald-600 text-white"
                  >
                    <Plus className="w-5 h-5 mr-2 stroke-1" />
                    Create Your First Presentation
                  </Button>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    );
  }

  // Wizard View - Step 1: Select Assessment
  if (view === "wizard" && currentStep === 1) {
    return (
      <div className="min-h-screen bg-gray-50 p-6">
        <div className="max-w-4xl mx-auto space-y-6">
          {/* Header */}
          <div className="bg-white rounded-xl p-6 border-2 border-emerald-500 shadow-sm">
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0">
                  <img 
                    src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/689b3088c_deepdive.png"
                    alt="Presentation Builder"
                    className="w-20 h-20"
                  />
                </div>
                <div className="flex-1">
                  <h1 className="text-3xl font-bold mb-2 text-gray-900">Presentation Wizard</h1>
                  <p className="text-gray-600 text-sm leading-relaxed">
                    Select an assessment to begin creating your professional presentation
                  </p>
                </div>
              </div>
              <Button 
                variant="outline"
                onClick={() => setView('list')}
              >
                <ArrowRight className="w-4 h-4 mr-2 rotate-180" />
                Back to List
              </Button>
            </div>
          </div>

          {/* Assessment Selection */}
          <Card>
            <CardHeader>
              <CardTitle>Step 1: Select an Assessment</CardTitle>
            </CardHeader>
            <CardContent>
              {assessments.length === 0 ? (
                <div className="text-center py-8">
                  <FileText className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-600">No published assessments available</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {assessments.map(assessment => (
                    <Card
                      key={assessment.id}
                      className="cursor-pointer hover:shadow-md transition-shadow border-2 hover:border-emerald-500"
                      onClick={() => handleSelectAssessment(assessment)}
                    >
                      <CardContent className="p-4">
                        <h3 className="font-semibold text-gray-900 mb-1">{assessment.title}</h3>
                        <div className="flex items-center gap-4 text-sm text-gray-600">
                          <span className="flex items-center gap-1">
                            <MapPin className="w-3 h-3" />
                            {assessment.geography?.city}, {assessment.geography?.state}
                          </span>
                          {assessment.geography?.zcta_codes && (
                            <Badge variant="outline">
                              {assessment.geography.zcta_codes.length} ZIPs
                            </Badge>
                          )}
                          {assessment.organizations && (
                            <Badge variant="outline">
                              {assessment.organizations.length} Organizations
                            </Badge>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Wizard View - Step 2: Create Presentation
  if (view === "wizard" && currentStep === 2) {
    return (
      <div className="min-h-screen bg-gray-50 p-6">
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="bg-white rounded-xl p-6 border-2 border-emerald-500 shadow-sm">
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1">
                <h1 className="text-2xl font-bold mb-2 text-gray-900">
                  {selectedAssessment?.title}
                </h1>
                <p className="text-gray-600 text-sm">
                  Create a presentation based on this assessment. You can add slides, charts, and insights.
                </p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setCurrentStep(1)}>
                  <ArrowRight className="w-4 h-4 mr-2 rotate-180" />
                  Back
                </Button>
                <Button onClick={handleSavePresentation} className="bg-emerald-600 hover:bg-emerald-700">
                  Save Draft
                </Button>
              </div>
            </div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Assessment Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-600">Location</p>
                  <p className="font-semibold">{selectedAssessment?.geography?.city}, {selectedAssessment?.geography?.state}</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-600">ZIP Codes</p>
                  <p className="font-semibold">{selectedAssessment?.geography?.zcta_codes?.length || 0}</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-600">Organizations</p>
                  <p className="font-semibold">{selectedAssessment?.organizations?.length || 0}</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-600">Status</p>
                  <Badge className="bg-emerald-100 text-emerald-700">{selectedAssessment?.status}</Badge>
                </div>
              </div>
              
              <div className="border-t pt-4">
                <p className="text-sm text-gray-600 mb-2">
                  A presentation will be created with this assessment's data. You can then edit slides and add content.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Editor Mode
  if (editingPresentation) {
    return (
      <PresentationEditor
        presentation={editingPresentation}
        onSave={handleSaveEdit}
        onClose={() => setEditingPresentation(null)}
        onPreview={handlePreview}
      />
    );
  }

  // Viewer Mode
  if (viewingPresentation) {
    return (
      <PresentationViewer
        presentation={viewingPresentation}
        onClose={() => setViewingPresentation(null)}
      />
    );
  }

  // Preview Mode (from editor)
  if (previewPresentation) {
    return (
      <PresentationViewer
        presentation={previewPresentation}
        onClose={() => setPreviewPresentation(null)}
      />
    );
  }

  return null;
}