import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { 
  Plus, 
  Map, 
  BarChart3, 
  Users, 
  FileText,
  TrendingUp,
  MessageSquare,
  Sparkles,
  Loader2
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

import WelcomeHero from "../components/dashboard/WelcomeHero";
import QuickActions from "../components/dashboard/QuickActions";
import RecentAssessments from "../components/dashboard/RecentAssessments";
import HealthMetrics from "../components/dashboard/HealthMetrics";
import AIInsights from "../components/dashboard/AIInsights";
import LottieLoader from "../components/ui/LottieLoader";

export default function Dashboard() {
  const [assessments, setAssessments] = useState([]);
  const [organizations, setOrganizations] = useState([]);
  const [dataUploads, setDataUploads] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [user, setUser] = useState(null);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    setIsLoading(true);
    try {
      const [currentUser, assessmentData, orgData, uploadData] = await Promise.allSettled([
        base44.auth.me(),
        base44.entities.Assessment.list('-created_date', 5),
        base44.entities.Organization.list('-created_date', 3),
        base44.entities.DataUpload.list('-created_date', 3)
      ]);

      setUser(currentUser.status === 'fulfilled' ? currentUser.value : null);
      setAssessments(assessmentData.status === 'fulfilled' ? (assessmentData.value || []) : []);
      setOrganizations(orgData.status === 'fulfilled' ? (orgData.value || []) : []);
      setDataUploads(uploadData.status === 'fulfilled' ? (uploadData.value || []) : []);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
      setAssessments([]);
      setOrganizations([]);
      setDataUploads([]);
    }
    setIsLoading(false);
  };

  const stats = [
    {
      title: "Total Assessments",
      value: assessments.length.toString(),
      icon: Map,
      color: "text-emerald-600",
      bgColor: "bg-emerald-50",
      change: "+12%"
    },
    {
      title: "Organizations Tracked",
      value: organizations.length.toString(),
      icon: Users,
      color: "text-green-600",
      bgColor: "bg-green-50",
      change: "+8%"
    },
    {
      title: "Data Sources",
      value: dataUploads.length.toString(),
      icon: FileText,
      color: "text-teal-600",
      bgColor: "bg-teal-50",
      change: "+23%"
    },
    {
      title: "AI Insights Generated",
      value: "47",
      icon: Sparkles,
      color: "text-lime-600",
      bgColor: "bg-lime-50",
      change: "+156%"
    }
  ];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <LottieLoader size={80} className="mx-auto mb-4" />
          <p className="text-gray-600 font-medium">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 md:p-8 bg-gray-50">
      <div className="max-w-7xl mx-auto space-y-8">
        
        <WelcomeHero />

        {/* Token Balance Card */}
        <Card className="border-2 border-emerald-200 bg-gradient-to-br from-emerald-50 to-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/83f057394_tokens.png"
                  alt="Tokens"
                  className="w-10 h-10"
                />
                <div>
                  <p className="text-sm text-gray-600">Your Token Balance</p>
                  <p className="text-2xl font-bold text-gray-900">{user?.token_balance || 0} tokens</p>
                </div>
              </div>
              <Link to={createPageUrl("Pricing")}>
                <Button variant="outline" className="border-emerald-500 text-emerald-700 hover:bg-emerald-50">
                  Get More Tokens
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <Card key={stat.title} className="border-gray-200 shadow-sm hover:shadow-md transition-all duration-300">
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                    <CardTitle className="text-3xl font-bold text-gray-900 mt-2">
                      {stat.value}
                    </CardTitle>
                  </div>
                  <div className={`p-3 rounded-xl ${stat.bgColor} border border-gray-100`}>
                    <stat.icon className={`w-6 h-6 ${stat.color} stroke-1`} />
                  </div>
                </div>
                <div className="flex items-center mt-4 text-sm">
                  <TrendingUp className="w-4 h-4 mr-1 text-emerald-500 stroke-1" />
                  <span className="text-emerald-600 font-semibold">{stat.change}</span>
                  <span className="text-gray-500 ml-1">vs last month</span>
                </div>
              </CardHeader>
            </Card>
          ))}
        </div>

        <QuickActions />

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <RecentAssessments 
              assessments={assessments}
              isLoading={isLoading}
            />
            
            <HealthMetrics />
          </div>

          <div className="space-y-8">
            <AIInsights />

            {/* Organizations Card */}
            <Card className="border-gray-200 shadow-sm">
              <CardHeader className="pb-4">
                <CardTitle className="text-gray-900 flex items-center gap-2">
                  <Users className="w-5 h-5 stroke-1" />
                  Recent Organizations
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {organizations.length > 0 ? (
                  organizations.slice(0, 5).map((org) => (
                    <div key={org.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg border border-gray-100">
                      <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
                      <div className="flex-1">
                        <p className="font-medium text-gray-900 text-sm">{org.name}</p>
                        <p className="text-gray-500 text-xs capitalize">{org.type}</p>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-gray-500 text-sm text-center py-4">No organizations tracked yet</p>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}