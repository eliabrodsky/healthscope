import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  LifeBuoy, 
  Send, 
  CheckCircle, 
  Clock, 
  AlertCircle,
  Loader2,
  Upload,
  MessageSquare,
  FileText
} from "lucide-react";
import { toast } from "sonner";

export default function Support() {
  const [tickets, setTickets] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    issue_type: "bug",
    title: "",
    description: "",
    steps_to_reproduce: "",
    region_dataset: ""
  });
  const [uploadedScreenshot, setUploadedScreenshot] = useState(null);

  useEffect(() => {
    loadTickets();
  }, []);

  const loadTickets = async () => {
    setIsLoading(true);
    try {
      const data = await base44.entities.SupportTicket.list('-created_date', 50);
      setTickets(data || []);
    } catch (error) {
      console.error('Error loading tickets:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      toast.loading('Uploading screenshot...', { id: 'upload' });
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setUploadedScreenshot(file_url);
      toast.success('Screenshot uploaded!', { id: 'upload' });
    } catch (error) {
      console.error('Upload error:', error);
      toast.error('Failed to upload screenshot', { id: 'upload' });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      await base44.entities.SupportTicket.create({
        ...formData,
        screenshot_url: uploadedScreenshot
      });
      toast.success('Support ticket submitted! We\'ll get back to you soon.');
      setFormData({
        issue_type: "bug",
        title: "",
        description: "",
        steps_to_reproduce: "",
        region_dataset: ""
      });
      setUploadedScreenshot(null);
      loadTickets();
    } catch (error) {
      console.error('Error submitting ticket:', error);
      toast.error('Failed to submit ticket');
    } finally {
      setIsSubmitting(false);
    }
  };

  const getStatusIcon = (status) => {
    const icons = {
      open: <Clock className="w-4 h-4 text-yellow-600" />,
      in_progress: <Loader2 className="w-4 h-4 text-blue-600 animate-spin" />,
      resolved: <CheckCircle className="w-4 h-4 text-green-600" />,
      closed: <CheckCircle className="w-4 h-4 text-gray-600" />
    };
    return icons[status] || icons.open;
  };

  const getStatusColor = (status) => {
    const colors = {
      open: "bg-yellow-50 text-yellow-700 border-yellow-200",
      in_progress: "bg-blue-50 text-blue-700 border-blue-200",
      resolved: "bg-green-50 text-green-700 border-green-200",
      closed: "bg-gray-50 text-gray-700 border-gray-200"
    };
    return colors[status] || colors.open;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-teal-50 p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div className="bg-white rounded-xl p-6 border-2 border-emerald-500 shadow-sm">
          <div className="flex items-start gap-4">
            <div className="w-16 h-16 bg-emerald-100 rounded-2xl flex items-center justify-center">
              <LifeBuoy className="w-8 h-8 text-emerald-600" />
            </div>
            <div className="flex-1">
              <h1 className="text-3xl font-bold mb-2">Support Center</h1>
              <p className="text-gray-600">
                Report bugs, data issues, or billing questions. We're here to help you get the most out of HealthScope.
              </p>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Submit New Ticket */}
          <Card className="border-2 border-gray-200">
            <CardHeader>
              <CardTitle>Submit Support Request</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">Issue Type</label>
                  <Select value={formData.issue_type} onValueChange={(value) => setFormData({...formData, issue_type: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="bug">Bug / Technical Issue</SelectItem>
                      <SelectItem value="data_issue">Data Issue</SelectItem>
                      <SelectItem value="billing">Billing / Tokens</SelectItem>
                      <SelectItem value="feature_request">Feature Request</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">Title</label>
                  <Input
                    placeholder="Brief description of the issue"
                    value={formData.title}
                    onChange={(e) => setFormData({...formData, title: e.target.value})}
                    required
                  />
                </div>

                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">Description</label>
                  <Textarea
                    placeholder="Provide details about the issue..."
                    value={formData.description}
                    onChange={(e) => setFormData({...formData, description: e.target.value})}
                    className="h-32"
                    required
                  />
                </div>

                {formData.issue_type === 'bug' && (
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-2 block">Steps to Reproduce</label>
                    <Textarea
                      placeholder="1. Go to...&#10;2. Click on...&#10;3. See error..."
                      value={formData.steps_to_reproduce}
                      onChange={(e) => setFormData({...formData, steps_to_reproduce: e.target.value})}
                      className="h-24"
                    />
                  </div>
                )}

                {formData.issue_type === 'data_issue' && (
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-2 block">Affected Region / Dataset</label>
                    <Input
                      placeholder="e.g., New Orleans, LA - ZIP 70112"
                      value={formData.region_dataset}
                      onChange={(e) => setFormData({...formData, region_dataset: e.target.value})}
                    />
                  </div>
                )}

                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">Screenshot (Optional)</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleFileUpload}
                      className="text-sm text-gray-600"
                    />
                    {uploadedScreenshot && <CheckCircle className="w-5 h-5 text-green-600" />}
                  </div>
                </div>

                <Button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="w-full bg-emerald-600 hover:bg-emerald-700"
                >
                  {isSubmitting ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Send className="w-4 h-4 mr-2" />
                  )}
                  Submit Ticket
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* My Tickets */}
          <Card className="border-2 border-gray-200">
            <CardHeader>
              <CardTitle>My Support Tickets</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="text-center py-8">
                  <Loader2 className="w-8 h-8 animate-spin text-emerald-600 mx-auto" />
                </div>
              ) : tickets.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <MessageSquare className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                  <p>No support tickets yet</p>
                </div>
              ) : (
                <div className="space-y-3 max-h-[600px] overflow-y-auto">
                  {tickets.map((ticket) => (
                    <div key={ticket.id} className="p-4 bg-gray-50 rounded-lg border border-gray-200">
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="font-semibold text-gray-900">{ticket.title}</h4>
                        <Badge className={getStatusColor(ticket.status)}>
                          {getStatusIcon(ticket.status)}
                          <span className="ml-1">{ticket.status.replace('_', ' ')}</span>
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{ticket.description}</p>
                      <div className="flex items-center gap-4 text-xs text-gray-500">
                        <Badge variant="outline" className="capitalize">{ticket.issue_type.replace('_', ' ')}</Badge>
                        <span>{new Date(ticket.created_date).toLocaleDateString()}</span>
                      </div>
                      {ticket.admin_notes && (
                        <div className="mt-3 p-3 bg-blue-50 rounded border border-blue-200">
                          <p className="text-sm font-medium text-blue-900 mb-1">Admin Response:</p>
                          <p className="text-sm text-gray-700">{ticket.admin_notes}</p>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}