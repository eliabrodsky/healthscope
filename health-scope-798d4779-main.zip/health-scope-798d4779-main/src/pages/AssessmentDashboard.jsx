import React, { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Loader2,
  AlertTriangle,
  RefreshCw,
  Map as MapIcon,
  BarChart3,
  Users,
  Building,
  Save,
  LayoutGrid,
  Database,
  BrainCircuit,
  Share,
  Pencil,
  Check,
  X
} from "lucide-react";
import { createPageUrl } from "@/utils";
import InteractiveMap from "../components/maps/InteractiveMap";
import GeographyControlsCard from "../components/assessment_dashboard/GeographyControlsCard";
import ZipDataTable from "../components/assessment_dashboard/ZipDataTable";
import EnhancedZipDataTable from "../components/assessment_dashboard/EnhancedZipDataTable";
import CitySummary from "../components/assessment_dashboard/CitySummary";
import AIChat from "../components/assessment_dashboard/AIChat";
import CompetitorManager from "../components/assessment_dashboard/CompetitorManager";
import KPICard from "../components/assessment_dashboard/KpiCard";
import DataSourceManager from "../components/assessment_dashboard/DataSourceManager";
import CompetitorLocationMapping from "../components/assessment_dashboard/CompetitorLocationMapping";
import PublishDashboard from "../components/assessment_dashboard/PublishDashboard";
import DataEnhancement from "../components/assessment_dashboard/DataEnhancement";
import KeyInsights from "../components/assessment_dashboard/KeyInsights";
import GooglePlacesEnricher from "../components/data/GooglePlacesEnricher";
import GooglePlacesWarningDialog from "../components/data/GooglePlacesWarningDialog";

export default function AssessmentDashboard() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const assessmentId = searchParams.get('id');

  const [assessment, setAssessment] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState(null);
  const [isSaving, setIsSaving] = useState(false);
  const [isReloadingAll, setIsReloadingAll] = useState(false);

  const [zipBoundaries, setZipBoundaries] = useState([]);
  const [censusData, setCensusData] = useState({});
  const [isLoadingCensusData, setIsLoadingCensusData] = useState(false);

  const [activeTab, setActiveTab] = useState('overview');
  const [isLoadingBoundaries, setIsLoadingBoundaries] = useState(false);
  const [mapColorMetric, setMapColorMetric] = useState('population');
  const [isFindingZips, setIsFindingZips] = useState(false);
  const [showRadiusReference, setShowRadiusReference] = useState(false);
  const [radiusMiles, setRadiusMiles] = useState(10);
  const [mapViewport, setMapViewport] = useState(null);
  const [showCompetitors, setShowCompetitors] = useState(true);
  const [mapSettings, setMapSettings] = useState({ colorScale: 'blue', showZipLabels: false });
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [quickPrompt, setQuickPrompt] = useState(null);
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [editedTitle, setEditedTitle] = useState('');
  const [showPlacesEnricher, setShowPlacesEnricher] = useState(false);
  const [showPlacesWarning, setShowPlacesWarning] = useState(false);

  const hasLoadedRef = useRef(false);

  const [loadingProgress, setLoadingProgress] = useState({
    step: '',
    isComplete: false
  });

  const uniqueZipCodes = useMemo(() => {
    const zips = assessment?.processed_data?.zip_codes || assessment?.geography?.zip_codes || [];
    return [...new Set(zips)].sort();
  }, [assessment]);

  const generateEstimate = (zipCode, state) => {
    const stateAverages = {
        'Louisiana': { population: 8500, medianIncome: 47905, povertyRate: 19.6, uninsuredRate: 8.4 },
        'Arkansas': { population: 7200, medianIncome: 48952, povertyRate: 16.2, uninsuredRate: 9.1 },
        'Mississippi': { population: 6800, medianIncome: 44717, povertyRate: 19.58, uninsuredRate: 12.4 },
        'Texas': { population: 9500, medianIncome: 63826, povertyRate: 13.6, uninsuredRate: 17.7 },
        'Oklahoma': { population: 7800, medianIncome: 52919, povertyRate: 15.2, uninsuredRate: 14.0 },
        'Alabama': { population: 7100, medianIncome: 51734, povertyRate: 16.8, uninsuredRate: 10.6 },
        'Tennessee': { population: 8200, medianIncome: 54833, povertyRate: 13.9, uninsuredRate: 9.8 },
        'Missouri': { population: 7600, medianIncome: 55461, povertyRate: 12.9, uninsuredRate: 9.5 },
    };
    
    const baseStats = stateAverages[state] || { 
      population: 8000, 
      medianIncome: 50000, 
      povertyRate: 15.0, 
      uninsuredRate: 10.0 
    };
    
    const variation = parseInt(zipCode.slice(-2)) / 100;

    return {
        population: Math.max(1, Math.round(baseStats.population * (0.7 + variation * 0.6))),
        medianIncome: Math.max(1000, Math.round(baseStats.medianIncome * (0.8 + variation * 0.4))),
        povertyRate: Math.max(0, Math.round((baseStats.povertyRate * (0.8 + variation * 0.4)) * 10) / 10),
        uninsuredRate: Math.max(0, Math.round((baseStats.uninsuredRate * (0.8 + variation * 0.4)) * 10) / 10),
        source: `Estimate (${state || 'State'} Average)`
    };
  };

  const loadDemographicData = useCallback(async (assessmentData, forceRefresh = false) => {
    const zipCodes = assessmentData.processed_data?.zip_codes || assessmentData.geography?.zip_codes || [];
    if (zipCodes.length === 0) {
      setCensusData({});
      return;
    }

    if (!forceRefresh && assessmentData.processed_data?.census_data) {
        const cachedData = assessmentData.processed_data.census_data;
        const cachedZips = Object.keys(cachedData);
        
        const hasCompleteData = zipCodes.every(zip => cachedZips.includes(zip));
        const hasRealData = Object.values(cachedData).some(d => 
          d.source && !d.source.includes('Estimate')
        );
        
        if (hasCompleteData && hasRealData) {
            console.log(`Using ${cachedZips.length} cached census records`);
            setCensusData(cachedData);
            return;
        }
    }

    setIsLoadingCensusData(true);

    try {
        const result = {};
        const CHUNK_SIZE = 100;
        
        for (let i = 0; i < zipCodes.length; i += CHUNK_SIZE) {
            const chunk = zipCodes.slice(i, i + CHUNK_SIZE);
            
            try {
              const demographics = await base44.entities.ZipDemographics.filter({
                  zcta5: { '$in': chunk }
              });

              // Group by ZCTA and prioritize Census data over CSV Upload
              const zctaMap = new Map();
              demographics.forEach(demo => {
                  const existing = zctaMap.get(demo.zcta5);
                  const isCensusSource = demo.source?.includes('Census') || demo.source?.includes('ACS');
                  const isExistingCensus = existing?.source?.includes('Census') || existing?.source?.includes('ACS');

                  // Prioritize Census data: only replace if new source is Census or no existing data
                  if (!existing || (isCensusSource && !isExistingCensus)) {
                      zctaMap.set(demo.zcta5, demo);
                  }
              });

              // Store the prioritized demographic data
              zctaMap.forEach((demo, zcta5) => {
                  result[zcta5] = {
                      population: demo.population || 0,
                      medianIncome: demo.median_income || 0,
                      povertyRate: demo.poverty_rate || 0,
                      uninsuredRate: demo.uninsured_rate || 0,
                      source: demo.source || 'Database'
                  };
              });
            } catch (chunkError) {
              console.warn(`Failed to load chunk ${i}-${i+CHUNK_SIZE}:`, chunkError);
            }
        }

        let estimateCount = 0;
        zipCodes.forEach(zip => {
            if (!result[zip]) {
                result[zip] = generateEstimate(zip, assessmentData.geography?.state);
                estimateCount++;
            }
        });

        setCensusData(result);
        
        // Auto-save census data back to assessment
        if (assessmentData.id) {
          setAssessment(prev => ({
            ...prev,
            processed_data: {
              ...prev.processed_data,
              census_data: result
            }
          }));
        }
        
        const dbCount = Object.values(result).filter(d => !d.source?.includes('Estimate')).length;
        console.log(`Loaded demographics: ${dbCount} from database, ${estimateCount} estimates`);

    } catch (error) {
        console.error("Error in loadDemographicData:", error);
        
        const result = {};
        zipCodes.forEach(zip => {
          result[zip] = generateEstimate(zip, assessmentData.geography?.state);
        });
        setCensusData(result);
        
        toast.warning("Using estimated data. Database unavailable.");
    } finally {
        setIsLoadingCensusData(false);
    }
  }, []);

  const loadZipBoundaries = useCallback(async (zipCodesToLoad) => {
    if (!zipCodesToLoad || zipCodesToLoad.length === 0) {
      setZipBoundaries([]);
      return [];
    }

    setIsLoadingBoundaries(true);
    const loadingToastId = 'loading-boundaries';
    toast.loading(`Loading boundaries for ${zipCodesToLoad.length} ZIP codes...`, { id: loadingToastId });
  
    try {
      const BATCH_SIZE = 25;
      const MAX_RETRIES = 2;
      const allBoundaries = [];
      let loadedCount = 0;
      const failedZips = [];
      
      for (let i = 0; i < zipCodesToLoad.length; i += BATCH_SIZE) {
        const batch = zipCodesToLoad.slice(i, i + BATCH_SIZE);
        const progress = Math.min(i + BATCH_SIZE, zipCodesToLoad.length);
        
        toast.loading(
          `Loading boundaries... ${progress}/${zipCodesToLoad.length} (${Math.round((progress/zipCodesToLoad.length)*100)}%)`,
          { id: loadingToastId }
        );
        
        let retryCount = 0;
        let batchSuccess = false;
        
        while (retryCount <= MAX_RETRIES && !batchSuccess) {
          try {
            const boundaries = await base44.entities.ZctaBoundary.filter({
              zcta5: { '$in': batch }
            });
            
            const batchBoundaries = boundaries || [];
            batchSuccess = true;
            
            if (batchBoundaries.length > 0) {
              allBoundaries.push(...batchBoundaries);
              loadedCount += batchBoundaries.length;
              
              const foundZips = new Set(batchBoundaries.map(b => b.zcta5));
              const missingInBatch = batch.filter(zip => !foundZips.has(zip));
              if (missingInBatch.length > 0) {
                failedZips.push(...missingInBatch);
              }
            } else {
              failedZips.push(...batch);
            }
          } catch (batchError) {
            retryCount++;
            if (retryCount <= MAX_RETRIES) {
              await new Promise(resolve => setTimeout(resolve, 1000 * retryCount));
            } else {
              failedZips.push(...batch);
            }
          }
        }
        
        if (i + BATCH_SIZE < zipCodesToLoad.length) {
          await new Promise(resolve => setTimeout(resolve, 500));
        }
      }
      
      const mappedBoundaries = allBoundaries.map(b => ({...b, zip_code: b.zcta5}));
      setZipBoundaries(mappedBoundaries);

      const uniqueFailedZips = [...new Set(failedZips)];
      
      if (uniqueFailedZips.length > 0) {
        const failedList = uniqueFailedZips.length <= 10 
          ? uniqueFailedZips.join(', ') 
          : `${uniqueFailedZips.slice(0, 10).join(', ')} and ${uniqueFailedZips.length - 10} more`;
        
        toast.warning(
          `Loaded ${mappedBoundaries.length}/${zipCodesToLoad.length} boundaries. Missing: ${failedList}`,
          { id: loadingToastId, duration: 10000 }
        );
      } else {
        toast.success(
          `✓ Successfully loaded all ${mappedBoundaries.length} boundaries!`,
          { id: loadingToastId }
        );
      }
      
      return mappedBoundaries;
  
    } catch (error) {
      console.error("Error loading boundaries:", error);
      toast.error("Failed to load ZIP boundaries.", { id: loadingToastId, duration: 8000 });
      return [];
    } finally {
      setIsLoadingBoundaries(false);
    }
  }, []);

  const handleFindCompetitors = useCallback(async (assessmentData) => {
    if (!assessmentData?.geography?.city || !assessmentData?.geography?.state) {
      return;
    }

    toast.loading("Searching for healthcare facilities...", { id: 'competitor-search' });
    
    try {
      const response = await base44.functions.invoke('findHealthcareFacilities', {
        latitude: assessmentData.geography.latitude,
        longitude: assessmentData.geography.longitude,
        radiusMiles: assessmentData.geography.radius_miles || 50,
        facilityTypes: ['hospital', 'clinic']
      });

      if (response?.data?.success && response.data?.facilities) {
        const facilities = response.data.facilities;
        
        if (facilities.length === 0) {
          toast.info(`No facilities found`, { id: 'competitor-search' });
          return;
        }

        const currentOrgNames = new Set((assessmentData.organizations || []).map(o => o.name?.toLowerCase()).filter(Boolean));
        
        const newOrgs = facilities
          .filter(facility => facility.name && !currentOrgNames.has(facility.name.toLowerCase()))
          .map(facility => ({
            id: 'osm_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9),
            name: facility.name,
            type: facility.type,
            address: facility.address || '',
            city: facility.city || assessmentData.geography.city,
            state: facility.state || assessmentData.geography.state,
            zip_code: facility.zip_code || '',
            coordinates: {
              latitude: facility.latitude,
              longitude: facility.longitude
            },
            source: 'OpenStreetMap'
          }));

        if (newOrgs.length > 0) {
          setAssessment(prev => ({ 
            ...prev, 
            organizations: [...(prev.organizations || []), ...newOrgs] 
          }));
          
          toast.success(
            `Added ${newOrgs.length} facilities`, 
            { id: 'competitor-search' }
          );
        } else {
          toast.info(
            `Found ${facilities.length} facilities (already in list)`, 
            { id: 'competitor-search' }
          );
        }
      }
    } catch (error) {
      console.warn("Error finding competitors:", error);
    }
  }, []);

  useEffect(() => {
    if (!assessmentId) {
      navigate(createPageUrl("Dashboard"));
      return;
    }

    if (hasLoadedRef.current) {
      return;
    }
    hasLoadedRef.current = true;

    const loadData = async () => {
      setIsLoading(true);
      setLoadError(null);
      setLoadingProgress({ step: 'Loading assessment...', isComplete: false });

      try {
        // Single fetch for assessment data
        const data = await base44.entities.Assessment.get(assessmentId);

        if (!data) {
          throw new Error("Assessment not found");
        }

        // Immediately set assessment and title - no waiting
        setAssessment(data);
        setEditedTitle(data.title || '');

        // Restore map settings immediately (synchronous, no waiting)
        if (data.processed_data?.map_settings) {
          const ms = data.processed_data.map_settings;
          setMapColorMetric(ms.color_metric || 'population');
          setShowRadiusReference(ms.show_radius || false);
          setRadiusMiles(ms.radius_miles || 10);
          if (ms.viewport) setMapViewport(ms.viewport);
          if (ms.show_competitors !== undefined) setShowCompetitors(ms.show_competitors);
          if (ms.color_scale || ms.show_zip_labels !== undefined) {
            setMapSettings(prev => ({
              ...prev,
              colorScale: ms.color_scale || prev.colorScale,
              showZipLabels: ms.show_zip_labels ?? prev.showZipLabels
            }));
          }
        }

        // Use cached census data immediately if available
        if (data.processed_data?.census_data && Object.keys(data.processed_data.census_data).length > 0) {
          setCensusData(data.processed_data.census_data);
          console.log(`✓ Restored ${Object.keys(data.processed_data.census_data).length} cached census records`);
        }

        // Use cached boundaries immediately if available
        if (data.processed_data?.trimmed_geojson?.features?.length > 0) {
          const boundaries = data.processed_data.trimmed_geojson.features.map(f => ({
            zcta5: f.properties.zcta5 || f.properties.ZCTA5CE10,
            geometry: f.geometry,
            state_abbr: f.properties.state_abbr,
            zip_code: f.properties.zcta5 || f.properties.ZCTA5CE10
          }));
          setZipBoundaries(boundaries);
          console.log(`✓ Restored ${boundaries.length} cached boundaries`);
        }

        setLoadingProgress({ step: 'Assessment ready', isComplete: true });

      } catch (error) {
        console.error("Error loading assessment:", error);
        setLoadError(error.message || 'Failed to load assessment');
        toast.error("Failed to load assessment", { duration: 5000 });
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, [assessmentId, navigate]);

  const handleReloadAllData = async () => {
    setIsReloadingAll(true);
    toast.loading("Fetching fresh Census data...", { id: 'reload-all' });

    try {
      // First reload the assessment to get latest data
      const freshAssessment = await base44.entities.Assessment.get(assessmentId);
      setAssessment(freshAssessment);
      
      // Fetch fresh Census data directly from API
      toast.loading(`Fetching data for ${uniqueZipCodes.length} ZIP codes...`, { id: 'reload-all' });
      const censusResponse = await base44.functions.invoke('fetchFreshCensusData', {
        zip_codes: uniqueZipCodes,
        year: 2023
      });
      
      if (censusResponse?.data?.success && censusResponse.data.results) {
        const freshCensusData = {};
        Object.entries(censusResponse.data.results).forEach(([zip, data]) => {
          if (data) {
            freshCensusData[zip] = {
              population: data.population,
              medianIncome: data.median_income,
              povertyRate: data.poverty_rate,
              uninsuredRate: data.uninsured_rate,
              medicareRate: data.medicare_rate,
              medicaidRate: data.medicaid_rate,
              source: data.source
            };
          }
        });
        
        setCensusData(freshCensusData);
        
        // Update assessment with fresh data
        setAssessment(prev => ({
          ...prev,
          processed_data: {
            ...prev.processed_data,
            census_data: freshCensusData
          }
        }));
        
        toast.loading("Reloading boundaries...", { id: 'reload-all' });
        await loadZipBoundaries(uniqueZipCodes);
        
        toast.loading("Updating competitors...", { id: 'reload-all' });
        await handleFindCompetitors(freshAssessment);
        
        toast.success(`Refreshed ${censusResponse.data.fetched_count} ZIP codes!`, { id: 'reload-all' });
      } else {
        throw new Error('Failed to fetch Census data');
      }
    } catch (error) {
      console.error("Reload error:", error);
      toast.error(`Refresh failed: ${error.message}`, { id: 'reload-all' });
    } finally {
      setIsReloadingAll(false);
    }
  };

  const handleUpdateGeography = (newGeo) => {
    const updatedAssessment = {
      ...assessment,
      geography: newGeo,
      processed_data: {
        ...assessment.processed_data,
        zip_codes: newGeo.zip_codes || []
      }
    };
    setAssessment(updatedAssessment);
    loadDemographicData(updatedAssessment, true);
  };

  const handleSaveAssessment = async () => {
    if (!assessment) return;

    setIsSaving(true);
    toast.loading("Saving...", { id: 'save' });

    try {
      let stringDataSources = [];
      if (assessment.data_sources && Array.isArray(assessment.data_sources)) {
        stringDataSources = assessment.data_sources.map(ds => {
          if (typeof ds === 'string') return ds;
          if (ds && typeof ds === 'object' && ds.name) return ds.name;
          return 'Unknown Data Source';
        });
      }

      const payload = {
        title: assessment.title,
        description: assessment.description,
        geography: assessment.geography,
        organizations: assessment.organizations || [],
        data_sources: stringDataSources,
        elements_included: assessment.elements_included,
        processed_data: {
          ...assessment.processed_data,
          zip_codes: uniqueZipCodes,
          source: assessment.processed_data?.source || 'dashboard',
          competitors_loaded: (assessment.organizations?.length || 0) > 0,
          demographics_loaded: Object.keys(censusData).length > 0,
          census_data: censusData,
          trimmed_geojson: assessment.processed_data?.trimmed_geojson,
          chat_history: assessment.processed_data?.chat_history,
          map_settings: {
            color_metric: mapColorMetric,
            show_radius: showRadiusReference,
            radius_miles: radiusMiles,
            viewport: mapViewport,
            show_competitors: showCompetitors,
            color_scale: mapSettings.colorScale,
            show_zip_labels: mapSettings.showZipLabels
          },
          data_sources_detailed: assessment.processed_data?.data_sources_detailed || [],
          last_updated: new Date().toISOString()
        }
      };

      await base44.entities.Assessment.update(assessment.id, payload);
      toast.success("Saved!", { id: 'save' });

    } catch (error) {
      console.error("Save error:", error);
      toast.error(`Save failed: ${error.message}`, { id: 'save' });
    } finally {
      setIsSaving(false);
    }
  };

  const handleUpdateTitle = async () => {
    if (!editedTitle.trim() || editedTitle === assessment.title) {
      setIsEditingTitle(false);
      return;
    }

    try {
      await base44.entities.Assessment.update(assessmentId, { title: editedTitle.trim() });
      setAssessment(prev => ({ ...prev, title: editedTitle.trim() }));
      toast.success("Renamed!");
      setIsEditingTitle(false);
    } catch (error) {
      toast.error("Failed to rename");
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-6">
        <div className="text-center">
          <Loader2 className="w-16 h-16 text-blue-600 animate-spin mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            {loadingProgress.isComplete ? 'Assessment Ready' : 'Loading Assessment'}
          </h2>
          <p className="text-gray-600">{loadingProgress.step}</p>
        </div>
      </div>
    );
  }

  if (loadError) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertTriangle className="h-8 w-8 mx-auto mb-4 text-red-500" />
          <h2 className="text-xl font-bold mb-2">Error Loading Assessment</h2>
          <p className="text-red-600 mb-4">{loadError}</p>
          <Button onClick={() => window.location.reload()}>Reload</Button>
        </div>
      </div>
    );
  }

  const organizations = assessment?.organizations || [];
  const totalPopulation = Object.values(censusData).reduce((acc, cur) => acc + (cur.population || 0), 0);

  return (
    <div className="min-h-screen bg-gray-50 p-4 sm:p-6">
      <div className="max-w-7xl mx-auto space-y-6 overflow-x-hidden">
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
          <div className="flex-1">
            {isEditingTitle ? (
              <div className="flex items-center space-x-2">
                <Input
                  value={editedTitle}
                  onChange={(e) => setEditedTitle(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleUpdateTitle();
                    if (e.key === 'Escape') setIsEditingTitle(false);
                  }}
                  className="text-3xl font-bold p-1 h-auto"
                />
                <Button variant="ghost" size="icon" onClick={handleUpdateTitle}>
                  <Check className="w-5 h-5 text-green-600" />
                </Button>
                <Button variant="ghost" size="icon" onClick={() => setIsEditingTitle(false)}>
                  <X className="w-5 h-5 text-red-600" />
                </Button>
              </div>
            ) : (
              <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 flex items-center group">
                {assessment?.title || 'Assessment Dashboard'}
                <Button
                  variant="ghost"
                  size="icon"
                  className="ml-2 opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={() => setIsEditingTitle(true)}
                >
                  <Pencil className="w-4 h-4 text-gray-500" />
                </Button>
              </h1>
            )}
            <p className="text-gray-600 text-sm sm:text-base">
              {assessment?.geography?.city && assessment?.geography?.state
                ? `${assessment.geography.city}, ${assessment.geography.state}`
                : 'Geographic Analysis'}
            </p>
          </div>
          <div className="flex gap-3 justify-start sm:justify-end">
            <Button
              variant="outline"
              onClick={() => setActiveTab('publish')}
              className="border-blue-500 text-blue-600 hover:bg-blue-50"
            >
              <Share className="w-4 h-4 mr-2" />
              Publish
            </Button>
            <Button onClick={handleSaveAssessment} disabled={isSaving}>
              {isSaving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
              Save
            </Button>
          </div>
        </div>

        <CitySummary 
          assessment={assessment}
          censusData={censusData}
          zipCodes={uniqueZipCodes}
          onRefreshDemographics={() => loadDemographicData(assessment, true)}
        />

        <div className="grid md:grid-cols-4 gap-6">
          <KPICard
            title="Total Population"
            value={totalPopulation > 0 ? totalPopulation.toLocaleString() : '...'}
            change="+1.4%"
            trend="up"
            source={`${Object.keys(censusData).length} ZIPs`}
            icon={Users}
            isLoading={isLoadingCensusData}
          />
          <KPICard
            title="Hospitals"
            value={organizations.filter(o => o.type === 'hospital').length.toString()}
            change="+0"
            trend="up"
            source="Healthcare facilities"
            icon={Building}
          />
          <KPICard
            title="FQHCs"
            value={organizations.filter(o => o.type === 'fqhc').length.toString()}
            change="+1"
            trend="up"
            source="Community health centers"
            icon={Building}
          />
          <KPICard
            title="% Patients in Poverty"
            value={Object.keys(censusData).length > 0 ? 
              `${(Object.values(censusData).reduce((acc, d) => acc + (d.povertyRate || 0), 0) / Object.keys(censusData).length).toFixed(1)}%` : 
              '...'}
            change="-0.5%"
            trend="down"
            source="Average poverty rate"
            icon={Users}
            isLoading={isLoadingCensusData}
          />
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="overview">
              <LayoutGrid className="w-4 h-4 mr-2" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="insights">
              <BarChart3 className="w-4 h-4 mr-2" />
              Insights
            </TabsTrigger>
            <TabsTrigger value="competitors">
              <Building className="w-4 h-4 mr-2" />
              Competitors
            </TabsTrigger>
            <TabsTrigger value="data">
              <Database className="w-4 h-4 mr-2" />
              Data
            </TabsTrigger>
            <TabsTrigger value="analysis">
              <BrainCircuit className="w-4 h-4 mr-2" />
              Analysis
            </TabsTrigger>
            <TabsTrigger value="publish">
              <Share className="w-4 h-4 mr-2" />
              Publish
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-6 space-y-6">
            <div className="relative">
              <div className={`grid gap-6 transition-all duration-300 ${
                isSidebarCollapsed ? 'grid-cols-1' : 'lg:grid-cols-3'
              }`}>
                <div className={`${isSidebarCollapsed ? '' : 'lg:col-span-2'}`}>
                  <InteractiveMap
                    zipBoundaries={zipBoundaries}
                    organizations={organizations}
                    center={assessment?.geography}
                    selectedZips={uniqueZipCodes}
                    colorMetric={mapColorMetric}
                    showRadiusReference={showRadiusReference}
                    radiusMiles={radiusMiles}
                    showCompetitors={showCompetitors}
                    onShowCompetitorsChange={setShowCompetitors}
                    assessment={assessment}
                    censusData={censusData}
                    isLoadingCensusData={isLoadingCensusData}
                    viewport={mapViewport}
                    onViewportChange={setMapViewport}
                    mapSettings={mapSettings}
                    onMapSettingsChange={setMapSettings}
                    sidebarCollapsed={isSidebarCollapsed}
                  />
                </div>

                <div className={isSidebarCollapsed ? 'absolute right-0 top-0 z-10' : ''}>
                  <GeographyControlsCard
                    assessment={assessment}
                    onUpdate={handleUpdateGeography}
                    onReloadMap={() => loadZipBoundaries(uniqueZipCodes)}
                    onLoadBoundaries={() => loadZipBoundaries(uniqueZipCodes)}
                    isLoadingBoundaries={isLoadingBoundaries}
                    isFindingZips={false}
                    mapColorMetric={mapColorMetric}
                    onMapColorMetricChange={setMapColorMetric}
                    showRadiusReference={showRadiusReference}
                    onShowRadiusChange={setShowRadiusReference}
                    radiusMiles={radiusMiles}
                    onRadiusMilesChange={setRadiusMiles}
                    zipCodes={uniqueZipCodes}
                    censusData={censusData}
                    onReloadAll={handleReloadAllData}
                    isReloadingAll={isReloadingAll}
                    showCompetitors={showCompetitors}
                    onShowCompetitorsChange={setShowCompetitors}
                    mapSettings={mapSettings}
                    onMapSettingsChange={setMapSettings}
                    onCollapseChange={setIsSidebarCollapsed}
                  />
                </div>
              </div>
              </div>

              <EnhancedZipDataTable
                zipCodes={uniqueZipCodes}
                mapColorMetric={mapColorMetric}
                onMapColorMetricChange={setMapColorMetric}
                assessment={assessment}
                censusData={censusData}
                isLoadingData={isLoadingCensusData}
                onRefresh={() => loadDemographicData(assessment, true)}
                onFindMissingData={() => {
                  setActiveTab('analysis');
                  setTimeout(() => {
                    setQuickPrompt("Find and fill in missing demographic data for ZIP codes that don't have complete information. Focus on median income, poverty rate, and uninsured rate data.");
                  }, 100);
                }}
              />
          </TabsContent>

          <TabsContent value="insights" className="mt-6">
            <KeyInsights 
              assessment={assessment}
              censusData={censusData}
              organizations={organizations}
            />
          </TabsContent>

          <TabsContent value="competitors" className="mt-6 space-y-6">
            <CompetitorManager
              assessment={assessment}
              onOrganizationsUpdate={(updatedOrgs) => setAssessment(prev => ({ ...prev, organizations: updatedOrgs }))}
            />
            <CompetitorLocationMapping
              organizations={organizations}
              zipCodes={uniqueZipCodes}
              assessment={assessment}
            />
          </TabsContent>

          <TabsContent value="data" className="mt-6 space-y-6">
            <DataSourceManager
              assessment={assessment}
              onUpdateAssessment={setAssessment}
            />
            
            {/* Google Places Enricher */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Google Places Data Enrichment</span>
                  <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                    5 tokens/search
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {showPlacesEnricher ? (
                  <GooglePlacesEnricher
                    latitude={assessment?.geography?.latitude}
                    longitude={assessment?.geography?.longitude}
                    onResultsFound={(results) => {
                      toast.success(`Found ${results.length} places`);
                    }}
                    onEnrichComplete={(enrichedPlaces) => {
                      // Add enriched places as organizations
                      const newOrgs = enrichedPlaces.map(place => ({
                        id: `gp_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                        name: place.name,
                        type: place.types?.includes('hospital') ? 'hospital' : 
                              place.types?.includes('health') ? 'clinic' : 'other',
                        address: place.address,
                        coordinates: place.coordinates,
                        phone: place.phone,
                        website: place.website,
                        source: 'Google Places'
                      }));
                      setAssessment(prev => ({
                        ...prev,
                        organizations: [...(prev.organizations || []), ...newOrgs]
                      }));
                      toast.success(`Added ${newOrgs.length} organizations`);
                    }}
                  />
                ) : (
                  <div className="text-center py-6">
                    <p className="text-gray-600 mb-4">
                      Search for schools, non-profits, healthcare facilities, and more using Google Places API
                    </p>
                    <Button 
                      onClick={() => setShowPlacesWarning(true)}
                      className="bg-emerald-600 hover:bg-emerald-700"
                    >
                      Enable Google Places Search
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
            
            <GooglePlacesWarningDialog
              open={showPlacesWarning}
              onOpenChange={setShowPlacesWarning}
              onConfirm={() => {
                setShowPlacesWarning(false);
                setShowPlacesEnricher(true);
              }}
            />
          </TabsContent>

          <TabsContent value="analysis" className="mt-6">
            <div className="grid lg:grid-cols-2 gap-6 items-start">
              <DataEnhancement
                assessment={assessment}
                onQuickAction={setQuickPrompt}
              />
              <AIChat 
                onAddZips={(zips) => {
                  const updatedZips = [...new Set([...uniqueZipCodes, ...zips])];
                  const updated = {
                    ...assessment,
                    geography: { ...assessment.geography, zip_codes: updatedZips },
                    processed_data: { ...assessment.processed_data, zip_codes: updatedZips }
                  };
                  setAssessment(updated);
                  loadDemographicData(updated, true);
                }}
                onAddOrgs={(orgs) => {
                  const newOrgs = orgs.map(org => ({
                    id: `ai_${Date.now()}_${Math.random()}`,
                    name: org.name,
                    type: 'fqhc',
                    source: 'AI Assistant'
                  }));
                  setAssessment(prev => ({ ...prev, organizations: [...(prev.organizations || []), ...newOrgs] }));
                }}
                onUpdateCensusData={(newData) => {
                  setCensusData(prev => {
                    const updated = { ...prev, ...newData };
                    
                    // Save to assessment processed_data
                    setAssessment(currentAssessment => ({
                      ...currentAssessment,
                      processed_data: {
                        ...currentAssessment.processed_data,
                        census_data: updated
                      }
                    }));
                    
                    return updated;
                  });
                }}
                assessment={assessment}
                quickPrompt={quickPrompt}
                onQuickPromptUsed={() => setQuickPrompt(null)}
              />
            </div>
          </TabsContent>

          <TabsContent value="publish" className="mt-6 space-y-6">
            <PublishDashboard assessment={assessment} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}