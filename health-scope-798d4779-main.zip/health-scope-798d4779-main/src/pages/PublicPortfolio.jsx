import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Map, 
  Calendar, 
  Users, 
  Building2, 
  ExternalLink,
  Loader2,
  Globe,
  Linkedin,
  Coins,
  MapPin
} from "lucide-react";

export default function PublicPortfolio() {
  const [assessments, setAssessments] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [creators, setCreators] = useState({});
  const [user, setUser] = useState(null);

  useEffect(() => {
    loadPublicAssessments();
    loadUser();
  }, []);

  const loadUser = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      // User not logged in, that's okay for public portfolio
      setUser(null);
    }
  };

  const loadPublicAssessments = async () => {
    setIsLoading(true);
    try {
      // Load all published assessments
      const data = await base44.entities.Assessment.filter({
        'published_settings.is_public': true,
        status: 'published'
      }, '-created_date', 50);

      setAssessments(data || []);

      // Load creator info for all assessments
      if (data && data.length > 0) {
        const creatorEmails = [...new Set(data.map(a => a.created_by).filter(Boolean))];
        if (creatorEmails.length > 0) {
          try {
            const users = await base44.entities.User.filter({
              email: { '$in': creatorEmails }
            });

            const creatorsMap = {};
            users.forEach(user => {
              creatorsMap[user.email] = user;
            });
            setCreators(creatorsMap);
          } catch (userError) {
            console.warn('Could not load creator info:', userError);
          }
        }
      }

    } catch (error) {
      console.error('Error loading public assessments:', error);
      setAssessments([]);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-blue-600 mx-auto mb-4" />
          <p className="text-gray-600">Loading public dashboards...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-blue-50">
      {/* Top Bar with Token */}
      {user && (
        <div className="bg-white border-b border-gray-100">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2">
            <div className="flex justify-end">
              <Link to={createPageUrl("Pricing")} className="flex items-center gap-2 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200 hover:bg-emerald-100 transition-colors">
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/83f057394_tokens.png"
                  alt="Tokens"
                  className="w-4 h-4"
                />
                <div className="text-xs">
                  <span className="font-semibold text-gray-900">{user.token_balance || 0}</span>
                  <span className="text-emerald-600 ml-1">tokens</span>
                </div>
              </Link>
            </div>
          </div>
        </div>
      )}
      
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center justify-between">
            <div className="flex items-start gap-4">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/0937d203f_portfolio2.png"
                alt="Public Portfolio"
                className="w-16 h-16 flex-shrink-0"
              />
              <div>
                <h1 className="text-4xl font-bold text-gray-900 mb-2">
                  Community Health Assessments
                </h1>
                <p className="text-lg text-gray-600">
                  Explore public health data and insights from communities across the nation
                </p>
              </div>
            </div>
            <Link to={createPageUrl("Home")}>
              <Button variant="outline">
                Create Your Own
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {assessments.length === 0 ? (
          <Card className="text-center py-12">
            <CardContent>
              <Map className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                No Public Dashboards Yet
              </h3>
              <p className="text-gray-600 mb-6">
                Be the first to publish a community health assessment!
              </p>
              <Link to={createPageUrl("Home")}>
                <Button>Get Started</Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {assessments.map((assessment) => {
              const creator = creators[assessment.created_by] || {};
              const publishSettings = assessment.published_settings || {};
              const location = assessment.geography?.city && assessment.geography?.state
                ? `${assessment.geography.city}, ${assessment.geography.state}`
                : 'Assessment';
              const zipCount = assessment.geography?.zcta_codes?.length || assessment.geography?.zip_codes?.length || 0;
              
              return (
                <Card key={assessment.id} className="hover:shadow-xl transition-all border border-gray-200 hover:border-emerald-300">
                  <CardHeader className="pb-4">
                    <div className="flex items-start justify-between mb-3">
                      <Badge className="bg-green-100 text-green-700 border-green-200 text-xs px-2 py-1">
                        Published
                      </Badge>
                    </div>
                    <CardTitle className="text-xl font-bold line-clamp-2 mb-2">
                      {publishSettings.title || assessment.title}
                    </CardTitle>
                    {(publishSettings.description || assessment.description) && (
                      <p className="text-sm text-gray-600 line-clamp-2 leading-relaxed">
                        {publishSettings.description || assessment.description}
                      </p>
                    )}
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Location */}
                    <div className="flex items-center gap-2 text-sm">
                      <MapPin className="w-4 h-4 text-gray-500" />
                      <span className="text-gray-700 font-medium">{location}</span>
                    </div>

                    {/* Stats */}
                    <div className="flex gap-2 text-sm">
                      <div className="flex items-center gap-1.5 bg-gray-50 px-3 py-1.5 rounded-md">
                        <Users className="w-4 h-4 text-gray-500" />
                        <span className="font-medium text-gray-700">{zipCount} ZIPs</span>
                      </div>
                      {assessment.organizations?.length > 0 && (
                        <div className="flex items-center gap-1.5 bg-gray-50 px-3 py-1.5 rounded-md">
                          <Building2 className="w-4 h-4 text-gray-500" />
                          <span className="font-medium text-gray-700">{assessment.organizations.length} orgs</span>
                        </div>
                      )}
                    </div>

                    {/* Creator Info */}
                    <div className="border-t pt-4">
                      <div className="flex items-center gap-3 mb-2">
                        <Avatar className="w-9 h-9">
                          <AvatarImage src={creator.profile_picture} className="object-cover" />
                          <AvatarFallback className="text-xs">
                            {creator.full_name?.charAt(0) || 'U'}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-gray-900 truncate">
                            {creator.full_name || 'Anonymous'}
                          </p>
                          {creator.title && (
                            <p className="text-xs text-gray-500 truncate">
                              {creator.title}
                            </p>
                          )}
                        </div>
                      </div>
                      
                      {/* Creator Links */}
                      {(creator.linkedin_url || creator.website_url) && (
                        <div className="flex gap-2 pl-12">
                          {creator.linkedin_url && (
                            <a
                              href={creator.linkedin_url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-blue-600 hover:text-blue-700"
                            >
                              <Linkedin className="w-3.5 h-3.5" />
                            </a>
                          )}
                          {creator.website_url && (
                            <a
                              href={creator.website_url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-gray-600 hover:text-gray-700"
                            >
                              <Globe className="w-3.5 h-3.5" />
                            </a>
                          )}
                        </div>
                      )}
                    </div>

                    {/* View Button */}
                    <Link to={createPageUrl("PublicAssessmentView") + `?id=${assessment.id}`}>
                      <Button className="w-full bg-emerald-600 hover:bg-emerald-700 text-white">
                        View Dashboard
                        <ExternalLink className="w-4 h-4 ml-2" />
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="border-t border-gray-200 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-center text-gray-600">
          <p>Powered by HealthScope | Community Health Analytics Platform</p>
        </div>
      </div>
    </div>
  );
}