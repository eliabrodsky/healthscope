import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { 
  Building2, 
  Users, 
  MapPin, 
  Activity, 
  TrendingUp, 
  Search, 
  ArrowRight, 
  Map as MapIcon, 
  FileText, 
  Loader2, 
  ArrowLeft, 
  Plus,
  Filter,
  RefreshCw,
  Check
} from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";

import FqhcList from "../components/fqhc/FqhcList";
import FqhcDetailPanel from "../components/fqhc/FqhcDetailPanel";
import FqhcMapView from "../components/fqhc/FqhcMapView";
import FqhcComparisonView from "../components/fqhc/FqhcComparisonView";
import FqhcServiceAreaMap from "../components/fqhc/FqhcServiceAreaMap";
import FqhcYoyComparison from "../components/fqhc/FqhcYoyComparison";
import FqhcFilters from "../components/fqhc/FqhcFilters";

// Haversine formula to calculate distance
function getDistanceFromLatLonInMiles(lat1, lon1, lat2, lon2) {
  var R = 3963; // Radius of the earth in miles
  var dLat = deg2rad(lat2-lat1);
  var dLon = deg2rad(lon2-lon1); 
  var a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * 
    Math.sin(dLon/2) * Math.sin(dLon/2)
    ; 
  var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
  var d = R * c; // Distance in miles
  return d;
}

function deg2rad(deg) {
  return deg * (Math.PI/180)
}

const LOADING_PHRASES = [
  "Fetching HRSA data from database...",
  "Parsing Census data by FQHC...",
  "Populating tables for FTE and Financial data...",
  "Fetching Demographics...",
  "Loading service area ZIP codes...",
  "Processing workforce metrics...",
  "Analyzing patient volume data...",
  "Compiling clinical quality measures...",
  "Geocoding FQHC site locations...",
  "Building payer mix breakdowns..."
];

export default function FqhcAssessment() {
  // Step 1: Selection Mode (null = not selected)
  // 'assessment' | 'location' | 'name'
  const [mode, setMode] = useState(null);
  const [loadingPhrase, setLoadingPhrase] = useState(LOADING_PHRASES[0]);
  
  // Data Context
  const [activeAssessment, setActiveAssessment] = useState(null);
  const [searchState, setSearchState] = useState("");
  const [searchName, setSearchName] = useState("");
  
  // Loaded Data
  const [fqhcs, setFqhcs] = useState([]);
  const [selectedFqhc, setSelectedFqhc] = useState(null);
  const [comparisonFqhcs, setComparisonFqhcs] = useState([]);
  const [assessments, setAssessments] = useState([]);
  
  // UI State
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("details");
  const [udsYear, setUdsYear] = useState("2024");
  const [showServiceArea, setShowServiceArea] = useState(false);
  const [showYoy, setShowYoy] = useState(false);

  // Filter State
  const [filters, setFilters] = useState({
    patients: [0, 200000],
    sites: [0, 50],
    proximity: { active: false, radius: 25 }
  });
  
  // Sidebar State
  const [listSidebarCollapsed, setListSidebarCollapsed] = useState(false);

  // Rotate loading phrases
  useEffect(() => {
    if (!isLoading) return;
    const interval = setInterval(() => {
      setLoadingPhrase(prev => {
        const currentIndex = LOADING_PHRASES.indexOf(prev);
        const nextIndex = (currentIndex + 1) % LOADING_PHRASES.length;
        return LOADING_PHRASES[nextIndex];
      });
    }, 2500);
    return () => clearInterval(interval);
  }, [isLoading]);

  // Filtered Data
  const filteredFqhcs = fqhcs.filter(f => {
    // Patients
    const patients = f.total_patients || 0;
    if (patients < filters.patients[0]) return false;
    if (filters.patients[1] < 200000 && patients > filters.patients[1]) return false;

    // Sites
    const sites = f.sites?.length || 0;
    if (sites < filters.sites[0]) return false;
    if (filters.sites[1] < 50 && sites > filters.sites[1]) return false;

    // Proximity
    if (filters.proximity.active && filters.proximity.latitude && filters.proximity.longitude) {
      if (!f.coordinates?.latitude || !f.coordinates?.longitude) return false;
      const dist = getDistanceFromLatLonInMiles(
        filters.proximity.latitude,
        filters.proximity.longitude,
        f.coordinates.latitude,
        f.coordinates.longitude
      );
      if (dist > filters.proximity.radius) return false;
    }

    return true;
  });

  // Load assessments on mount - ONLY fetch id and title for performance
  useEffect(() => {
    const fetchAssessments = async () => {
      // Use filter with minimal data - just need id and title for the dropdown
      const data = await base44.entities.Assessment.filter({}, '-created_date', 50);
      // Map to lightweight objects to avoid memory issues
      const lightweight = data.map(a => ({
        id: a.id,
        title: a.title,
        geography: a.geography // Keep geography for state info when selected
      }));
      setAssessments(lightweight);
    };
    fetchAssessments();
  }, []);

  // Handlers for Step 1
  const handleModeSelect = (selectedMode) => {
    setMode(selectedMode);
    setFqhcs([]);
    setSelectedFqhc(null);
  };

  const handleAssessmentSelect = async (assessmentId) => {
    setIsLoading(true);
    // Reset data when switching assessments
    setFqhcs([]);
    setSelectedFqhc(null);
    setComparisonFqhcs([]);
    
    try {
      const assessment = assessments.find(a => a.id === assessmentId);
      setActiveAssessment(assessment);
      setSearchState(assessment.geography?.state || ""); // Ensure state context is known
      
      // Load FQHCs for this assessment
      // 1. Try cache
      const cached = await base44.entities.FqhcProfile.filter({
        assessment_id: assessmentId,
        uds_year: parseInt(udsYear)
      }, null, 100);

      if (cached.length > 0) {
        setFqhcs(cached);
        toast.success(`Loaded ${cached.length} FQHCs from assessment`);
      } else {
        // 2. Enrich if needed
        const state = assessment.geography?.state;
        if (state) {
          toast.loading("Loading FQHC data for assessment area...");
          const res = await base44.functions.invoke('fetchHrsaFqhcData', {
            assessmentId: assessment.id,
            state: state,
            udsYear: parseInt(udsYear)
          });
          if (res.data?.success) {
            // Reload from cache
            const fresh = await base44.entities.FqhcProfile.filter({
              assessment_id: assessmentId,
              uds_year: parseInt(udsYear)
            }, null, 100);
            setFqhcs(fresh);
            toast.dismiss();
            toast.success(`Found ${fresh.length} FQHCs`);
          }
        }
      }
    } catch (err) {
      console.error(err);
      toast.error("Failed to load assessment data");
    } finally {
      setIsLoading(false);
    }
  };

  const handleLocationSearch = async () => {
    if (!searchState) return;
    setIsLoading(true);
    try {
      // Use fetchHrsaFqhcData without assessmentId to just get data
      // Note: The function creates profiles. We can filter by state.
      const res = await base44.functions.invoke('fetchHrsaFqhcData', {
        state: searchState,
        udsYear: parseInt(udsYear)
      });

      if (res.data?.success) {
        // Now fetch the profiles created/updated for this state/year
        // Since we didn't pass assessmentId, we filter by state
        const profiles = await base44.entities.FqhcProfile.filter({
          state: searchState,
          uds_year: parseInt(udsYear)
        }, null, 100);
        
        setFqhcs(profiles);
        toast.success(`Found ${profiles.length} FQHCs in ${searchState}`);
      } else {
        toast.error("No FQHCs found for this location");
      }
    } catch (err) {
      console.error(err);
      toast.error("Search failed");
    } finally {
      setIsLoading(false);
    }
  };

  const handleNameSearch = async () => {
    if (!searchName) return;
    setIsLoading(true);
    try {
      const res = await base44.functions.invoke('searchFqhc', {
        query: searchName,
        udsYear: parseInt(udsYear)
      });
      
      if (res.data?.success && res.data.fqhcs) {
        setFqhcs(res.data.fqhcs);
        toast.success(`Found ${res.data.fqhcs.length} matching FQHCs`);
      } else {
        toast.warning("No matches found");
      }
    } catch (err) {
      console.error(err);
      toast.error("Search failed");
    } finally {
      setIsLoading(false);
    }
  };

  const reset = () => {
    setMode(null);
    setFqhcs([]);
    setActiveAssessment(null);
    setSearchState("");
    setSearchName("");
    setSelectedFqhc(null);
    setComparisonFqhcs([]);
  };

  const handleReloadData = async () => {
    // Use only the active assessment's state, not the searchState from location mode
    const state = activeAssessment?.geography?.state;
    if (!activeAssessment && !state) return;
    
    setIsLoading(true);
    
    try {
      
      // Force refresh from API
      const res = await base44.functions.invoke('fetchHrsaFqhcData', {
        assessmentId: activeAssessment?.id,
        state: state,
        udsYear: parseInt(udsYear)
      });
      
      if (res.data?.success) {
        // Reload from cache - always use assessment_id when we have it
        const fresh = await base44.entities.FqhcProfile.filter({
          assessment_id: activeAssessment.id,
          uds_year: parseInt(udsYear)
        }, null, 100);
        setFqhcs(fresh);
        toast.success(`Reloaded ${fresh.length} FQHCs`);
      }
    } catch (err) {
      console.error(err);
      toast.error("Failed to reload data");
    } finally {
      setIsLoading(false);
    }
  };

  const toggleCompare = (fqhc) => {
    const exists = comparisonFqhcs.find(c => c.bhcmis_id === fqhc.bhcmis_id);
    if (exists) {
      setComparisonFqhcs(prev => prev.filter(f => f.bhcmis_id !== fqhc.bhcmis_id));
    } else {
      setComparisonFqhcs(prev => [...prev, fqhc]);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6 relative">
      {isLoading && (
                <div className="fixed inset-0 bg-white/90 backdrop-blur-sm z-[9999] flex items-center justify-center">
                  <div className="bg-white p-8 rounded-2xl shadow-xl flex flex-col items-center border border-slate-100 min-w-[320px]">
                    <div className="relative">
                      <div className="w-16 h-16 border-4 border-emerald-100 border-t-emerald-500 rounded-full animate-spin"></div>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <Activity className="w-6 h-6 text-emerald-600" />
                      </div>
                    </div>
                    <h3 className="mt-6 text-lg font-bold text-slate-900">Loading FQHC Data</h3>
                    <p className="text-slate-500 mt-2 text-center transition-opacity duration-300">{loadingPhrase}</p>
                  </div>
                </div>
              )}

      <div className="max-w-[1600px] mx-auto space-y-6">
        
        {/* Header Banner */}
        <div className="bg-white rounded-xl p-6 mb-6 shadow-sm border-2 border-emerald-500">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/6579b7b6c_map-fqhc-icon.png"
                alt="FQHC"
                className="w-16 h-16 object-contain"
              />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">FQHC Assessment</h1>
                <p className="text-sm text-gray-600 mt-1">
                  Analyze Federally Qualified Health Centers using UDS data. Compare patient volumes, service areas, workforce, and financial performance.
                </p>
              </div>
            </div>
            {mode && (
              <Button variant="outline" size="sm" onClick={reset}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Selection
              </Button>
            )}
          </div>
        </div>

        {/* Step 1: Mode Selection */}
        {!mode && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
            <Card className="hover:shadow-lg cursor-pointer transition-all group border-gray-200" onClick={() => handleModeSelect('assessment')}>
              <CardHeader>
                <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-emerald-200 transition-colors">
                  <FileText className="w-6 h-6 text-emerald-700" />
                </div>
                <CardTitle>Existing Assessment</CardTitle>
                <CardDescription>Analyze FQHCs within one of your defined assessment areas.</CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant="ghost" className="w-full justify-between group-hover:text-emerald-700">
                  Select Assessment <ArrowRight className="w-4 h-4" />
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg cursor-pointer transition-all group border-gray-200" onClick={() => handleModeSelect('location')}>
              <CardHeader>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-blue-200 transition-colors">
                  <MapPin className="w-6 h-6 text-blue-700" />
                </div>
                <CardTitle>Select an Area</CardTitle>
                <CardDescription>Explore FQHCs by State or Region without an assessment.</CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant="ghost" className="w-full justify-between group-hover:text-blue-700">
                  Search by Location <ArrowRight className="w-4 h-4" />
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg cursor-pointer transition-all group border-gray-200" onClick={() => handleModeSelect('name')}>
              <CardHeader>
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-purple-200 transition-colors">
                  <Search className="w-6 h-6 text-purple-700" />
                </div>
                <CardTitle>Search by Name</CardTitle>
                <CardDescription>Find a specific FQHC by name, grant number, or BHCMIS ID.</CardDescription>
              </CardHeader>
              <CardContent>
                <Button variant="ghost" className="w-full justify-between group-hover:text-purple-700">
                  Find FQHC <ArrowRight className="w-4 h-4" />
                </Button>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Step 2: Input & Loading */}
        {mode && fqhcs.length === 0 && (
          <Card>
            <CardHeader>
              <CardTitle>
                {mode === 'assessment' && "Select Assessment"}
                {mode === 'location' && "Enter Location"}
                {mode === 'name' && "Search FQHC"}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4 max-w-xl">
                {mode === 'assessment' && (
                  <Select onValueChange={handleAssessmentSelect}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose an assessment..." />
                    </SelectTrigger>
                    <SelectContent>
                      {assessments.map(a => (
                        <SelectItem key={a.id} value={a.id}>{a.title}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}

                {mode === 'location' && (
                  <>
                    <Select value={searchState} onValueChange={setSearchState}>
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="Select State" />
                      </SelectTrigger>
                      <SelectContent>
                        {["AL","AK","AZ","AR","CA","CO","CT","DE","FL","GA","HI","ID","IL","IN","IA","KS","KY","LA","ME","MD","MA","MI","MN","MS","MO","MT","NE","NV","NH","NJ","NM","NY","NC","ND","OH","OK","OR","PA","RI","SC","SD","TN","TX","UT","VT","VA","WA","WV","WI","WY"].map(s => (
                          <SelectItem key={s} value={s}>{s}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Button onClick={handleLocationSearch} disabled={isLoading || !searchState}>
                      {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Search Area"}
                    </Button>
                  </>
                )}

                {mode === 'name' && (
                  <>
                    <Input 
                      placeholder="FQHC Name, Grant #, or BHCMIS ID" 
                      value={searchName}
                      onChange={(e) => setSearchName(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleNameSearch()}
                    />
                    <Button onClick={handleNameSearch} disabled={isLoading || !searchName}>
                      {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Search"}
                    </Button>
                  </>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Step 3: Dashboard */}
        {fqhcs.length > 0 && (
          <div className="space-y-6">
            
            {/* Top Bar: Context + Actions */}
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
              <div className="flex items-center gap-4">
                <div className="bg-emerald-600 p-3 rounded-xl shadow-sm">
                  <Activity className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="font-bold text-slate-900 text-xl">
                    {activeAssessment ? activeAssessment.title : (searchState || "Area Search")}
                  </h2>
                  <div className="flex items-center gap-4 text-sm text-slate-500 mt-1">
                    <span className="flex items-center gap-1.5">
                      <Building2 className="w-4 h-4" />
                      <strong className="text-slate-700">{filteredFqhcs.length}</strong> FQHCs
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Users className="w-4 h-4" />
                      <strong className="text-slate-700">{(filteredFqhcs.reduce((sum, f) => sum + (f.total_patients || 0), 0) / 1000).toFixed(1)}k</strong> Patients
                    </span>
                    <span className="flex items-center gap-1.5">
                      <MapPin className="w-4 h-4" />
                      <strong className="text-slate-700">{filteredFqhcs.reduce((sum, f) => sum + (f.sites?.length || 1), 0)}</strong> Sites
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <Sheet>
                  <SheetTrigger asChild>
                    <Button variant="outline" size="sm" className="gap-2">
                      <Filter className="w-4 h-4" />
                      Filters
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="right" className="w-[320px] sm:w-[360px] z-[100]">
                    <SheetHeader>
                      <SheetTitle>Filter Organizations</SheetTitle>
                    </SheetHeader>
                    <div className="mt-6">
                      <FqhcFilters 
                        filters={filters}
                        onFilterChange={setFilters}
                      />
                    </div>
                  </SheetContent>
                </Sheet>
                
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={handleReloadData}
                  disabled={isLoading}
                  className="gap-2"
                >
                  <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
                  Reload
                </Button>
                
                <Select value={udsYear} onValueChange={setUdsYear}>
                  <SelectTrigger className="w-[100px] bg-slate-50 border-slate-200">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="2024">2024</SelectItem>
                    <SelectItem value="2023">2023</SelectItem>
                    <SelectItem value="2022">2022</SelectItem>
                  </SelectContent>
                </Select>
                
                {activeAssessment && (
                  <Button 
                    className="bg-emerald-600 text-white hover:bg-emerald-700"
                    size="sm"
                    onClick={async () => {
                      try {
                        const orgs = fqhcs.map(f => ({
                          id: f.bhcmis_id,
                          name: f.health_center_name,
                          type: 'fqhc',
                          city: f.city,
                          state: f.state,
                          patient_volume: f.total_patients,
                          coordinates: f.coordinates
                        }));
                        
                        await base44.entities.Assessment.update(activeAssessment.id, {
                          organizations: orgs,
                          status: 'building'
                        });
                        toast.success("Saved FQHCs to Assessment Dashboard");
                      } catch(e) {
                        console.error(e);
                        toast.error("Failed to save");
                      }
                    }}
                  >
                    Save
                  </Button>
                )}
              </div>
            </div>

            {/* Main Content: List + Detail Panel */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">

              {/* Left: Organization List (Collapsible) */}
              {!listSidebarCollapsed && (
                <div className="lg:col-span-5 xl:col-span-4">
                  <Card className="border-slate-200 shadow-sm overflow-hidden">
                    <CardHeader className="py-2 px-4 border-b bg-slate-50/80">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-sm font-semibold text-slate-600">
                          Organizations
                        </CardTitle>
                        <div className="flex items-center gap-2">
                          {comparisonFqhcs.length > 0 && (
                            <Badge className="bg-emerald-100 text-emerald-700 text-xs">
                              {comparisonFqhcs.length} selected
                            </Badge>
                          )}
                          <Badge variant="secondary" className="text-xs">
                            {filteredFqhcs.length}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <div className="max-h-[calc(100vh-320px)] min-h-[500px] overflow-y-auto bg-white">
                      <FqhcList 
                        fqhcs={filteredFqhcs}
                        onSelect={(f) => {
                          setSelectedFqhc(f);
                          if (activeTab === 'list') setActiveTab('details');
                        }}
                        onAddToComparison={toggleCompare}
                        selectedId={selectedFqhc?.bhcmis_id}
                        comparisonIds={comparisonFqhcs.map(c => c.bhcmis_id)}
                      />
                    </div>
                  </Card>
                </div>
              )}

              {/* Right: Detail Tabs */}
              <div className={listSidebarCollapsed ? "lg:col-span-12" : "lg:col-span-7 xl:col-span-8"}>
                <Card className="border-slate-200 shadow-sm overflow-hidden">
                  <Tabs value={activeTab} onValueChange={setActiveTab} className="flex flex-col">
                    <div className="px-4 pt-3 pb-2 border-b bg-slate-50/50">
                      <TabsList className="bg-white border border-slate-200 p-1 h-10">
                        <TabsTrigger value="details" className="text-sm px-4">
                          <FileText className="w-4 h-4 mr-2" /> Details
                        </TabsTrigger>
                        <TabsTrigger value="map" className="text-sm px-4">
                          <MapIcon className="w-4 h-4 mr-2" /> Map
                        </TabsTrigger>
                        <TabsTrigger value="trends" className="text-sm px-4">
                          <TrendingUp className="w-4 h-4 mr-2" /> Trends
                        </TabsTrigger>
                        <TabsTrigger value="compare" className="text-sm px-4" disabled={comparisonFqhcs.length < 2}>
                          <Activity className="w-4 h-4 mr-2" /> Compare ({comparisonFqhcs.length})
                        </TabsTrigger>
                      </TabsList>
                    </div>

                    <div className="max-h-[calc(100vh-320px)] min-h-[500px] overflow-y-auto bg-white">
                      
                      <TabsContent value="details" className="mt-0 p-0">
                        {selectedFqhc ? (
                          <FqhcDetailPanel 
                            fqhc={selectedFqhc}
                            onBack={() => setSelectedFqhc(null)}
                            onAddToComparison={() => {
                              if (!comparisonFqhcs.find(c => c.bhcmis_id === selectedFqhc.bhcmis_id)) {
                                setComparisonFqhcs([...comparisonFqhcs, selectedFqhc]);
                                toast.success("Added to comparison");
                              }
                            }}
                            onViewServiceArea={() => setShowServiceArea(true)}
                            onViewYoY={() => setShowYoy(true)}
                            embedded={true} 
                          />
                        ) : (
                          <div className="h-[500px] flex flex-col items-center justify-center text-center p-8">
                            <div className="bg-slate-100 p-5 rounded-2xl mb-5">
                              <Building2 className="w-10 h-10 text-slate-400" />
                            </div>
                            <h3 className="text-lg font-semibold text-slate-800">Select an Organization</h3>
                            <p className="text-slate-500 max-w-sm mt-2">
                              Choose an FQHC from the list to view detailed profile, service area, workforce, and financial metrics.
                            </p>
                          </div>
                        )}
                      </TabsContent>

                      <TabsContent value="map" className="mt-0 p-4 h-[500px]">
                        <FqhcMapView 
                          fqhcs={filteredFqhcs}
                          onSelectFqhc={(f) => {
                            setSelectedFqhc(f);
                            setListSidebarCollapsed(false);
                            setActiveTab('details');
                          }}
                          assessment={activeAssessment}
                          selectedFqhc={selectedFqhc}
                          sidebarCollapsed={listSidebarCollapsed}
                          onSidebarToggle={() => setListSidebarCollapsed(!listSidebarCollapsed)}
                        />
                      </TabsContent>

                      <TabsContent value="trends" className="mt-0 p-4">
                        {selectedFqhc ? (
                          <div className="h-[450px] flex flex-col items-center justify-center">
                            <TrendingUp className="w-12 h-12 text-emerald-500 mb-4" />
                            <h3 className="text-lg font-medium text-slate-800">{selectedFqhc.health_center_name}</h3>
                            <p className="text-slate-500 max-w-xs mt-2 mb-4">Click below to view year-over-year performance trends.</p>
                            <Button onClick={() => setShowYoy(true)} className="bg-emerald-600 hover:bg-emerald-700">
                              <TrendingUp className="w-4 h-4 mr-2" /> View Trends
                            </Button>
                          </div>
                        ) : (
                          <div className="h-[400px] flex flex-col items-center justify-center text-center p-8">
                            <TrendingUp className="w-12 h-12 text-slate-300 mb-4" />
                            <h3 className="text-lg font-medium text-slate-800">No FQHC Selected</h3>
                            <p className="text-slate-500 max-w-xs mt-2">Select an organization to analyze year-over-year performance trends.</p>
                          </div>
                        )}
                      </TabsContent>

                      <TabsContent value="compare" className="mt-0 p-4">
                        <FqhcComparisonView 
                          fqhcs={comparisonFqhcs}
                          onRemove={(id) => setComparisonFqhcs(prev => prev.filter(f => f.bhcmis_id !== id))}
                        />
                      </TabsContent>
                    </div>
                  </Tabs>
                </Card>
              </div>
            </div>
          </div>
        )}

        {/* Modals */}
        {showServiceArea && selectedFqhc && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-xl w-full max-w-5xl max-h-[90vh] overflow-auto">
              <FqhcServiceAreaMap 
                fqhc={selectedFqhc}
                onClose={() => setShowServiceArea(false)}
              />
            </div>
          </div>
        )}

        {showYoy && selectedFqhc && (
          <FqhcYoyComparison
            fqhc={selectedFqhc}
            onClose={() => setShowYoy(false)}
          />
        )}

      </div>
    </div>
  );
}