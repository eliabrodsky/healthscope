import React, { useState, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Upload, 
  FileText, 
  ImageIcon, 
  Database,
  CheckCircle,
  AlertCircle,
  X,
  FileArchive,
  AlertTriangle,
  MapPin
} from "lucide-react";
import { toast } from "sonner";

import UploadZone from "../components/upload/UploadZone";
import FilePreview from "../components/upload/FilePreview";
import DataExtraction from "../components/upload/DataExtraction";
import ExcelPreview from "../components/upload/ExcelPreview";

const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB limit
const UPLOAD_TIMEOUT = 120000; // 2 minute timeout
const JSON_PARSE_TIMEOUT = 30000; // 30 second timeout for JSON parsing

export default function DataUploadPage() {
  const [files, setFiles] = useState([]);
  const [uploading, setUploading] = useState([]);
  const [processing, setProcessing] = useState([]);
  const [uploadProgress, setUploadProgress] = useState([]);
  const [extractedData, setExtractedData] = useState([]);
  const [uploadErrors, setUploadErrors] = useState([]);
  const [zctaCsvFile, setZctaCsvFile] = useState(null);
  const [isLoadingZcta, setIsLoadingZcta] = useState(false);
  const fileInputRef = useRef(null);
  const zctaInputRef = useRef(null);

  const handleZctaCsvUpload = async () => {
    if (!zctaCsvFile) {
      toast.error("Please select a file first");
      return;
    }

    setIsLoadingZcta(true);
    const loadingToastId = 'zcta-upload';
    toast.loading(`Loading ZCTA data from ${zctaCsvFile.name}...`, { id: loadingToastId });

    try {
      const csvText = await zctaCsvFile.text();
      
      // Auto-detect state from filename or first data row
      const firstDataLine = csvText.split('\n')[1]; // Skip header
      const stateAbbr = firstDataLine?.split(',')[0]?.trim().toUpperCase();

      if (!stateAbbr || stateAbbr.length !== 2) {
        throw new Error('Could not detect state abbreviation from file. Ensure the first column of the first data row contains a 2-letter state abbreviation.');
      }

      const response = await base44.functions.invoke('loadZctaCrosswalk', {
        csvText: csvText,
        stateAbbr: stateAbbr
      });

      if (response?.data?.success) {
        toast.success(
          response.data.message,
          { id: loadingToastId, duration: 8000 }
        );
        setZctaCsvFile(null);
        if (zctaInputRef.current) {
          zctaInputRef.current.value = '';
        }
      } else {
        throw new Error(response?.data?.error || 'Upload failed');
      }

    } catch (error) {
      console.error('ZCTA upload error:', error);
      toast.error(
        `Failed to load ZCTA data: ${error.message}`,
        { id: loadingToastId, duration: 10000 }
      );
    } finally {
      setIsLoadingZcta(false);
    }
  };

  const handleFileSelect = (selectedFiles) => {
    const newFiles = Array.from(selectedFiles).filter(file => 
      file.type === 'application/pdf' || 
      file.type.startsWith('image/') ||
      file.name.endsWith('.csv') ||
      file.name.endsWith('.xlsx') ||
      file.name.endsWith('.json') ||
      file.type === 'application/json' ||
      file.name.endsWith('.geojson') ||
      file.name.endsWith('.geo.json') ||
      file.name.endsWith('.zip') ||
      file.type === 'application/zip' ||
      file.type === 'application/x-zip-compressed'
    );
    
    if (newFiles.length > 0) {
      // Check for oversized files
      const oversizedFiles = newFiles.filter(f => f.size > MAX_FILE_SIZE);
      
      if (oversizedFiles.length > 0) {
        oversizedFiles.forEach(file => {
          const sizeMB = (file.size / (1024 * 1024)).toFixed(1);
          toast.error(
            `${file.name} is too large (${sizeMB} MB). Maximum file size is 50 MB.`,
            { 
              duration: 10000,
              description: file.name.includes('zcta') || file.name.includes('zip') || file.name.includes('geo') ? 
                'For ZCTA boundary files, use Admin → Data Loader instead.' : 
                'Please compress or split the file into smaller parts.'
            }
          );
        });
      }
      
      // Only add files under size limit
      const validFiles = newFiles.filter(f => f.size <= MAX_FILE_SIZE);
      
      if (validFiles.length > 0) {
        setFiles(prev => [...prev, ...validFiles]);
        setUploading(prev => [...prev, ...Array(validFiles.length).fill(false)]);
        setProcessing(prev => [...prev, ...Array(validFiles.length).fill(false)]);
        setUploadProgress(prev => [...prev, ...Array(validFiles.length).fill(0)]);
        setExtractedData(prev => [...prev, ...Array(validFiles.length).fill(null)]);
        setUploadErrors(prev => [...prev, ...Array(validFiles.length).fill(null)]);
      }
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    handleFileSelect(e.dataTransfer.files);
  };

  const uploadFile = async (file, index) => {
    setUploading(prev => {
      const newUploading = [...prev];
      newUploading[index] = true;
      return newUploading;
    });

    setUploadErrors(prev => {
      const newErrors = [...prev];
      newErrors[index] = null;
      return newErrors;
    });

    // Real progress tracking
    const progressInterval = setInterval(() => {
      setUploadProgress(prev => {
        const newProgress = [...prev];
        // Simulate progress up to 90%, then wait for actual completion
        newProgress[index] = Math.min(90, (newProgress[index] || 0) + 5);
        return newProgress;
      });
    }, 500);

    try {
      // Race against timeout
      const uploadPromise = base44.integrations.Core.UploadFile({ file });
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Upload timeout')), UPLOAD_TIMEOUT)
      );

      const { file_url } = await Promise.race([uploadPromise, timeoutPromise]);
      
      clearInterval(progressInterval);
      setUploadProgress(prev => {
        const newProgress = [...prev];
        newProgress[index] = 100;
        return newProgress;
      });

      // Save to database
      const uploadRecord = await base44.entities.DataUpload.create({
        filename: file.name,
        file_url,
        file_type: getFileType(file),
        data_source: "Custom Upload",
        processed: false
      });

      toast.success(`${file.name} uploaded successfully!`);

      return { file_url, uploadRecord };
    } catch (error) {
      clearInterval(progressInterval);
      
      let errorMessage = 'Upload failed';
      
      if (error.message === 'Upload timeout') {
        errorMessage = `Upload timed out after 2 minutes. File may be too large (${(file.size / (1024 * 1024)).toFixed(1)} MB).`;
      } else if (error.message?.includes('Network Error')) {
        errorMessage = 'Network error. Check your connection and try again.';
      } else if (error.message?.includes('413') || error.message?.includes('too large')) {
        errorMessage = 'File is too large for upload. Maximum size is 50 MB.';
      } else {
        errorMessage = error.message || 'Upload failed';
      }
      
      setUploadErrors(prev => {
        const newErrors = [...prev];
        newErrors[index] = errorMessage;
        return newErrors;
      });
      
      toast.error(`Failed to upload ${file.name}: ${errorMessage}`, { duration: 8000 });
      
      throw error;
    } finally {
      setUploading(prev => {
        const newUploading = [...prev];
        newUploading[index] = false;
        return newUploading;
      });
    }
  };

  return (
    <div className="min-h-screen p-4 md:p-8 bg-gray-50">
      <div className="max-w-6xl mx-auto space-y-8">
        
        {/* Header with Icon */}
        <div className="bg-white rounded-xl p-6 border-2 border-emerald-500 shadow-sm">
          <div className="flex items-start gap-4">
            <div className="flex-shrink-0">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/6ddbf2f1f_data-upload.png"
                alt="Data Upload"
                className="w-20 h-20"
              />
            </div>
            <div className="flex-1">
              <h1 className="text-3xl font-bold mb-2 text-gray-900">Data Upload Center</h1>
              <p className="text-gray-600 text-sm leading-relaxed">
                Import custom datasets, health reports, and assessment documents. Extract structured data from PDFs, 
                images, and spreadsheets to enrich your community health analysis.
              </p>
            </div>
          </div>
        </div>

        {/* ZCTA Population Upload Section */}
        <Card className="bg-gradient-to-br from-emerald-50 to-green-50 border-emerald-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-emerald-900">
              <MapPin className="w-5 h-5" />
              ZCTA-County Population Data
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert className="border-emerald-200 bg-white">
              <AlertDescription className="text-sm text-gray-700">
                <strong>Upload cleaned ZCTA population CSVs</strong> with format: 
                <code className="mx-1 px-2 py-0.5 bg-gray-100 rounded text-xs">state_abbr, county_name, ZIP code, total_population</code>
                <br/>
                This will populate county mappings and demographics for the state.
              </AlertDescription>
            </Alert>

            <div className="flex gap-3 items-end">
              <div className="flex-1">
                <input
                  ref={zctaInputRef}
                  type="file"
                  accept=".csv,.txt"
                  onChange={(e) => setZctaCsvFile(e.target.files?.[0] || null)}
                  className="block w-full text-sm text-gray-600 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-medium file:bg-emerald-100 file:text-emerald-700 hover:file:bg-emerald-200"
                />
              </div>
              <Button
                onClick={handleZctaCsvUpload}
                disabled={!zctaCsvFile || isLoadingZcta}
                className="bg-emerald-600 hover:bg-emerald-700"
              >
                {isLoadingZcta ? (
                  <>
                    <AlertCircle className="w-4 h-4 mr-2 animate-spin" />
                    Loading...
                  </>
                ) : (
                  <>
                    <Upload className="w-4 h-4 mr-2" />
                    Load Data
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* File Size Warning */}
        <Alert className="border-amber-200 bg-amber-50">
          <AlertTriangle className="w-5 h-5 text-amber-600" />
          <AlertDescription className="text-amber-800">
            <strong>⚠️ For ZCTA Boundary Files (GeoJSON over 5 MB):</strong> Do NOT use this uploader - large boundary files often get corrupted during browser upload/download. 
            Use <strong>Admin → Data Loader → "Load Boundaries"</strong> instead. It downloads directly from GitHub and handles files of any size reliably.
            <br/><br/>
            <strong>General Upload Limit: 50 MB</strong> for PDFs, images, CSV, Excel, and small JSON files.
          </AlertDescription>
        </Alert>

        {/* Upload Zone */}
        <UploadZone 
          onFileSelect={handleFileSelect}
          onDrop={handleDrop}
          fileInputRef={fileInputRef}
        />

        {/* File List */}
        {files.length > 0 && (
          <Card className="bg-white border-gray-200 shadow-sm">
            <CardHeader>
              <CardTitle className="text-gray-900 flex items-center gap-2">
                <Database className="w-5 h-5 stroke-1" />
                Uploaded Files ({files.length})
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {files.map((file, index) => (
                <div key={index}>
                  <FilePreview
                    file={file}
                    index={index}
                    isUploading={uploading[index]}
                    isProcessing={processing[index]}
                    progress={uploadProgress[index]}
                    extractedData={extractedData[index]}
                    error={uploadErrors[index]}
                    onProcess={() => processFile(file, index)}
                    onRemove={() => removeFile(index)}
                  />
                  {uploadErrors[index] && (
                    <Alert className="mt-2 border-red-200 bg-red-50">
                      <AlertCircle className="w-4 h-4 text-red-600" />
                      <AlertDescription className="text-red-800 text-sm whitespace-pre-wrap">
                        {uploadErrors[index]}
                      </AlertDescription>
                    </Alert>
                  )}
                </div>
              ))}
              
              <div className="flex gap-3 pt-4 border-t border-gray-200">
                <Button
                  onClick={() => files.forEach((file, index) => !uploading[index] && !processing[index] && !extractedData[index] && processFile(file, index))}
                  className="bg-emerald-500 hover:bg-emerald-600 text-white"
                  disabled={files.every((_, index) => uploading[index] || processing[index] || extractedData[index])}
                >
                  Process All Files
                </Button>
                
                <Button
                  variant="outline"
                  onClick={() => {
                    setFiles([]);
                    setUploading([]);
                    setProcessing([]);
                    setUploadProgress([]);
                    setExtractedData([]);
                    setUploadErrors([]);
                  }}
                  className="border-gray-300 text-gray-700 hover:bg-gray-50"
                >
                  Clear All
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Excel Previews */}
        {extractedData.map((data, index) => 
          data && data.type === 'excel' ? (
            <ExcelPreview 
              key={index}
              file={files[index]}
              fileUrl={data.file_url}
              onDataImported={(result) => {
                toast.success(`Data imported successfully!`);
              }}
            />
          ) : null
        )}

        {/* Data Extraction Results */}
        {extractedData.some(data => data !== null && data.type !== 'excel') && (
          <DataExtraction extractedData={extractedData.filter(data => data !== null && data.type !== 'excel')} />
        )}
      </div>
    </div>
  );

  async function extractData(file, fileUrl, index) {
    setProcessing(prev => {
      const newProcessing = [...prev];
      newProcessing[index] = true;
      return newProcessing;
    });

    try {
      // Skip extraction for ZIP files
      if (file.name.endsWith('.zip') || file.type === 'application/zip') {
        setExtractedData(prev => {
          const newData = [...prev];
          newData[index] = { 
            type: 'zip',
            message: 'ZIP file uploaded successfully. Use the boundary loader to process ZCTA data.'
          };
          return newData;
        });
        return;
      }

      // For JSON/GeoJSON files, try to parse directly
      if (file.name.endsWith('.json') || file.name.endsWith('.geojson') || file.name.endsWith('.geo.json') || file.type === 'application/json') {
        const isGeoJSON = file.name.includes('geo') || file.name.includes('zcta') || file.name.includes('boundary');
        const sizeMB = (file.size / (1024 * 1024)).toFixed(1);
        
        // Strong warning for large GeoJSON files - don't even attempt
        if (isGeoJSON && file.size > 5 * 1024 * 1024) {
          const errorMsg = `⚠️ GeoJSON files over 5 MB should use Data Loader`;
          const errorDesc = `This ${sizeMB} MB boundary file is too large for browser parsing. It may be corrupted during download/upload or exceed browser memory limits.\n\n` +
                           `✅ Use Admin → Data Loader → "Load Boundaries" instead:\n` +
                           `   • Handles files of ANY size\n` +
                           `   • Downloads directly from GitHub (more reliable)\n` +
                           `   • Processes in backend (faster, no corruption)\n` +
                           `   • Shows progress tracking\n\n` +
                           `The Data Loader is specifically designed for ZCTA boundary data and will work perfectly for your file.`;
          
          setUploadErrors(prev => {
            const newErrors = [...prev];
            newErrors[index] = errorDesc;
            return newErrors;
          });
          
          toast.error(errorMsg, { 
            duration: 15000,
            description: 'Large GeoJSON files often get corrupted during upload. Use Data Loader for reliable boundary loading.'
          });
          return;
        }
        
        try {
          console.log(`Attempting to parse ${file.name} (${sizeMB} MB)...`);
          
          // Fetch with timeout
          const fetchPromise = fetch(fileUrl);
          const timeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Fetch timeout')), JSON_PARSE_TIMEOUT)
          );
          
          const response = await Promise.race([fetchPromise, timeoutPromise]);
          
          if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
          }
          
          // Get raw text first to check for corruption
          const textPromise = response.text();
          const textTimeoutPromise = new Promise((_, reject) => 
            setTimeout(() => reject(new Error('Download timeout')), JSON_PARSE_TIMEOUT)
          );
          
          const jsonText = await Promise.race([textPromise, textTimeoutPromise]);
          
          console.log(`Downloaded ${jsonText.length} characters, attempting parse...`);
          
          // Now try to parse with timeout
          let jsonData;
          try {
            const parsePromise = new Promise((resolve, reject) => {
              try {
                const parsed = JSON.parse(jsonText);
                resolve(parsed);
              } catch (parseError) {
                reject(parseError);
              }
            });
            
            const parseTimeoutPromise = new Promise((_, reject) => 
              setTimeout(() => reject(new Error('Parse timeout')), JSON_PARSE_TIMEOUT)
            );
            
            jsonData = await Promise.race([parsePromise, parseTimeoutPromise]);
            
          } catch (parseError) {
            // Check if it's a syntax error indicating corruption
            if (parseError.message?.includes('Unexpected token') || 
                parseError.message?.includes('Expected') ||
                parseError.message?.includes('JSON')) {
              
              // Extract position info if available
              const positionMatch = parseError.message.match(/position (\d+)/);
              const lineMatch = parseError.message.match(/line (\d+)/);
              
              let positionInfo = '';
              if (positionMatch) {
                const position = parseInt(positionMatch[1]);
                const percentThrough = ((position / jsonText.length) * 100).toFixed(1);
                positionInfo = ` at ${percentThrough}% through the file`;
              } else if (lineMatch) {
                positionInfo = ` at line ${lineMatch[1]}`;
              }
              
              throw new Error(
                `JSON_CORRUPTED: The file appears to be corrupted or malformed${positionInfo}. ` +
                `This commonly happens when large files (${sizeMB} MB) are uploaded/downloaded through the browser. ` +
                `Original error: ${parseError.message}`
              );
            }
            throw parseError;
          }
          
          // Analyze the JSON structure
          let itemCount = 0;
          let dataType = 'object';
          
          if (Array.isArray(jsonData)) {
            itemCount = jsonData.length;
            dataType = 'array';
          } else if (jsonData && typeof jsonData === 'object') {
            if (jsonData.type === 'FeatureCollection' && jsonData.features) {
              itemCount = jsonData.features.length;
              dataType = 'GeoJSON FeatureCollection';
            } else if (jsonData.type === 'Feature') {
              itemCount = 1;
              dataType = 'GeoJSON Feature';
            } else {
              itemCount = Object.keys(jsonData).length;
              dataType = 'object';
            }
          }
          
          setExtractedData(prev => {
            const newData = [...prev];
            newData[index] = { 
              type: 'json',
              data: jsonData,
              message: `${dataType === 'GeoJSON FeatureCollection' ? '🗺️ ' : ''}${dataType} parsed successfully. Contains ${itemCount} ${dataType === 'array' || dataType === 'GeoJSON FeatureCollection' ? 'items' : 'properties'}.`,
              dataType: dataType,
              itemCount: itemCount
            };
            return newData;
          });
          
          if (isGeoJSON) {
            toast.success(
              `GeoJSON loaded with ${itemCount} features!`,
              {
                duration: 5000,
                description: 'Small boundary files only. For state-level data, use Data Loader.'
              }
            );
          } else {
            toast.success(`JSON data loaded from ${file.name}!`);
          }
          return;
          
        } catch (jsonError) {
          console.error('JSON parsing error:', jsonError);
          
          let errorMsg = 'Failed to parse JSON';
          let errorDesc = '';
          
          if (jsonError.message?.includes('JSON_CORRUPTED')) {
            errorMsg = '🚫 File Corrupted During Upload';
            errorDesc = jsonError.message.replace('JSON_CORRUPTED: ', '') + 
                       `\n\n✅ SOLUTION: Use Admin → Data Loader\n` +
                       `   The Data Loader downloads boundary files directly from GitHub,\n` +
                       `   avoiding corruption and browser limitations.\n\n` +
                       `   Steps:\n` +
                       `   1. Go to Admin → Data Loader\n` +
                       `   2. Find your state (e.g., Louisiana)\n` +
                       `   3. Click "Load Until Complete"\n` +
                       `   4. Wait for 100% completion\n` +
                       `   5. Use boundaries in your assessments!\n\n` +
                       `   This is the RECOMMENDED way to load ZCTA boundary data.`;
          } else if (jsonError.message === 'Fetch timeout') {
            errorMsg = 'Download timed out';
            errorDesc = `File took too long to download (${sizeMB} MB). For ZCTA boundaries, use Admin → Data Loader instead - it's designed for large files.`;
          } else if (jsonError.message === 'Download timeout') {
            errorMsg = 'Download timed out';
            errorDesc = `File too large to download in browser (${sizeMB} MB). Use Admin → Data Loader for ZCTA boundary files.`;
          } else if (jsonError.message === 'Parse timeout') {
            errorMsg = 'Parsing timed out';
            errorDesc = `File too complex to parse in browser (${sizeMB} MB). Use Admin → Data Loader for ZCTA boundary files.`;
          } else if (jsonError.message?.includes('Unexpected token') || jsonError.message?.includes('Expected')) {
            errorMsg = 'Invalid JSON format';
            errorDesc = `The file contains malformed JSON. This may be due to corruption during upload or an invalid source file. Error: ${jsonError.message}`;
          } else if (jsonError.message?.includes('HTTP')) {
            errorMsg = 'Download failed';
            errorDesc = jsonError.message;
          } else {
            errorMsg = 'Failed to load JSON';
            errorDesc = jsonError.message || 'Unknown error occurred';
          }
          
          setUploadErrors(prev => {
            const newErrors = [...prev];
            newErrors[index] = errorDesc;
            return newErrors;
          });
          
          toast.error(errorMsg, { 
            duration: 15000,
            description: isGeoJSON && file.size > 1024 * 1024 ? 
              'Large GeoJSON files should use Data Loader to avoid corruption' : 
              errorDesc.split('\n')[0]
          });
          return;
        }
      }

      const schema = {
        type: "object",
        properties: {
          organization: { type: "string" },
          metrics: {
            type: "array",
            items: {
              type: "object", 
              properties: {
                name: { type: "string" },
                value: { type: "number" },
                unit: { type: "string" }
              }
            }
          }
        }
      };

      // Handle Excel files - show preview instead of extracting
      if (file.name.endsWith('.xlsx') || file.name.includes('.xlsx')) {
        setExtractedData(prev => {
          const newData = [...prev];
          newData[index] = { 
            type: 'excel',
            file_url: fileUrl,
            message: 'Excel file ready for preview'
          };
          return newData;
        });
        return;
      }

      const result = await base44.integrations.Core.ExtractDataFromUploadedFile({
        file_url: fileUrl,
        json_schema: schema
      });

      if (result.status === "success") {
        setExtractedData(prev => {
          const newData = [...prev];
          newData[index] = result.output;
          return newData;
        });
        toast.success(`Data extracted from ${file.name}!`);
      }
    } catch (error) {
      console.error('Error extracting data:', error);
      
      setUploadErrors(prev => {
        const newErrors = [...prev];
        newErrors[index] = error.message || 'Data extraction failed';
        return newErrors;
      });
      
      toast.error(`Failed to extract data from ${file.name}`);
    } finally {
      setProcessing(prev => {
        const newProcessing = [...prev];
        newProcessing[index] = false;
        return newProcessing;
      });
    }
  }

  async function processFile(file, index) {
    try {
      const { file_url } = await uploadFile(file, index);
      await extractData(file, file_url, index);
    } catch (error) {
      console.error('Error processing file:', error);
    }
  }

  function removeFile(index) {
    setFiles(prev => prev.filter((_, i) => i !== index));
    setUploading(prev => prev.filter((_, i) => i !== index));
    setProcessing(prev => prev.filter((_, i) => i !== index));
    setUploadProgress(prev => prev.filter((_, i) => i !== index));
    setExtractedData(prev => prev.filter((_, i) => i !== index));
    setUploadErrors(prev => prev.filter((_, i) => i !== index));
  }

  function getFileType(file) {
    if (file.type === 'application/pdf') return 'pdf';
    if (file.type.startsWith('image/')) return 'image';
    if (file.name.endsWith('.csv')) return 'csv';
    if (file.name.endsWith('.xlsx')) return 'excel';
    if (file.name.endsWith('.json') || file.name.endsWith('.geojson') || file.name.endsWith('.geo.json') || file.type === 'application/json') return 'json';
    if (file.name.endsWith('.zip') || file.type === 'application/zip' || file.type === 'application/x-zip-compressed') return 'zip';
    return 'other';
  }
}