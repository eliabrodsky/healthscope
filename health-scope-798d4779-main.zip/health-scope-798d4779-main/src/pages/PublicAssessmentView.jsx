import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { BarChart3, Loader2, AlertTriangle, Users, Building, MapPin, Eye, Info, Share2, Download, Linkedin, Globe } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import InteractiveMap from '../components/maps/InteractiveMap';
import KPICard from '../components/assessment_dashboard/KpiCard';
import ZipDataTable from '../components/assessment_dashboard/ZipDataTable';
import CompetitorLocationMapping from '../components/assessment_dashboard/CompetitorLocationMapping';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';

export default function PublicAssessmentView() {
    const [searchParams] = useSearchParams();
    const assessmentId = searchParams.get('id');
    
    const [assessment, setAssessment] = useState(null);
    const [creator, setCreator] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchAssessment = async () => {
            if (!assessmentId) {
                setError("No assessment ID provided in the URL.");
                setIsLoading(false);
                return;
            }

            try {
                // Try to fetch assessment - RLS should allow if published_settings.is_public is true
                let data;
                try {
                    data = await base44.entities.Assessment.get(assessmentId);
                } catch (getError) {
                    // If get fails, try filter with public flag
                    console.log('Direct get failed, trying public filter...');
                    const publicAssessments = await base44.entities.Assessment.filter({
                        id: assessmentId,
                        'published_settings.is_public': true,
                        status: 'published'
                    });
                    if (publicAssessments && publicAssessments.length > 0) {
                        data = publicAssessments[0];
                    }
                }

                // Check if assessment exists and is published/public
                if (data && data.status === 'published') {
                    setAssessment(data);
                    
                    // Load creator info (may fail for non-authenticated users)
                    try {
                        const users = await base44.entities.User.filter({
                            email: data.created_by
                        });
                        if (users && users.length > 0) {
                            setCreator(users[0]);
                        }
                    } catch (userError) {
                        console.warn('Could not load creator info:', userError);
                    }
                } else {
                    setError("This assessment is not published or does not exist.");
                }
            } catch (err) {
                console.error("Failed to fetch public assessment:", err);
                setError("Could not load the assessment. It may be private or no longer available.");
            } finally {
                setIsLoading(false);
            }
        };

        fetchAssessment();
    }, [assessmentId]);

    const handleShare = () => {
        navigator.clipboard.writeText(window.location.href);
        toast.success("Link copied to clipboard!");
    };

    if (isLoading) {
        return (
            <div className="min-h-screen bg-gray-50 flex items-center justify-center">
                <div className="text-center">
                    <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-blue-500" />
                    <p>Loading public assessment...</p>
                </div>
            </div>
        );
    }

    if (error) {
        return (
            <div className="min-h-screen bg-gray-50 flex items-center justify-center">
                <div className="text-center p-8">
                    <AlertTriangle className="h-12 w-12 mx-auto mb-4 text-red-500" />
                    <h2 className="text-2xl font-bold mb-2">Unable to Load Assessment</h2>
                    <p className="text-red-600 mb-6">{error}</p>
                    <a href="/">
                        <Button>Go to Homepage</Button>
                    </a>
                </div>
            </div>
        );
    }

    if (!assessment) {
        return null;
    }

    const {
        published_settings: settings,
        geography,
        organizations = [],
        processed_data = {}
    } = assessment;

    const zipCodes = processed_data.zip_codes || geography?.zip_codes || [];
    const censusData = processed_data.census_data || {};
    const totalPopulation = Object.values(censusData).reduce((acc, cur) => acc + (cur.population || 0), 0);

    return (
        <div className="bg-gray-50 min-h-screen">
            <header className="bg-white border-b border-gray-200 sticky top-0 z-10 shadow-sm">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
                    <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-emerald-500 rounded-lg flex items-center justify-center">
                            <BarChart3 className="w-5 h-5 text-white" />
                        </div>
                        <div>
                            <h1 className="text-xl font-bold text-gray-900">{settings?.title || assessment.title}</h1>
                            {settings?.description && <p className="text-sm text-gray-500">{settings.description}</p>}
                        </div>
                    </div>
                    <Button variant="outline" size="sm" onClick={handleShare}>
                        <Share2 className="w-4 h-4 mr-2" /> Share
                    </Button>
                </div>
            </header>

            <main className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
                {/* Creator Info Card */}
                {creator && (
                    <Card className="bg-gradient-to-r from-blue-50 to-indigo-50">
                        <CardContent className="p-6">
                            <div className="flex items-center gap-4">
                                <Avatar className="w-16 h-16">
                                    <AvatarImage src={creator.profile_picture} />
                                    <AvatarFallback className="bg-blue-600 text-white text-xl">
                                        {creator.full_name?.charAt(0) || 'U'}
                                    </AvatarFallback>
                                </Avatar>
                                <div className="flex-1">
                                    <p className="text-sm text-gray-600 mb-1">Published by</p>
                                    <h3 className="text-xl font-bold text-gray-900">
                                        {creator.full_name || 'Anonymous'}
                                    </h3>
                                    {creator.title && (
                                        <p className="text-sm text-gray-700">{creator.title}</p>
                                    )}
                                    {creator.company && (
                                        <p className="text-sm text-gray-600">{creator.company}</p>
                                    )}
                                    {creator.bio && (
                                        <p className="text-sm text-gray-600 mt-2">{creator.bio}</p>
                                    )}
                                </div>
                                {(creator.linkedin_url || creator.website_url) && (
                                    <div className="flex gap-3">
                                        {creator.linkedin_url && (
                                            <a
                                                href={creator.linkedin_url}
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                className="p-2 rounded-lg bg-white hover:bg-blue-50 transition-colors"
                                            >
                                                <Linkedin className="w-5 h-5 text-blue-600" />
                                            </a>
                                        )}
                                        {creator.website_url && (
                                            <a
                                                href={creator.website_url}
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                className="p-2 rounded-lg bg-white hover:bg-gray-50 transition-colors"
                                            >
                                                <Globe className="w-5 h-5 text-gray-600" />
                                            </a>
                                        )}
                                    </div>
                                )}
                            </div>
                        </CardContent>
                    </Card>
                )}
                <div className="grid md:grid-cols-4 gap-6">
                    <KPICard
                        title="Total Population"
                        value={totalPopulation > 0 ? totalPopulation.toLocaleString() : '...'}
                        source={`${zipCodes.length} ZIPs in service area`}
                        icon={Users}
                    />
                    <KPICard
                        title="Active Competitors"
                        value={organizations.length.toString()}
                        source="Healthcare organizations in area"
                        icon={Building}
                    />
                    <KPICard
                        title="Service Area"
                        value={geography?.city || 'N/A'}
                        source={geography?.state || ''}
                        icon={MapPin}
                    />
                    <KPICard
                        title="ZIP Codes"
                        value={zipCodes.length.toString()}
                        source="Areas covered"
                        icon={Eye}
                    />
                </div>

                <InteractiveMap
                    zipBoundaries={processed_data.zip_boundaries || []}
                    organizations={settings?.show_competitors !== false ? organizations : []}
                    center={geography}
                    selectedZips={zipCodes}
                    colorMetric={processed_data.map_settings?.color_metric || 'population'}
                    showRadiusReference={processed_data.map_settings?.show_radius || false}
                    radiusMiles={processed_data.map_settings?.radius_miles || 10}
                    showCompetitors={settings?.show_competitors !== false}
                    assessment={assessment}
                    censusData={censusData}
                    isLoadingCensusData={false}
                    viewport={processed_data.map_settings?.viewport}
                    onViewportChange={() => {}}
                    mapSettings={processed_data.map_settings || {}}
                    onMapSettingsChange={() => {}}
                />

                {settings?.show_demographics !== false && (
                    <ZipDataTable
                        zipCodes={zipCodes}
                        mapColorMetric={processed_data.map_settings?.color_metric || 'population'}
                        onMapColorMetricChange={() => {}}
                        assessment={assessment}
                        censusData={censusData}
                        isLoadingData={false}
                        onRefresh={() => {}}
                    />
                )}

                {settings?.show_market_analysis !== false && organizations.length > 0 && (
                    <CompetitorLocationMapping
                        organizations={organizations}
                        zipCodes={zipCodes}
                        assessment={assessment}
                    />
                )}

                {settings?.allow_downloads && (
                    <Card>
                        <CardHeader>
                            <CardTitle>Export Options</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <Button className="w-full">
                                <Download className="w-4 h-4 mr-2" /> Export Assessment Data
                            </Button>
                        </CardContent>
                    </Card>
                )}
            </main>

            <footer className="text-center py-6 text-sm text-gray-500 border-t mt-12 bg-white">
                <p>Powered by <span className="font-semibold text-emerald-600">HealthScope</span></p>
                <p className="text-xs mt-1">Community Health Assessment Platform</p>
            </footer>
        </div>
    );
}