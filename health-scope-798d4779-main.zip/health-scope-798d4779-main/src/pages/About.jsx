import React, { useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  BarChart3, 
  Users, 
  TrendingUp, 
  Building2, 
  MapPin, 
  ArrowRight,
  CheckCircle,
  Sparkles,
  Globe
} from "lucide-react";

export default function About() {
  const sectionsRef = useRef([]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-in");
          }
        });
      },
      {
        root: null,
        threshold: 0.2,
        rootMargin: "0px 0px -10% 0px",
      }
    );

    sectionsRef.current.forEach((section) => {
      if (section) observer.observe(section);
    });

    return () => observer.disconnect();
  }, []);

  const addToRefs = (el) => {
    if (el && !sectionsRef.current.includes(el)) {
      sectionsRef.current.push(el);
    }
  };

  const handleLogin = () => {
    base44.auth.redirectToLogin(createPageUrl("Dashboard"));
  };

  const handleSignup = () => {
    base44.auth.redirectToLogin(createPageUrl("Dashboard"));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-emerald-50 to-teal-50">
      {/* Top Navigation */}
      <nav className="border-b border-gray-200 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4 md:py-5">
            <Link to={createPageUrl("Home")} className="flex items-center gap-3">
              <div className="w-10 h-10 bg-emerald-500 rounded-lg flex items-center justify-center">
                <BarChart3 className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">HealthScope</span>
            </Link>
            <div className="flex items-center gap-4">
              <Link to={createPageUrl("About")} className="text-gray-600 hover:text-gray-900 font-medium">
                About
              </Link>
              <Button variant="ghost" onClick={handleLogin}>
                Log In
              </Button>
              <Button className="bg-emerald-600 hover:bg-emerald-700" onClick={handleSignup}>
                Get Started Free
              </Button>
            </div>
          </div>
        </div>
      </nav>
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/5 via-teal-500/5 to-transparent" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center max-w-4xl mx-auto">
            <Badge className="bg-emerald-100 text-emerald-700 border-emerald-300 mb-6">
              <span className="w-2 h-2 bg-emerald-500 rounded-full mr-2 animate-pulse" />
              About HealthScope
            </Badge>
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              HealthScope – <span className="bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">Interactive Healthcare Data Explorer</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Transform community health data into action. HealthScope is the all-in-one platform for community
              health assessments, market analysis, and strategic planning.
            </p>
            <div className="flex flex-wrap justify-center gap-3 mb-8">
              <Badge variant="outline" className="text-sm">FQHCs & community health centers</Badge>
              <Badge variant="outline" className="text-sm">Health systems & payers</Badge>
              <Badge variant="outline" className="text-sm">Policy & public health leaders</Badge>
              <Badge variant="outline" className="text-sm">Students & researchers</Badge>
            </div>
            <div className="inline-flex items-center gap-2 bg-gradient-to-r from-emerald-500 to-teal-500 text-white px-6 py-3 rounded-full font-semibold shadow-lg">
              <Sparkles className="w-5 h-5" />
              Save 50+ hours per assessment
            </div>
          </div>
        </div>
      </section>

      {/* Scrolling Sections */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
        
        {/* Problem Section */}
        <Card 
          ref={addToRefs}
          className="section-card border-2 border-gray-200 hover:border-emerald-400 transition-all duration-500 opacity-0 translate-y-10 shadow-lg hover:shadow-2xl"
        >
          <CardContent className="p-8 md:p-12">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/e301d55a1_mapinganddata2.jpg"
                  alt="Service area map details"
                  className="w-full rounded-lg shadow-md"
                />
              </div>
              <div>
                <div className="flex items-center gap-3 mb-6">
                  <img 
                    src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/2735c1447_potfolio1.png"
                    alt="Health Status Icon"
                    className="w-16 h-16 flex-shrink-0"
                  />
                  <div>
                    <h2 className="text-2xl sm:text-3xl font-bold text-gray-900">Health data is everywhere. Insight is nowhere.</h2>
                    <Badge className="bg-red-100 text-red-700 border-red-300 mt-2">The Problem</Badge>
                  </div>
                </div>
                <p className="text-gray-700 text-lg mb-6">
                  Data lives across HRSA, Census, CDC, claims, and internal systems. Teams spend
                  weeks downloading spreadsheets, cleaning fields, and wrestling geographies just
                  to answer basic questions about their markets.
                </p>
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0" />
                    <p className="text-gray-700">Fragmented data sources and inconsistent geographies</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0" />
                    <p className="text-gray-700">Manual mapping of competitors, payers, and service areas</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0" />
                    <p className="text-gray-700">Static slide decks that are out of date as soon as they're created</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0" />
                    <p className="text-gray-700">Strategy time lost to low-value data wrangling</p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Solution Section */}
        <Card 
          ref={addToRefs}
          className="section-card border-2 border-gray-200 hover:border-emerald-400 transition-all duration-500 opacity-0 translate-y-10 shadow-lg hover:shadow-2xl"
        >
          <CardContent className="p-8 md:p-12">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div className="order-2 md:order-1">
                <div className="flex items-center gap-3 mb-6">
                  <img 
                    src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/8415edeb3_mapicon.png"
                    alt="Interactive Map Icon"
                    className="w-16 h-16 flex-shrink-0"
                  />
                  <div>
                    <h2 className="text-2xl sm:text-3xl font-bold text-gray-900">One interactive map. All your strategic insights.</h2>
                    <Badge className="bg-emerald-100 text-emerald-700 border-emerald-300 mt-2">The Solution</Badge>
                  </div>
                </div>
                <p className="text-gray-700 text-lg mb-6">
                  HealthScope turns your geography into an interactive canvas, layering community
                  health needs, demographics, access, and competition into a single, living view.
                </p>
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-emerald-500 mt-0.5 flex-shrink-0" />
                    <p className="text-gray-700">Interactive geography explorer from state to ZIP, county, and ZCTA</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-emerald-500 mt-0.5 flex-shrink-0" />
                    <p className="text-gray-700">Demographics, income, poverty, and insurance coverage in one place</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-emerald-500 mt-0.5 flex-shrink-0" />
                    <p className="text-gray-700">FQHCs, hospitals, clinics, and urgent care overlaid as facility layers</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-emerald-500 mt-0.5 flex-shrink-0" />
                    <p className="text-gray-700">Health needs indicators like chronic disease and ED/IP utilization</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-emerald-500 mt-0.5 flex-shrink-0" />
                    <p className="text-gray-700">Scenario planning for new sites, services, and partnerships</p>
                  </div>
                </div>
              </div>
              <div className="order-1 md:order-2">
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/caae9c6b0_serviceareamapediting.jpg"
                  alt="Service area map editing"
                  className="w-full rounded-lg shadow-md"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Who It's For Section */}
        <Card 
          ref={addToRefs}
          className="section-card border-2 border-gray-200 hover:border-emerald-400 transition-all duration-500 opacity-0 translate-y-10 shadow-lg hover:shadow-2xl"
        >
          <CardContent className="p-8 md:p-12">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/7063be3b8_healthscope-builtfor.jpg"
                  alt="HealthScope built for"
                  className="w-full rounded-lg shadow-md"
                />
              </div>
              <div>
                <div className="flex items-center gap-3 mb-6">
                  <img 
                    src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/b728fa779_assessment.png"
                    alt="Assessment Icon"
                    className="w-16 h-16 flex-shrink-0"
                  />
                  <div>
                    <h2 className="text-2xl sm:text-3xl font-bold text-gray-900">Built for people who shape health systems.</h2>
                    <Badge className="bg-blue-100 text-blue-700 border-blue-300 mt-2">Who Uses HealthScope</Badge>
                  </div>
                </div>
                <p className="text-gray-700 text-lg mb-6">
                  HealthScope is designed for decision-makers and analysts who need to translate
                  complex data into clear, defensible decisions.
                </p>
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0" />
                    <p className="text-gray-700">Healthcare strategy and market planning teams</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0" />
                    <p className="text-gray-700">FQHC and community health center executives</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0" />
                    <p className="text-gray-700">Policy leaders at state and federal agencies</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0" />
                    <p className="text-gray-700">Payers and value-based care teams</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0" />
                    <p className="text-gray-700">Public health students, researchers, and data fellows</p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Value Proposition Section */}
        <Card 
          ref={addToRefs}
          className="section-card border-2 border-gray-200 hover:border-emerald-400 transition-all duration-500 opacity-0 translate-y-10 shadow-lg hover:shadow-2xl"
        >
          <CardContent className="p-8 md:p-12">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div className="order-2 md:order-1">
                <div className="flex items-center gap-3 mb-6">
                  <img 
                    src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/eb659944a_dataanalysis.png"
                    alt="Data Analysis Icon"
                    className="w-16 h-16 flex-shrink-0"
                  />
                  <div>
                    <h2 className="text-2xl sm:text-3xl font-bold text-gray-900">Save 50+ hours per assessment.</h2>
                    <Badge className="bg-purple-100 text-purple-700 border-purple-300 mt-2">Key Value</Badge>
                  </div>
                </div>
                <p className="text-gray-700 text-lg mb-8">
                  HealthScope automates the most painful parts of community health analysis so your
                  team can stay focused on strategy, partnerships, and execution.
                </p>
                <div className="space-y-4">
                  <div className="bg-white p-4 rounded-xl border-2 border-purple-200">
                    <div className="text-3xl font-bold text-purple-600 mb-1">50+ hrs</div>
                    <div className="text-sm text-gray-600 uppercase tracking-wide mb-1">Time saved per project</div>
                    <p className="text-gray-700 text-sm">Stop hunting for data and updating static slide decks.</p>
                  </div>
                  <div className="bg-white p-4 rounded-xl border-2 border-purple-200">
                    <div className="text-3xl font-bold text-purple-600 mb-1">1 workspace</div>
                    <div className="text-sm text-gray-600 uppercase tracking-wide mb-1">All your data</div>
                    <p className="text-gray-700 text-sm">Bring public data and internal insights into a single interactive map.</p>
                  </div>
                  <div className="bg-white p-4 rounded-xl border-2 border-purple-200">
                    <div className="text-3xl font-bold text-purple-600 mb-1">Real-time</div>
                    <div className="text-sm text-gray-600 uppercase tracking-wide mb-1">Market view</div>
                    <p className="text-gray-700 text-sm">Explore scenarios live with leadership, boards, and partners.</p>
                  </div>
                </div>
              </div>
              <div className="order-1 md:order-2">
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/341552b93_marketsummary.jpg"
                  alt="Market summary"
                  className="w-full rounded-lg shadow-md"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* What You Can Do Section */}
        <Card 
          ref={addToRefs}
          className="section-card border-2 border-gray-200 hover:border-emerald-400 transition-all duration-500 opacity-0 translate-y-10 shadow-lg hover:shadow-2xl"
        >
          <CardContent className="p-8 md:p-12">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/30dc5d8c1_competitoranalysiswizard.jpg"
                  alt="Competitor analysis wizard"
                  className="w-full rounded-lg shadow-md"
                />
              </div>
              <div>
                <div className="flex items-center gap-3 mb-6">
                  <img 
                    src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/b539273e2_deepdive.png"
                    alt="Deep Dive Icon"
                    className="w-16 h-16 flex-shrink-0"
                  />
                  <div>
                    <h2 className="text-2xl sm:text-3xl font-bold text-gray-900">From data to decisions in a few clicks.</h2>
                    <Badge className="bg-teal-100 text-teal-700 border-teal-300 mt-2">What You Can Do</Badge>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-teal-500 mt-0.5 flex-shrink-0" />
                    <p className="text-gray-700">Build community health needs assessments that are visual and defensible</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-teal-500 mt-0.5 flex-shrink-0" />
                    <p className="text-gray-700">Identify growth markets and underserved populations for new clinics</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-teal-500 mt-0.5 flex-shrink-0" />
                    <p className="text-gray-700">Compare payer mix, competition, and access across service areas</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-teal-500 mt-0.5 flex-shrink-0" />
                    <p className="text-gray-700">Support grants, waivers, and policy proposals with real data</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-teal-500 mt-0.5 flex-shrink-0" />
                    <p className="text-gray-700">Give students and trainees a modern, interactive public health lab</p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* CTA Section */}
        <Card 
          ref={addToRefs}
          className="section-card border-2 border-emerald-400 hover:border-emerald-500 transition-all duration-500 opacity-0 translate-y-10 shadow-2xl bg-gradient-to-br from-emerald-600 to-teal-700"
        >
          <CardContent className="p-8 md:p-12 text-white">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/2c04b8bed_presentationbuilder.jpg"
                  alt="Presentation builder"
                  className="w-full rounded-lg shadow-xl"
                />
              </div>
              <div>
                <div className="flex items-center gap-3 mb-6">
                  <img 
                    src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/6d36d911a_presentation.png"
                    alt="Presentation Icon"
                    className="w-16 h-16 flex-shrink-0"
                  />
                  <h2 className="text-2xl sm:text-3xl font-bold">Turn your market into a map you can act on.</h2>
                </div>
                <p className="text-lg mb-8 text-white/90">
                  Whether you're leading an FQHC expansion, designing a rural health strategy,
                  or teaching the next generation of public health leaders, HealthScope gives
                  you everything you need for data-driven decisions in your geography.
                </p>
                <div className="space-y-4">
                  <p className="text-white/90 font-medium">Ready to see HealthScope on your market?</p>
                  <div className="flex flex-wrap gap-3">
                    <Link to={createPageUrl("Home")}>
                      <Button className="bg-white text-emerald-600 hover:bg-gray-100 font-semibold">
                        Get Started
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </Button>
                    </Link>
                    <Button variant="outline" className="border-2 border-white bg-white text-emerald-700 hover:bg-gray-100 font-semibold">
                      View Demo
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex items-center justify-center gap-2 mb-4">
              <BarChart3 className="w-8 h-8 text-emerald-400" />
              <span className="text-2xl font-bold">HealthScope</span>
            </div>
            <p className="text-gray-400 mb-6">
              Interactive Healthcare Data Explorer
            </p>
            <div className="border-t border-gray-800 pt-6">
              <p className="text-sm text-gray-500">
                Powered by{" "}
                <a 
                  href="https://undercurrentlabs.ai" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-emerald-400 hover:text-emerald-300 font-semibold transition-colors"
                >
                  Undercurrent Labs.AI
                </a>
              </p>
              <p className="text-xs text-gray-600 mt-2">
                © {new Date().getFullYear()} HealthScope. All rights reserved.
              </p>
            </div>
          </div>
        </div>
      </footer>

      <style dangerouslySetInnerHTML={{__html: `
        .section-card.animate-in {
          opacity: 1 !important;
          transform: translateY(0) !important;
        }
      `}} />
    </div>
  );
}