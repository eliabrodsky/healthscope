import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import {
  BarChart3,
  Map,
  Upload,
  Globe,
  PanelLeftClose,
  PanelLeftOpen,
  User as UserIcon,
  LogOut,
  Settings,
  LifeBuoy,
  Menu,
  X,
  Database,
  Library,
  Building2,
  Users,
  Sparkles
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import LottieLoader from "@/components/ui/LottieLoader";
import { Toaster } from "sonner";

// Helper component to manage document head
const MetaTags = () => {
  useEffect(() => {
    document.title = "HealthScope – Community Health Insights";

    const metaTags = [
      { property: "og:title", content: "HealthScope – Community Health Insights" },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "https://healthscope.undercurrentlabs.ai/" },
      { property: "og:image", content: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/d53009f77_cares-map-room.png" },
      { property: "og:image:width", content: "1200" },
      { property: "og:image:height", content: "630" },
      { property: "og:description", content: "Interactive maps and dashboards for community health, FQHCs, and market insights." },
      { property: "og:site_name", content: "HealthScope" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "HealthScope – Community Health Insights" },
      { name: "twitter:image", content: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/d53009f77_cares-map-room.png" },
      { name: "description", content: "AI-powered platform for community health assessments, demographic analysis, and identifying service gaps to improve public health outcomes." },
    ];

    const linkTags = [
      { rel: "icon", type: "image/svg+xml", href: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='%2310b981' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' class='lucide lucide-bar-chart-3'%3E%3Cpath d='M3 3v18h18'/%3E%3Cpath d='M18 17V9'/%3E%3Cpath d='M13 17V5'/%3E%3Cpath d='M8 17v-3'/%3E%3C/svg%3E" },
      { rel: "apple-touch-icon", href: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/d53009f77_cares-map-room.png" },
    ];

    document.querySelectorAll('meta[name], meta[property^="og:"], meta[name^="twitter:"]').forEach(tag => tag.remove());
    document.querySelectorAll('link[rel="icon"], link[rel="apple-touch-icon"]').forEach(tag => tag.remove());

    metaTags.forEach(tagInfo => {
      const meta = document.createElement('meta');
      if (tagInfo.name) meta.name = tagInfo.name;
      if (tagInfo.property) meta.setAttribute('property', tagInfo.property);
      meta.content = tagInfo.content;
      document.head.appendChild(meta);
    });

    linkTags.forEach(tagInfo => {
        const link = document.createElement('link');
        link.rel = tagInfo.rel;
        if(tagInfo.type) link.type = tagInfo.type;
        link.href = tagInfo.href;
        document.head.appendChild(link);
    });

  }, []);

  return null;
};

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [user, setUser] = useState(null);
  const [isLoadingUser, setIsLoadingUser] = useState(true);
  
  const [sidebarOpen, setSidebarOpen] = useState(() => {
    if (typeof window !== 'undefined') {
      return window.innerWidth >= 768;
    }
    return true;
  });
  
  const [isMobile, setIsMobile] = useState(() => {
    if (typeof window !== 'undefined') {
      return window.innerWidth < 768;
    }
    return false;
  });

  useEffect(() => {
    const checkMobile = () => {
      const mobile = window.innerWidth < 768;
      setIsMobile(mobile);
      if (mobile) {
        setSidebarOpen(false);
      } else {
        setSidebarOpen(true);
      }
    };

    checkMobile();
    
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  useEffect(() => {
    if (!isMobile || !sidebarOpen) return;

    const handleClickOutside = (event) => {
      if (
        !event.target.closest('.sidebar') &&
        !event.target.closest('.sidebar-toggle')
      ) {
        setSidebarOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isMobile, sidebarOpen]);

  useEffect(() => {
    const fetchUserAndHandleAuth = async () => {
      setIsLoadingUser(true);
      try {
        const currentUser = await base44.auth.me();
        setUser(currentUser);

        // Grant signup tokens if user doesn't have any yet
        base44.functions.invoke('grantSignupTokens').catch(err => 
          console.error('Failed to grant signup tokens:', err)
        );
      } catch (error) {
        setUser(null);

        const protectedPages = [
          'Dashboard', 'Assessments', 'DataUpload', 
          'InitialDataLoader', 'DataManagement', 'CreateAssessmentWizard'
        ];

        if (protectedPages.includes(currentPageName)) {
          setTimeout(() => {
            base44.auth.redirectToLogin(createPageUrl(currentPageName));
          }, 100);
        }
      } finally {
        setIsLoadingUser(false);
      }
    };

    fetchUserAndHandleAuth().catch(() => {
      setIsLoadingUser(false);
      setUser(null);
    });
    }, [currentPageName]);

  const handleLogout = () => {
    base44.auth.logout();
  };

  // For home and about pages, just render content directly
  if (currentPageName === 'Home' || currentPageName === 'About') {
    return (
      <>
        <MetaTags />
        {children}
      </>
    );
  }

  // Allow unauthenticated view for AssessmentDashboard and PublicAssessmentView
  if ((currentPageName === 'AssessmentDashboard' || currentPageName === 'PublicAssessmentView') && !user && !isLoadingUser) {
    return (
      <>
        <MetaTags />
        {children}
      </>
    );
  }

  if (isLoadingUser) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <LottieLoader size={64} className="mx-auto mb-4" />
          <div className="text-gray-600">Loading...</div>
        </div>
      </div>
    );
  }

  // Safety fallback - render page even if no user after loading
  if (!user && !isLoadingUser && currentPageName !== 'Home' && currentPageName !== 'AssessmentDashboard' && currentPageName !== 'PublicAssessmentView') {
    const protectedPages = [
      'Dashboard', 'Assessments', 'DataUpload', 
      'InitialDataLoader', 'DataManagement', 'CreateAssessmentWizard'
    ];
    
    if (protectedPages.includes(currentPageName)) {
      return (
        <div className="min-h-screen bg-gray-50 flex items-center justify-center">
          <div className="text-center">
            <div className="text-gray-600 mb-4">Redirecting to login...</div>
          </div>
        </div>
      );
    }
  }

  const navigationItems = [
  { title: "Dashboard", url: createPageUrl("Dashboard"), icon: BarChart3 },
  { title: "Assessments", url: createPageUrl("Assessments"), icon: Map },
  { title: "FQHC Assessment", url: createPageUrl("FqhcAssessment"), icon: Building2 },
  { title: "Competitor Analysis", url: createPageUrl("CompetitorAnalysis"), icon: Building2 },
  { title: "Regional Analysis", url: createPageUrl("RegionalAnalysis"), icon: Users },
  { title: "Data Upload", url: createPageUrl("DataUpload"), icon: Upload },
  { title: "Public Portfolio", url: createPageUrl("PublicPortfolio"), icon: Globe },
  ];

  const aiNavItems = [
    { title: "AI Chat", url: createPageUrl("AIChat"), icon: Sparkles },
  ];

  const advancedNavItems = [
    { title: "Presentation Builder", url: createPageUrl("PresentationBuilder"), icon: Globe },
  ];

  const adminNavItems = [
      { title: "Data Loader", url: createPageUrl("InitialDataLoader"), icon: Database },
      { title: "Data Management", url: createPageUrl("DataManagement"), icon: Library },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <MetaTags />
      <Toaster position="top-center" expand={true} richColors toastOptions={{
        style: { maxWidth: '600px' }
      }} />
      <div className="h-screen flex w-full overflow-hidden">

        {isMobile && sidebarOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 z-40" onClick={() => setSidebarOpen(false)} />
        )}

        {user && (
          <div className={`sidebar ${
            isMobile
              ? `fixed inset-y-0 left-0 z-50 w-64 transform ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} transition-transform duration-300 ease-in-out`
              : `${sidebarOpen ? 'w-64' : 'w-0'} transition-all duration-300 overflow-hidden`
          } border-r border-gray-200 bg-white flex flex-col`}>

            <div className="flex-shrink-0 border-b border-gray-100 p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-emerald-500 rounded-lg flex items-center justify-center">
                    <BarChart3 className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h2 className="font-bold text-gray-900 text-lg">HealthScope</h2>
                    <p className="text-xs text-gray-500">Community Health Analytics</p>
                  </div>
                </div>
                {isMobile && (
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setSidebarOpen(false)}
                    className="hover:bg-gray-100"
                  >
                    <X className="w-5 h-5" />
                  </Button>
                )}
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-3">
              <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider px-3 py-3">
                Navigation
              </div>
              <nav className="space-y-2">
                {navigationItems.map((item) => (
                  <Link
                    key={item.title}
                    to={item.url}
                    onClick={() => isMobile && setSidebarOpen(false)}
                    className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                      location.pathname === item.url
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : 'text-gray-600 hover:bg-emerald-50 hover:text-emerald-700'
                    }`}
                  >
                    <item.icon className="w-5 h-5" />
                    <span className="font-medium">{item.title}</span>
                  </Link>
                ))}
              </nav>

              <div className="mt-6">
                <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider px-3 py-3">
                  AI Tools
                </div>
                <nav className="space-y-2">
                  {aiNavItems.map((item) => (
                    <Link
                      key={item.title}
                      to={item.url}
                      onClick={() => isMobile && setSidebarOpen(false)}
                      className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                        location.pathname === item.url
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : 'text-gray-600 hover:bg-emerald-50 hover:text-emerald-700'
                      }`}
                    >
                      <item.icon className="w-5 h-5" />
                      <span className="font-medium">{item.title}</span>
                    </Link>
                  ))}
                </nav>
              </div>

              <div className="mt-6">
                <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider px-3 py-3">
                  Deep Dive
                </div>
                <nav className="space-y-2">
                  {advancedNavItems.map((item) => (
                    <Link
                      key={item.title}
                      to={item.url}
                      onClick={() => isMobile && setSidebarOpen(false)}
                      className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                        location.pathname === item.url
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : 'text-gray-600 hover:bg-emerald-50 hover:text-emerald-700'
                      }`}
                    >
                      <item.icon className="w-5 h-5" />
                      <span className="font-medium">{item.title}</span>
                    </Link>
                  ))}
                </nav>
              </div>

              {user?.role === 'admin' && (
                  <div className="mt-6">
                      <div className="text-xs font-semibold text-gray-400 uppercase tracking-wider px-3 py-3">
                        Admin
                      </div>
                      <nav className="space-y-2">
                        {adminNavItems.map((item) => (
                          <Link
                            key={item.title}
                            to={item.url}
                            onClick={() => isMobile && setSidebarOpen(false)}
                            className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                              location.pathname === item.url
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                : 'text-gray-600 hover:bg-emerald-50 hover:text-emerald-700'
                            }`}
                          >
                            <item.icon className="w-5 h-5" />
                            <span className="font-medium">{item.title}</span>
                          </Link>
                        ))}
                      </nav>
                  </div>
              )}
            </div>

            <div className="flex-shrink-0 border-t border-gray-200 p-3">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="w-full justify-start text-left h-auto py-3">
                    <div className="flex items-center gap-3">
                      <Avatar className="w-9 h-9">
                        <AvatarFallback>{user?.full_name?.charAt(0) || 'U'}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <p className="font-semibold text-sm truncate">{user?.full_name}</p>
                        <p className="text-xs text-gray-500 truncate">{user?.email}</p>
                      </div>
                    </div>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56 mb-2" side="top" align="start">
                  <DropdownMenuLabel>My Account</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => window.location.href = createPageUrl("UserProfile")}>
                    <UserIcon className="mr-2 h-4 w-4" />
                    <span>Profile</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Settings className="mr-2 h-4 w-4" />
                    <span>Settings</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <LifeBuoy className="mr-2 h-4 w-4" />
                    <span>Support</span>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Log out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        )}

        <main className="flex-1 flex flex-col h-screen overflow-hidden">
          {user && (
            <header className="bg-white border-b border-gray-200 px-4 sm:px-6 py-4 flex-shrink-0">
              <div className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setSidebarOpen(!sidebarOpen)}
                    className="sidebar-toggle hover:bg-gray-100"
                  >
                    {sidebarOpen && !isMobile ? (
                      <PanelLeftClose className="w-5 h-5" />
                    ) : (
                      <Menu className="w-5 h-5" />
                    )}
                  </Button>
                  <h1 className="text-xl font-bold text-gray-900 md:hidden">HealthScope</h1>
                </div>
                <Link to={createPageUrl("Pricing")} className="flex items-center gap-2 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200 hover:bg-emerald-100 transition-colors">
                  <img 
                    src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/83f057394_tokens.png"
                    alt="Tokens"
                    className="w-4 h-4"
                  />
                  <div className="text-xs">
                    <span className="font-semibold text-gray-900">{user.token_balance || 0}</span>
                    <span className="text-emerald-600 ml-1">tokens</span>
                  </div>
                </Link>
              </div>
            </header>
          )}

          <div className="flex-1 overflow-y-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}