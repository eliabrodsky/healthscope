import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { base44 } from '@/api/base44Client';
import { Sparkles, Loader2, TrendingUp, AlertTriangle, Target, Users, BarChart3 } from 'lucide-react';
import { toast } from 'sonner';

export default function CompetitorAIInsights({ competitors, assessment }) {
  const [insights, setInsights] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState(null);

  const generateInsights = async () => {
    setIsGenerating(true);
    setError(null);
    toast.loading('Analyzing competitive landscape...', { id: 'ai-insights' });

    try {
      const competitorSummary = competitors.map(c => ({
        name: c.name,
        type: c.type,
        patients: c.total_patients,
        sites: c.total_sites,
        location: `${c.city}, ${c.state}`
      }));

      const prompt = `Analyze this competitive healthcare landscape:

Assessment Region: ${assessment.geography?.city}, ${assessment.geography?.state}
Total Competitors: ${competitors.length}

Competitor Data:
${JSON.stringify(competitorSummary, null, 2)}

Provide a strategic analysis covering:
1. Market dominance and competitive intensity
2. Service gaps and opportunities
3. Geographic coverage patterns
4. Strategic recommendations for market entry or expansion
5. Partnership opportunities

Be specific and actionable.`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            market_overview: { type: "string" },
            dominant_players: { type: "array", items: { type: "string" } },
            opportunities: { type: "array", items: { type: "string" } },
            threats: { type: "array", items: { type: "string" } },
            recommendations: { type: "array", items: { type: "string" } },
            competitive_intensity: { type: "string", enum: ["Low", "Moderate", "High", "Very High"] }
          }
        }
      });

      setInsights(response);
      toast.success('Analysis complete!', { id: 'ai-insights' });
    } catch (error) {
      console.error('AI insights error:', error);
      const errorMessage = error?.message || error?.toString() || 'Failed to generate insights';
      setError(errorMessage);
      toast.error('Failed to generate insights', { id: 'ai-insights' });
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <Card className="border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-white">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-600" />
            AI-Powered Competitive Intelligence
          </div>
          <Button 
            onClick={generateInsights} 
            disabled={isGenerating || competitors.length === 0}
            className="bg-purple-600 hover:bg-purple-700"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Analyzing...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Generate Insights
              </>
            )}
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {!insights && !isGenerating && !error && (
          <div className="text-center py-8 text-gray-500">
            <Sparkles className="w-12 h-12 mx-auto mb-4 text-purple-300" />
            <p>Click "Generate Insights" to analyze the competitive landscape</p>
          </div>
        )}

        {error && !isGenerating && (
          <div className="bg-red-50 border-2 border-red-200 rounded-lg p-6">
            <div className="flex items-start gap-3 mb-4">
              <AlertTriangle className="w-6 h-6 text-red-600 flex-shrink-0 mt-1" />
              <div>
                <h4 className="font-semibold text-red-900 mb-1">Failed to Generate Insights</h4>
                <p className="text-sm text-red-700">{error}</p>
              </div>
            </div>
            <Button 
              onClick={generateInsights}
              className="bg-red-600 hover:bg-red-700"
            >
              <Sparkles className="w-4 h-4 mr-2" />
              Try Again
            </Button>
          </div>
        )}

        {isGenerating && (
          <div className="text-center py-12">
            <Loader2 className="w-12 h-12 animate-spin text-purple-600 mx-auto mb-4" />
            <p className="text-gray-600">Analyzing {competitors.length} competitors...</p>
          </div>
        )}

        {insights && (
          <div className="space-y-6">
            <div className="flex items-center gap-4">
              <Badge className="text-lg px-4 py-2 bg-purple-100 text-purple-800 border-purple-300">
                Competitive Intensity: {insights.competitive_intensity}
              </Badge>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-blue-600" />
                Market Overview
              </h3>
              <p className="text-gray-700 leading-relaxed bg-white p-4 rounded-lg border border-gray-200">
                {insights.market_overview}
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-green-600" />
                  Opportunities
                </h3>
                <div className="space-y-2">
                  {insights.opportunities?.map((opp, idx) => (
                    <div key={idx} className="bg-green-50 p-3 rounded-lg border border-green-200">
                      <p className="text-sm text-gray-800">{opp}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-amber-600" />
                  Competitive Threats
                </h3>
                <div className="space-y-2">
                  {insights.threats?.map((threat, idx) => (
                    <div key={idx} className="bg-amber-50 p-3 rounded-lg border border-amber-200">
                      <p className="text-sm text-gray-800">{threat}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center gap-2">
                <Target className="w-5 h-5 text-purple-600" />
                Strategic Recommendations
              </h3>
              <div className="space-y-2">
                {insights.recommendations?.map((rec, idx) => (
                  <div key={idx} className="bg-purple-50 p-4 rounded-lg border border-purple-200 flex items-start gap-3">
                    <div className="flex-shrink-0 w-6 h-6 rounded-full bg-purple-600 text-white flex items-center justify-center text-sm font-bold">
                      {idx + 1}
                    </div>
                    <p className="text-sm text-gray-800 flex-1">{rec}</p>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center gap-2">
                <Users className="w-5 h-5 text-blue-600" />
                Dominant Players
              </h3>
              <div className="flex flex-wrap gap-2">
                {insights.dominant_players?.map((player, idx) => (
                  <Badge key={idx} className="bg-blue-100 text-blue-800 border-blue-300 px-3 py-1">
                    {player}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}