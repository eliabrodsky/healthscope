import React, { useMemo, useState } from 'react';
import { MapContainer, TileLayer, CircleMarker, Popup, Tooltip as LeafletTooltip } from 'react-leaflet';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin } from 'lucide-react';
import 'leaflet/dist/leaflet.css';

export default function MarketShareMap({ competitors, assessment }) {
  const [selectedType, setSelectedType] = useState('all');

  const mapData = useMemo(() => {
    const sites = [];
    
    competitors.forEach(comp => {
      if (selectedType !== 'all' && comp.type !== selectedType) return;
      
      if (comp.sites?.length > 0) {
        comp.sites.forEach(site => {
          if (site.coordinates?.latitude && site.coordinates?.longitude) {
            sites.push({
              ...site,
              parentName: comp.name,
              parentType: comp.type,
              patients: comp.total_patients || 0,
              color: comp.type === 'hospital' ? '#dc2626' : 
                     comp.type === 'fqhc' ? '#2563eb' : 
                     comp.type === 'clinic' ? '#16a34a' : '#64748b'
            });
          }
        });
      } else if (comp.coordinates?.latitude && comp.coordinates?.longitude) {
        sites.push({
          name: comp.name,
          coordinates: comp.coordinates,
          parentName: comp.name,
          parentType: comp.type,
          patients: comp.total_patients || 0,
          color: comp.type === 'hospital' ? '#dc2626' : 
                 comp.type === 'fqhc' ? '#2563eb' : 
                 comp.type === 'clinic' ? '#16a34a' : '#64748b'
        });
      }
    });
    
    return sites;
  }, [competitors, selectedType]);

  const center = useMemo(() => {
    if (assessment?.geography?.latitude && assessment?.geography?.longitude) {
      return [assessment.geography.latitude, assessment.geography.longitude];
    }
    if (mapData.length > 0) {
      const avgLat = mapData.reduce((sum, s) => sum + s.coordinates.latitude, 0) / mapData.length;
      const avgLng = mapData.reduce((sum, s) => sum + s.coordinates.longitude, 0) / mapData.length;
      return [avgLat, avgLng];
    }
    return [32.3, -90.2];
  }, [assessment, mapData]);

  const getRadius = (patients) => {
    if (patients < 5000) return 8;
    if (patients < 20000) return 12;
    if (patients < 50000) return 16;
    return 20;
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <MapPin className="w-5 h-5" />
            Competitor Site Locations
          </CardTitle>
          <div className="flex gap-2">
            <Badge 
              className={`cursor-pointer ${selectedType === 'all' ? 'bg-gray-800' : 'bg-gray-200 text-gray-700'}`}
              onClick={() => setSelectedType('all')}
            >
              All ({mapData.length})
            </Badge>
            <Badge 
              className={`cursor-pointer ${selectedType === 'hospital' ? 'bg-red-600' : 'bg-red-100 text-red-800'}`}
              onClick={() => setSelectedType('hospital')}
            >
              Hospitals
            </Badge>
            <Badge 
              className={`cursor-pointer ${selectedType === 'fqhc' ? 'bg-blue-600' : 'bg-blue-100 text-blue-800'}`}
              onClick={() => setSelectedType('fqhc')}
            >
              FQHCs
            </Badge>
            <Badge 
              className={`cursor-pointer ${selectedType === 'clinic' ? 'bg-green-600' : 'bg-green-100 text-green-800'}`}
              onClick={() => setSelectedType('clinic')}
            >
              Clinics
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-[600px] rounded-lg border overflow-hidden">
          <MapContainer
            center={center}
            zoom={10}
            style={{ height: '100%', width: '100%' }}
            scrollWheelZoom={true}
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            {mapData.map((site, idx) => (
              <CircleMarker
                key={idx}
                center={[site.coordinates.latitude, site.coordinates.longitude]}
                radius={getRadius(site.patients)}
                pathOptions={{
                  fillColor: site.color,
                  color: '#fff',
                  weight: 2,
                  opacity: 1,
                  fillOpacity: 0.7
                }}
              >
                <LeafletTooltip>
                  <div className="font-semibold">{site.parentName}</div>
                </LeafletTooltip>
                <Popup>
                  <div className="p-2">
                    <p className="font-bold text-gray-900 mb-1">{site.parentName}</p>
                    <p className="text-sm text-gray-600 mb-2">{site.name || 'Main Site'}</p>
                    <div className="text-xs space-y-1">
                      <p className="capitalize">Type: <span className="font-semibold">{site.parentType}</span></p>
                      <p>Patients: <span className="font-semibold">{site.patients.toLocaleString()}</span></p>
                    </div>
                  </div>
                </Popup>
              </CircleMarker>
            ))}
          </MapContainer>
        </div>
      </CardContent>
    </Card>
  );
}