import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Download, FileSpreadsheet } from 'lucide-react';
import { toast } from 'sonner';

export default function DownloadableTable({ competitors, assessment }) {
  const downloadCSV = () => {
    const headers = ['Organization', 'Type', 'City', 'State', 'Total Sites', 'Total Patients', 'Patients per Site', 'Service ZIPs'];
    
    const rows = competitors.map(comp => [
      comp.name,
      comp.type,
      comp.city || '',
      comp.state || '',
      comp.total_sites || 0,
      comp.total_patients || 0,
      comp.patients_per_site || 0,
      (comp.service_area_zips || []).join('; ')
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `competitor-analysis-${assessment?.geography?.city || 'data'}-${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast.success('Downloaded competitor data!');
  };

  const downloadJSON = () => {
    const data = {
      assessment: {
        title: assessment?.title,
        location: `${assessment?.geography?.city}, ${assessment?.geography?.state}`,
        generated: new Date().toISOString()
      },
      competitors: competitors.map(comp => ({
        name: comp.name,
        type: comp.type,
        location: {
          city: comp.city,
          state: comp.state,
          coordinates: comp.coordinates
        },
        metrics: {
          total_sites: comp.total_sites,
          total_patients: comp.total_patients,
          patients_per_site: comp.patients_per_site
        },
        service_area: comp.service_area_zips,
        sites: comp.sites
      }))
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `competitor-analysis-${assessment?.geography?.city || 'data'}-${new Date().toISOString().split('T')[0]}.json`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast.success('Downloaded competitor data (JSON)!');
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5" />
            Export Competitor Data
          </span>
          <div className="flex gap-2">
            <Button onClick={downloadCSV} variant="outline" size="sm">
              <Download className="w-4 h-4 mr-2" />
              CSV
            </Button>
            <Button onClick={downloadJSON} variant="outline" size="sm">
              <Download className="w-4 h-4 mr-2" />
              JSON
            </Button>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gradient-to-r from-emerald-50 to-blue-50">
              <tr>
                <th className="px-4 py-3 text-left font-semibold text-gray-900 border">Organization</th>
                <th className="px-4 py-3 text-center font-semibold text-gray-900 border">Type</th>
                <th className="px-4 py-3 text-center font-semibold text-gray-900 border">Sites</th>
                <th className="px-4 py-3 text-right font-semibold text-gray-900 border">Patients</th>
                <th className="px-4 py-3 text-right font-semibold text-gray-900 border">Per Site</th>
                <th className="px-4 py-3 text-center font-semibold text-gray-900 border">ZIP Codes</th>
              </tr>
            </thead>
            <tbody>
              {competitors.map((comp, idx) => (
                <tr key={idx} className="hover:bg-gray-50">
                  <td className="px-4 py-3 border font-medium text-gray-900">{comp.name}</td>
                  <td className="px-4 py-3 border text-center">
                    <span className={`inline-block px-2 py-1 rounded text-xs font-semibold capitalize ${
                      comp.type === 'hospital' ? 'bg-red-100 text-red-800' :
                      comp.type === 'fqhc' ? 'bg-blue-100 text-blue-800' :
                      'bg-green-100 text-green-800'
                    }`}>
                      {comp.type}
                    </span>
                  </td>
                  <td className="px-4 py-3 border text-center font-semibold">{comp.total_sites || 0}</td>
                  <td className="px-4 py-3 border text-right font-semibold">{(comp.total_patients || 0).toLocaleString()}</td>
                  <td className="px-4 py-3 border text-right">{(comp.patients_per_site || 0).toLocaleString()}</td>
                  <td className="px-4 py-3 border text-center text-gray-600">{(comp.service_area_zips || []).length}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}