import React, { useMemo } from "react";
import { MapContainer, TileLayer, GeoJSON, Popup, Tooltip } from "react-leaflet";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import "leaflet/dist/leaflet.css";

export default function PatientOriginMap({ originData, competitor, assessment }) {
  const center = useMemo(() => {
    if (competitor.coordinates) {
      return [competitor.coordinates.latitude, competitor.coordinates.longitude];
    }
    if (assessment?.geography) {
      return [assessment.geography.latitude || 35.0, assessment.geography.longitude || -90.0];
    }
    return [35.0, -90.0];
  }, [competitor, assessment]);

  const maxPatients = useMemo(() => {
    return Math.max(...originData.map(d => d.patient_count), 1);
  }, [originData]);

  const getColor = (patientCount) => {
    const intensity = patientCount / maxPatients;
    if (intensity > 0.7) return '#dc2626';
    if (intensity > 0.4) return '#f59e0b';
    if (intensity > 0.2) return '#3b82f6';
    return '#10b981';
  };

  // Create a map of ZIP to patient data
  const zipDataMap = useMemo(() => {
    const map = {};
    originData.forEach(d => {
      map[d.zip_code] = d;
    });
    return map;
  }, [originData]);

  // Get boundaries from assessment
  const boundaries = useMemo(() => {
    const features = assessment?.processed_data?.trimmed_geojson?.features || [];
    return features.filter(f => {
      const zip = f.properties.zcta5 || f.properties.ZCTA5CE10;
      return zipDataMap[zip]; // Only show boundaries for ZIPs with patient data
    });
  }, [assessment, zipDataMap]);

  const styleFeature = (feature) => {
    const zip = feature.properties.zcta5 || feature.properties.ZCTA5CE10;
    const data = zipDataMap[zip];
    const patientCount = data?.patient_count || 0;
    const color = getColor(patientCount);
    
    return {
      fillColor: color,
      weight: 2,
      opacity: 1,
      color: '#ffffff',
      fillOpacity: 0.7
    };
  };

  const onEachFeature = (feature, layer) => {
    const zip = feature.properties.zcta5 || feature.properties.ZCTA5CE10;
    const data = zipDataMap[zip];
    
    if (data) {
      layer.bindPopup(`
        <div class="p-2">
          <div class="font-bold text-lg mb-2">ZIP ${zip}</div>
          <div class="space-y-1 text-sm">
            <div><strong>Patients:</strong> ${data.patient_count.toLocaleString()}</div>
            <div><strong>% of Total:</strong> ${data.percentage.toFixed(1)}%</div>
            ${data.population ? `<div><strong>Population:</strong> ${data.population.toLocaleString()}</div>` : ''}
            <div><strong>Penetration:</strong> ${data.penetration_rate.toFixed(1)}%</div>
          </div>
        </div>
      `);
      
      layer.bindTooltip(`${zip}: ${data.patient_count.toLocaleString()} patients`, {
        permanent: false,
        direction: 'center',
        className: 'bg-white text-xs font-semibold'
      });
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Patient Origin Map - {competitor.name}</CardTitle>
        <p className="text-sm text-gray-600">
          Showing where patients originate from. Circle size and color indicate patient volume.
        </p>
      </CardHeader>
      <CardContent>
        <div className="h-[500px] rounded-lg overflow-hidden border-2 border-gray-200">
          <MapContainer
            center={center}
            zoom={10}
            style={{ height: '100%', width: '100%' }}
            scrollWheelZoom={true}
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            
            {boundaries.map((feature, idx) => (
              <GeoJSON
                key={idx}
                data={feature}
                style={styleFeature}
                onEachFeature={onEachFeature}
              />
            ))}
          </MapContainer>
        </div>

        <div className="mt-4 flex items-center justify-between">
          <div className="flex items-center gap-4 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-red-600"></div>
              <span>High Volume (&gt;70%)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-amber-500"></div>
              <span>Medium (40-70%)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-blue-500"></div>
              <span>Low (20-40%)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-green-500"></div>
              <span>Minimal (&lt;20%)</span>
            </div>
          </div>
          <Badge variant="outline">
            Total: {originData.reduce((sum, d) => sum + d.patient_count, 0).toLocaleString()} patients
          </Badge>
        </div>

        <div className="mt-6">
          <h4 className="font-semibold mb-3">Top Origin ZIP Codes</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {originData.slice(0, 6).map((origin) => (
              <div key={origin.zip_code} className="p-3 bg-gray-50 rounded-lg border">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="font-semibold text-gray-900">ZIP {origin.zip_code}</div>
                    <div className="text-sm text-gray-600 mt-1">
                      {origin.patient_count.toLocaleString()} patients ({origin.percentage.toFixed(1)}%)
                    </div>
                  </div>
                  <Badge 
                    style={{ 
                      backgroundColor: getColor(origin.patient_count),
                      color: 'white'
                    }}
                  >
                    {origin.penetration_rate.toFixed(1)}% penetration
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}