import React, { useMemo } from 'react';
import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ZAxis, Legend } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const CustomTooltip = ({ active, payload }) => {
  if (!active || !payload || !payload[0]) return null;
  
  const data = payload[0].payload;
  return (
    <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200">
      <p className="font-bold text-gray-900 mb-2">{data.name}</p>
      <div className="space-y-1 text-sm">
        <p className="text-gray-700">Patients: <span className="font-semibold">{data.patients.toLocaleString()}</span></p>
        <p className="text-gray-700">Revenue: <span className="font-semibold">{data.revenue > 0 ? `$${data.revenue.toLocaleString()}` : 'Unknown*'}</span></p>
        <p className="text-gray-700">Patients/Site: <span className="font-semibold">{data.z.toLocaleString()}</span></p>
        <Badge className={`capitalize mt-2 ${
          data.type === 'hospital' ? 'bg-red-100 text-red-800' :
          data.type === 'fqhc' ? 'bg-blue-100 text-blue-800' :
          'bg-green-100 text-green-800'
        }`}>
          {data.type}
        </Badge>
      </div>
    </div>
  );
};

export default function CompetitorBubbleChart({ competitors }) {
  const chartData = useMemo(() => {
    return competitors
      .filter(comp => (comp.total_patients || 0) > 0) // Remove competitors with no patient data
      .map(comp => ({
        name: comp.name,
        patients: comp.total_patients || 0,
        revenue: comp.total_revenue || 0,
        z: comp.patients_per_site || 0,
        type: comp.type,
        fill: comp.type === 'hospital' ? '#dc2626' : 
              comp.type === 'fqhc' ? '#2563eb' : 
              comp.type === 'clinic' ? '#16a34a' : '#64748b'
      }));
  }, [competitors]);

  if (chartData.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Competitor Performance Matrix</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-500 text-center py-12">No data available</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Competitor Performance Matrix</span>
          <div className="flex gap-2 text-xs">
            <Badge className="bg-red-100 text-red-800">Hospitals</Badge>
            <Badge className="bg-blue-100 text-blue-800">FQHCs</Badge>
            <Badge className="bg-green-100 text-green-800">Clinics</Badge>
          </div>
        </CardTitle>
        <p className="text-sm text-gray-600">Bubble size = Patients per Site | X-axis = Total Revenue | Y-axis = Total Patients</p>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={450}>
          <ScatterChart margin={{ top: 20, right: 20, bottom: 60, left: 20 }}>
            <defs>
              <linearGradient id="hospitalGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#dc2626" stopOpacity={0.8}/>
                <stop offset="95%" stopColor="#dc2626" stopOpacity={0.3}/>
              </linearGradient>
              <linearGradient id="fqhcGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#2563eb" stopOpacity={0.8}/>
                <stop offset="95%" stopColor="#2563eb" stopOpacity={0.3}/>
              </linearGradient>
              <linearGradient id="clinicGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#16a34a" stopOpacity={0.8}/>
                <stop offset="95%" stopColor="#16a34a" stopOpacity={0.3}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis 
              type="number" 
              dataKey="revenue" 
              name="Revenue"
              label={{ value: 'Total Revenue', position: 'insideBottom', offset: -10, style: { fontSize: 12 } }}
              tick={{ fill: '#6b7280', fontSize: 10 }}
              tickFormatter={(value) => value > 0 ? `$${(value / 1000000).toFixed(1)}M` : '$0'}
            />
            <YAxis 
              type="number" 
              dataKey="patients" 
              name="Patients"
              label={{ value: 'Total Patients', angle: -90, position: 'insideLeft', style: { fontSize: 12 } }}
              tick={{ fill: '#6b7280', fontSize: 10 }}
              tickFormatter={(value) => value >= 1000 ? `${(value / 1000).toFixed(0)}K` : value}
            />
            <ZAxis type="number" dataKey="z" range={[100, 2000]} name="Patients/Site" />
            <Tooltip content={<CustomTooltip />} cursor={{ strokeDasharray: '3 3' }} />
            <Scatter 
              data={chartData} 
              fill="#8884d8"
            >
              {chartData.map((entry, index) => (
                <circle key={index} cx={0} cy={0} r={10} fill={entry.fill} opacity={0.7} />
              ))}
            </Scatter>
          </ScatterChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}