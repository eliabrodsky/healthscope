import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, X } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function CompetitorComparisonView({ competitors, assessment, onBack, onRemoveCompetitor }) {
  const comparisonData = competitors.map(c => ({
    name: c.name.substring(0, 20) + (c.name.length > 20 ? '...' : ''),
    patients: c.total_patients || 0,
    sites: c.total_sites || 0,
    zips: c.service_area_zips?.length || 0
  }));

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <Button variant="ghost" onClick={onBack} className="mb-4">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to List
          </Button>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Competitor Comparison
          </h1>
          <p className="text-gray-600">
            Comparing {competitors.length} organizations
          </p>
        </div>

        {/* Selected Competitors */}
        <Card>
          <CardHeader>
            <CardTitle>Selected Competitors</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {competitors.map(c => (
                <Badge key={c.id} variant="secondary" className="text-sm py-2 px-3">
                  {c.name}
                  <button
                    onClick={() => onRemoveCompetitor(c.id)}
                    className="ml-2 hover:text-red-600"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Comparison Table */}
        <Card>
          <CardHeader>
            <CardTitle>Side-by-Side Comparison</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-4 font-semibold">Metric</th>
                    {competitors.map(c => (
                      <th key={c.id} className="text-right py-3 px-4 font-semibold">
                        {c.name.substring(0, 15)}...
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b">
                    <td className="py-3 px-4 font-medium">Type</td>
                    {competitors.map(c => (
                      <td key={c.id} className="text-right py-3 px-4">
                        <Badge variant="outline" className="capitalize">
                          {c.type?.replace('_', ' ')}
                        </Badge>
                      </td>
                    ))}
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4 font-medium">Total Patients</td>
                    {competitors.map(c => (
                      <td key={c.id} className="text-right py-3 px-4">
                        {(c.total_patients || 0).toLocaleString()}
                      </td>
                    ))}
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4 font-medium">Total Sites</td>
                    {competitors.map(c => (
                      <td key={c.id} className="text-right py-3 px-4">
                        {c.total_sites || 0}
                      </td>
                    ))}
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4 font-medium">Service ZIPs</td>
                    {competitors.map(c => (
                      <td key={c.id} className="text-right py-3 px-4">
                        {c.service_area_zips?.length || 0}
                      </td>
                    ))}
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4 font-medium">Patients per Site</td>
                    {competitors.map(c => (
                      <td key={c.id} className="text-right py-3 px-4">
                        {(c.patients_per_site || 0).toLocaleString()}
                      </td>
                    ))}
                  </tr>
                  <tr className="border-b">
                    <td className="py-3 px-4 font-medium">Location</td>
                    {competitors.map(c => (
                      <td key={c.id} className="text-right py-3 px-4 text-sm">
                        {c.city}, {c.state}
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Charts */}
        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Patient Volume Comparison</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={comparisonData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" angle={-45} textAnchor="end" height={80} />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="patients" fill="#3b82f6" name="Total Patients" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Sites & Coverage</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={comparisonData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" angle={-45} textAnchor="end" height={80} />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="sites" fill="#10b981" name="Total Sites" />
                  <Bar dataKey="zips" fill="#f59e0b" name="Service ZIPs" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}