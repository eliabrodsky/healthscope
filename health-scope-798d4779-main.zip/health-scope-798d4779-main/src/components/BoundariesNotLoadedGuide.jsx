import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { MapPin, AlertTriangle, ArrowRight, RefreshCw } from 'lucide-react';

export default function BoundariesNotLoadedGuide({ stateAbbr, stateName, onLoadBoundaries, isLoading }) {
    return (
        <Card className="border-amber-200 bg-amber-50">
            <CardHeader>
                <CardTitle className="flex items-center gap-2 text-amber-900">
                    <MapPin className="w-5 h-5" />
                    Load Boundaries First - {stateName}
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <Alert className="bg-white border-amber-200">
                    <AlertTriangle className="w-4 h-4 text-amber-600" />
                    <AlertDescription className="text-amber-900">
                        <strong>Missing prerequisite:</strong> ZCTA boundaries must be loaded first for {stateName}.
                    </AlertDescription>
                </Alert>

                <div className="bg-white rounded-lg p-4 border border-amber-200 space-y-3">
                    <div>
                        <h3 className="font-semibold text-gray-900 mb-2">📍 What are boundaries?</h3>
                        <p className="text-sm text-gray-600">
                            ZCTA (ZIP Code Tabulation Area) boundaries are the geographic shapes that define each ZIP code area.
                            The demographics loader needs these boundaries to build a list of ZCTAs for {stateName}.
                        </p>
                    </div>

                    <div>
                        <h3 className="font-semibold text-gray-900 mb-2">✅ How to fix:</h3>
                        <ol className="text-sm text-gray-600 space-y-2 ml-4 list-decimal">
                            <li>
                                Click the button below to load boundaries for <strong>{stateName}</strong>
                                <p className="text-xs text-gray-500 mt-1 ml-2">(Takes 30-90 seconds)</p>
                            </li>
                            <li>
                                Wait for the "Boundaries" column to show a green checkmark
                            </li>
                            <li>
                                Then click "Load" for Demographics again
                            </li>
                        </ol>
                    </div>

                    <div className="bg-blue-50 p-3 rounded-md border border-blue-200">
                        <p className="text-xs text-blue-900 font-medium mb-1">💡 What happens during boundary loading:</p>
                        <ul className="text-xs text-blue-800 space-y-1 ml-4 list-disc">
                            <li>Downloads GeoJSON file from Census Bureau GitHub</li>
                            <li>Extracts ZCTA polygons for {stateName}</li>
                            <li>Builds a cached list of ZCTA codes</li>
                            <li>Saves to database (ZctaBoundary table)</li>
                        </ul>
                    </div>

                    <div className="flex gap-2">
                        <Button
                            onClick={onLoadBoundaries}
                            disabled={isLoading}
                            className="bg-emerald-600 hover:bg-emerald-700 flex-1"
                        >
                            {isLoading ? (
                                <>
                                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                                    Loading Boundaries...
                                </>
                            ) : (
                                <>
                                    <MapPin className="w-4 h-4 mr-2" />
                                    Load {stateName} Boundaries
                                    <ArrowRight className="w-4 h-4 ml-2" />
                                </>
                            )}
                        </Button>
                    </div>
                </div>

                <div className="bg-gray-50 rounded-lg p-3 border border-gray-200">
                    <h3 className="font-semibold text-gray-900 mb-2 text-sm">🔄 Load Order</h3>
                    <div className="flex items-center gap-2 text-sm">
                        <div className="flex items-center gap-1">
                            <div className="w-6 h-6 rounded-full bg-emerald-500 text-white flex items-center justify-center text-xs font-bold">1</div>
                            <span className="text-gray-700">Boundaries</span>
                        </div>
                        <ArrowRight className="w-4 h-4 text-gray-400" />
                        <div className="flex items-center gap-1">
                            <div className="w-6 h-6 rounded-full bg-gray-300 text-white flex items-center justify-center text-xs font-bold">2</div>
                            <span className="text-gray-500">Demographics</span>
                        </div>
                        <ArrowRight className="w-4 h-4 text-gray-400" />
                        <div className="flex items-center gap-1">
                            <div className="w-6 h-6 rounded-full bg-gray-300 text-white flex items-center justify-center text-xs font-bold">3</div>
                            <span className="text-gray-500">CDC Data</span>
                        </div>
                    </div>
                    <p className="text-xs text-gray-500 mt-2">
                        Each step requires the previous one to complete.
                    </p>
                </div>
            </CardContent>
        </Card>
    );
}