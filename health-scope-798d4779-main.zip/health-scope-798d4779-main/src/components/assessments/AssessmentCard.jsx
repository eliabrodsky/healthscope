import React, { useState } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { MapPin, MoreVertical, Calendar, Pencil, Trash2, Archive, Eye } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

export default function AssessmentCard({ assessment, onUpdate, onEdit, hasCheckbox = false }) {
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isArchiveDialogOpen, setIsArchiveDialogOpen] = useState(false);

  const statusColors = {
    draft: "bg-yellow-100 text-yellow-800 border-yellow-200",
    building: "bg-blue-100 text-blue-800 border-blue-200",
    published: "bg-emerald-100 text-emerald-800 border-emerald-200",
    archived: "bg-gray-100 text-gray-800 border-gray-200",
  };

  const handleDelete = async () => {
    try {
      await base44.entities.Assessment.delete(assessment.id);
      toast.success("Assessment permanently deleted.");
      onUpdate();
    } catch (error) {
      toast.error("Failed to delete assessment.");
    }
    setIsDeleteDialogOpen(false);
  };
  
  const handleArchive = async () => {
    try {
      await base44.entities.Assessment.update(assessment.id, { status: 'archived' });
      toast.success("Assessment has been archived.");
      onUpdate();
    } catch (error) {
      toast.error("Failed to archive assessment.");
    }
    setIsArchiveDialogOpen(false);
  };

  const geoDescription = [
    assessment.geography?.city,
    assessment.geography?.county,
    assessment.geography?.state,
  ]
    .filter(Boolean)
    .join(", ");

  return (
    <>
      <Card className="flex flex-col h-full bg-white border-gray-200 shadow-sm hover:shadow-lg transition-all duration-300">
        <CardHeader className={hasCheckbox ? "pt-12" : ""}>
          <div className="flex justify-between items-start">
            <Link to={createPageUrl(`AssessmentDashboard?id=${assessment.id}`)} className="flex-1">
              <CardTitle className="text-lg font-bold text-gray-900 leading-tight hover:text-emerald-600 transition-colors cursor-pointer">
                {assessment.title}
              </CardTitle>
            </Link>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <MoreVertical className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => onEdit(assessment)}>
                  <Pencil className="w-4 h-4 mr-2" /> Edit
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setIsArchiveDialogOpen(true)}>
                  <Archive className="w-4 h-4 mr-2" /> Archive
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  className="text-red-600 focus:text-red-600 focus:bg-red-50"
                  onClick={() => setIsDeleteDialogOpen(true)}
                >
                  <Trash2 className="w-4 h-4 mr-2" /> Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          <CardDescription className="text-gray-500 text-sm flex items-center gap-2 pt-1">
            <MapPin className="w-4 h-4 stroke-1" />
            <span>{geoDescription || "No location specified"}</span>
          </CardDescription>
        </CardHeader>
        <CardContent className="flex-grow">
          <p className="text-sm text-gray-600 line-clamp-2">
            {assessment.description || "No description provided."}
          </p>
        </CardContent>
        <CardFooter className="flex justify-between items-center">
          <Badge className={`capitalize ${statusColors[assessment.status]}`}>
            {assessment.status}
          </Badge>
          <Link to={createPageUrl(`AssessmentDashboard?id=${assessment.id}`)}>
            <Button variant="outline" className="text-emerald-600 border-emerald-200 hover:bg-emerald-50">
              <Eye className="w-4 h-4 mr-2" />
              View
            </Button>
          </Link>
        </CardFooter>
      </Card>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the assessment
              and all of its associated data.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
              Delete Permanently
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      {/* Archive Confirmation Dialog */}
      <AlertDialog open={isArchiveDialogOpen} onOpenChange={setIsArchiveDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Archive this assessment?</AlertDialogTitle>
            <AlertDialogDescription>
              Archiving will remove this assessment from the main list but keep its data. You can find it later by filtering for 'Archived' assessments.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleArchive}>
              Yes, Archive
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}