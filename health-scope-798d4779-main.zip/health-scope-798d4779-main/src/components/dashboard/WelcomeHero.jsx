import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Plus, BarChart3, Sparkles } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function WelcomeHero() {
  const [counts, setCounts] = useState({
    assessments: 0,
    regionalAnalyses: 0,
    organizations: 0,
    dataUploads: 0
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadCounts();
  }, []);

  const loadCounts = async () => {
    setIsLoading(true);
    try {
      const [assessments, regionalAnalyses, orgs, uploads] = await Promise.all([
        base44.entities.Assessment.list('-created_date', 100).catch(() => []),
        base44.entities.RegionalAnalysis.list('-created_date', 100).catch(() => []),
        base44.entities.Organization.list('-created_date', 100).catch(() => []),
        base44.entities.DataUpload.list('-created_date', 100).catch(() => [])
      ]);
      
      setCounts({
        assessments: assessments.length,
        regionalAnalyses: regionalAnalyses.filter(r => r.status === 'published').length,
        organizations: orgs.length,
        dataUploads: uploads.length
      });
    } catch (error) {
      console.error('Error loading counts:', error);
    } finally {
      setIsLoading(false);
    }
  };
  return (
    <div className="relative">
      {/* Hero Section */}
      <div className="relative bg-white rounded-2xl p-8 md:p-12 border-2 border-emerald-500 shadow-sm overflow-hidden">
        <div className="relative z-10 flex items-start justify-between flex-col md:flex-row gap-6">
          <div className="flex-1">
            <div className="flex items-start gap-4 mb-4">
              <div className="flex-shrink-0">
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/df444d7a5_dashboard.png"
                  alt="HealthScope AI"
                  className="w-20 h-20"
                />
              </div>
              <div>
                <h1 className="text-3xl md:text-4xl font-bold mb-2 text-gray-900">
                  Welcome to HealthScope
                </h1>
                <p className="text-gray-600 text-base leading-relaxed">
                  Your AI-powered platform for community health needs assessments
                </p>
              </div>
            </div>
            
            <div className="grid md:grid-cols-3 gap-4 mb-6">
              <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/ac23ebbf6_mapicon.png"
                  alt="Map"
                  className="w-10 h-10 mb-2"
                />
                <h3 className="font-semibold mb-1 text-gray-900">Interactive Maps</h3>
                <p className="text-sm text-gray-600">Visualize demographics & boundaries</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/1ba8b70a7_healthstatus.png"
                  alt="Health"
                  className="w-10 h-10 mb-2"
                />
                <h3 className="font-semibold mb-1 text-gray-900">Health Indicators</h3>
                <p className="text-sm text-gray-600">CDC data & community needs</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68baec872f334abd798d4779/3142a027d_dataanalysis.png"
                  alt="Analysis"
                  className="w-10 h-10 mb-2"
                />
                <h3 className="font-semibold mb-1 text-gray-900">Smart Analytics</h3>
                <p className="text-sm text-gray-600">Automated insights & trends</p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Link to={createPageUrl("CreateAssessmentWizard")} className="w-full">
                <Button className="w-full bg-emerald-500 hover:bg-emerald-600 text-white border-0 shadow-sm px-6 py-3 h-auto font-semibold">
                  <Plus className="w-5 h-5 mr-2 stroke-1" />
                  Start New Assessment
                </Button>
              </Link>
              
              <Link to={createPageUrl("AIChat")} className="w-full">
                <Button 
                  variant="outline" 
                  className="w-full border-gray-300 text-gray-700 hover:bg-gray-50 px-6 py-3 h-auto font-semibold"
                >
                  <Sparkles className="w-5 h-5 mr-2 stroke-1" />
                  Explore AI Insights
                </Button>
              </Link>
            </div>
          </div>

          <div className="min-w-[280px] w-full sm:w-auto mt-6 sm:mt-0">
            <h3 className="text-gray-900 font-semibold mb-4">Quick Overview</h3>
            <div className="space-y-2">
              <Link to={createPageUrl("Assessments")} className="flex justify-between items-center hover:bg-gray-50 p-2 rounded-lg transition-colors">
                <span className="text-gray-600 text-sm">Active Assessments</span>
                <span className="text-gray-900 font-bold">
                  {isLoading ? <span className="inline-flex gap-1"><span className="animate-pulse">.</span><span className="animate-pulse" style={{animationDelay: '0.2s'}}>.</span><span className="animate-pulse" style={{animationDelay: '0.4s'}}>.</span></span> : counts.assessments}
                </span>
              </Link>
              <Link to={createPageUrl("CompetitorAnalysis")} className="flex justify-between items-center hover:bg-gray-50 p-2 rounded-lg transition-colors">
                <span className="text-gray-600 text-sm">Competitor Analysis</span>
                <span className="text-gray-900 font-bold">→</span>
              </Link>
              <Link to={createPageUrl("RegionalAnalysis")} className="flex justify-between items-center hover:bg-gray-50 p-2 rounded-lg transition-colors">
                <span className="text-gray-600 text-sm">Regional Analysis</span>
                <span className="text-gray-900 font-bold">
                  {isLoading ? <span className="inline-flex gap-1"><span className="animate-pulse">.</span><span className="animate-pulse" style={{animationDelay: '0.2s'}}>.</span><span className="animate-pulse" style={{animationDelay: '0.4s'}}>.</span></span> : (counts.regionalAnalyses || '→')}
                </span>
              </Link>
              <Link to={createPageUrl("DataUpload")} className="flex justify-between items-center hover:bg-gray-50 p-2 rounded-lg transition-colors">
                <span className="text-gray-600 text-sm">Data Sources</span>
                <span className="text-gray-900 font-bold">
                  {isLoading ? <span className="inline-flex gap-1"><span className="animate-pulse">.</span><span className="animate-pulse" style={{animationDelay: '0.2s'}}>.</span><span className="animate-pulse" style={{animationDelay: '0.4s'}}>.</span></span> : counts.dataUploads}
                </span>
              </Link>
              <Link to={createPageUrl("CompetitorAnalysis")} className="flex justify-between items-center hover:bg-gray-50 p-2 rounded-lg transition-colors">
                <span className="text-gray-600 text-sm">Organizations</span>
                <span className="text-gray-900 font-bold">
                  {isLoading ? <span className="inline-flex gap-1"><span className="animate-pulse">.</span><span className="animate-pulse" style={{animationDelay: '0.2s'}}>.</span><span className="animate-pulse" style={{animationDelay: '0.4s'}}>.</span></span> : counts.organizations}
                </span>
              </Link>
              <Link to={createPageUrl("PresentationBuilder")} className="flex justify-between items-center hover:bg-gray-50 p-2 rounded-lg transition-colors">
                <span className="text-gray-600 text-sm">Presentations</span>
                <span className="text-gray-900 font-bold">→</span>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}