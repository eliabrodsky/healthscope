import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Plus, 
  Upload, 
  Map, 
  BarChart3, 
  FileText, 
  Users,
  Sparkles,
  ArrowRight
} from "lucide-react";

const actions = [
  {
    title: "New Assessment",
    description: "Create comprehensive health analysis",
    icon: Plus,
    link: createPageUrl("CreateAssessmentWizard"),
    color: "text-emerald-600",
    bgColor: "bg-emerald-50 hover:bg-emerald-100"
  },
  {
    title: "Upload Data",
    description: "Import health datasets and reports",
    icon: Upload,
    link: createPageUrl("DataUpload"),
    color: "text-green-600",
    bgColor: "bg-green-50 hover:bg-green-100"
  },
  {
    title: "View Dashboards",
    description: "Explore interactive visualizations",
    icon: BarChart3,
    link: createPageUrl("Assessments"),
    color: "text-teal-600",
    bgColor: "bg-teal-50 hover:bg-teal-100"
  },
  {
    title: "AI Chat",
    description: "Ask questions about your data",
    icon: Sparkles,
    link: "#",
    color: "text-lime-600",
    bgColor: "bg-lime-50 hover:bg-lime-100"
  }
];

export default function QuickActions() {
  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Quick Actions</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {actions.map((action, index) => (
          <Link key={action.title} to={action.link} className="group">
            <Card className={`border-gray-200 hover:shadow-md transition-all duration-300 group-hover:scale-105 h-full ${action.bgColor}`}>
              <CardContent className="p-6">
                <div className={`w-12 h-12 rounded-xl bg-white flex items-center justify-center mb-4 shadow-sm border border-gray-100`}>
                  <action.icon className={`w-6 h-6 ${action.color} stroke-1`} />
                </div>
                
                <h3 className="text-gray-900 font-semibold text-lg mb-2">
                  {action.title}
                </h3>
                
                <p className="text-gray-600 text-sm mb-4">
                  {action.description}
                </p>
                
                <div className="flex items-center text-gray-500 group-hover:text-gray-700 transition-colors">
                  <span className="text-sm font-medium">Get started</span>
                  <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform stroke-1" />
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}