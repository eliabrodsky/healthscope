import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, TrendingDown, Users, Heart } from "lucide-react";

const metrics = [
  {
    title: "Population Health Score",
    value: "7.2/10",
    change: "+0.3",
    trend: "up",
    description: "Composite health indicator"
  },
  {
    title: "Diabetes Prevalence",
    value: "12.4%",
    change: "-1.2%",
    trend: "down",
    description: "Below national average"
  },
  {
    title: "Uninsured Rate",
    value: "8.7%",
    change: "+0.8%",
    trend: "up", 
    description: "Slight increase this quarter"
  },
  {
    title: "FQHC Coverage",
    value: "34%",
    change: "+5.2%",
    trend: "up",
    description: "Improved accessibility"
  }
];

export default function HealthMetrics() {
  return (
    <Card className="border-gray-200 shadow-sm">
      <CardHeader>
        <CardTitle className="text-gray-900 flex items-center gap-2">
          <Heart className="w-5 h-5 stroke-1" />
          Key Health Metrics
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {metrics.map((metric, index) => (
            <div key={metric.title} className="p-4 bg-gray-50 rounded-xl border border-gray-100">
              <div className="flex items-start justify-between mb-2">
                <h4 className="font-medium text-gray-900 text-sm">{metric.title}</h4>
                <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs ${
                  metric.trend === 'up' 
                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                    : 'bg-red-50 text-red-700 border border-red-200'
                }`}>
                  {metric.trend === 'up' ? (
                    <TrendingUp className="w-3 h-3 stroke-1" />
                  ) : (
                    <TrendingDown className="w-3 h-3 stroke-1" />
                  )}
                  <span>{metric.change}</span>
                </div>
              </div>
              
              <div className="text-2xl font-bold text-gray-900 mb-1">
                {metric.value}
              </div>
              
              <p className="text-xs text-gray-500">
                {metric.description}
              </p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}