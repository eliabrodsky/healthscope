import React from "react";
import { useNavigate, Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Map, Eye, Calendar, MapPin, User } from "lucide-react";
import { format } from "date-fns";

const statusColors = {
  draft: "bg-yellow-50 text-yellow-700 border-yellow-200",
  published: "bg-emerald-50 text-emerald-700 border-emerald-200",
  active: "bg-emerald-50 text-emerald-700 border-emerald-200",
  archived: "bg-gray-50 text-gray-700 border-gray-200"
};

export default function RecentAssessments({ assessments, isLoading }) {
  const navigate = useNavigate();

  const handleTitleClick = (assessment) => {
    navigate(`${createPageUrl("AssessmentDashboard")}?id=${assessment.id}`);
  };

  return (
    <Card className="border-gray-200 shadow-sm">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-gray-900 flex items-center gap-2">
          <Map className="w-5 h-5 stroke-1" />
          Recent Assessments
        </CardTitle>
        <Link to={createPageUrl("Assessments")}>
          <Button variant="outline" size="sm" className="border-gray-300 text-gray-700 hover:bg-gray-50">
            View All
          </Button>
        </Link>
      </CardHeader>
      <CardContent className="space-y-4">
        {isLoading ? (
          Array(3).fill(0).map((_, i) => (
            <div key={i} className="p-4 bg-gray-50 rounded-xl border border-gray-100 space-y-3">
              <Skeleton className="h-5 w-3/4 bg-gray-200" />
              <Skeleton className="h-4 w-1/2 bg-gray-200" />
              <Skeleton className="h-6 w-16 bg-gray-200" />
            </div>
          ))
        ) : Array.isArray(assessments) && assessments.length > 0 ? ( // Added Array.isArray check to prevent crash if 'assessments' is not an array
          assessments.slice(0, 5).map((assessment) => (
            <div key={assessment.id} className="p-4 bg-gray-50 rounded-xl border border-gray-100 hover:bg-gray-100 transition-all group cursor-pointer">
              <div className="flex items-start justify-between">
                <div className="flex-1" onClick={() => handleTitleClick(assessment)}>
                  <h3 className="font-semibold text-gray-900 group-hover:text-emerald-700 transition-colors cursor-pointer">
                    {assessment.title}
                  </h3>
                  
                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-2 text-sm text-gray-600">
                    {assessment.geography && (
                      <div className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 stroke-1" />
                        <span>{assessment.geography.state || 'Multiple States'}</span>
                      </div>
                    )}
                    {assessment.created_date && ( // Added check for created_date to prevent potential issues
                      <div className="flex items-center gap-1">
                        <Calendar className="w-3 h-3 stroke-1" />
                        <span>{format(new Date(assessment.created_date), 'MMM d, yyyy')}</span>
                      </div>
                    )}
                    {assessment.created_by && (
                      <div className="flex items-center gap-1">
                        <User className="w-3 h-3 stroke-1" />
                        <span>{assessment.created_by}</span>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-2 mt-3">
                    <Badge className={statusColors[assessment.status] || statusColors.draft}>
                      {assessment.status || 'draft'}
                    </Badge>
                    {assessment.data_sources && (
                      <span className="text-xs text-gray-500">
                        {assessment.data_sources.length} data sources
                      </span>
                    )}
                  </div>
                </div>
                
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="text-gray-500 hover:text-gray-700 hover:bg-gray-200"
                  onClick={() => handleTitleClick(assessment)}
                >
                  <Eye className="w-4 h-4 stroke-1" />
                </Button>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-8">
            <Map className="w-12 h-12 text-gray-300 mx-auto mb-4 stroke-1" />
            <p className="text-gray-600 mb-4">No assessments created yet</p>
            <Link to={createPageUrl("Assessments")}>
              <Button className="bg-emerald-500 hover:bg-emerald-600 text-white">
                Create Your First Assessment
              </Button>
            </Link>
          </div>
        )}
      </CardContent>
    </Card>
  );
}