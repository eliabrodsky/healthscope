
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sparkles, TrendingUp, AlertTriangle, Target } from "lucide-react";

const insights = [
  {
    type: "opportunity",
    icon: Target,
    title: "Service Gap Identified",
    description: "Mental health services are underrepresented in the South Side region with 43% higher demand than supply.",
    priority: "high",
    color: "text-emerald-600"
  },
  {
    type: "trend",
    icon: TrendingUp,
    title: "Growing Diabetes Prevalence",
    description: "Diabetes rates have increased 15% in target ZIP codes, particularly in areas with limited grocery access.",
    priority: "medium",
    color: "text-blue-600"
  },
  {
    type: "risk",
    icon: AlertTriangle,
    title: "Competitor Expansion",
    description: "Two new urgent care centers opened within 5 miles of your primary location in the last 6 months.",
    priority: "high",
    color: "text-orange-600"
  }
];

const priorityColors = {
  high: "bg-red-50 text-red-700 border-red-200",
  medium: "bg-yellow-50 text-yellow-700 border-yellow-200",
  low: "bg-emerald-50 text-emerald-700 border-emerald-200"
};

export default function AIInsights() {
  return (
    <Card className="border-gray-200 shadow-sm">
      <CardHeader className="pb-4">
        <CardTitle className="text-gray-900 flex items-center gap-2">
          <Sparkles className="w-5 h-5 stroke-1" />
          AI Insights
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {insights.map((insight, index) => (
          <div key={index} className="p-4 bg-gray-50 rounded-xl border border-gray-100">
            <div className="flex items-start gap-3">
              <div className={`p-2 rounded-lg bg-white border border-gray-100 ${insight.color}`}>
                <insight.icon className="w-4 h-4 stroke-1" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <h4 className="font-medium text-gray-900 text-sm">{insight.title}</h4>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium border ${priorityColors[insight.priority]}`}>
                    {insight.priority}
                  </span>
                </div>
                <p className="text-gray-600 text-xs leading-relaxed">
                  {insight.description}
                </p>
              </div>
            </div>
          </div>
        ))}
        
        <Button variant="outline" className="w-full border-gray-300 text-gray-700 hover:bg-gray-50" size="sm">
          <Sparkles className="w-4 h-4 mr-2 stroke-1" />
          Generate New Insights
        </Button>
      </CardContent>
    </Card>
  );
}
