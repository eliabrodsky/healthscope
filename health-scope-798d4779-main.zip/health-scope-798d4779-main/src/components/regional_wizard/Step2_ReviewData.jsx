import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { CheckCircle, AlertCircle, ChevronRight, ChevronLeft, Loader2, RefreshCw, Download } from "lucide-react";
import CdcDataLoader from "../regional_analysis/CdcDataLoader";
import { toast } from "sonner";

export default function Step2_ReviewData({ formData, updateFormData, onNext, onPrev }) {
  const [dataStatus, setDataStatus] = useState({
    population: { loaded: 0, total: 0, status: 'checking', loading: false },
    economics: { loaded: 0, total: 0, status: 'checking', loading: false },
    health: { loaded: 0, total: 0, status: 'checking', loading: false },
    boundaries: { loaded: 0, total: 0, status: 'checking', loading: false },
    organizations: { loaded: 0, total: 0, status: 'checking', loading: false },
    populationCenters: { loaded: 0, total: 0, status: 'checking', loading: false }
  });
  const [showCdcLoader, setShowCdcLoader] = useState(false);
  const [isChecking, setIsChecking] = useState(true);
  const [isCleaningDuplicates, setIsCleaningDuplicates] = useState(false);

  useEffect(() => {
    if (formData.zip_codes && formData.zip_codes.length > 0) {
      checkDataStatus();
    }
  }, [formData.zip_codes?.length]);

  const checkDataStatus = async () => {
    const zipCodes = formData.zip_codes || [];
    
    try {
      const sampleZips = zipCodes.slice(0, Math.min(5, zipCodes.length));
      
      let demographics = [];
      let healthData = [];
      let boundaries = [];
      let organizations = [];
      let cityData = [];
      
      try {
        demographics = await base44.entities.ZipDemographics.filter(
          { zcta5: { $in: sampleZips } },
          null,
          100
        );
      } catch (err) {
        // Silent fail
      }

      try {
        // Check all ZIP codes for boundaries, not just sample
        boundaries = await base44.entities.ZctaBoundary.filter(
          { zcta5: { $in: zipCodes } },
          null,
          500
        );
      } catch (err) {
        // Silent fail
      }

      try {
        healthData = await base44.entities.CdcHealthData.filter(
          { zcta5: { $in: sampleZips }, measure_id: 'OBESITY' },
          null,
          100
        );
      } catch (err) {
        // Silent fail
      }

      try {
        organizations = await base44.entities.Organization.filter(
          { zip_code: { $in: zipCodes } },
          null,
          2000
        );
      } catch (err) {
        // Silent fail
      }

      try {
        cityData = await base44.entities.ZctaPlaceRelationship.filter(
          { zcta5: { $in: zipCodes } },
          null,
          2000
        );
      } catch (err) {
        // Silent fail
      }

      const uniqueDemoZips = new Set(demographics.map(d => d.zcta5)).size;
      const uniqueHealthZips = new Set(healthData.map(h => h.zcta5)).size;
      const uniqueBoundaryZips = new Set(boundaries.filter(b => zipCodes.includes(b.zcta5)).map(b => b.zcta5)).size;
      const uniqueOrgZips = new Set(organizations.map(o => o.zip_code).filter(z => zipCodes.includes(z))).size;
      const uniqueCityZips = new Set(cityData.map(c => c.zcta5).filter(z => zipCodes.includes(z))).size;

      const demoRatio = sampleZips.length > 0 ? uniqueDemoZips / sampleZips.length : 0;
      const populationRatio = demoRatio;
      
      // For boundaries, check against all ZIPs not just sample
      const boundaryRatio = zipCodes.length > 0 ? uniqueBoundaryZips / zipCodes.length : 0;

      const demoWithEconomicData = demographics.filter(d => 
        d.median_income > 0 && d.median_income < 500000 &&
        ((d.poverty_rate !== undefined && d.poverty_rate !== null && d.poverty_rate > 0) ||
         (d.uninsured_rate !== undefined && d.uninsured_rate !== null && d.uninsured_rate > 0))
      );
      const economicRatio = sampleZips.length > 0 ? 
        demoWithEconomicData.filter(d => sampleZips.includes(d.zcta5)).length / sampleZips.length : 0;

      const healthRatio = sampleZips.length > 0 ? uniqueHealthZips / sampleZips.length : 0;

      const estimatedPopulation = Math.min(Math.round(zipCodes.length * populationRatio), zipCodes.length);
      const estimatedEconomics = Math.min(Math.round(zipCodes.length * economicRatio), zipCodes.length);
      const estimatedHealth = Math.min(Math.round(zipCodes.length * healthRatio), zipCodes.length);
      const estimatedBoundaries = uniqueBoundaryZips; // Use actual count, not estimate

      setDataStatus({
        population: {
          loaded: estimatedPopulation,
          total: zipCodes.length,
          status: populationRatio >= 0.9 ? 'complete' : populationRatio > 0.1 ? 'partial' : 'missing',
          loading: false
        },
        economics: {
          loaded: estimatedEconomics,
          total: zipCodes.length,
          status: economicRatio >= 0.9 ? 'complete' : economicRatio > 0.1 ? 'partial' : 'missing',
          loading: false
        },
        health: {
          loaded: estimatedHealth,
          total: zipCodes.length,
          status: healthRatio >= 0.9 ? 'complete' : healthRatio > 0.1 ? 'partial' : 'missing',
          loading: false
        },
        boundaries: {
          loaded: estimatedBoundaries,
          total: zipCodes.length,
          status: boundaryRatio >= 0.9 ? 'complete' : boundaryRatio > 0.1 ? 'partial' : 'missing',
          loading: false
        },
        organizations: {
          loaded: uniqueOrgZips,
          total: zipCodes.length,
          status: organizations.length > 0 ? 'complete' : 'missing',
          loading: false
        },
        populationCenters: {
          loaded: uniqueCityZips,
          total: zipCodes.length,
          status: cityData.length > 0 ? 'complete' : 'missing',
          loading: false
        }
      });
    } catch (error) {
      console.error('Error checking data status:', error);
      setDataStatus({
        demographics: { loaded: 0, total: zipCodes.length, status: 'partial', loading: false },
        health: { loaded: 0, total: zipCodes.length, status: 'partial', loading: false },
        boundaries: { loaded: 0, total: zipCodes.length, status: 'partial', loading: false },
        organizations: { loaded: 0, total: zipCodes.length, status: 'partial', loading: false },
        populationCenters: { loaded: 0, total: zipCodes.length, status: 'partial', loading: false }
      });
    } finally {
      setIsChecking(false);
    }
  };

  const loadPopulationData = async () => {
    setDataStatus(prev => ({ 
      ...prev, 
      population: { ...prev.population, loading: true },
      economics: { ...prev.economics, loading: true }
    }));
    
    try {
      const zipCodes = formData.zip_codes || [];
      let stateAbbr = formData.assessment?.geography?.state;
      
      if (!stateAbbr) {
        toast.error('State information required to load demographics');
        setDataStatus(prev => ({ 
          ...prev, 
          population: { ...prev.population, loading: false },
          economics: { ...prev.economics, loading: false }
        }));
        return;
      }
      
      // Convert full state name to abbreviation if needed
      const stateNameToAbbr = {
        'Alabama': 'AL', 'Alaska': 'AK', 'Arizona': 'AZ', 'Arkansas': 'AR', 'California': 'CA',
        'Colorado': 'CO', 'Connecticut': 'CT', 'Delaware': 'DE', 'Florida': 'FL', 'Georgia': 'GA',
        'Hawaii': 'HI', 'Idaho': 'ID', 'Illinois': 'IL', 'Indiana': 'IN', 'Iowa': 'IA',
        'Kansas': 'KS', 'Kentucky': 'KY', 'Louisiana': 'LA', 'Maine': 'ME', 'Maryland': 'MD',
        'Massachusetts': 'MA', 'Michigan': 'MI', 'Minnesota': 'MN', 'Mississippi': 'MS', 'Missouri': 'MO',
        'Montana': 'MT', 'Nebraska': 'NE', 'Nevada': 'NV', 'New Hampshire': 'NH', 'New Jersey': 'NJ',
        'New Mexico': 'NM', 'New York': 'NY', 'North Carolina': 'NC', 'North Dakota': 'ND', 'Ohio': 'OH',
        'Oklahoma': 'OK', 'Oregon': 'OR', 'Pennsylvania': 'PA', 'Rhode Island': 'RI', 'South Carolina': 'SC',
        'South Dakota': 'SD', 'Tennessee': 'TN', 'Texas': 'TX', 'Utah': 'UT', 'Vermont': 'VT',
        'Virginia': 'VA', 'Washington': 'WA', 'West Virginia': 'WV', 'Wisconsin': 'WI', 'Wyoming': 'WY'
      };
      
      if (stateAbbr.length > 2) {
        stateAbbr = stateNameToAbbr[stateAbbr] || stateAbbr;
      }
      
      // Check existing data first
      const existingData = await base44.entities.ZipDemographics.filter(
        { zcta5: { $in: zipCodes } },
        null,
        10000
      );
      
      const existingZctas = new Set(existingData.map(d => d.zcta5));
      const missingZctas = zipCodes.filter(z => !existingZctas.has(z));
      
      // Identify ZCTAs with Census source but incomplete economic data
      const incompleteZctas = existingData
        .filter(d => {
          const isCensusSource = d.source?.includes('Census');
          const hasNullEconomics = !d.median_income || d.median_income === 0 || 
                                   d.poverty_rate === null || d.poverty_rate === undefined ||
                                   d.uninsured_rate === null || d.uninsured_rate === undefined;
          return isCensusSource && hasNullEconomics;
        })
        .map(d => d.zcta5);
      
      const zctasToFetch = [...missingZctas, ...incompleteZctas];
      
      if (zctasToFetch.length === 0) {
        toast.info('All ZIPs already have complete data');
        await checkDataStatus();
        return;
      }
      
      toast.info(`Fetching Census data for ${zctasToFetch.length} ZIPs...`);
      const response = await base44.functions.invoke('loadZctaDemographics', {
        state_abbr: stateAbbr,
        zctas: zctasToFetch
      });

      if (response?.data?.success && response.data.processed > 0) {
        toast.success(`Updated ${response.data.processed} ZIP codes from Census`);
      } else {
        toast.warning('Some ZIP codes may still be missing data');
      }
      await checkDataStatus();
    } catch (error) {
      toast.error('Failed to load demographics: ' + (error.message || 'Unknown error'));
    } finally {
      setDataStatus(prev => ({ 
        ...prev, 
        population: { ...prev.population, loading: false },
        economics: { ...prev.economics, loading: false }
      }));
    }
  };

  const loadEconomicData = loadPopulationData; // Same function loads both

  const loadBoundaries = async () => {
    setDataStatus(prev => ({ ...prev, boundaries: { ...prev.boundaries, loading: true } }));
    
    try {
      const zipCodes = formData.zip_codes || [];
      
      if (!zipCodes || zipCodes.length === 0) {
        toast.error('No ZIP codes selected');
        setDataStatus(prev => ({ ...prev, boundaries: { ...prev.boundaries, loading: false } }));
        return;
      }
      
      // First, check if boundaries already exist in the database for these ZIPs
      toast.info('Checking database for boundaries...');
      let existingBoundaries = [];
      try {
        existingBoundaries = await base44.entities.ZctaBoundary.filter(
          { zcta5: { $in: zipCodes } },
          null,
          500
        );
      } catch (dbError) {
        console.warn('Database check failed:', dbError);
      }
      
      const foundZips = new Set(existingBoundaries.map(b => b.zcta5));
      const missingZips = zipCodes.filter(z => !foundZips.has(z));
      
      if (missingZips.length === 0) {
        toast.success(`All ${existingBoundaries.length} boundaries found in database!`);
        await checkDataStatus();
        return;
      }
      
      // Fetch missing boundaries from BigQuery API
      toast.info(`Fetching ${missingZips.length} boundaries from BigQuery...`);
      
      // Process in batches of 50 to avoid URL length limits
      const batchSize = 50;
      let totalLoaded = 0;
      
      // Get state abbreviation for storage
      let stateAbbr = formData.assessment?.geography?.state || '';
      const stateNameToAbbr = {
        'Alabama': 'AL', 'Alaska': 'AK', 'Arizona': 'AZ', 'Arkansas': 'AR', 'California': 'CA',
        'Colorado': 'CO', 'Connecticut': 'CT', 'Delaware': 'DE', 'Florida': 'FL', 'Georgia': 'GA',
        'Hawaii': 'HI', 'Idaho': 'ID', 'Illinois': 'IL', 'Indiana': 'IN', 'Iowa': 'IA',
        'Kansas': 'KS', 'Kentucky': 'KY', 'Louisiana': 'LA', 'Maine': 'ME', 'Maryland': 'MD',
        'Massachusetts': 'MA', 'Michigan': 'MI', 'Minnesota': 'MN', 'Mississippi': 'MS', 'Missouri': 'MO',
        'Montana': 'MT', 'Nebraska': 'NE', 'Nevada': 'NV', 'New Hampshire': 'NH', 'New Jersey': 'NJ',
        'New Mexico': 'NM', 'New York': 'NY', 'North Carolina': 'NC', 'North Dakota': 'ND', 'Ohio': 'OH',
        'Oklahoma': 'OK', 'Oregon': 'OR', 'Pennsylvania': 'PA', 'Rhode Island': 'RI', 'South Carolina': 'SC',
        'South Dakota': 'SD', 'Tennessee': 'TN', 'Texas': 'TX', 'Utah': 'UT', 'Vermont': 'VT',
        'Virginia': 'VA', 'Washington': 'WA', 'West Virginia': 'WV', 'Wisconsin': 'WI', 'Wyoming': 'WY'
      };
      if (stateAbbr.length > 2) {
        stateAbbr = stateNameToAbbr[stateAbbr] || stateAbbr;
      }
      
      for (let i = 0; i < missingZips.length; i += batchSize) {
        const batch = missingZips.slice(i, i + batchSize);
        const zipsParam = batch.join(',');
        
        try {
          const response = await fetch(`https://getzctas-1038555279570.us-south1.run.app/?zips=${zipsParam}`);
          
          if (!response.ok) {
            console.error(`BigQuery API error: ${response.status}`);
            continue;
          }
          
          const data = await response.json();
          
          // The API returns an array of objects with WKT geometry
          if (data && Array.isArray(data) && data.length > 0) {
            // Transform WKT to GeoJSON and create boundary records
            const boundaryRecords = data.map(item => {
              // Parse WKT to GeoJSON
              const wkt = item.wkt;
              if (!wkt) return null;
              
              // Convert WKT POLYGON to GeoJSON
              let geometry = null;
              if (wkt.startsWith('POLYGON')) {
                const coordsMatch = wkt.match(/POLYGON \(\((.+)\)\)/);
                if (coordsMatch) {
                  const coordPairs = coordsMatch[1].split(', ').map(pair => {
                    const [lng, lat] = pair.split(' ').map(Number);
                    return [lng, lat];
                  });
                  geometry = {
                    type: 'Polygon',
                    coordinates: [coordPairs]
                  };
                }
              } else if (wkt.startsWith('MULTIPOLYGON')) {
                const multiMatch = wkt.match(/MULTIPOLYGON \(\(\((.+)\)\)\)/);
                if (multiMatch) {
                  const polygons = multiMatch[1].split(')), ((').map(polyStr => {
                    return polyStr.split(', ').map(pair => {
                      const [lng, lat] = pair.replace(/[()]/g, '').split(' ').map(Number);
                      return [lng, lat];
                    });
                  });
                  geometry = {
                    type: 'MultiPolygon',
                    coordinates: polygons.map(p => [p])
                  };
                }
              }
              
              if (!geometry) return null;
              
              return {
                zcta5: item.zip,
                geometry: geometry,
                state_abbr: item.state_abbr || stateAbbr,
                is_po_box: false
              };
            }).filter(r => r && r.zcta5 && r.geometry);
            
            if (boundaryRecords.length > 0) {
              await base44.entities.ZctaBoundary.bulkCreate(boundaryRecords);
              totalLoaded += boundaryRecords.length;
            }
          }
        } catch (fetchError) {
          console.error('Error fetching batch:', fetchError);
        }
        
        // Update progress
        if (i + batchSize < missingZips.length) {
          toast.info(`Loaded ${totalLoaded} of ${missingZips.length} boundaries...`);
        }
      }
      
      if (totalLoaded > 0) {
        toast.success(`Successfully loaded ${totalLoaded} boundaries from BigQuery`);
      } else {
        toast.warning('No boundaries could be loaded from BigQuery');
      }
      
      await checkDataStatus();
    } catch (error) {
      console.error('Error loading boundaries:', error);
      const errorMsg = error.response?.data?.error || error.message || 'Unknown error';
      toast.error('Failed to load boundaries: ' + errorMsg);
    } finally {
      setDataStatus(prev => ({ ...prev, boundaries: { ...prev.boundaries, loading: false } }));
    }
  };

  const loadOrganizations = async () => {
    setDataStatus(prev => ({ ...prev, organizations: { ...prev.organizations, loading: true } }));
    
    try {
      const zipCodes = formData.zip_codes || [];
      const assessment = formData.assessment;
      
      toast.info('Searching for healthcare providers...');
      
      // First, try to find facilities using OpenStreetMap
      let osmFacilities = [];
      if (assessment?.geography?.latitude && assessment?.geography?.longitude) {
        try {
          const osmResponse = await base44.functions.invoke('findHealthcareFacilities', {
            latitude: assessment.geography.latitude,
            longitude: assessment.geography.longitude,
            radiusMiles: assessment.geography.radius_miles || 50,
            facilityTypes: ['hospital', 'clinic']
          });
          
          if (osmResponse?.data?.success && osmResponse.data?.facilities) {
            osmFacilities = osmResponse.data.facilities;
          }
        } catch (osmError) {
          console.warn('OSM search failed:', osmError);
        }
      }
      
      // Next, try to find FQHCs using HRSA data
      let hrsaFacilities = [];
      if (assessment?.geography?.latitude && assessment?.geography?.longitude) {
        try {
          const hrsaResponse = await base44.functions.invoke('getHrsaHealthCenters', {
            method: 'aroundLocation',
            latitude: assessment.geography.latitude,
            longitude: assessment.geography.longitude,
            radiusMiles: assessment.geography.radius_miles || 50
          });
          
          if (hrsaResponse?.data?.success && hrsaResponse.data?.sites) {
            hrsaFacilities = hrsaResponse.data.sites.map(site => ({
              name: site.name,
              type: 'fqhc',
              address: site.address || '',
              city: site.city || '',
              state: site.state || '',
              zip_code: site.zip_code || '',
              coordinates: site.coordinates,
              source: 'HRSA',
              data_source: 'HRSA'
            }));
          }
        } catch (hrsaError) {
          console.warn('HRSA search failed:', hrsaError);
        }
      }
      
      // Combine all facilities
      const allFacilities = [...osmFacilities, ...hrsaFacilities];
      
      if (allFacilities.length === 0) {
        toast.info('No healthcare providers found in the search area');
        await checkDataStatus();
        return;
      }
      
      // Get existing organizations to avoid duplicates
      const existingOrgs = await base44.entities.Organization.filter(
        { zip_code: { $in: zipCodes } },
        null,
        2000
      );
      const existingNames = new Set(existingOrgs.map(o => o.name?.toLowerCase()).filter(Boolean));
      
      // Normalize and filter new facilities
      const newFacilities = allFacilities
        .filter(f => f.name && !existingNames.has(f.name.toLowerCase()))
        .map(f => {
          // Try to determine ZIP code from coordinates if not provided
          let zipCode = f.zip_code || '';
          
          // If no ZIP code and we have coordinates, try to match to nearest ZIP in our list
          if (!zipCode && f.latitude && f.longitude && zipCodes.length > 0) {
            // Simple proximity match - find closest ZIP from our list
            // In a real implementation, you'd use a geocoding service
            zipCode = zipCodes[0]; // Fallback to first ZIP in analysis
          }
          
          return {
            name: f.name,
            type: f.type || 'clinic',
            address: f.address || '',
            city: f.city || assessment?.geography?.city || '',
            state: f.state || assessment?.geography?.state || '',
            zip_code: zipCode,
            coordinates: f.latitude && f.longitude ? {
              latitude: f.latitude,
              longitude: f.longitude
            } : f.coordinates,
            patient_volume: f.patient_volume || 0,
            services: f.services || [],
            source: f.source || 'OpenStreetMap',
            data_source: f.data_source || f.source || 'OpenStreetMap'
          };
        })
        .filter(f => f.zip_code); // Only keep facilities with ZIP codes
      
      // Store new facilities in database
      if (newFacilities.length > 0) {
        await base44.entities.Organization.bulkCreate(newFacilities);
        const uniqueZips = new Set(newFacilities.map(f => f.zip_code).filter(Boolean)).size;
        toast.success(`Found and added ${newFacilities.length} providers across ${uniqueZips} ZIP codes`);
      } else {
        toast.info(`Found ${allFacilities.length} providers (already in database)`);
      }
      
      // Update status after loading
      await checkDataStatus();
    } catch (error) {
      console.error('Error loading organizations:', error);
      toast.error('Failed to load providers: ' + (error.message || 'Unknown error'));
      await checkDataStatus();
    } finally {
      setDataStatus(prev => ({ ...prev, organizations: { ...prev.organizations, loading: false } }));
    }
  };

  const loadPopulationCenters = async () => {
    setDataStatus(prev => ({ ...prev, populationCenters: { ...prev.populationCenters, loading: true } }));
    
    try {
      const zipCodes = formData.zip_codes || [];
      let stateAbbr = formData.assessment?.geography?.state;
      
      if (!stateAbbr) {
        toast.error('State information required to load population centers');
        setDataStatus(prev => ({ ...prev, populationCenters: { ...prev.populationCenters, loading: false } }));
        return;
      }
      
      // Convert full state name to abbreviation if needed
      const stateNameToAbbr = {
        'Alabama': 'AL', 'Alaska': 'AK', 'Arizona': 'AZ', 'Arkansas': 'AR', 'California': 'CA',
        'Colorado': 'CO', 'Connecticut': 'CT', 'Delaware': 'DE', 'Florida': 'FL', 'Georgia': 'GA',
        'Hawaii': 'HI', 'Idaho': 'ID', 'Illinois': 'IL', 'Indiana': 'IN', 'Iowa': 'IA',
        'Kansas': 'KS', 'Kentucky': 'KY', 'Louisiana': 'LA', 'Maine': 'ME', 'Maryland': 'MD',
        'Massachusetts': 'MA', 'Michigan': 'MI', 'Minnesota': 'MN', 'Mississippi': 'MS', 'Missouri': 'MO',
        'Montana': 'MT', 'Nebraska': 'NE', 'Nevada': 'NV', 'New Hampshire': 'NH', 'New Jersey': 'NJ',
        'New Mexico': 'NM', 'New York': 'NY', 'North Carolina': 'NC', 'North Dakota': 'ND', 'Ohio': 'OH',
        'Oklahoma': 'OK', 'Oregon': 'OR', 'Pennsylvania': 'PA', 'Rhode Island': 'RI', 'South Carolina': 'SC',
        'South Dakota': 'SD', 'Tennessee': 'TN', 'Texas': 'TX', 'Utah': 'UT', 'Vermont': 'VT',
        'Virginia': 'VA', 'Washington': 'WA', 'West Virginia': 'WV', 'Wisconsin': 'WI', 'Wyoming': 'WY'
      };
      
      if (stateAbbr.length > 2) {
        stateAbbr = stateNameToAbbr[stateAbbr] || stateAbbr;
      }
      
      toast.info('Loading population centers...');
      
      // Check if data already exists for these ZIPs
      const existingData = await base44.entities.ZctaPlaceRelationship.filter(
        { zcta5: { $in: zipCodes } },
        null,
        2000
      );
      
      if (existingData && existingData.length > 0) {
        const uniqueCities = new Set(existingData.map(c => c.place_geoid)).size;
        toast.success(`Found ${uniqueCities} population centers`);
        await checkDataStatus();
        setDataStatus(prev => ({ ...prev, populationCenters: { ...prev.populationCenters, loading: false } }));
        return;
      }
      
      // No data exists, fetch from Census
      toast.info(`Loading population center data for ${stateAbbr}... This may take 30-60 seconds.`);
      
      const response = await base44.functions.invoke('loadZctaPlaceRelationships', {
        state_abbr: stateAbbr,
        batch_size: 100
      });
      
      if (response?.data?.success) {
        const count = response.data.relationships_loaded || 0;
        if (count > 0) {
          toast.success(`Loaded ${count} place relationships for ${stateAbbr}`);
        } else {
          toast.warning(`Census data processed but found 0 relationships for ${stateAbbr}. This state may not have ZCTA-Place data available.`);
        }
      } else {
        const errorMsg = response?.data?.error || 'Unknown error';
        toast.error(`Failed to load population centers: ${errorMsg}`);
      }
      
      await checkDataStatus();
    } catch (error) {
      console.error('Error loading population centers:', error);
      toast.error('Failed to load population centers: ' + (error.message || 'Unknown error'));
    } finally {
      setDataStatus(prev => ({ ...prev, populationCenters: { ...prev.populationCenters, loading: false } }));
    }
  };

  const cleanupDuplicates = async () => {
    setIsCleaningDuplicates(true);
    try {
      const stateAbbr = formData.assessment?.geography?.state;
      if (!stateAbbr) {
        toast.error('State information required');
        return;
      }
      
      // Convert full state name to abbreviation if needed
      const stateNameToAbbr = {
        'Alabama': 'AL', 'Alaska': 'AK', 'Arizona': 'AZ', 'Arkansas': 'AR', 'California': 'CA',
        'Colorado': 'CO', 'Connecticut': 'CT', 'Delaware': 'DE', 'Florida': 'FL', 'Georgia': 'GA',
        'Hawaii': 'HI', 'Idaho': 'ID', 'Illinois': 'IL', 'Indiana': 'IN', 'Iowa': 'IA',
        'Kansas': 'KS', 'Kentucky': 'KY', 'Louisiana': 'LA', 'Maine': 'ME', 'Maryland': 'MD',
        'Massachusetts': 'MA', 'Michigan': 'MI', 'Minnesota': 'MN', 'Mississippi': 'MS', 'Missouri': 'MO',
        'Montana': 'MT', 'Nebraska': 'NE', 'Nevada': 'NV', 'New Hampshire': 'NH', 'New Jersey': 'NJ',
        'New Mexico': 'NM', 'New York': 'NY', 'North Carolina': 'NC', 'North Dakota': 'ND', 'Ohio': 'OH',
        'Oklahoma': 'OK', 'Oregon': 'OR', 'Pennsylvania': 'PA', 'Rhode Island': 'RI', 'South Carolina': 'SC',
        'South Dakota': 'SD', 'Tennessee': 'TN', 'Texas': 'TX', 'Utah': 'UT', 'Vermont': 'VT',
        'Virginia': 'VA', 'Washington': 'WA', 'West Virginia': 'WV', 'Wisconsin': 'WI', 'Wyoming': 'WY'
      };
      
      let state_abbr_code = stateAbbr;
      if (stateAbbr.length > 2) {
        state_abbr_code = stateNameToAbbr[stateAbbr] || stateAbbr;
      }
      
      toast.info('Cleaning up duplicate ZIP demographics...');
      
      const response = await base44.functions.invoke('cleanupDuplicateZipDemographics', {
        state_abbr: state_abbr_code,
        dry_run: false
      });
      
      if (response?.data?.success) {
        toast.success(`Removed ${response.data.records_deleted} duplicate records`);
        await checkDataStatus();
      } else {
        toast.error('Failed to cleanup duplicates');
      }
    } catch (error) {
      toast.error('Error cleaning duplicates: ' + (error.message || 'Unknown error'));
    } finally {
      setIsCleaningDuplicates(false);
    }
  };

  const getStatusBadge = (status) => {
    const variants = {
      complete: { label: 'Complete', className: 'bg-green-100 text-green-800' },
      partial: { label: 'Partial', className: 'bg-yellow-100 text-yellow-800' },
      missing: { label: 'Not Loaded', className: 'bg-gray-100 text-gray-800' },
      checking: { label: 'Checking...', className: 'bg-blue-100 text-blue-800' }
    };
    const variant = variants[status] || variants.checking;
    return <Badge className={variant.className}>{variant.label}</Badge>;
  };

  const getStatusIcon = (status) => {
    if (status === 'complete') return <CheckCircle className="w-5 h-5 text-green-600" />;
    if (status === 'partial' || status === 'missing') return <AlertCircle className="w-5 h-5 text-yellow-600" />;
    return <Loader2 className="w-5 h-5 text-blue-600 animate-spin" />;
  };

  const canProceed = dataStatus.boundaries.status !== 'missing';

  return (
    <div className="space-y-6 pb-32 sm:pb-24">
      <Card>
        <CardHeader>
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <CardTitle>Review Data Status</CardTitle>
              <CardDescription key={formData.zip_codes?.length}>
                Check what data is available for the selected {formData.zip_codes?.length || 0} ZIP codes
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={checkDataStatus}
                disabled={isChecking}
                className="w-full sm:w-auto"
              >
                <RefreshCw className={`w-4 h-4 mr-2 ${isChecking ? 'animate-spin' : ''}`} />
                Refresh All
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={cleanupDuplicates}
                disabled={isCleaningDuplicates}
                className="w-full sm:w-auto"
              >
                <RefreshCw className={`w-4 h-4 mr-2 ${isCleaningDuplicates ? 'animate-spin' : ''}`} />
                Clean Duplicates
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
              {/* Boundaries */}
              <div className="border rounded-lg p-4">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-3">
                  <div className="flex items-start gap-3">
                    {getStatusIcon(dataStatus.boundaries.status)}
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900">Geographic Boundaries</h4>
                      <p className="text-sm text-gray-600">
                        ZIP code boundary shapes for mapping
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    {getStatusBadge(dataStatus.boundaries.status)}
                    {dataStatus.boundaries.status === 'missing' ? (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={loadBoundaries}
                        disabled={dataStatus.boundaries.loading}
                      >
                        {dataStatus.boundaries.loading ? (
                          <Loader2 className="w-4 h-4 sm:mr-2 animate-spin" />
                        ) : (
                          <Download className="w-4 h-4 sm:mr-2" />
                        )}
                        <span className="hidden sm:inline">{dataStatus.boundaries.loading ? 'Loading...' : 'Load Data'}</span>
                      </Button>
                    ) : (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={loadBoundaries}
                        disabled={dataStatus.boundaries.loading}
                      >
                        {dataStatus.boundaries.loading ? (
                          <Loader2 className="w-4 h-4 sm:mr-2 animate-spin" />
                        ) : (
                          <RefreshCw className="w-4 h-4 sm:mr-2" />
                        )}
                        <span className="hidden sm:inline">{dataStatus.boundaries.loading ? 'Loading...' : 'Refresh'}</span>
                      </Button>
                    )}
                  </div>
                </div>
                <div className="space-y-2">
                  <Progress 
                    value={(dataStatus.boundaries.loaded / dataStatus.boundaries.total) * 100} 
                    className="h-2"
                  />
                  <p className="text-xs text-gray-600">
                    {dataStatus.boundaries.loaded} of {dataStatus.boundaries.total} ZIP codes loaded
                  </p>
                </div>
              </div>

              {/* Population Centers */}
              <div className="border rounded-lg p-4">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-3">
                  <div className="flex items-start gap-3">
                    {getStatusIcon(dataStatus.populationCenters.status)}
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900">Population Centers</h4>
                      <p className="text-sm text-gray-600">
                        Cities and towns within the regional analysis
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    {getStatusBadge(dataStatus.populationCenters.status)}
                    {dataStatus.populationCenters.status === 'missing' ? (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={loadPopulationCenters}
                        disabled={dataStatus.populationCenters.loading}
                      >
                        {dataStatus.populationCenters.loading ? (
                          <Loader2 className="w-4 h-4 sm:mr-2 animate-spin" />
                        ) : (
                          <Download className="w-4 h-4 sm:mr-2" />
                        )}
                        <span className="hidden sm:inline">{dataStatus.populationCenters.loading ? 'Loading...' : 'Load Data'}</span>
                      </Button>
                    ) : (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={loadPopulationCenters}
                        disabled={dataStatus.populationCenters.loading}
                      >
                        {dataStatus.populationCenters.loading ? (
                          <Loader2 className="w-4 h-4 sm:mr-2 animate-spin" />
                        ) : (
                          <RefreshCw className="w-4 h-4 sm:mr-2" />
                        )}
                        <span className="hidden sm:inline">{dataStatus.populationCenters.loading ? 'Loading...' : 'Refresh'}</span>
                      </Button>
                    )}
                  </div>
                </div>
                <div className="space-y-2">
                  <Progress 
                    value={(dataStatus.populationCenters.loaded / dataStatus.populationCenters.total) * 100} 
                    className="h-2"
                  />
                  <p className="text-xs text-gray-600">
                    {dataStatus.populationCenters.loaded} of {dataStatus.populationCenters.total} ZIP codes loaded
                  </p>
                  </div>
                  </div>

                  {/* Population Data */}
                  <div className="border rounded-lg p-4">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-3">
                      <div className="flex items-start gap-3">
                        {getStatusIcon(dataStatus.population.status)}
                        <div className="flex-1">
                          <h4 className="font-semibold text-gray-900">Population Data</h4>
                          <p className="text-sm text-gray-600">
                            Census population by age, sex, and ZIP code
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 flex-shrink-0">
                        {getStatusBadge(dataStatus.population.status)}
                        {dataStatus.population.status === 'missing' ? (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={loadPopulationData}
                            disabled={dataStatus.population.loading}
                          >
                            {dataStatus.population.loading ? (
                              <Loader2 className="w-4 h-4 sm:mr-2 animate-spin" />
                            ) : (
                              <Download className="w-4 h-4 sm:mr-2" />
                            )}
                            <span className="hidden sm:inline">{dataStatus.population.loading ? 'Loading...' : 'Load Data'}</span>
                          </Button>
                        ) : (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={loadPopulationData}
                            disabled={dataStatus.population.loading}
                          >
                            {dataStatus.population.loading ? (
                              <Loader2 className="w-4 h-4 sm:mr-2 animate-spin" />
                            ) : (
                              <RefreshCw className="w-4 h-4 sm:mr-2" />
                            )}
                            <span className="hidden sm:inline">{dataStatus.population.loading ? 'Loading...' : 'Refresh'}</span>
                          </Button>
                        )}
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Progress 
                        value={(dataStatus.population.loaded / dataStatus.population.total) * 100} 
                        className="h-2"
                      />
                      <p className="text-xs text-gray-600">
                        {dataStatus.population.loaded} of {dataStatus.population.total} ZIP codes loaded
                      </p>
                    </div>
                  </div>

                  {/* Economic Indicators */}
                  <div className="border rounded-lg p-4">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-3">
                      <div className="flex items-start gap-3">
                        {getStatusIcon(dataStatus.economics.status)}
                        <div className="flex-1">
                          <h4 className="font-semibold text-gray-900">Economic Indicators</h4>
                          <p className="text-sm text-gray-600">
                            Income, poverty, and insurance coverage rates
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 flex-shrink-0 flex-wrap justify-end">
                        {getStatusBadge(dataStatus.economics.status)}
                        {dataStatus.economics.status === 'missing' ? (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={loadEconomicData}
                            disabled={dataStatus.economics.loading}
                          >
                            {dataStatus.economics.loading ? (
                              <Loader2 className="w-4 h-4 sm:mr-2 animate-spin" />
                            ) : (
                              <Download className="w-4 h-4 sm:mr-2" />
                            )}
                            <span className="hidden sm:inline">{dataStatus.economics.loading ? 'Loading...' : 'Load Data'}</span>
                          </Button>
                        ) : (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={loadEconomicData}
                            disabled={dataStatus.economics.loading}
                          >
                            {dataStatus.economics.loading ? (
                              <Loader2 className="w-4 h-4 sm:mr-2 animate-spin" />
                            ) : (
                              <RefreshCw className="w-4 h-4 sm:mr-2" />
                            )}
                            <span className="hidden sm:inline">{dataStatus.economics.loading ? 'Loading...' : 'Reload All ZIPs'}</span>
                          </Button>
                        )}
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Progress 
                        value={(dataStatus.economics.loaded / dataStatus.economics.total) * 100} 
                        className="h-2"
                      />
                      <p className="text-xs text-gray-600">
                        {dataStatus.economics.loaded} of {dataStatus.economics.total} ZIP codes loaded with income, poverty & insurance data
                      </p>
                    </div>
                    {dataStatus.economics.status === 'partial' && (
                      <div className="mt-3 p-3 bg-yellow-50 border border-yellow-200 rounded text-sm text-yellow-800">
                        Some ZIP codes are missing economic data. Click "Reload All ZIPs" to fetch complete Census data.
                      </div>
                    )}
                  </div>

                  {/* Health Indicators */}
                  <div className="border rounded-lg p-4">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-3">
                  <div className="flex items-start gap-3">
                    {getStatusIcon(dataStatus.health.status)}
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900">Health Indicators</h4>
                      <p className="text-sm text-gray-600">
                        CDC PLACES health needs data
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    {getStatusBadge(dataStatus.health.status)}
                    {dataStatus.health.status === 'missing' ? (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setShowCdcLoader(true)}
                      >
                        <Download className="w-4 h-4 sm:mr-2" />
                        <span className="hidden sm:inline">Load Data</span>
                      </Button>
                    ) : (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setShowCdcLoader(true)}
                      >
                        <RefreshCw className="w-4 h-4 sm:mr-2" />
                        <span className="hidden sm:inline">Refresh</span>
                      </Button>
                    )}
                  </div>
                  </div>
                  <div className="space-y-2">
                  <Progress 
                    value={(dataStatus.health.loaded / dataStatus.health.total) * 100} 
                    className="h-2"
                  />
                  <p className="text-xs text-gray-600">
                    {dataStatus.health.loaded} of {dataStatus.health.total} ZIP codes loaded
                  </p>
                  </div>
                  </div>

                  {/* Healthcare Providers */}
                  <div className="border rounded-lg p-4">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-3">
                  <div className="flex items-start gap-3">
                    {getStatusIcon(dataStatus.organizations.status)}
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900">Healthcare Providers</h4>
                      <p className="text-sm text-gray-600">
                        FQHCs, hospitals, and clinics in the region
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    {getStatusBadge(dataStatus.organizations.status)}
                    {dataStatus.organizations.status === 'missing' ? (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={loadOrganizations}
                        disabled={dataStatus.organizations.loading}
                      >
                        {dataStatus.organizations.loading ? (
                          <Loader2 className="w-4 h-4 sm:mr-2 animate-spin" />
                        ) : (
                          <Download className="w-4 h-4 sm:mr-2" />
                        )}
                        <span className="hidden sm:inline">{dataStatus.organizations.loading ? 'Loading...' : 'Load Data'}</span>
                      </Button>
                    ) : (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={loadOrganizations}
                        disabled={dataStatus.organizations.loading}
                      >
                        {dataStatus.organizations.loading ? (
                          <Loader2 className="w-4 h-4 sm:mr-2 animate-spin" />
                        ) : (
                          <RefreshCw className="w-4 h-4 sm:mr-2" />
                        )}
                        <span className="hidden sm:inline">{dataStatus.organizations.loading ? 'Loading...' : 'Refresh'}</span>
                      </Button>
                    )}
                  </div>
                  </div>
                  <div className="space-y-2">
                  <Progress 
                    value={(dataStatus.organizations.loaded / dataStatus.organizations.total) * 100} 
                    className="h-2"
                  />
                  <p className="text-xs text-gray-600">
                    {dataStatus.organizations.loaded} of {dataStatus.organizations.total} ZIP codes have providers
                  </p>
                  </div>
                  </div>

                  {!canProceed && (
                    <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                      <div className="flex gap-3">
                        <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                        <div>
                          <h4 className="font-semibold text-yellow-900 mb-1">Missing Required Data</h4>
                          <p className="text-sm text-yellow-800">
                            Boundaries are required to proceed. Please load this data first.
                          </p>
                        </div>
                      </div>
                    </div>
                    )}
                </CardContent>
      </Card>

      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t border-gray-200 sm:relative sm:border-0 sm:p-0 sm:bg-transparent z-10">
        <div className="grid grid-cols-2 gap-3 max-w-5xl mx-auto">
          <Button variant="outline" onClick={onPrev} className="w-full h-12 sm:h-10">
            <ChevronLeft className="w-4 h-4 mr-2" />
            Previous
          </Button>
          <Button
            onClick={onNext}
            disabled={!canProceed}
            className="bg-emerald-600 hover:bg-emerald-700 w-full h-12 sm:h-10"
          >
            <span className="hidden sm:inline">Next: View Summary</span>
            <span className="sm:hidden">Next</span>
            <ChevronRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>

      {showCdcLoader && formData.assessment && (
        <CdcDataLoader
          assessment={{
            ...formData.assessment,
            processed_data: {
              ...formData.assessment.processed_data,
              zcta_codes: formData.zip_codes
            },
            geography: {
              ...formData.assessment.geography,
              zcta_codes: formData.zip_codes
            }
          }}
          open={showCdcLoader}
          onClose={() => setShowCdcLoader(false)}
          onDataLoaded={() => {
            setShowCdcLoader(false);
            checkDataStatus();
          }}
        />
      )}
    </div>
  );
}