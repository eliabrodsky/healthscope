import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { MapPin, Building2, ChevronRight } from "lucide-react";

export default function Step1_SelectAssessment({ formData, updateFormData, onNext }) {
  const [assessments, setAssessments] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedZips, setSelectedZips] = useState([]);

  useEffect(() => {
    loadAssessments();
  }, []);

  useEffect(() => {
    if (formData.assessment_id) {
      loadAssessmentZips();
    }
  }, [formData.assessment_id]);

  const loadAssessments = async () => {
    try {
      // Only load user's own assessments (RLS will enforce this)
      const data = await base44.entities.Assessment.list('-created_date', 100);
      // Filter to exclude public assessments from other users
      const user = await base44.auth.me();
      const userAssessments = (data || []).filter(a => 
        a.created_by === user.email || user.role === 'admin'
      );
      setAssessments(userAssessments);
    } catch (error) {
      console.error('Error loading assessments:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadAssessmentZips = async () => {
    const selected = assessments.find(a => a.id === formData.assessment_id);
    if (selected) {
      // Use the exact same ZIP list as the assessment dashboard
      const zipCodes = selected.processed_data?.zip_codes || 
                      selected.geography?.zip_codes || [];
      setSelectedZips(zipCodes);
      updateFormData({ zip_codes: zipCodes });
    }
  };

  const handleAssessmentChange = (assessmentId) => {
    const selected = assessments.find(a => a.id === assessmentId);
    updateFormData({ 
      assessment_id: assessmentId,
      assessment: selected
    });
  };

  const toggleZip = (zip) => {
    const newZips = selectedZips.includes(zip)
      ? selectedZips.filter(z => z !== zip)
      : [...selectedZips, zip];
    setSelectedZips(newZips);
    updateFormData({ zip_codes: newZips });
  };

  const selectedAssessment = assessments.find(a => a.id === formData.assessment_id);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Select Assessment</CardTitle>
          <CardDescription>
            Choose an assessment to analyze and verify which ZIP codes to include
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {isLoading ? (
            <div className="text-center py-8 text-gray-500">Loading assessments...</div>
          ) : (
            <>
              <div>
                <label className="text-sm font-medium mb-2 block">Assessment</label>
                <Select value={formData.assessment_id} onValueChange={handleAssessmentChange}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select an assessment" />
                  </SelectTrigger>
                  <SelectContent>
                    {assessments.map(assessment => (
                      <SelectItem key={assessment.id} value={assessment.id}>
                        {assessment.title} - {assessment.geography?.city}, {assessment.geography?.state}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {selectedAssessment && (
                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="flex items-start gap-3 mb-4">
                    <MapPin className="w-5 h-5 text-blue-600 mt-0.5" />
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900">{selectedAssessment.title}</h4>
                      <p className="text-sm text-gray-600 mt-1">
                        {selectedAssessment.geography?.city}, {selectedAssessment.geography?.state}
                      </p>
                      {selectedAssessment.description && (
                        <p className="text-sm text-gray-600 mt-2">{selectedAssessment.description}</p>
                      )}
                    </div>
                  </div>

                  <div className="border-t pt-4">
                    <div className="flex items-center justify-between mb-3">
                      <h5 className="font-medium text-gray-900">ZIP Codes ({selectedZips.length})</h5>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            const allZips = selectedAssessment.processed_data?.zip_codes || 
                                          selectedAssessment.geography?.zip_codes || [];
                            setSelectedZips(allZips);
                            updateFormData({ zip_codes: allZips });
                          }}
                        >
                          Select All
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            setSelectedZips([]);
                            updateFormData({ zip_codes: [] });
                          }}
                        >
                          Clear All
                        </Button>
                      </div>
                    </div>

                    <div className="max-h-64 overflow-y-auto">
                      <div className="grid grid-cols-4 gap-2">
                        {(selectedAssessment.processed_data?.zip_codes || 
                          selectedAssessment.geography?.zip_codes || []).map(zip => (
                          <div
                            key={zip}
                            className="flex items-center gap-2 p-2 rounded hover:bg-gray-100 cursor-pointer"
                            onClick={() => toggleZip(zip)}
                          >
                            <Checkbox
                              checked={selectedZips.includes(zip)}
                              onCheckedChange={() => toggleZip(zip)}
                            />
                            <span className="text-sm">{zip}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button
          onClick={onNext}
          disabled={!formData.assessment_id || selectedZips.length === 0}
          className="bg-emerald-600 hover:bg-emerald-700"
        >
          Next: Review Data
          <ChevronRight className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </div>
  );
}