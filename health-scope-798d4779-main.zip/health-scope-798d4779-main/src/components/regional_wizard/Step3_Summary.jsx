import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ChevronLeft, Map as MapIcon, Table as TableIcon, BarChart3, Save, Globe, Sparkles, Edit, Plus, X, CheckCircle2, AlertCircle, RefreshCw } from "lucide-react";
import InteractiveMap from "../maps/InteractiveMap";
import CityBubbleMap from "../maps/CityBubbleMap";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, LabelList, ReferenceLine } from "recharts";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import ReactMarkdown from "react-markdown";
import LottieLoader from "../ui/LottieLoader";
import { Download } from "lucide-react";

export default function Step3_Summary({ formData, updateFormData, onPrev, onSave, onPublish }) {
  const [viewMode, setViewMode] = useState('summary');
  const [demographics, setDemographics] = useState([]);
  const [healthData, setHealthData] = useState([]);
  const [boundaries, setBoundaries] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedHealthMetrics, setSelectedHealthMetrics] = useState([]);
  const [healthMapMetric, setHealthMapMetric] = useState('');
  const [mapSettings, setMapSettings] = useState({
    showZipLabels: false,
    showDataOverlay: true,
    colorScale: 'viridis'
  });
  const [insights, setInsights] = useState('');
  const [isGeneratingInsights, setIsGeneratingInsights] = useState(false);
  const [showZipEditor, setShowZipEditor] = useState(false);
  const [newZipCode, setNewZipCode] = useState('');
  const [published, setPublished] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [organizations, setOrganizations] = useState([]);
  const [cityData, setCityData] = useState([]);

  useEffect(() => {
    loadAllData();
  }, [formData.zip_codes]);

  useEffect(() => {
    setHasUnsavedChanges(true);
  }, [formData]);

  const loadAllData = async () => {
    setIsLoading(true);
    const zipCodes = formData.zip_codes || [];

    if (zipCodes.length > 100) {
      toast.warning(`Loading data for ${zipCodes.length} ZIP codes may take a while...`);
    }

    try {
      // Phase 1: Fetch existing data from database
      let currentDemoData = [];
      if (zipCodes.length > 0) {
        currentDemoData = await base44.entities.ZipDemographics.filter({ zcta5: { $in: zipCodes } }, null, 10000);
      }
      const existingDemoData = currentDemoData.filter(d => zipCodes.includes(d.zcta5));
      setDemographics(existingDemoData);

      // Phase 2: Identify ZCTAs with missing Census data
      const existingZctas = new Set(existingDemoData.map(d => d.zcta5));
      const missingZctas = zipCodes.filter(z => !existingZctas.has(z));
      
      // Identify ZCTAs with Census source but null economic data
      const incompleteZctas = existingDemoData
        .filter(d => {
          const isCensusSource = d.source?.includes('Census');
          const hasNullEconomics = !d.median_income || d.median_income === 0 || 
                                   d.poverty_rate === null || d.poverty_rate === undefined ||
                                   d.uninsured_rate === null || d.uninsured_rate === undefined;
          return isCensusSource && hasNullEconomics;
        })
        .map(d => d.zcta5);
      
      const zctasToFetch = [...missingZctas, ...incompleteZctas];
      
      // Phase 3: Targeted Census fetch for missing/incomplete data only
      if (zctasToFetch.length > 0) {
        const stateAbbr = formData.assessment?.geography?.state;
        if (stateAbbr) {
          toast.info(`Fetching Census data for ${zctasToFetch.length} ZIPs with missing data...`);
          try {
            const response = await base44.functions.invoke('loadZctaDemographics', {
              state_abbr: stateAbbr,
              zctas: zctasToFetch,
              batchSize: 5
            });
            
            if (response?.data?.success) {
              toast.success(`Updated ${response.data.processed} ZIPs from Census`);
              // Refetch data to get updated records
              await new Promise(resolve => setTimeout(resolve, 1500));
              const updatedData = await base44.entities.ZipDemographics.filter({ zcta5: { $in: zipCodes } }, null, 10000);
              setDemographics(updatedData.filter(d => zipCodes.includes(d.zcta5)));
            }
          } catch (err) {
            toast.error('Failed to fetch missing Census data');
          }
        }
      }

      let bounds = [];
      try {
        if (zipCodes.length > 30) {
          for (let i = 0; i < zipCodes.length; i += 30) {
            const batch = zipCodes.slice(i, i + 30);
            const batchBounds = await base44.entities.ZctaBoundary.filter({ zcta5: { $in: batch } });
            bounds = [...bounds, ...batchBounds.filter(b => batch.includes(b.zcta5))];
          }
        } else {
          const allBounds = await base44.entities.ZctaBoundary.filter({ zcta5: { $in: zipCodes } });
          bounds = allBounds.filter(b => zipCodes.includes(b.zcta5));
        }
        setBoundaries(bounds);
      } catch (err) {
        // Silent fail
      }

      let health = [];
      try {
        const limit = zipCodes.length > 50 ? 2000 : 1000;
        if (zipCodes.length > 40) {
          for (let i = 0; i < zipCodes.length; i += 20) {
            const batch = zipCodes.slice(i, i + 20);
            const batchHealth = await base44.entities.CdcHealthData.filter(
              { zcta5: { $in: batch } },
              null,
              500
            );
            health = [...health, ...batchHealth.filter(h => batch.includes(h.zcta5))];
          }
        } else {
          const allHealth = await base44.entities.CdcHealthData.filter(
            { zcta5: { $in: zipCodes } },
            null,
            limit
          );
          health = allHealth.filter(h => zipCodes.includes(h.zcta5));
        }
        setHealthData(health);
      } catch (err) {
        // Silent fail
      }

      let orgs = [];
      try {
        const allOrgs = await base44.entities.Organization.filter(
          { zip_code: { $in: zipCodes } },
          null,
          2000
        );
        orgs = allOrgs.filter(o => zipCodes.includes(o.zip_code));
        setOrganizations(orgs);
      } catch (err) {
        // Silent fail
      }

      try {
        const allCities = await base44.entities.ZctaPlaceRelationship.filter(
          { zcta5: { $in: zipCodes } },
          null,
          2000
        );
        const cities = (allCities || []).filter(c => zipCodes.includes(c.zcta5));
        setCityData(cities);
      } catch (err) {
        setCityData([]);
      }

      const filteredDemoData = currentDemoData.filter(d => zipCodes.includes(d.zcta5));
      updateFormData({ 
      demographics: filteredDemoData, 
      health_data: health, 
      boundaries: bounds,
      demographics_summary: {
        total_population: filteredDemoData.reduce((sum, d) => sum + (d.population || 0), 0),
        avg_income: filteredDemoData.length > 0 
          ? Math.round(filteredDemoData.filter(d => d.median_income > 0 && d.median_income < 500000).reduce((sum, d) => sum + d.median_income, 0) / filteredDemoData.filter(d => d.median_income > 0 && d.median_income < 500000).length)
          : 0,
        avg_poverty: filteredDemoData.length > 0
          ? (filteredDemoData.reduce((sum, d) => sum + (d.poverty_rate || 0), 0) / filteredDemoData.length)
          : 0,
        avg_uninsured: filteredDemoData.length > 0
          ? (filteredDemoData.reduce((sum, d) => sum + (d.uninsured_rate || 0), 0) / filteredDemoData.length)
          : 0
      }
    });
      toast.success('Data loaded successfully');
    } catch (error) {
      console.error('Error loading data:', error);
      toast.error('Failed to load data: ' + (error.message || 'Unknown error'));
    } finally {
      setIsLoading(false);
    }
  };

  // Only include demographics for selected ZIP codes and deduplicate by zcta5
  // Prefer Census-sourced data over CSV uploads
  const demographicsMap = new Map();
  demographics.forEach(demo => {
    if (formData.zip_codes.includes(demo.zcta5)) {
      const existing = demographicsMap.get(demo.zcta5);
      if (!existing || (demo.source?.includes('Census') && !existing.source?.includes('Census'))) {
        demographicsMap.set(demo.zcta5, demo);
      }
    }
  });
  const selectedDemographics = Array.from(demographicsMap.values());

  // Filter out invalid data and outliers for accurate calculations
  const validDemographics = selectedDemographics.filter(d => 
    d.median_income > 0 && d.median_income < 500000
  );

  const regionalStats = {
    total_population: selectedDemographics.reduce((sum, d) => sum + (d.population || 0), 0),
    avg_income: validDemographics.length > 0 
      ? Math.round(validDemographics.reduce((sum, d) => sum + d.median_income, 0) / validDemographics.length)
      : 0,
    avg_poverty: selectedDemographics.length > 0
      ? parseFloat((selectedDemographics.reduce((sum, d) => sum + (d.poverty_rate || 0), 0) / selectedDemographics.length).toFixed(1))
      : 0,
    avg_uninsured: selectedDemographics.length > 0
      ? parseFloat((selectedDemographics.reduce((sum, d) => sum + (d.uninsured_rate || 0), 0) / selectedDemographics.length).toFixed(1))
      : 0
  };

  const totalPop = regionalStats.total_population || 0;
  
  const ageDistribution = [
    { 
      age: '0-17', 
      male: Math.round(totalPop * 0.22 * 0.49), 
      female: Math.round(totalPop * 0.22 * 0.51),
      malePct: 10.8,
      femalePct: 11.2
    },
    { 
      age: '18-44', 
      male: Math.round(totalPop * 0.35 * 0.49), 
      female: Math.round(totalPop * 0.35 * 0.51),
      malePct: 17.2,
      femalePct: 17.8
    },
    { 
      age: '45-64', 
      male: Math.round(totalPop * 0.25 * 0.49), 
      female: Math.round(totalPop * 0.25 * 0.51),
      malePct: 12.3,
      femalePct: 12.8
    },
    { 
      age: '65+', 
      male: Math.round(totalPop * 0.18 * 0.49), 
      female: Math.round(totalPop * 0.18 * 0.51),
      malePct: 8.8,
      femalePct: 9.2
    }
  ];

  const insuranceDistribution = [
    { type: 'Private', value: Math.round(totalPop * 0.45), color: '#3b82f6' },
    { type: 'Medicare', value: Math.round(totalPop * 0.18), color: '#10b981' },
    { type: 'Medicaid', value: Math.round(totalPop * 0.20), color: '#f59e0b' },
    { type: 'Uninsured', value: Math.round(totalPop * parseFloat(regionalStats.avg_uninsured || 0) / 100), color: '#ef4444' }
  ];

  // Per-ZIP demographics data for charts
  const ageByZipData = selectedDemographics.map(demo => ({
    zip: demo.zcta5,
    '0-17': Math.round((demo.population || 0) * 0.22),
    '18-44': Math.round((demo.population || 0) * 0.35),
    '45-64': Math.round((demo.population || 0) * 0.25),
    '65+': Math.round((demo.population || 0) * 0.18)
  }));

  const insuranceByZipData = selectedDemographics.map(demo => ({
    zip: demo.zcta5,
    Private: Math.round((demo.population || 0) * 0.45),
    Medicare: Math.round((demo.population || 0) * 0.18),
    Medicaid: Math.round((demo.population || 0) * 0.20),
    Uninsured: Math.round((demo.population || 0) * (demo.uninsured_rate || 0) / 100)
  }));

  // Group health data by ZIP code and measure
  const healthByZip = {};
  healthData.forEach(item => {
    if (!healthByZip[item.zcta5]) {
      healthByZip[item.zcta5] = {};
    }
    healthByZip[item.zcta5][item.measure_id] = {
      value: item.data_value,
      name: item.measure
    };
  });

  // Get all available indicators
  const availableIndicators = [...new Set(healthData.map(h => h.measure_id))].map(id => {
    const sample = healthData.find(h => h.measure_id === id);
    return { id, name: sample.measure };
  });

  // Calculate averages for each indicator
  const healthAverages = {};
  availableIndicators.forEach(indicator => {
    const values = healthData
      .filter(h => h.measure_id === indicator.id)
      .map(h => h.data_value);
    healthAverages[indicator.id] = values.length > 0
      ? values.reduce((a, b) => a + b, 0) / values.length
      : 0;
  });

  // Prepare chart data for selected metrics
  const healthChartData = formData.zip_codes.map(zip => {
    const dataPoint = { zipCode: zip };
    selectedHealthMetrics.forEach(metricId => {
      const zipData = healthByZip[zip]?.[metricId];
      dataPoint[metricId] = zipData?.value || 0;
      dataPoint[`${metricId}_avg`] = healthAverages[metricId] || 0;
    });
    return dataPoint;
  });

  const renderDemographicsContent = () => {
    if (viewMode === 'map') {
      return (
        <InteractiveMap
          key={`demographics-map-${demographics.length}`}
          zipBoundaries={boundaries}
          organizations={[]}
          selectedZips={formData.zip_codes}
          colorMetric="population"
          showCompetitors={false}
          censusData={demographicCensusData}
          assessment={formData.assessment}
          mapSettings={mapSettings}
          onMapSettingsChange={setMapSettings}
        />
      );
    }

    if (viewMode === 'table') {
      return (
        <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-4 py-3 text-left font-semibold">ZIP Code</th>
                  <th className="px-4 py-3 text-right font-semibold">Population</th>
                  <th className="px-4 py-3 text-right font-semibold">Median Income</th>
                  <th className="px-4 py-3 text-right font-semibold">Poverty Rate</th>
                  <th className="px-4 py-3 text-right font-semibold">Uninsured Rate</th>
                  <th className="px-4 py-3 text-center font-semibold">Actions</th>
                </tr>
              </thead>
            <tbody>
              {selectedDemographics.map(demo => {
                const income = demo.median_income || 0;
                const isValidIncome = income > 0 && income < 500000;
                return (
                  <tr key={demo.zcta5} className="border-b hover:bg-gray-50">
                    <td className="px-4 py-3 font-medium">{demo.zcta5}</td>
                    <td className="px-4 py-3 text-right">{(demo.population || 0).toLocaleString()}</td>
                    <td className="px-4 py-3 text-right">
                      {isValidIncome ? `$${income.toLocaleString()}` : 'N/A'}
                    </td>
                    <td className="px-4 py-3 text-right">{(demo.poverty_rate || 0).toFixed(1)}%</td>
                    <td className="px-4 py-3 text-right">{(demo.uninsured_rate || 0).toFixed(1)}%</td>
                    <td className="px-4 py-3 text-center">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={async () => {
                          toast.info(`Fetching Census data for ZIP ${demo.zcta5}...`);
                          try {
                            const stateAbbr = formData.assessment?.geography?.state;
                            const response = await base44.functions.invoke('loadZctaDemographics', {
                              state_abbr: stateAbbr,
                              zctas: [demo.zcta5]
                            });
                            
                            if (response?.data?.success && response.data.processed > 0) {
                              await loadAllData();
                              toast.success(`Reloaded ZIP ${demo.zcta5}`);
                            } else {
                              toast.warning(`No Census data available for ZIP ${demo.zcta5}`);
                            }
                          } catch (err) {
                            console.error('Reload error:', err);
                            toast.error(`Failed to reload ZIP ${demo.zcta5}: ${err.message || 'Unknown error'}`);
                          }
                        }}
                        className="h-7 px-2 text-xs"
                      >
                        Reload
                      </Button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      );
    }

    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Regional Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div>
                <div className="text-sm text-gray-600">Total Population</div>
                <div className="text-2xl font-bold">{(regionalStats.total_population || 0).toLocaleString()}</div>
              </div>
              <div>
                <div className="text-sm text-gray-600">Median Income</div>
                <div className="text-2xl font-bold">${(regionalStats.avg_income || 0).toLocaleString()}</div>
              </div>
              <div>
                <div className="text-sm text-gray-600">Avg Poverty Rate</div>
                <div className="text-2xl font-bold">{(regionalStats.avg_poverty || 0)}%</div>
              </div>
              <div>
                <div className="text-sm text-gray-600">Avg Uninsured</div>
                <div className="text-2xl font-bold">{(regionalStats.avg_uninsured || 0)}%</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Age & Sex Distribution (Regional)</CardTitle>
            </CardHeader>
            <CardContent className="overflow-x-auto">
              <ResponsiveContainer width="100%" height={320} minWidth={300}>
                <BarChart data={ageDistribution} barGap={8} margin={{ top: 30, right: 20, bottom: 20, left: 20 }}>
                  <defs>
                    <linearGradient id="maleGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#6366f1" stopOpacity={0.9} />
                      <stop offset="100%" stopColor="#6366f1" stopOpacity={0.5} />
                    </linearGradient>
                    <linearGradient id="femaleGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#ec4899" stopOpacity={0.9} />
                      <stop offset="100%" stopColor="#ec4899" stopOpacity={0.5} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="age" tick={{ fontSize: 8 }} />
                  <YAxis tick={{ fontSize: 8 }} tickFormatter={(value) => value.toLocaleString()} />
                  <Tooltip formatter={(value) => value.toLocaleString()} />
                  <Legend wrapperStyle={{ fontSize: 12 }} iconSize={10} />
                  <Bar dataKey="male" fill="url(#maleGradient)" name="Male">
                    <LabelList 
                      position="top" 
                      style={{ fontSize: 8 }} 
                      content={({ value, x, y, width, index }) => {
                        const entry = ageDistribution[index];
                        if (!entry) return null;
                        return (
                          <text 
                            x={x + width / 2} 
                            y={y - 8} 
                            fill="#666" 
                            textAnchor="middle" 
                            fontSize={8}
                          >
                            {value.toLocaleString()} ({entry.malePct}%)
                          </text>
                        );
                      }}
                    />
                  </Bar>
                  <Bar dataKey="female" fill="url(#femaleGradient)" name="Female">
                    <LabelList 
                      position="top" 
                      style={{ fontSize: 8 }} 
                      content={({ value, x, y, width, index }) => {
                        const entry = ageDistribution[index];
                        if (!entry) return null;
                        return (
                          <text 
                            x={x + width / 2} 
                            y={y - 8} 
                            fill="#666" 
                            textAnchor="middle" 
                            fontSize={8}
                          >
                            {value.toLocaleString()} ({entry.femalePct}%)
                          </text>
                        );
                      }}
                    />
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Insurance Coverage (Regional)</CardTitle>
            </CardHeader>
            <CardContent className="overflow-x-auto">
              <ResponsiveContainer width="100%" height={320} minWidth={300}>
                <BarChart data={insuranceDistribution} margin={{ top: 30, right: 20, bottom: 20, left: 20 }}>
                  <defs>
                    <linearGradient id="privateGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#3b82f6" stopOpacity={0.9} />
                      <stop offset="100%" stopColor="#3b82f6" stopOpacity={0.5} />
                    </linearGradient>
                    <linearGradient id="medicareGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#10b981" stopOpacity={0.9} />
                      <stop offset="100%" stopColor="#10b981" stopOpacity={0.5} />
                    </linearGradient>
                    <linearGradient id="medicaidGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#f59e0b" stopOpacity={0.9} />
                      <stop offset="100%" stopColor="#f59e0b" stopOpacity={0.5} />
                    </linearGradient>
                    <linearGradient id="uninsuredGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#ef4444" stopOpacity={0.9} />
                      <stop offset="100%" stopColor="#ef4444" stopOpacity={0.5} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="type" tick={{ fontSize: 8 }} />
                  <YAxis tick={{ fontSize: 8 }} tickFormatter={(value) => value.toLocaleString()} />
                  <Tooltip formatter={(value) => value.toLocaleString()} />
                  <Bar dataKey="value">
                    <LabelList 
                      position="top" 
                      style={{ fontSize: 8 }} 
                      content={({ value, x, y, width }) => {
                        const pct = ((value / totalPop) * 100).toFixed(1);
                        return (
                          <text 
                            x={x + width / 2} 
                            y={y - 8} 
                            fill="#666" 
                            textAnchor="middle" 
                            fontSize={8}
                          >
                            {value.toLocaleString()} ({pct}%)
                          </text>
                        );
                      }}
                    />
                    {insuranceDistribution.map((entry, index) => {
                      const gradients = ['url(#privateGradient)', 'url(#medicareGradient)', 'url(#medicaidGradient)', 'url(#uninsuredGradient)'];
                      return <Cell key={`cell-${index}`} fill={gradients[index]} />;
                    })}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Age Distribution by ZIP Code</CardTitle>
            </CardHeader>
            <CardContent className="overflow-x-auto">
              <ResponsiveContainer width="100%" height={Math.max(300, ageByZipData.length * 35)} minWidth={300}>
                <BarChart data={ageByZipData} layout="vertical" margin={{ left: 50, right: 10, top: 10, bottom: 10 }}>
                  <defs>
                    <linearGradient id="age0Gradient" x1="0" y1="0" x2="1" y2="0">
                      <stop offset="0%" stopColor="#6366f1" stopOpacity={0.9} />
                      <stop offset="100%" stopColor="#6366f1" stopOpacity={0.5} />
                    </linearGradient>
                    <linearGradient id="age1Gradient" x1="0" y1="0" x2="1" y2="0">
                      <stop offset="0%" stopColor="#10b981" stopOpacity={0.9} />
                      <stop offset="100%" stopColor="#10b981" stopOpacity={0.5} />
                    </linearGradient>
                    <linearGradient id="age2Gradient" x1="0" y1="0" x2="1" y2="0">
                      <stop offset="0%" stopColor="#f59e0b" stopOpacity={0.9} />
                      <stop offset="100%" stopColor="#f59e0b" stopOpacity={0.5} />
                    </linearGradient>
                    <linearGradient id="age3Gradient" x1="0" y1="0" x2="1" y2="0">
                      <stop offset="0%" stopColor="#ef4444" stopOpacity={0.9} />
                      <stop offset="100%" stopColor="#ef4444" stopOpacity={0.5} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" tick={{ fontSize: 8 }} />
                  <YAxis dataKey="zip" type="category" width={50} tick={{ fontSize: 8 }} />
                  <Tooltip />
                  <Legend wrapperStyle={{ fontSize: 10 }} />
                  <Bar dataKey="0-17" stackId="a" fill="url(#age0Gradient)" />
                  <Bar dataKey="18-44" stackId="a" fill="url(#age1Gradient)" />
                  <Bar dataKey="45-64" stackId="a" fill="url(#age2Gradient)" />
                  <Bar dataKey="65+" stackId="a" fill="url(#age3Gradient)" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Insurance Coverage by ZIP Code</CardTitle>
            </CardHeader>
            <CardContent className="overflow-x-auto">
              <ResponsiveContainer width="100%" height={Math.max(300, insuranceByZipData.length * 35)} minWidth={300}>
                <BarChart data={insuranceByZipData} layout="vertical" margin={{ left: 50, right: 10, top: 10, bottom: 10 }}>
                  <defs>
                    <linearGradient id="ins0Gradient" x1="0" y1="0" x2="1" y2="0">
                      <stop offset="0%" stopColor="#3b82f6" stopOpacity={0.9} />
                      <stop offset="100%" stopColor="#3b82f6" stopOpacity={0.5} />
                    </linearGradient>
                    <linearGradient id="ins1Gradient" x1="0" y1="0" x2="1" y2="0">
                      <stop offset="0%" stopColor="#10b981" stopOpacity={0.9} />
                      <stop offset="100%" stopColor="#10b981" stopOpacity={0.5} />
                    </linearGradient>
                    <linearGradient id="ins2Gradient" x1="0" y1="0" x2="1" y2="0">
                      <stop offset="0%" stopColor="#f59e0b" stopOpacity={0.9} />
                      <stop offset="100%" stopColor="#f59e0b" stopOpacity={0.5} />
                    </linearGradient>
                    <linearGradient id="ins3Gradient" x1="0" y1="0" x2="1" y2="0">
                      <stop offset="0%" stopColor="#ef4444" stopOpacity={0.9} />
                      <stop offset="100%" stopColor="#ef4444" stopOpacity={0.5} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" tick={{ fontSize: 8 }} />
                  <YAxis dataKey="zip" type="category" width={50} tick={{ fontSize: 8 }} />
                  <Tooltip />
                  <Legend wrapperStyle={{ fontSize: 10 }} />
                  <Bar dataKey="Private" stackId="a" fill="url(#ins0Gradient)" />
                  <Bar dataKey="Medicare" stackId="a" fill="url(#ins1Gradient)" />
                  <Bar dataKey="Medicaid" stackId="a" fill="url(#ins2Gradient)" />
                  <Bar dataKey="Uninsured" stackId="a" fill="url(#ins3Gradient)" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  };

  const toggleHealthMetric = (metricId) => {
    setSelectedHealthMetrics(prev => {
      if (prev.includes(metricId)) {
        return prev.filter(m => m !== metricId);
      } else if (prev.length < 5) {
        return [...prev, metricId];
      }
      return prev;
    });
  };

  const generateInsights = async () => {
    setIsGeneratingInsights(true);
    try {
      const summaryData = {
        zip_codes: formData.zip_codes,
        total_population: regionalStats.total_population,
        avg_income: regionalStats.avg_income,
        avg_poverty: regionalStats.avg_poverty,
        avg_uninsured: regionalStats.avg_uninsured,
        health_indicators: selectedHealthMetrics.map(id => 
          availableIndicators.find(i => i.id === id)?.name
        )
      };

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze this regional health data and provide 3-5 key insights about health needs, disparities, and opportunities:
        
Region: ${formData.assessment?.title}
ZIP Codes: ${formData.zip_codes.length}
Population: ${summaryData.total_population.toLocaleString()}
Avg Income: $${summaryData.avg_income.toLocaleString()}
Poverty Rate: ${summaryData.avg_poverty}%
Uninsured Rate: ${summaryData.avg_uninsured}%

Provide actionable insights for healthcare planning and resource allocation.`,
      });

      setInsights(response);
      toast.success('Insights generated successfully');
    } catch (error) {
      toast.error('Failed to generate insights');
      console.error(error);
    } finally {
      setIsGeneratingInsights(false);
    }
  };

  const removeZipCode = (zipToRemove) => {
    const updated = formData.zip_codes.filter(z => z !== zipToRemove);
    updateFormData({ zip_codes: updated });
    toast.success(`Removed ZIP ${zipToRemove}`);
  };

  const addZipCode = () => {
    if (!newZipCode || newZipCode.length !== 5) {
      toast.error('Please enter a valid 5-digit ZIP code');
      return;
    }
    if (formData.zip_codes.includes(newZipCode)) {
      toast.error('ZIP code already included');
      return;
    }
    updateFormData({ zip_codes: [...formData.zip_codes, newZipCode] });
    setNewZipCode('');
    toast.success(`Added ZIP ${newZipCode}`);
  };

  const handleSave = async () => {
    if (isSaving) return;
    setIsSaving(true);
    try {
      updateFormData({
        demographics_summary: regionalStats,
        insights: insights
      });
      await onSave();
      setHasUnsavedChanges(false);
    } catch (error) {
      console.error('Save error:', error);
      toast.error('Failed to save regional analysis');
    } finally {
      setIsSaving(false);
    }
  };

  const handlePublishAndReset = async () => {
    if (isPublishing) return;
    setIsPublishing(true);
    try {
      updateFormData({
        demographics_summary: regionalStats,
        insights: insights
      });
      await onPublish();
      setPublished(true);
    } catch (error) {
      console.error('Publish error:', error);
      toast.error('Failed to publish regional analysis');
    } finally {
      setIsPublishing(false);
    }
  };

  const startNewAnalysis = () => {
    localStorage.removeItem('regional_analysis_data');
    localStorage.removeItem('regional_analysis_step');
    window.location.reload();
  };

  const exportToCSV = (data, filename) => {
    if (!data || data.length === 0) {
      toast.error('No data to export');
      return;
    }

    const headers = Object.keys(data[0]);
    const csvContent = [
      headers.join(','),
      ...data.map(row => 
        headers.map(header => {
          const value = row[header];
          if (value === null || value === undefined) return '';
          if (typeof value === 'string' && value.includes(',')) return `"${value}"`;
          return value;
        }).join(',')
      )
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success(`Exported ${filename}`);
  };

  // Format demographic data for map
  const demographicCensusData = {};
  demographics.forEach(demo => {
    const pop = demo.population || 0;
    const income = demo.median_income || 0;
    const poverty = demo.poverty_rate !== undefined && demo.poverty_rate !== null ? demo.poverty_rate : 0;
    const uninsured = demo.uninsured_rate !== undefined && demo.uninsured_rate !== null ? demo.uninsured_rate : 0;
    
    demographicCensusData[demo.zcta5] = {
      population: pop,
      medianIncome: income,
      povertyRate: poverty,
      uninsuredRate: uninsured,
      source: demo.source?.includes('Census') || demo.acs_year ? 'US Census Bureau ACS' : (demo.source || 'Census Data')
    };
  });

  // Format health data for map
  const healthCensusData = {};
  formData.zip_codes.forEach(zip => {
    const zipHealth = healthByZip[zip] || {};
    const dataPoint = { source: 'CDC PLACES' };
    
    Object.keys(zipHealth).forEach(metricId => {
      dataPoint[metricId] = zipHealth[metricId].value || 0;
    });
    
    healthCensusData[zip] = dataPoint;
  });

  const renderHealthContent = () => {
    // Health indicator selection
    const indicatorSelection = (
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Health Indicators by ZIP Code</CardTitle>
          <p className="text-xs text-gray-600 mt-1">Select up to 5 indicators to compare across ZIP codes</p>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-2">
            {availableIndicators.slice(0, 15).map(indicator => (
              <div key={indicator.id} className="flex items-start space-x-1.5">
                <Checkbox
                  id={indicator.id}
                  checked={selectedHealthMetrics.includes(indicator.id)}
                  onCheckedChange={() => toggleHealthMetric(indicator.id)}
                  disabled={!selectedHealthMetrics.includes(indicator.id) && selectedHealthMetrics.length >= 5}
                  className="mt-0.5"
                />
                <Label
                  htmlFor={indicator.id}
                  className="text-xs leading-tight cursor-pointer line-clamp-2"
                >
                  {indicator.name}
                </Label>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );

    if (viewMode === 'map') {
      if (!healthMapMetric && selectedHealthMetrics.length > 0) {
        setHealthMapMetric(selectedHealthMetrics[0]);
      }

      return (
        <div className="space-y-4">
          {indicatorSelection}

          {selectedHealthMetrics.length > 0 ? (
            <>
              <div className="bg-white border rounded-lg p-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                  <div>
                    <Label className="text-sm font-medium text-gray-700 mb-2 block">Color by Indicator</Label>
                    <Select 
                      value={healthMapMetric} 
                      onValueChange={setHealthMapMetric}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select health indicator" />
                      </SelectTrigger>
                      <SelectContent>
                        {selectedHealthMetrics.map(metricId => {
                          const indicator = availableIndicators.find(i => i.id === metricId);
                          return (
                            <SelectItem key={metricId} value={metricId}>
                              {indicator?.name}
                            </SelectItem>
                          );
                        })}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="text-sm font-medium text-gray-700 mb-2 block">Color Scheme</Label>
                    <Select 
                      value={mapSettings.colorScale} 
                      onValueChange={(value) => 
                        setMapSettings({ ...mapSettings, colorScale: value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="viridis">Viridis (Purple-Green)</SelectItem>
                        <SelectItem value="plasma">Plasma (Purple-Yellow)</SelectItem>
                        <SelectItem value="inferno">Inferno (Black-Yellow)</SelectItem>
                        <SelectItem value="bluePurple">Blue-Purple</SelectItem>
                        <SelectItem value="redYellowGreen">Red-Yellow-Green</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex gap-4">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="zip-labels"
                        checked={mapSettings.showZipLabels}
                        onCheckedChange={(checked) => 
                          setMapSettings({ ...mapSettings, showZipLabels: checked })
                        }
                      />
                      <Label htmlFor="zip-labels" className="text-sm cursor-pointer">ZIP Labels</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="data-overlay"
                        checked={mapSettings.showDataOverlay}
                        onCheckedChange={(checked) => 
                          setMapSettings({ ...mapSettings, showDataOverlay: checked })
                        }
                      />
                      <Label htmlFor="data-overlay" className="text-sm cursor-pointer">Data Overlay</Label>
                    </div>
                  </div>
                </div>
              </div>

              <InteractiveMap
                key={`health-map-${healthData.length}`}
                zipBoundaries={boundaries}
                organizations={[]}
                selectedZips={formData.zip_codes}
                colorMetric={healthMapMetric}
                showCompetitors={false}
                censusData={healthCensusData}
                assessment={formData.assessment}
                mapSettings={mapSettings}
                onMapSettingsChange={setMapSettings}
                metricDisplayName={availableIndicators.find(i => i.id === healthMapMetric)?.name}
              />
            </>
          ) : (
            <div className="text-center py-12 text-gray-500 border-2 border-dashed rounded-lg">
              Select at least one health indicator to view the map
            </div>
          )}
        </div>
      );
    }

    if (viewMode === 'summary') {
      return (
        <div className="space-y-4">
          {indicatorSelection}

          {selectedHealthMetrics.length > 0 ? (
            <Card>
              <CardContent className="pt-6">
                <ResponsiveContainer width="100%" height={Math.max(300, formData.zip_codes.length * 40)}>
                  <BarChart data={healthChartData} layout="vertical" margin={{ left: 50, right: 80, top: 20, bottom: 20 }}>
                    <defs>
                      <linearGradient id="healthGradient0" x1="0" y1="0" x2="1" y2="0">
                        <stop offset="0%" stopColor="#3b82f6" stopOpacity={0.9} />
                        <stop offset="100%" stopColor="#3b82f6" stopOpacity={0.5} />
                      </linearGradient>
                      <linearGradient id="healthGradient1" x1="0" y1="0" x2="1" y2="0">
                        <stop offset="0%" stopColor="#10b981" stopOpacity={0.9} />
                        <stop offset="100%" stopColor="#10b981" stopOpacity={0.5} />
                      </linearGradient>
                      <linearGradient id="healthGradient2" x1="0" y1="0" x2="1" y2="0">
                        <stop offset="0%" stopColor="#f59e0b" stopOpacity={0.9} />
                        <stop offset="100%" stopColor="#f59e0b" stopOpacity={0.5} />
                      </linearGradient>
                      <linearGradient id="healthGradient3" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#ef4444" stopOpacity={0.9} />
                        <stop offset="100%" stopColor="#ef4444" stopOpacity={0.5} />
                      </linearGradient>
                      <linearGradient id="healthGradient4" x1="0" y1="0" x2="1" y2="0">
                        <stop offset="0%" stopColor="#8b5cf6" stopOpacity={0.9} />
                        <stop offset="100%" stopColor="#8b5cf6" stopOpacity={0.5} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" tick={{ fontSize: 8 }} domain={[0, 'auto']} />
                    <YAxis dataKey="zipCode" type="category" width={60} tick={{ fontSize: 8 }} />
                    <Tooltip 
                      contentStyle={{ fontSize: 11 }}
                      formatter={(value, name) => [`${value.toFixed(1)}%`, name]}
                    />
                    <Legend wrapperStyle={{ fontSize: 10 }} />
                    {selectedHealthMetrics.map((metricId, idx) => {
                      const indicatorName = availableIndicators.find(i => i.id === metricId)?.name;
                      const avgValue = healthAverages[metricId];
                      return (
                        <React.Fragment key={metricId}>
                          <Bar
                            dataKey={metricId}
                            fill={`url(#healthGradient${idx})`}
                            name={indicatorName}
                          >
                            <LabelList 
                              dataKey={metricId} 
                              position="right" 
                              style={{ fontSize: 9, fill: '#666' }} 
                              formatter={(value) => value ? `${value.toFixed(1)}%` : ''} 
                            />
                          </Bar>
                          {avgValue && (
                            <ReferenceLine 
                              x={avgValue} 
                              stroke={['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'][idx]} 
                              strokeDasharray="5 5"
                              strokeWidth={2}
                              label={{ 
                                value: `Avg: ${avgValue.toFixed(1)}%`, 
                                position: 'top',
                                fontSize: 9,
                                fill: '#666'
                              }}
                            />
                          )}
                        </React.Fragment>
                      );
                    })}
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          ) : (
            <div className="text-center py-12 text-sm text-gray-500 border-2 border-dashed rounded-lg">
              Select at least one health indicator to view the comparison
            </div>
          )}
        </div>
      );
    }

    if (viewMode === 'table') {
      return (
        <div className="space-y-4">
          {indicatorSelection}

          {selectedHealthMetrics.length > 0 ? (
            <Card>
              <CardContent className="pt-6">
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead className="bg-gray-50 border-b">
                      <tr>
                        <th className="px-3 py-2 text-left font-semibold">ZIP Code</th>
                        {selectedHealthMetrics.map(metricId => {
                          const indicator = availableIndicators.find(i => i.id === metricId);
                          return (
                            <th key={metricId} className="px-3 py-2 text-right font-semibold">
                              {indicator?.name}
                            </th>
                          );
                        })}
                      </tr>
                    </thead>
                    <tbody>
                      {healthChartData.map(row => (
                        <tr key={row.zipCode} className="border-b hover:bg-gray-50">
                          <td className="px-3 py-2 font-medium">{row.zipCode}</td>
                          {selectedHealthMetrics.map(metricId => {
                            const value = row[metricId];
                            const avg = healthAverages[metricId];
                            return (
                              <td key={metricId} className="px-3 py-2 text-right">
                                {value?.toFixed(1)}% 
                                <span className="text-gray-500 ml-1">({avg?.toFixed(1)}%)</span>
                              </td>
                            );
                          })}
                        </tr>
                      ))}
                      <tr className="bg-gray-50 font-semibold">
                        <td className="px-3 py-2">Regional Avg</td>
                        {selectedHealthMetrics.map(metricId => {
                          const avg = healthAverages[metricId];
                          return (
                            <td key={metricId} className="px-3 py-2 text-right">
                              {avg?.toFixed(1)}%
                            </td>
                          );
                        })}
                      </tr>
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="text-center py-12 text-sm text-gray-500 border-2 border-dashed rounded-lg">
              Select at least one health indicator to view the table
            </div>
          )}
        </div>
      );
    }

    return null;
  };

  const renderProvidersContent = () => {
    if (viewMode === 'map') {
      return (
        <InteractiveMap
          key={`providers-map-${organizations.length}`}
          zipBoundaries={boundaries}
          organizations={organizations}
          selectedZips={formData.zip_codes}
          colorMetric="population"
          showCompetitors={true}
          censusData={demographicCensusData}
          assessment={formData.assessment}
          mapSettings={mapSettings}
          onMapSettingsChange={setMapSettings}
        />
      );
    }

    // Group organizations by type and ZIP
    const orgsByType = organizations.reduce((acc, org) => {
      const type = org.type || 'other';
      if (!acc[type]) acc[type] = [];
      acc[type].push(org);
      return acc;
    }, {});

    const orgsByZip = organizations.reduce((acc, org) => {
      const zip = org.zip_code;
      if (!acc[zip]) acc[zip] = [];
      acc[zip].push(org);
      return acc;
    }, {});

    const providerSummary = [
      {
        type: 'FQHCs',
        count: orgsByType.fqhc?.length || 0,
        sites: orgsByType.fqhc?.reduce((sum, org) => sum + (org.sites?.length || 1), 0) || 0,
        patients: orgsByType.fqhc?.reduce((sum, org) => sum + (org.patient_volume || 0), 0) || 0
      },
      {
        type: 'Hospitals',
        count: orgsByType.hospital?.length || 0,
        sites: orgsByType.hospital?.reduce((sum, org) => sum + (org.sites?.length || 1), 0) || 0,
        patients: orgsByType.hospital?.reduce((sum, org) => sum + (org.patient_volume || 0), 0) || 0
      },
      {
        type: 'Clinics',
        count: orgsByType.clinic?.length || 0,
        sites: orgsByType.clinic?.reduce((sum, org) => sum + (org.sites?.length || 1), 0) || 0,
        patients: orgsByType.clinic?.reduce((sum, org) => sum + (org.patient_volume || 0), 0) || 0
      },
      {
        type: 'Safety Net',
        count: orgsByType.safety_net?.length || 0,
        sites: orgsByType.safety_net?.reduce((sum, org) => sum + (org.sites?.length || 1), 0) || 0,
        patients: orgsByType.safety_net?.reduce((sum, org) => sum + (org.patient_volume || 0), 0) || 0
      },
      {
        type: 'Other',
        count: orgsByType.other?.length || 0,
        sites: orgsByType.other?.reduce((sum, org) => sum + (org.sites?.length || 1), 0) || 0,
        patients: orgsByType.other?.reduce((sum, org) => sum + (org.patient_volume || 0), 0) || 0
      }
    ].filter(item => item.count > 0);

    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Provider Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div>
                <div className="text-sm text-gray-600">Total Organizations</div>
                <div className="text-2xl font-bold">{organizations.length}</div>
              </div>
              <div>
                <div className="text-sm text-gray-600">Total Sites</div>
                <div className="text-2xl font-bold">
                  {organizations.reduce((sum, org) => sum + (org.sites?.length || 1), 0)}
                </div>
              </div>
              <div>
                <div className="text-sm text-gray-600">Total Patients</div>
                <div className="text-2xl font-bold">
                  {organizations.reduce((sum, org) => sum + (org.patient_volume || 0), 0).toLocaleString()}
                </div>
              </div>
              <div>
                <div className="text-sm text-gray-600">ZIP Coverage</div>
                <div className="text-2xl font-bold">
                  {Object.keys(orgsByZip).length}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {providerSummary.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Providers by Type</CardTitle>
            </CardHeader>
            <CardContent className="overflow-x-auto">
              <ResponsiveContainer width="100%" height={300} minWidth={300}>
                <BarChart data={providerSummary}>
                  <defs>
                    <linearGradient id="fqhcGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#10b981" stopOpacity={0.9} />
                      <stop offset="100%" stopColor="#10b981" stopOpacity={0.5} />
                    </linearGradient>
                    <linearGradient id="hospitalGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#ef4444" stopOpacity={0.9} />
                      <stop offset="100%" stopColor="#ef4444" stopOpacity={0.5} />
                    </linearGradient>
                    <linearGradient id="clinicGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#3b82f6" stopOpacity={0.9} />
                      <stop offset="100%" stopColor="#3b82f6" stopOpacity={0.5} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="type" tick={{ fontSize: 8 }} />
                  <YAxis tick={{ fontSize: 8 }} />
                  <Tooltip />
                  <Bar dataKey="count" name="Organizations">
                    <LabelList dataKey="count" position="top" style={{ fontSize: 10 }} />
                    {providerSummary.map((entry, index) => {
                      let fill = 'url(#clinicGradient)';
                      if (entry.type === 'FQHCs') fill = 'url(#fqhcGradient)';
                      else if (entry.type === 'Hospitals') fill = 'url(#hospitalGradient)';
                      return <Cell key={`cell-${index}`} fill={fill} />;
                    })}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Providers by ZIP Code</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="px-4 py-3 text-left font-semibold">ZIP Code</th>
                    <th className="px-4 py-3 text-right font-semibold">Total Orgs</th>
                    <th className="px-4 py-3 text-right font-semibold">FQHCs</th>
                    <th className="px-4 py-3 text-right font-semibold">Hospitals</th>
                    <th className="px-4 py-3 text-right font-semibold">Clinics</th>
                    <th className="px-4 py-3 text-right font-semibold">Other</th>
                  </tr>
                </thead>
                <tbody>
                  {Object.entries(orgsByZip).sort(([a], [b]) => a.localeCompare(b)).map(([zip, orgs]) => {
                    const counts = {
                      fqhc: orgs.filter(o => o.type === 'fqhc').length,
                      hospital: orgs.filter(o => o.type === 'hospital').length,
                      clinic: orgs.filter(o => o.type === 'clinic').length,
                      other: orgs.filter(o => !['fqhc', 'hospital', 'clinic', 'safety_net'].includes(o.type)).length + orgs.filter(o => o.type === 'safety_net').length
                    };
                    return (
                      <tr key={zip} className="border-b hover:bg-gray-50">
                        <td className="px-4 py-3 font-medium">{zip}</td>
                        <td className="px-4 py-3 text-right font-semibold">{orgs.length}</td>
                        <td className="px-4 py-3 text-right">{counts.fqhc || '-'}</td>
                        <td className="px-4 py-3 text-right">{counts.hospital || '-'}</td>
                        <td className="px-4 py-3 text-right">{counts.clinic || '-'}</td>
                        <td className="px-4 py-3 text-right">{counts.other || '-'}</td>
                      </tr>
                    );
                  })}
                  <tr className="bg-gray-50 font-semibold">
                    <td className="px-4 py-3">Total</td>
                    <td className="px-4 py-3 text-right">{organizations.length}</td>
                    <td className="px-4 py-3 text-right">{orgsByType.fqhc?.length || 0}</td>
                    <td className="px-4 py-3 text-right">{orgsByType.hospital?.length || 0}</td>
                    <td className="px-4 py-3 text-right">{orgsByType.clinic?.length || 0}</td>
                    <td className="px-4 py-3 text-right">
                      {(orgsByType.safety_net?.length || 0) + (orgsByType.other?.length || 0)}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Provider List</CardTitle>
          </CardHeader>
          <CardContent>
            {organizations.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                No provider organizations found in the selected ZIP codes
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="px-4 py-3 text-left font-semibold">Name</th>
                      <th className="px-4 py-3 text-left font-semibold">Type</th>
                      <th className="px-4 py-3 text-right font-semibold">Sites</th>
                      <th className="px-4 py-3 text-right font-semibold">Patients</th>
                      <th className="px-4 py-3 text-left font-semibold">ZIP</th>
                    </tr>
                  </thead>
                  <tbody>
                    {organizations.sort((a, b) => (a.zip_code || '').localeCompare(b.zip_code || '')).map(org => (
                      <tr key={org.id} className="border-b hover:bg-gray-50">
                        <td className="px-4 py-3">{org.name}</td>
                        <td className="px-4 py-3 capitalize">{org.type}</td>
                        <td className="px-4 py-3 text-right">{org.sites?.length || 1}</td>
                        <td className="px-4 py-3 text-right">
                          {(org.patient_volume || 0).toLocaleString()}
                        </td>
                        <td className="px-4 py-3">{org.zip_code}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  };

  const renderPopulationCentersContent = () => {
    if (viewMode === 'map') {
      return (
        <CityBubbleMap
          key={`city-map-${cityData.length}`}
          cityData={cityData}
          selectedZips={formData.zip_codes}
        />
      );
    }

    // Group cities by unique place and sum up populations
    const cityMap = new Map();
    cityData.forEach(relation => {
      const key = relation.place_geoid;
      if (!cityMap.has(key)) {
        cityMap.set(key, {
          name: relation.place_name,
          state: relation.state_abbr,
          population: relation.place_population || 0,
          zipCount: 1,
          zips: [relation.zcta5]
        });
      } else {
        const existing = cityMap.get(key);
        existing.zipCount++;
        existing.zips.push(relation.zcta5);
      }
    });

    const cities = Array.from(cityMap.values())
      .sort((a, b) => b.population - a.population)
      .slice(0, 20);

    const topCities = cities.slice(0, 10);

    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Population Centers Overview</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
              <div>
                <div className="text-sm text-gray-600">Total Cities</div>
                <div className="text-2xl font-bold">{cities.length}</div>
              </div>
              <div>
                <div className="text-sm text-gray-600">Largest City</div>
                <div className="text-2xl font-bold">
                  {topCities[0]?.name.split(' ')[0] || 'N/A'}
                </div>
              </div>
              <div>
                <div className="text-sm text-gray-600">Total City Population</div>
                <div className="text-2xl font-bold">
                  {cities.reduce((sum, city) => sum + city.population, 0).toLocaleString()}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {topCities.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Top Cities by Population</CardTitle>
            </CardHeader>
            <CardContent className="overflow-x-auto">
              <ResponsiveContainer width="100%" height={Math.max(300, topCities.length * 40)} minWidth={350}>
                <BarChart data={topCities} layout="vertical" margin={{ left: 100, right: 20, top: 10, bottom: 10 }}>
                  <defs>
                    <linearGradient id="cityGradient" x1="0" y1="0" x2="1" y2="0">
                      <stop offset="0%" stopColor="#6366f1" stopOpacity={0.9} />
                      <stop offset="100%" stopColor="#6366f1" stopOpacity={0.5} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" tick={{ fontSize: 8 }} tickFormatter={(value) => (value / 1000).toFixed(0) + 'K'} />
                  <YAxis 
                    dataKey="name" 
                    type="category" 
                    width={110} 
                    tick={{ fontSize: 8 }}
                    tickFormatter={(value) => value.length > 20 ? value.substring(0, 20) + '...' : value}
                  />
                  <Tooltip formatter={(value) => value.toLocaleString()} />
                  <Bar dataKey="population" fill="url(#cityGradient)" name="Population">
                    <LabelList 
                      dataKey="population" 
                      position="right" 
                      formatter={(value) => value.toLocaleString()}
                      style={{ fontSize: 10, fill: '#666' }}
                    />
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">City Details</CardTitle>
          </CardHeader>
          <CardContent>
            {cities.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                No city data available for the selected ZIP codes
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="px-4 py-3 text-left font-semibold">City</th>
                      <th className="px-4 py-3 text-left font-semibold">State</th>
                      <th className="px-4 py-3 text-right font-semibold">Population</th>
                      <th className="px-4 py-3 text-right font-semibold">ZIPs</th>
                    </tr>
                  </thead>
                  <tbody>
                    {cities.map((city, idx) => (
                      <tr key={idx} className="border-b hover:bg-gray-50">
                        <td className="px-4 py-3">{city.name}</td>
                        <td className="px-4 py-3">{city.state}</td>
                        <td className="px-4 py-3 text-right">{city.population.toLocaleString()}</td>
                        <td className="px-4 py-3 text-right">{city.zipCount}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
            <div>
              <CardTitle className="text-lg md:text-xl">Regional Analysis Summary</CardTitle>
              <div className="flex items-center gap-2 mt-1">
                <p className="text-xs md:text-sm text-gray-600">
                  {formData.assessment?.title} • {formData.zip_codes?.length} ZIP codes
                </p>
                <Dialog open={showZipEditor} onOpenChange={setShowZipEditor}>
                  <DialogTrigger asChild>
                    <Button variant="ghost" size="sm" className="h-6 px-2 text-xs">
                      <Edit className="w-3 h-3 mr-1" />
                      Edit ZIPs
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>Edit ZIP Codes</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="flex gap-2">
                        <Input
                          placeholder="Enter 5-digit ZIP"
                          value={newZipCode}
                          onChange={(e) => setNewZipCode(e.target.value)}
                          maxLength={5}
                        />
                        <Button onClick={addZipCode} size="sm">
                          <Plus className="w-4 h-4 mr-1" />
                          Add
                        </Button>
                      </div>
                      <div className="border rounded-lg p-3 max-h-64 overflow-y-auto">
                        <div className="flex flex-wrap gap-2">
                          {formData.zip_codes.map(zip => (
                            <div key={zip} className="flex items-center gap-1 bg-gray-100 rounded px-2 py-1">
                              <span className="text-sm font-medium">{zip}</span>
                              <button
                                onClick={() => removeZipCode(zip)}
                                className="text-gray-500 hover:text-red-600"
                              >
                                <X className="w-3 h-3" />
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
            <div className="flex gap-1 border rounded-lg p-1 self-start">
              <Button
                size="sm"
                variant={viewMode === 'summary' ? 'default' : 'ghost'}
                onClick={() => setViewMode('summary')}
                className="h-8 px-2"
                title="Chart View"
              >
                <BarChart3 className="w-4 h-4" />
              </Button>
              <Button
                size="sm"
                variant={viewMode === 'table' ? 'default' : 'ghost'}
                onClick={() => setViewMode('table')}
                className="h-8 px-2"
                title="Table View"
              >
                <TableIcon className="w-4 h-4" />
              </Button>
              <Button
                size="sm"
                variant={viewMode === 'map' ? 'default' : 'ghost'}
                onClick={() => setViewMode('map')}
                className="h-8 px-2"
                title="Map View"
              >
                <MapIcon className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <div className="text-center">
                <LottieLoader size={80} className="mx-auto mb-4" />
                <p className="text-gray-600">Loading data visualization...</p>
              </div>
            </div>
          ) : (
            <Tabs defaultValue="demographics" className="w-full">
              <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 gap-1">
                <TabsTrigger value="demographics" className="text-xs md:text-sm">Demographics</TabsTrigger>
                <TabsTrigger value="health" className="text-xs md:text-sm">Health</TabsTrigger>
                <TabsTrigger value="providers" className="text-xs md:text-sm">Providers</TabsTrigger>
                <TabsTrigger value="population" className="text-xs md:text-sm">Pop. Centers</TabsTrigger>
              </TabsList>

              <TabsContent value="demographics" className="mt-6">
                <div className="space-y-4">
                  {viewMode === 'table' && selectedDemographics.length > 0 && (
                    <div className="flex justify-end">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          const exportData = selectedDemographics.map(demo => ({
                            'ZIP Code': demo.zcta5,
                            'Population': demo.population || 0,
                            'Median Income': demo.median_income || 0,
                            'Poverty Rate': demo.poverty_rate || 0,
                            'Uninsured Rate': demo.uninsured_rate || 0
                          }));
                          exportToCSV(exportData, `demographics_${formData.assessment?.title || 'regional'}_${new Date().toISOString().split('T')[0]}.csv`);
                        }}
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Export CSV
                      </Button>
                    </div>
                  )}
                  {renderDemographicsContent()}
                </div>
              </TabsContent>

              <TabsContent value="health" className="mt-6">
                <div className="space-y-4">
                  {viewMode === 'table' && selectedHealthMetrics.length > 0 && (
                    <div className="flex justify-end">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          const exportData = healthChartData.map(row => {
                            const rowData = { 'ZIP Code': row.zipCode };
                            selectedHealthMetrics.forEach(metricId => {
                              const indicator = availableIndicators.find(i => i.id === metricId);
                              rowData[indicator?.name || metricId] = row[metricId] || 0;
                            });
                            return rowData;
                          });
                          exportToCSV(exportData, `health_indicators_${formData.assessment?.title || 'regional'}_${new Date().toISOString().split('T')[0]}.csv`);
                        }}
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Export CSV
                      </Button>
                    </div>
                  )}
                  {renderHealthContent()}
                </div>
              </TabsContent>

              <TabsContent value="providers" className="mt-6">
                <div className="space-y-4">
                  {viewMode === 'table' && organizations.length > 0 && (
                    <div className="flex justify-end">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          const exportData = organizations.map(org => ({
                            'Name': org.name,
                            'Type': org.type,
                            'Sites': org.sites?.length || 1,
                            'Patients': org.patient_volume || 0,
                            'ZIP Code': org.zip_code,
                            'Address': org.address || '',
                            'City': org.city || '',
                            'State': org.state || ''
                          }));
                          exportToCSV(exportData, `providers_list_${formData.assessment?.title || 'regional'}_${new Date().toISOString().split('T')[0]}.csv`);
                        }}
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Export CSV
                      </Button>
                    </div>
                  )}
                  {renderProvidersContent()}
                </div>
              </TabsContent>

              <TabsContent value="population" className="mt-6">
                <div className="space-y-4">
                  {viewMode === 'table' && cityData.length > 0 && (
                    <div className="flex justify-end">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          const cityMap = new Map();
                          cityData.forEach(relation => {
                            const key = relation.place_geoid;
                            if (!cityMap.has(key)) {
                              cityMap.set(key, {
                                name: relation.place_name,
                                state: relation.state_abbr,
                                population: relation.place_population || 0,
                                zipCount: 1,
                                zips: [relation.zcta5]
                              });
                            } else {
                              const existing = cityMap.get(key);
                              existing.zipCount++;
                              existing.zips.push(relation.zcta5);
                            }
                          });
                          const cities = Array.from(cityMap.values()).sort((a, b) => b.population - a.population);
                          const exportData = cities.map(city => ({
                            'City': city.name,
                            'State': city.state,
                            'Population': city.population,
                            'ZIP Count': city.zipCount,
                            'ZIP Codes': city.zips.join('; ')
                          }));
                          exportToCSV(exportData, `population_centers_${formData.assessment?.title || 'regional'}_${new Date().toISOString().split('T')[0]}.csv`);
                        }}
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Export CSV
                      </Button>
                    </div>
                  )}
                  {renderPopulationCentersContent()}
                </div>
              </TabsContent>
            </Tabs>
          )}
        </CardContent>
      </Card>

      {/* AI Insights Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-600" />
            AI Insights
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {!insights ? (
            <div className="text-center py-8">
              <p className="text-gray-600 mb-4">
                Generate AI-powered insights from your regional health data
              </p>
              <Button 
                onClick={generateInsights} 
                disabled={isGeneratingInsights}
                className="bg-purple-600 hover:bg-purple-700"
              >
                {isGeneratingInsights ? (
                  <>
                    <LottieLoader size={16} className="mr-2" />
                    Generating Insights...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 mr-2" />
                    Generate Insights
                  </>
                )}
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-4 prose prose-sm max-w-none">
                <ReactMarkdown>{insights}</ReactMarkdown>
              </div>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={generateInsights}
                disabled={isGeneratingInsights}
              >
                Regenerate Insights
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Data Verification Section */}
      <Card className="border-gray-200">
        <CardHeader>
          <CardTitle className="text-lg">Data Verification</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div className="flex items-center gap-2 text-sm">
                {demographics.length > 0 ? (
                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-gray-400" />
                )}
                <span className={demographics.length > 0 ? 'text-green-700' : 'text-gray-500'}>
                  Demographics
                </span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                {healthData.length > 0 ? (
                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-gray-400" />
                )}
                <span className={healthData.length > 0 ? 'text-green-700' : 'text-gray-500'}>
                  Health Data
                </span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                {boundaries.length > 0 ? (
                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-gray-400" />
                )}
                <span className={boundaries.length > 0 ? 'text-green-700' : 'text-gray-500'}>
                  Boundaries
                </span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                {organizations.length > 0 ? (
                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-gray-400" />
                )}
                <span className={organizations.length > 0 ? 'text-green-700' : 'text-gray-500'}>
                  Providers
                </span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                {cityData.length > 0 ? (
                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-gray-400" />
                )}
                <span className={cityData.length > 0 ? 'text-green-700' : 'text-gray-500'}>
                  Cities
                </span>
              </div>
            </div>
            <div className="flex gap-2 pt-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  const lastUpdated = new Date().toLocaleString();
                  toast.success(`Data verified as of ${lastUpdated}`);
                }}
                className="flex-1"
              >
                <CheckCircle2 className="w-4 h-4 mr-2" />
                Verify Accuracy
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={loadAllData}
                className="flex-1"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh All
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {!published ? (
        <div className="space-y-3 pb-32 sm:pb-8">
          <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t border-gray-200 sm:relative sm:border-0 sm:p-0 sm:bg-transparent z-10">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 max-w-5xl mx-auto">
              <Button 
                variant="outline" 
                onClick={onPrev}
                disabled={isSaving || isPublishing}
                className="w-full h-12 text-base"
              >
                <ChevronLeft className="w-4 h-4 mr-2" />
                Previous
              </Button>
              <Button 
                variant="outline" 
                onClick={handleSave}
                disabled={isSaving || isPublishing || !hasUnsavedChanges}
                className="w-full h-12 text-base"
              >
                {isSaving ? (
                  <>
                    <LottieLoader size={16} className="mr-2" />
                    Saving...
                  </>
                ) : !hasUnsavedChanges ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 mr-2" />
                    Saved
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4 mr-2" />
                    Save Draft
                  </>
                )}
              </Button>
              <Button 
                onClick={handlePublishAndReset} 
                disabled={isSaving || isPublishing}
                className="w-full h-12 text-base bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50"
              >
                {isPublishing ? (
                  <>
                    <LottieLoader size={16} className="mr-2" />
                    Publishing...
                  </>
                ) : (
                  <>
                    <Globe className="w-4 h-4 mr-2" />
                    Publish
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      ) : (
        <Card className="bg-emerald-50 border-emerald-200">
          <CardContent className="pt-6">
            <div className="text-center space-y-4">
              <div className="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center mx-auto">
                <Globe className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-emerald-900">Analysis Published!</h3>
                <p className="text-sm text-emerald-700 mt-1">
                  Your regional analysis has been added to the assessment dashboard
                </p>
              </div>
              <Button onClick={startNewAnalysis} className="bg-emerald-600 hover:bg-emerald-700">
                <Plus className="w-4 h-4 mr-2" />
                Start New Regional Analysis
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}