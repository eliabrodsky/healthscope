import React, { useEffect, useMemo, useState } from 'react';
import { MapContainer, TileLayer, CircleMarker, Popup, useMap, Marker } from 'react-leaflet';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { MapIcon, Settings } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { base44 } from '@/api/base44Client';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

const MapController = ({ cities, center, zoom }) => {
  const map = useMap();
  const [hasAutoFitted, setHasAutoFitted] = useState(false);

  useEffect(() => {
    if (!map || hasAutoFitted) return;

    try {
      if (center && zoom) {
        map.setView(center, zoom);
        setHasAutoFitted(true);
        return;
      }

      if (cities && cities.length > 0) {
        const validCities = cities.filter(c => c.coordinates?.latitude && c.coordinates?.longitude);
        if (validCities.length > 0) {
          const bounds = L.latLngBounds(
            validCities.map(c => [c.coordinates.latitude, c.coordinates.longitude])
          );
          map.fitBounds(bounds, { padding: [50, 50] });
          setHasAutoFitted(true);
        }
      }
    } catch (e) {
      console.warn('MapController error:', e);
    }
  }, [cities, center, zoom, map, hasAutoFitted]);

  return null;
};

const ZipLabels = ({ selectedZips, showLabels }) => {
  const map = useMap();

  useEffect(() => {
    if (!map || !showLabels || !selectedZips || selectedZips.length === 0) {
      return;
    }

    // Add ZIP code labels (using hash-based positioning)
    const markers = [];
    
    try {
      selectedZips.slice(0, 50).forEach(zip => {
        const hash = zip.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
        const lat = 30.5 + ((hash % 200) / 100) - 1;
        const lng = -89.0 + (((hash * 7) % 200) / 100) - 1;

        const icon = L.divIcon({
          html: `<div style="background: rgba(255,255,255,0.9); padding: 2px 6px; border-radius: 4px; font-size: 10px; font-weight: bold; border: 1px solid #ccc; color: #333;">${zip}</div>`,
          className: 'zip-label',
          iconSize: [null, null]
        });

        const marker = L.marker([lat, lng], { icon });
        marker.addTo(map);
        markers.push(marker);
      });
    } catch (error) {
      console.warn('Error adding ZIP labels:', error);
    }

    return () => {
      markers.forEach(marker => {
        try {
          if (map && marker) {
            map.removeLayer(marker);
          }
        } catch (e) {
          // Ignore cleanup errors
        }
      });
    };
  }, [map, selectedZips, showLabels]);

  return null;
};

export default function CityBubbleMap({ cityData, selectedZips }) {
  const [citiesWithCoords, setCitiesWithCoords] = useState([]);
  const [isLoadingCoords, setIsLoadingCoords] = useState(true);
  const [mapSettings, setMapSettings] = useState({
    showZipLabels: false,
    showCityLabels: true
  });

  // Group cities by unique place
  const cityGroups = useMemo(() => {
    const cityMap = new Map();
    
    (cityData || []).forEach(relation => {
      const key = relation.place_geoid;
      if (!cityMap.has(key)) {
        cityMap.set(key, {
          geoid: relation.place_geoid,
          name: relation.place_name,
          state: relation.state_abbr,
          type: relation.place_type || 'city',
          population: relation.place_population || 0,
          zipCount: 1,
          zips: [relation.zcta5]
        });
      } else {
        const existing = cityMap.get(key);
        existing.zipCount++;
        existing.zips.push(relation.zcta5);
      }
    });

    return Array.from(cityMap.values());
  }, [cityData]);

  // Fetch city coordinates with caching
  useEffect(() => {
    const fetchCityCoordinates = async () => {
      setIsLoadingCoords(true);
      
      try {
        // Limit to top 10 cities by population
        const topCities = cityGroups
          .sort((a, b) => b.population - a.population)
          .slice(0, 10)
          .map(city => ({
            ...city,
            name: city.name.replace(/ city$| town$| village$| CDP$/i, '').trim()
          }));
        
        if (topCities.length === 0) {
          setCitiesWithCoords([]);
          setIsLoadingCoords(false);
          return;
        }
        
        // Check cache first - query each city individually to avoid complex $or queries
        const cachedPromises = topCities.map(c => 
          base44.entities.CityCoordinates.filter({ city_name: c.name, state: c.state }, null, 1)
        );
        const cachedResults = await Promise.all(cachedPromises);
        const cached = cachedResults.flat().filter(Boolean);
        
        const cachedMap = new Map(cached.map(c => [`${c.city_name}_${c.state}`, c]));
        
        const citiesNeedingGeocode = topCities.filter(c => !cachedMap.has(`${c.name}_${c.state}`));
        
        // Only geocode cities not in cache
        if (citiesNeedingGeocode.length > 0) {
          const response = await base44.functions.invoke('batchGeocodeCity', {
            cities: citiesNeedingGeocode
          });
          
          if (response?.data?.success && response.data.results) {
            // Save to cache
            const newCoords = response.data.results
              .filter(city => city.success && city.coordinates)
              .map(city => ({
                city_name: city.name,
                state: city.state,
                latitude: city.coordinates.latitude,
                longitude: city.coordinates.longitude,
                place_geoid: city.geoid
              }));
            
            if (newCoords.length > 0) {
              try {
                await base44.entities.CityCoordinates.bulkCreate(newCoords);
              } catch (e) {
                console.warn('Failed to cache coordinates:', e);
              }
            }
            
            // Add to cached map
            response.data.results.forEach(city => {
              if (city.success && city.coordinates) {
                cachedMap.set(`${city.name}_${city.state}`, {
                  city_name: city.name,
                  state: city.state,
                  latitude: city.coordinates.latitude,
                  longitude: city.coordinates.longitude
                });
              }
            });
          }
        }
        
        // Build final list from cache
        const citiesWithCoords = topCities
          .map(city => {
            const cached = cachedMap.get(`${city.name}_${city.state}`);
            if (cached) {
              return {
                geoid: city.geoid,
                name: city.name,
                state: city.state,
                type: city.type,
                population: city.population,
                zipCount: city.zipCount,
                zips: city.zips,
                coordinates: { latitude: cached.latitude, longitude: cached.longitude }
              };
            }
            return null;
          })
          .filter(Boolean);
        
        setCitiesWithCoords(citiesWithCoords);
      } catch (error) {
        console.error('Failed to fetch city coordinates:', error);
        setCitiesWithCoords([]);
      } finally {
        setIsLoadingCoords(false);
      }
    };
    
    if (cityGroups.length > 0) {
      fetchCityCoordinates();
    } else {
      setIsLoadingCoords(false);
      setCitiesWithCoords([]);
    }
  }, [cityGroups]);

  const cities = citiesWithCoords;

  const initialCenter = useMemo(() => {
    if (cities.length > 0) {
      const avgLat = cities.reduce((sum, c) => sum + c.coordinates.latitude, 0) / cities.length;
      const avgLng = cities.reduce((sum, c) => sum + c.coordinates.longitude, 0) / cities.length;
      return [avgLat, avgLng];
    }
    return [31.5, -89.0]; // Default to Mississippi area
  }, [cities]);

  // Scale bubble size based on population
  const { minPop, maxPop } = useMemo(() => {
    const pops = cities.map(c => c.population).filter(p => p > 0);
    return {
      minPop: Math.min(...pops),
      maxPop: Math.max(...pops)
    };
  }, [cities]);

  const getBubbleRadius = (population) => {
    if (!population || population === 0) return 5;
    const normalized = (population - minPop) / (maxPop - minPop);
    return 8 + normalized * 30; // 8px to 38px radius
  };

  const getCityColor = (type) => {
    const colors = {
      'city': '#3b82f6',      // Blue
      'town': '#10b981',      // Green
      'village': '#f59e0b',   // Orange
      'CDP': '#8b5cf6'        // Purple
    };
    return colors[type] || '#64748b'; // Default gray
  };

  return (
    <Card className="relative z-0">
      <CardHeader>
        <div className="flex items-center justify-between flex-wrap gap-2">
          <CardTitle className="flex items-center gap-2 flex-wrap">
            <MapIcon className="w-5 h-5" />
            Population Centers
            <Badge variant="secondary">{cities.length} Cities</Badge>
            <Badge variant="outline" className="text-gray-600 border-gray-200">
              Bubble Size = Population
            </Badge>
          </CardTitle>
          
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm">
                <Settings className="w-4 h-4 mr-2" />
                Map Settings
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Map Display Settings</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="zip-labels" className="cursor-pointer">Show ZIP Code Labels</Label>
                  <Switch
                    id="zip-labels"
                    checked={mapSettings.showZipLabels}
                    onCheckedChange={(checked) => 
                      setMapSettings({ ...mapSettings, showZipLabels: checked })
                    }
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="city-labels" className="cursor-pointer">Show City Labels</Label>
                  <Switch
                    id="city-labels"
                    checked={mapSettings.showCityLabels}
                    onCheckedChange={(checked) => 
                      setMapSettings({ ...mapSettings, showCityLabels: checked })
                    }
                  />
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-[700px] w-full rounded-lg border border-gray-200 overflow-hidden relative">
          {isLoadingCoords ? (
            <div className="h-full flex items-center justify-center bg-gray-50">
              <div className="text-center">
                <div className="animate-spin w-8 h-8 border-4 border-emerald-600 border-t-transparent rounded-full mx-auto mb-4" />
                <p className="text-gray-600">Loading city coordinates...</p>
              </div>
            </div>
          ) : cities.length === 0 ? (
            <div className="h-full flex items-center justify-center bg-gray-50">
              <div className="text-center">
                <MapIcon className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-600">No city data available</p>
              </div>
            </div>
          ) : (
            <>
              <MapContainer
                center={initialCenter}
                zoom={8}
                style={{ height: '100%', width: '100%' }}
                scrollWheelZoom={true}
              >
                <TileLayer
                  attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                />
                
                {cities.map(city => (
                  <CircleMarker
                    key={city.geoid}
                    center={[city.coordinates.latitude, city.coordinates.longitude]}
                    radius={getBubbleRadius(city.population)}
                    pathOptions={{
                      fillColor: getCityColor(city.type),
                      color: '#fff',
                      weight: 2,
                      opacity: 1,
                      fillOpacity: 0.6
                    }}
                  >
                    {mapSettings.showCityLabels && (
                      <Popup>
                        <div style={{ fontFamily: 'system-ui, -apple-system, sans-serif' }}>
                          <div style={{ fontSize: '16px', fontWeight: 'bold', color: '#1f2937', marginBottom: '8px' }}>
                            {city.name}
                          </div>
                          <div style={{ display: 'grid', gap: '6px' }}>
                            <div>
                              <div style={{ fontSize: '10px', color: '#6b7280', textTransform: 'uppercase' }}>Type</div>
                              <div style={{ fontSize: '14px', fontWeight: '600', color: '#1f2937', textTransform: 'capitalize' }}>
                                {city.type}
                              </div>
                            </div>
                            <div>
                              <div style={{ fontSize: '10px', color: '#6b7280', textTransform: 'uppercase' }}>Population</div>
                              <div style={{ fontSize: '14px', fontWeight: '600', color: '#1f2937' }}>
                                {city.population.toLocaleString()}
                              </div>
                            </div>
                            <div>
                              <div style={{ fontSize: '10px', color: '#6b7280', textTransform: 'uppercase' }}>ZIP Codes</div>
                              <div style={{ fontSize: '14px', fontWeight: '600', color: '#1f2937' }}>
                                {city.zipCount}
                              </div>
                            </div>
                          </div>
                        </div>
                      </Popup>
                    )}
                  </CircleMarker>
                ))}
                
                <ZipLabels selectedZips={selectedZips} showLabels={mapSettings.showZipLabels} />
                <MapController cities={cities} />
              </MapContainer>
              
              {/* Legend */}
              <div className="absolute bottom-6 left-6 bg-white/95 backdrop-blur-sm border border-gray-200 rounded-lg shadow-lg p-4 z-[1000]">
                <p className="text-sm font-semibold text-gray-800 mb-3">City Types</p>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded-full bg-blue-600 border-2 border-white"></div>
                    <span className="text-xs text-gray-700">City</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded-full bg-green-600 border-2 border-white"></div>
                    <span className="text-xs text-gray-700">Town</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded-full bg-orange-600 border-2 border-white"></div>
                    <span className="text-xs text-gray-700">Village</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded-full bg-purple-600 border-2 border-white"></div>
                    <span className="text-xs text-gray-700">CDP</span>
                  </div>
                </div>
                <div className="mt-3 pt-3 border-t border-gray-200">
                  <p className="text-xs text-gray-600">Bubble size = Population</p>
                </div>
              </div>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );
}