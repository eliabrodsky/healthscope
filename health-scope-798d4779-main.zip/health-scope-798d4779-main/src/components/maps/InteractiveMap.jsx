import React, { useEffect, useMemo, useState, useRef, useCallback } from 'react';
import { MapContainer, TileLayer, GeoJSON, useMap, Marker, Popup, Circle } from 'react-leaflet';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { MapIcon, Settings, Eye, EyeOff, Loader2 } from 'lucide-react';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

const getOrgIcon = (type) => {
  const colors = {
    hospital: '#dc2626', // Red-600
    clinic: '#2563eb', // Blue-600
    fqhc: '#16a34a', // Green-600
    safety_net: '#f97316', // Orange-600
    default: '#64748b' // Gray-600
  };

  const color = colors[type] || colors.default;

  return L.divIcon({
    html: `<div style="
      width: 12px;
      height: 12px;
      background-color: ${color};
      border: 2px solid white;
      border-radius: 50%;
      box-shadow: 0 1px 3px rgba(0,0,0,0.3);
    "></div>`,
    className: '',
    iconSize: [12, 12],
    iconAnchor: [6, 6]
  });
};

// Perceptually-uniform divergent color palettes
const COLOR_PALETTES = {
  viridis: ['#440154', '#3b528b', '#21918c', '#5ec962', '#fde725'],
  plasma: ['#0d0887', '#6a00a8', '#b12a90', '#e16462', '#fca636', '#f0f921'],
  magma: ['#000004', '#3b0f70', '#8c2981', '#de4968', '#f98c0a', '#fcfdbf'],
  inferno: ['#000004', '#320a5a', '#781c6d', '#bd3655', '#ed6925', '#fbff2c'],
  bluePurple: ['#081d58', '#253494', '#225ea8', '#1d91c0', '#41b6c4', '#c7e9b4'],
  redYellowGreen: ['#d73027', '#fc8d59', '#fee08b', '#d9ef8b', '#91cf60', '#1a9850'],
  spectral: ['#d53e4f', '#f46d43', '#fdae61', '#fee08b', '#e6f598', '#abdda4', '#66c2a5', '#3288bd'],
};

// Legacy RGB scales for backward compatibility
const COLOR_SCALES = {
  blue: { name: 'Blue Scale', low: [200, 230, 255], high: [8, 47, 120] },
  green: { name: 'Green Scale', low: [200, 255, 200], high: [0, 100, 0] },
  red: { name: 'Red Scale', low: [255, 230, 230], high: [180, 0, 0] },
  purple: { name: 'Purple Scale', low: [240, 230, 255], high: [75, 0, 130] },
  orange: { name: 'Orange Scale', low: [255, 245, 200], high: [255, 140, 0] },
  inverted_blue: { name: 'Inverted Blue', low: [8, 47, 120], high: [200, 230, 255] },
  inverted_green: { name: 'Inverted Green', low: [0, 100, 0], high: [200, 255, 200] },
  inverted_red: { name: 'Inverted Red', low: [180, 0, 0], high: [255, 230, 230] }
};

// Helper functions for palette interpolation
const hexToRgb = (hex) => {
  if (!hex || typeof hex !== 'string') return { r: 200, g: 200, b: 200 };
  const v = hex.replace('#', '');
  const bigint = parseInt(v, 16);
  return {
    r: (bigint >> 16) & 255,
    g: (bigint >> 8) & 255,
    b: bigint & 255,
  };
};

const rgbToHex = ({ r, g, b }) => {
  const toHex = (x) => Math.max(0, Math.min(255, Math.round(x))).toString(16).padStart(2, '0');
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
};

// Interpolate along a palette where t is in [0,1]
const interpolatePalette = (palette, t) => {
  if (!palette || palette.length === 0) return '#cccccc';
  if (palette.length === 1) return palette[0];
  
  const n = palette.length - 1;
  const scaled = Math.max(0, Math.min(n, t * n));
  const i = Math.floor(scaled);
  const frac = scaled - i;

  const c0 = hexToRgb(palette[i]);
  const c1 = hexToRgb(palette[Math.min(i + 1, n)]);

  const r = c0.r + (c1.r - c0.r) * frac;
  const g = c0.g + (c1.g - c0.g) * frac;
  const b = c0.b + (c1.b - c1.b) * frac;

  return rgbToHex({ r, g, b });
};

const getColorByMetric = (value, metric, allValues, colorScale = 'viridis') => {
  if (value === null || value === undefined || isNaN(value) || allValues.length === 0) return '#cccccc';
  const min = Math.min(...allValues);
  const max = Math.max(...allValues);
  const normalized = (max === min) ? 0.5 : Math.max(0, Math.min(1, (value - min) / (max - min)));
  
  // Check if it's a new palette-based scheme
  if (colorScale && COLOR_PALETTES[colorScale]) {
    const palette = COLOR_PALETTES[colorScale];
    return interpolatePalette(palette, normalized);
  }
  
  // Fall back to legacy RGB-based scales
  const scale = COLOR_SCALES[colorScale] || COLOR_SCALES.blue;
  if (!scale) return '#cccccc';
  const r = Math.round(scale.low[0] + (scale.high[0] - scale.low[0]) * normalized);
  const g = Math.round(scale.low[1] + (scale.high[1] - scale.low[1]) * normalized);
  const b = Math.round(scale.low[2] + (scale.high[2] - scale.low[2]) * normalized);
  return `rgb(${r}, ${g}, ${b})`;
};

const MapController = ({ boundaries, center, zoom, onViewportChange, shouldAutoFit, sidebarCollapsed }) => {
  const map = useMap();
  const [hasAutoFitted, setHasAutoFitted] = useState(false);
  const [hasRestoredViewport, setHasRestoredViewport] = useState(false);
  const [userHasInteracted, setUserHasInteracted] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      try {
        if (map && map.invalidateSize) {
          map.invalidateSize();
        }
      } catch (e) {
        // Ignore
      }
    }, 100);
    return () => clearTimeout(timer);
  }, [map, sidebarCollapsed]);

  // CRITICAL FIX: Only restore viewport ONCE on initial load
  useEffect(() => {
    if (!map || hasRestoredViewport) return;

    try {
      // If viewport is explicitly set, use it ONCE (user's saved view)
      if (center && zoom) {
        map.setView(center, zoom);
        setHasRestoredViewport(true);
        setHasAutoFitted(true); // Prevent auto-fit after restoring
        return;
      }

      // Only auto-fit once, and only if user hasn't interacted
      if (shouldAutoFit && boundaries?.length > 0 && !hasAutoFitted && !userHasInteracted) {
        const validBoundaries = boundaries.filter(b => b?.geometry);
        if (validBoundaries.length === 0) return;

        const geoJsonGroup = L.geoJSON({
          type: 'FeatureCollection',
          features: validBoundaries.map(b => ({
            type: 'Feature',
            geometry: b.geometry,
            properties: {}
          }))
        });
        
        const bounds = geoJsonGroup.getBounds();
        if (bounds && bounds.isValid && bounds.isValid()) {
          map.fitBounds(bounds, { padding: [50, 50], maxZoom: 12 });
          setHasAutoFitted(true);
        }
      }
    } catch (e) {
      // Ignore
    }
  }, [boundaries, center, zoom, map, shouldAutoFit, hasAutoFitted, userHasInteracted, hasRestoredViewport]);

  // Track user interaction to prevent auto-fit from overriding manual panning
  useEffect(() => {
    if (!map) return;

    const onUserInteraction = () => {
      setUserHasInteracted(true);
    };

    try {
      map.on('dragstart', onUserInteraction);
      map.on('zoomstart', onUserInteraction);
    } catch (e) {
      // Ignore
    }

    return () => {
      try {
        if (map && map.off) {
          map.off('dragstart', onUserInteraction);
          map.off('zoomstart', onUserInteraction);
        }
      } catch (e) {
        // Ignore
      }
    };
  }, [map]);

  // Update viewport on moveend/zoomend
  useEffect(() => {
    if (!map) return;

    const onMoveEnd = () => {
      try {
        const newCenter = map.getCenter();
        const newZoom = map.getZoom();
        if (newCenter && typeof newZoom === 'number') {
          onViewportChange({ center: [newCenter.lat, newCenter.lng], zoom: newZoom });
        }
      } catch (e) {
        // Ignore
      }
    };

    try {
      map.on('moveend', onMoveEnd);
      map.on('zoomend', onMoveEnd);
    } catch (e) {
      // Ignore
    }

    return () => {
      try {
        if (map && map.off) {
          map.off('moveend', onMoveEnd);
          map.off('zoomend', onMoveEnd);
        }
      } catch (e) {
        // Ignore
      }
    };
  }, [map, onViewportChange]);

  return null;
};

const ZctaLabels = ({ boundaries, showLabels }) => {
  const map = useMap();
  const labelsRef = useRef([]);

  useEffect(() => {
    // Cleanup ALL labels first
    labelsRef.current.forEach(label => {
      try {
        if (label && map && map.removeLayer) {
          map.removeLayer(label);
        }
      } catch (e) {
        // Ignore
      }
    });
    labelsRef.current = [];

    if (!showLabels || !map || !boundaries?.length) return;

    // Wait for GeoJSON to settle
    const timer = setTimeout(() => {
      try {
        const newLabels = [];

        boundaries.forEach(boundary => {
          if (!boundary?.geometry) return;

          try {
            const geoJsonLayer = L.geoJSON(boundary.geometry);
            const bounds = geoJsonLayer.getBounds();
            if (!bounds || !bounds.isValid || !bounds.isValid()) return;

            const center = bounds.getCenter();
            if (!center || typeof center.lat !== 'number') return;

            const zcta = boundary.zcta5; // Use ZCTA field consistently
            const label = L.divIcon({
              html: `<div style="background: rgba(255,255,255,0.8); padding: 2px 6px; border-radius: 4px; font-size: 11px; font-weight: bold; border: 1px solid #ccc; color: #333;">${zcta}</div>`,
              className: 'zcta-label',
              iconSize: [null, null]
            });

            const marker = L.marker(center, { icon: label });
            if (map && map.addLayer) {
              marker.addTo(map);
              newLabels.push(marker);
            }
          } catch (e) {
            // Ignore individual label errors
          }
        });

        labelsRef.current = newLabels;
      } catch (e) {
        // Ignore
      }
    }, 300);

    return () => {
      clearTimeout(timer);
      labelsRef.current.forEach(label => {
        try {
          if (label && map && map.removeLayer) {
            map.removeLayer(label);
          }
        } catch (e) {
          // Ignore
        }
      });
      labelsRef.current = [];
    };
  }, [map, boundaries, showLabels]);

  return null;
};

const DataOverlay = ({ boundaries, censusData, colorMetric, showOverlay }) => {
  const map = useMap();
  const overlaysRef = useRef([]);

  useEffect(() => {
    // Cleanup all overlays
    overlaysRef.current.forEach(overlay => {
      try {
        if (overlay && map && map.removeLayer) {
          map.removeLayer(overlay);
        }
      } catch (e) {
        // Ignore
      }
    });
    overlaysRef.current = [];

    if (!showOverlay || !map || !boundaries?.length || !censusData) return;

    const timer = setTimeout(() => {
      try {
        const newOverlays = [];

        boundaries.forEach(boundary => {
          if (!boundary?.geometry) return;

          try {
            const geoJsonLayer = L.geoJSON(boundary.geometry);
            const bounds = geoJsonLayer.getBounds();
            if (!bounds || !bounds.isValid || !bounds.isValid()) return;

            const center = bounds.getCenter();
            if (!center || typeof center.lat !== 'number') return;

            const zcta = boundary.zcta5;
            const data = censusData[zcta];
            if (!data) return;

            let displayValue = '';
            const value = data[colorMetric];
            
            if (value === null || value === undefined) {
              displayValue = 'N/A';
            } else if (colorMetric === 'medianIncome') {
              displayValue = '$' + Math.round(value).toLocaleString();
            } else if (colorMetric === 'population') {
              displayValue = Math.round(value).toLocaleString();
            } else {
              displayValue = value.toFixed(1) + '%';
            }

            const overlay = L.divIcon({
              html: `<div style="color: #1f2937; padding: 2px 4px; font-size: 10px; font-weight: 700; white-space: nowrap; text-shadow: 0 0 3px white, 0 0 3px white, 0 0 3px white;">${displayValue}</div>`,
              className: 'data-overlay',
              iconSize: [null, null]
            });

            const marker = L.marker(center, { icon: overlay });
            if (map && map.addLayer) {
              marker.addTo(map);
              newOverlays.push(marker);
            }
          } catch (e) {
            // Ignore
          }
        });

        overlaysRef.current = newOverlays;
      } catch (e) {
        // Ignore
      }
    }, 300);

    return () => {
      clearTimeout(timer);
      overlaysRef.current.forEach(overlay => {
        try {
          if (overlay && map && map.removeLayer) {
            map.removeLayer(overlay);
          }
        } catch (e) {
          // Ignore
        }
      });
      overlaysRef.current = [];
    };
  }, [map, boundaries, censusData, colorMetric, showOverlay]);

  return null;
};

export default function InteractiveMap({
  zipBoundaries, // Keep prop name for compatibility
  organizations = [],
  center,
  selectedZips = [],
  colorMetric = 'population',
  showRadiusReference,
  radiusMiles = 10,
  showCompetitors = true,
  onShowCompetitorsChange,
  assessment,
  censusData = {},
  isLoadingCensusData,
  viewport,
  onViewportChange,
  mapSettings,
  onMapSettingsChange,
  sidebarCollapsed = false,
  metricDisplayName // Optional: human-readable name for custom metrics
}) {
  const [isMapReady, setIsMapReady] = useState(false);

  // Check if pre-processed GeoJSON is available
  const preprocessedGeoJSON = assessment?.processed_data?.trimmed_geojson;
  const usePreprocessed = preprocessedGeoJSON?.features?.length > 0;

  // Filter boundaries to only include selected ZCTAs
  const effectiveBoundaries = useMemo(() => {
    const selectedZctaSet = new Set(selectedZips || []); // Keep selectedZips for compatibility
    
    if (usePreprocessed && preprocessedGeoJSON?.features?.length > 0) {
      console.log(`Using pre-processed GeoJSON with ${preprocessedGeoJSON.features.length} features`);
      const allBoundaries = preprocessedGeoJSON.features.map(feature => ({
        zcta5: feature.properties.zcta5 || feature.properties.ZCTA5CE10,
        geometry: feature.geometry,
        state_name: feature.properties.state_name,
        state_abbr: feature.properties.state_abbr
      }));
      
      const filteredBoundaries = allBoundaries.filter(b => selectedZctaSet.has(b.zcta5));
      console.log(`Filtered pre-processed boundaries: ${filteredBoundaries.length}/${allBoundaries.length} match selected ZCTAs`);
      return filteredBoundaries;
    }
    
    // Filter regular boundaries by selected ZCTAs
    const filtered = (zipBoundaries || []).filter(b => b && selectedZctaSet.has(b.zcta5));
    console.log(`Filtered boundaries: ${filtered.length}/${zipBoundaries?.length || 0} match selected ZCTAs`);
    return filtered;
  }, [usePreprocessed, preprocessedGeoJSON, zipBoundaries, selectedZips]);

  const { initialCenter, initialZoom, shouldAutoFit } = useMemo(() => {
    if (viewport?.center && viewport?.zoom) {
      return { initialCenter: viewport.center, initialZoom: viewport.zoom, shouldAutoFit: false };
    }

    if (effectiveBoundaries?.length > 0) {
      const firstBoundary = effectiveBoundaries[0];
      if (firstBoundary?.geometry) {
        try {
          const geoJsonLayer = L.geoJSON(firstBoundary.geometry);
          const bounds = geoJsonLayer.getBounds();
          const centerPoint = bounds.getCenter();
          return { initialCenter: [centerPoint.lat, centerPoint.lng], initialZoom: 9, shouldAutoFit: true };
        } catch (e) {
          // Fall through
        }
      }
    }

    if (center?.latitude && center?.longitude) {
      return { initialCenter: [center.latitude, center.longitude], initialZoom: 9, shouldAutoFit: false };
    }
    return { initialCenter: [39.8283, -98.5795], initialZoom: 4, shouldAutoFit: false };
  }, [viewport, effectiveBoundaries, center]);

  const validBoundaries = useMemo(() =>
    (effectiveBoundaries || []).filter(b => b?.geometry),
    [effectiveBoundaries]
  );

  const { geoJsonData, allMetricValues } = useMemo(() => {
    const collectedMetricValues = [];
    const features = validBoundaries.map(boundary => {
      const zcta = boundary.zcta5; // Use zcta5 consistently
      const dataForZcta = censusData?.[zcta] || {};

      const value = parseFloat(dataForZcta[colorMetric]);
      if (!isNaN(value) && value !== null) {
        collectedMetricValues.push(value);
      }

      // Merge all data properties into feature properties
      const properties = {
        zcta5: zcta,
        state_name: boundary.state_name,
        ...dataForZcta // Include all census/health data dynamically
      };

      return {
        type: 'Feature',
        geometry: boundary.geometry,
        properties
      };
    });

    return {
      geoJsonData: { type: 'FeatureCollection', features },
      allMetricValues: collectedMetricValues
    };
  }, [validBoundaries, colorMetric, censusData]);

  const getFeatureStyle = useCallback((feature) => {
    const data = feature?.properties;
    if (!data) return { color: '#ffffff', weight: 1.5, opacity: 0.6, fillColor: '#cccccc', fillOpacity: 0.5 };

    const value = parseFloat(data[colorMetric]);
    const fillColor = getColorByMetric(value, colorMetric, allMetricValues, mapSettings?.colorScale);
    return { color: '#ffffff', weight: 1.5, opacity: 0.6, fillColor, fillOpacity: 0.5 };
  }, [colorMetric, allMetricValues, mapSettings?.colorScale]);

  const onEachFeature = useCallback((feature, layer) => {
    if (!feature?.properties?.zcta5 || !layer) return;

    const props = feature.properties;
    
    // Check if this is health data or demographic data based on available fields
    const isHealthData = colorMetric && !['population', 'medianIncome', 'povertyRate', 'uninsuredRate'].includes(colorMetric);
    
    let popupContent = '';
    
    if (isHealthData) {
      // Show health indicators in the popup
      const healthMetrics = Object.keys(props).filter(key => 
        key !== 'zcta5' && key !== 'state_name' && key !== 'source' && 
        key !== 'population' && key !== 'medianIncome' && key !== 'povertyRate' && key !== 'uninsuredRate'
      );
      
      popupContent = `
        <div style="min-width: 220px; font-family: system-ui, -apple-system, sans-serif;">
          <div style="border-bottom: 2px solid #3b82f6; padding-bottom: 8px; margin-bottom: 12px;">
            <div style="font-size: 18px; font-weight: bold; color: #1f2937;">ZCTA ${props.zcta5}</div>
          </div>
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 12px;">
            ${healthMetrics.slice(0, 4).map(metric => {
              const value = props[metric];
              const displayValue = value !== null && value !== undefined && !isNaN(value) ? `${parseFloat(value).toFixed(1)}%` : 'N/A';
              const metricName = metric.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
              return `
                <div style="background: #f3f4f6; padding: 8px; border-radius: 6px;">
                  <div style="font-size: 10px; color: #6b7280; text-transform: uppercase; font-weight: 600;">${metricName}</div>
                  <div style="font-size: 16px; font-weight: bold; color: #1f2937;">${displayValue}</div>
                </div>
              `;
            }).join('')}
          </div>
          <div style="padding-top: 8px; border-top: 1px solid #e5e7eb;">
            <div style="font-size: 11px; color: #9ca3af;"><strong>Data Source:</strong> ${props.source || 'CDC PLACES'}</div>
          </div>
        </div>
      `;
    } else {
      // Show demographic data in the popup
      // Robust validation for all demographic fields
      const population = (typeof props.population === 'number' && !isNaN(props.population) && props.population > 0)
        ? Math.round(props.population).toLocaleString()
        : 'N/A';
      
      const medianIncome = (typeof props.medianIncome === 'number' && !isNaN(props.medianIncome) && props.medianIncome > 0 && props.medianIncome < 500000)
        ? '$' + Math.round(props.medianIncome).toLocaleString()
        : (props.medianIncome === 0 || props.medianIncome === null) ? 'N/A' : 'N/A';
      
      const povertyRate = (typeof props.povertyRate === 'number' && !isNaN(props.povertyRate) && props.povertyRate >= 0)
        ? parseFloat(props.povertyRate).toFixed(1) + '%'
        : 'N/A';
      
      const uninsuredRate = (typeof props.uninsuredRate === 'number' && !isNaN(props.uninsuredRate) && props.uninsuredRate >= 0)
        ? parseFloat(props.uninsuredRate).toFixed(1) + '%'
        : 'N/A';
      
      popupContent = `
        <div style="min-width: 220px; font-family: system-ui, -apple-system, sans-serif;">
          <div style="border-bottom: 2px solid #3b82f6; padding-bottom: 8px; margin-bottom: 12px;">
            <div style="font-size: 18px; font-weight: bold; color: #1f2937;">ZCTA ${props.zcta5}</div>
            <div style="font-size: 12px; color: #6b7280;">${props.state_name || ''}</div>
          </div>
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 12px;">
            <div style="background: #f3f4f6; padding: 8px; border-radius: 6px;">
              <div style="font-size: 10px; color: #6b7280; text-transform: uppercase; font-weight: 600;">Population</div>
              <div style="font-size: 16px; font-weight: bold; color: #1f2937;">${population}</div>
            </div>
            <div style="background: #f3f4f6; padding: 8px; border-radius: 6px;">
              <div style="font-size: 10px; color: #6b7280; text-transform: uppercase; font-weight: 600;">Med. Income</div>
              <div style="font-size: 16px; font-weight: bold; color: #1f2937;">${medianIncome}</div>
            </div>
            <div style="background: #f3f4f6; padding: 8px; border-radius: 6px;">
              <div style="font-size: 10px; color: #6b7280; text-transform: uppercase; font-weight: 600;">Poverty</div>
              <div style="font-size: 16px; font-weight: bold; color: #1f2937;">${povertyRate}</div>
            </div>
            <div style="background: #f3f4f6; padding: 8px; border-radius: 6px;">
              <div style="font-size: 10px; color: #6b7280; text-transform: uppercase; font-weight: 600;">Uninsured</div>
              <div style="font-size: 16px; font-weight: bold; color: #1f2937;">${uninsuredRate}</div>
            </div>
          </div>
          <div style="padding-top: 8px; border-top: 1px solid #e5e7eb;">
            <div style="font-size: 11px; color: #9ca3af;"><strong>Data Source:</strong> ${props.source || 'US Census Bureau ACS'}</div>
          </div>
        </div>
      `;
    }

    try {
      if (layer.bindPopup) {
        layer.bindPopup(popupContent, { maxWidth: 300, autoClose: false, closeOnClick: false });
      }
    } catch (e) {
      // Ignore
    }
  }, [colorMetric]);

  const competitorSites = useMemo(() => {
    const sites = [];
    (organizations || []).forEach(org => {
      if (org?.sites?.length > 0) {
        org.sites.forEach(site => {
          if (site?.coordinates?.latitude && site?.coordinates?.longitude) {
            sites.push({ ...site, id: `${org.id}_${site.name}`, parentName: org.name, parentType: org.type });
          }
        });
      } else if (org?.coordinates?.latitude && org?.coordinates?.longitude) {
        sites.push({ id: org.id, name: org.name, address: org.address, parentName: org.name, parentType: org.type, coordinates: org.coordinates });
      }
    });
    return sites;
  }, [organizations]);

  // Add delay before showing map to ensure it's fully ready
  useEffect(() => {
    const timer = setTimeout(() => setIsMapReady(true), 100);
    return () => clearTimeout(timer);
  }, []);

  // Legend component with facility types
  const MapLegend = () => {
    const legendInfo = useMemo(() => {
      const predefinedLegends = {
        population: { title: 'Population', unit: '' },
        medianIncome: { title: 'Median Income', unit: '$' },
        povertyRate: { title: 'Poverty Rate', unit: '%' },
        uninsuredRate: { title: 'Uninsured Rate', unit: '%' }
      };

      const values = Object.values(censusData || {})
        .map(data => data[colorMetric])
        .filter(val => val !== null && val !== undefined && !isNaN(val));

      if (values.length === 0) {
        return { 
          title: predefinedLegends[colorMetric]?.title || colorMetric, 
          unit: '%',
          minValue: 'N/A', 
          maxValue: 'N/A' 
        };
      }

      const minValue = Math.min(...values);
      const maxValue = Math.max(...values);

      // Use predefined legend or create dynamic one
      let legend;
      if (predefinedLegends[colorMetric]) {
        legend = predefinedLegends[colorMetric];
      } else {
        // Dynamic legend for health metrics or other custom metrics
        const metricName = metricDisplayName || colorMetric.replace(/_/g, ' ').toLowerCase()
          .replace(/\b\w/g, l => l.toUpperCase());
        legend = { 
          title: metricName, 
          unit: '%' // Default to % for health metrics
        };
      }

      return {
        ...legend,
        minValue: legend.unit === '$' ?
          new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0 }).format(minValue) :
          legend.unit === '' && minValue > 100 ? minValue.toLocaleString() :
          `${minValue.toFixed(1)}${legend.unit}`,
        maxValue: legend.unit === '$' ?
          new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0 }).format(maxValue) :
          legend.unit === '' && maxValue > 100 ? maxValue.toLocaleString() :
          `${maxValue.toFixed(1)}${legend.unit}`
      };
    }, [colorMetric, censusData]);

    // Generate gradient background for legend
    const gradientBackground = useMemo(() => {
      const scaleKey = mapSettings?.colorScale || 'viridis';
      
      // For palette-based schemes, create gradient from palette colors
      if (COLOR_PALETTES[scaleKey]) {
        const palette = COLOR_PALETTES[scaleKey];
        return `linear-gradient(to right, ${palette.join(', ')})`;
      }
      
      // For legacy RGB scales
      const scale = COLOR_SCALES[scaleKey] || COLOR_SCALES.blue;
      return `linear-gradient(to right, rgb(${scale.low.join(',')}), rgb(${scale.high.join(',')}))`;
    }, [mapSettings?.colorScale]);

    return (
      <div className="absolute bottom-6 left-6 bg-white/95 backdrop-blur-sm border border-gray-200 rounded-lg shadow-lg p-4 z-[1000] min-w-[200px]">
        <div className="space-y-3">
          {/* ZIP Code Color Legend */}
          <div>
            <p className="text-sm font-semibold text-gray-800 mb-2">{legendInfo.title}</p>
            <div className="flex items-center justify-between bg-gray-50 p-2 rounded-md border min-w-[180px]">
              <span className="text-xs text-gray-600 whitespace-nowrap">{legendInfo.minValue}</span>
              <div className="flex-1 h-3 mx-2 rounded min-w-[80px]" style={{ background: gradientBackground }}></div>
              <span className="text-xs text-gray-600 whitespace-nowrap">{legendInfo.maxValue}</span>
            </div>
          </div>

          {/* Facility Type Legend */}
          {showCompetitors && competitorSites.length > 0 && (
            <div className="pt-3 border-t border-gray-200">
              <p className="text-sm font-semibold text-gray-800 mb-2">Healthcare Facilities</p>
              <div className="space-y-1.5">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-600 border-2 border-white shadow-sm"></div>
                  <span className="text-xs text-gray-700">Hospitals</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-green-600 border-2 border-white shadow-sm"></div>
                  <span className="text-xs text-gray-700">FQHCs</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-blue-600 border-2 border-white shadow-sm"></div>
                  <span className="text-xs text-gray-700">Clinics</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-gray-600 border-2 border-white shadow-sm"></div>
                  <span className="text-xs text-gray-700">Other</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <Card className="relative z-0">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 flex-wrap">
            <MapIcon className="w-5 h-5" />
            Service Area Map
            <Badge variant="secondary">{selectedZips.length} ZCTAs</Badge>
            {validBoundaries.length > 0 && (
              <Badge variant="outline" className="text-green-600 border-green-200">
                {validBoundaries.length} boundaries loaded
              </Badge>
            )}
            {usePreprocessed && (
              <Badge className="bg-emerald-100 text-emerald-800 border-emerald-200">
                ⚡ Pre-processed (Instant Loading)
              </Badge>
            )}
            {validBoundaries.length !== selectedZips.length && selectedZips.length > 0 && (
              <Badge variant="outline" className="text-amber-600 border-amber-200">
                ⚠ {selectedZips.length - validBoundaries.length} boundaries missing
              </Badge>
            )}
            {organizations.length > 0 && (
              <Badge variant="outline" className="text-blue-600 border-blue-200">{competitorSites.length} competitor sites</Badge>
            )}
            <Badge variant="outline" className="text-gray-600 border-gray-200 capitalize">
              Colored by: {colorMetric.replace(/([A-Z])/g, ' $1').trim()}
            </Badge>
            {Object.values(censusData || {}).some(d => d.source && d.source.includes('Census')) && (
              <Badge variant="outline" className="text-emerald-600 border-emerald-200">Real Census Data</Badge>
            )}
            {isLoadingCensusData && (
              <Badge variant="outline" className="text-orange-600 border-orange-200">
                <Loader2 className="w-3 h-3 mr-1 animate-spin" />Loading Data
              </Badge>
            )}
          </CardTitle>
          {/* Map settings and competitor toggle UI moved out of this component, now controlled by props */}
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-[700px] w-full rounded-lg border border-gray-200 overflow-hidden relative">
          {validBoundaries.length === 0 ? (
            <div className="h-full flex items-center justify-center bg-gray-50">
              <div className="text-center">
                <MapIcon className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-600 mb-2">No ZCTA boundaries loaded yet</p>
                <p className="text-sm text-gray-500">Use "Smart Pre-Process" in Geography Controls to prepare your map</p>
              </div>
            </div>
          ) : (
            <>
              <MapContainer
                key="stable-map-instance"
                center={initialCenter}
                zoom={initialZoom}
                style={{ height: '100%', width: '100%' }}
                scrollWheelZoom={true}
                zoomControl={true}
              >
                <TileLayer
                  attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                  maxZoom={19}
                />
                {showRadiusReference && center?.latitude && center?.longitude && (
                  <Circle 
                    center={[center.latitude, center.longitude]} 
                    radius={radiusMiles * 1609.34} 
                    pathOptions={{ 
                      color: radiusMiles === 10 ? '#f97316' : radiusMiles === 30 ? '#3b82f6' : '#8b5cf6',
                      dashArray: '5, 10', 
                      fillOpacity: 0.05,
                      weight: 2 
                    }} 
                  />
                )}
                {isMapReady && validBoundaries.length > 0 && (
                  <GeoJSON 
                    data={geoJsonData} 
                    style={getFeatureStyle} 
                    onEachFeature={onEachFeature}
                  />
                )}
                <ZctaLabels boundaries={validBoundaries} showLabels={mapSettings?.showZipLabels} />
                <DataOverlay 
                  boundaries={validBoundaries} 
                  censusData={censusData}
                  colorMetric={colorMetric}
                  showOverlay={mapSettings?.showDataOverlay} 
                />
                {showCompetitors && competitorSites.map(site => {
                  if (!site?.coordinates) return null;
                  
                  const lat = parseFloat(site.coordinates.latitude);
                  const lng = parseFloat(site.coordinates.longitude);
                  
                  if (isNaN(lat) || isNaN(lng)) return null;
                  
                  return (
                    <Marker 
                      key={`marker-${site.id}`}
                      position={[lat, lng]} 
                      icon={getOrgIcon(site.parentType)}
                    >
                      <Popup>
                        <div>
                          <div className="text-sm font-bold text-gray-900 mb-1">{site.parentName || 'Unknown'}</div>
                          <div className="text-xs text-gray-600 mb-2">{site.name || 'N/A'}</div>
                          <div className="text-xs text-gray-500 capitalize mb-1">{site.parentType?.replace('_', ' ') || 'N/A'}</div>
                          <div className="text-xs text-gray-600">{site.address || 'N/A'}</div>
                        </div>
                      </Popup>
                    </Marker>
                  );
                })}
                <MapController 
                  boundaries={validBoundaries} 
                  center={viewport?.center} 
                  zoom={viewport?.zoom} 
                  onViewportChange={onViewportChange} 
                  shouldAutoFit={shouldAutoFit}
                  sidebarCollapsed={sidebarCollapsed}
                />
              </MapContainer>
              <MapLegend />
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );
}