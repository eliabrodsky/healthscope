
// MapZipChoropleth.jsx
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { GeoJSON } from 'react-leaflet';

const MapZipChoropleth = ({
  zipBoundaries, // Expected to be a GeoJSON object with 'features' array
  selectedZipCodes = [], // Array of strings, e.g., ['90210', '90211']
  overlay, // String, indicates the type of data to be displayed (e.g., 'population', 'income') - used for demo data generation
  colorScale = 'Blues', // String, e.g., 'Blues', 'Reds', 'Greens'
  opacity = 0.7, // Number, overall fill opacity for the choropleth
  onZipCodeClick, // Function, callback when a zip code area is clicked (receives zipCode as argument)
  onDataRangeChange // Function, callback to report min/max values of the currently displayed data ({ min, max })
}) => {
  const [mapData, setMapData] = useState({});

  // Helper function to generate demo data values for each ZIP code
  // In a real application, this data would come from props or an API call.
  const generateDemoValue = useCallback((zipCode, dataType, index) => {
    // Example demo data generation:
    // A value based on the numeric part of the zip code, plus some randomness
    const numericPart = parseInt(zipCode?.replace(/\D/g, '').slice(-3) || '0', 10);
    const baseValue = (numericPart % 100) + (index % 50); // Provide some spread
    const randomModifier = Math.random() * 30; // Add some randomness for variety
    return baseValue + randomModifier;
  }, []);

  // Memoize the GeoJSON features from the zipBoundaries prop
  const geoJsonFeatures = useMemo(() => {
    return zipBoundaries?.features || [];
  }, [zipBoundaries]);

  // Effect to generate demo data (or process real data if passed) and report the data range
  useEffect(() => {
    const demoData = {};
    geoJsonFeatures.forEach((feature, index) => {
      // Common property names for ZIP codes in GeoJSONs are 'zip_code' or 'ZCTA5CE10'
      const zipCode = feature.properties?.zip_code || feature.properties?.ZCTA5CE10;
      if (zipCode) {
        demoData[zipCode] = generateDemoValue(zipCode, overlay, index);
      }
    });
    setMapData(demoData);

    const values = Object.values(demoData);
    if (values.length > 0) {
      const min = Math.min(...values);
      const max = Math.max(...values);
      if (onDataRangeChange) {
        onDataRangeChange({ min, max });
      }
    } else {
      if (onDataRangeChange) {
        onDataRangeChange({ min: 0, max: 0 }); // Report zero range if no data
      }
    }
  }, [overlay, geoJsonFeatures, generateDemoValue, onDataRangeChange]);

  // Callback to determine the fill color for a given value based on the color scale
  const getColor = useCallback((value, dataType) => {
    if (value === undefined || value === null) return '#f0f0f0'; // Default light grey for no data

    const values = Object.values(mapData);
    const min = values.length > 0 ? Math.min(...values) : 0;
    const max = values.length > 0 ? Math.max(...values) : 100; // Default max if no data

    // Avoid division by zero if min and max are the same
    const range = max - min;
    if (range === 0) return '#bddeff'; // Return a mid-range blue if all values are the same or no range

    const normalized = (value - min) / range;
    // Scale intensity to a visible range (e.g., 50 to 255) for better color distinction
    const intensity = Math.floor(normalized * 205) + 50;

    if (colorScale === 'Reds') return `rgb(255, ${255 - intensity}, ${255 - intensity})`;
    if (colorScale === 'Greens') return `rgb(${255 - intensity}, 255, ${255 - intensity})`;
    return `rgb(${255 - intensity}, ${255 - intensity}, 255)`; // Blues default
  }, [colorScale, mapData]);

  // Callback to define the style for each GeoJSON feature (ZIP code boundary)
  const getZipStyle = useCallback((feature) => {
    const zipCode = feature.properties?.zip_code || feature.properties?.ZCTA5CE10;
    const value = mapData[zipCode];
    // A zip code is considered 'selected' if selectedZipCodes is empty (meaning all are implicitly selected)
    // or if its ID is explicitly in the selectedZipCodes array.
    const isSelected = selectedZipCodes.length === 0 || selectedZipCodes.includes(zipCode);

    const effectiveOpacity = typeof opacity === 'number' ? Math.max(0, Math.min(1, opacity)) : 0.7; // Ensure opacity is between 0 and 1
    const nonSelectedFillOpacity = isSelected ? effectiveOpacity : effectiveOpacity * 0.3; // Dim non-selected areas

    return {
      fillColor: getColor(value, overlay),
      weight: isSelected ? 2 : 0.5, // Thicker border for selected ZIPs
      opacity: isSelected ? 1 : 0.3, // Border opacity
      color: isSelected ? '#1d4ed8' : 'white', // Border color (e.g., a Tailwind blue-700 for selected)
      fillOpacity: nonSelectedFillOpacity, // Fill opacity
    };
  }, [mapData, selectedZipCodes, getColor, overlay, opacity]);

  // Callback for actions on each GeoJSON layer (e.g., binding popups, click handlers)
  const onEachZip = useCallback((feature, layer) => {
    const zipCode = feature.properties?.zip_code || feature.properties?.ZCTA5CE10;
    const value = mapData[zipCode];

    // Bind a tooltip/popup to show ZIP code and its value
    if (zipCode && value !== undefined) {
      layer.bindTooltip(`ZIP: ${zipCode}<br>${overlay || 'Value'}: ${value.toFixed(2)}`);
    } else if (zipCode) {
      layer.bindTooltip(`ZIP: ${zipCode}<br>No data available`);
    }

    // Add click event listener
    layer.on({
      click: (e) => {
        if (onZipCodeClick) {
          onZipCodeClick(zipCode);
        }
        // Optional: Bring clicked layer to front for better visibility
        // e.target.bringToFront();
      },
      // Optional: Add hover effect
      // mouseover: (e) => {
      //   e.target.setStyle({
      //     weight: 3,
      //     color: '#666',
      //     dashArray: '',
      //     fillOpacity: 0.7
      //   });
      // },
      // mouseout: (e) => {
      //   // Reset style on mouseout, use layer.resetStyle to apply original style from getZipStyle
      //   // e.target.setStyle(getZipStyle(feature)); // This doesn't work directly with resetStyle
      //   layer.resetStyle(e.target); // This resets to the initial style passed to GeoJSON
      // }
    });
  }, [mapData, onZipCodeClick, overlay]); // Depend on mapData and overlay to ensure tooltips update

  // Render the GeoJSON layer
  // The 'key' prop is important for GeoJSON components in react-leaflet.
  // Changing the key forces react-leaflet to re-create the layer, which is crucial
  // when the underlying data or style logic dependencies change.
  return (
    <GeoJSON
      key={`${geoJsonFeatures.length}-${selectedZipCodes.join(',')}-${overlay}-${colorScale}-${opacity}`}
      data={{ type: "FeatureCollection", features: geoJsonFeatures }}
      style={getZipStyle}
      onEachFeature={onEachZip}
    />
  );
};

export default MapZipChoropleth;
