import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Upload, FileText, Loader2, X } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

export default function CHNAUploader({ assessment, onDataAdded }) {
  const [isUploading, setIsUploading] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState([]);

  const handleFileUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const validTypes = ['application/pdf', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'text/plain'];
    if (!validTypes.includes(file.type)) {
      toast.error('Please upload PDF, DOCX, or TXT files');
      return;
    }

    setIsUploading(true);
    toast.loading('Uploading CHNA document...', { id: 'chna-upload' });

    try {
      const uploadResponse = await base44.integrations.Core.UploadFile({ file });
      const fileUrl = uploadResponse.file_url;

      // Extract insights from the uploaded document
      toast.loading('Analyzing document...', { id: 'chna-upload' });

      const analysisPrompt = `
Analyze this Community Health Needs Assessment (CHNA) document and extract:
1. Key health needs identified
2. Priority populations
3. Service gaps mentioned
4. Recommended interventions
5. Relevant statistics or data points

Assessment context: ${assessment.title}
Location: ${assessment.geography?.city || 'N/A'}, ${assessment.geography?.state || 'N/A'}
      `;

      const analysis = await base44.integrations.Core.InvokeLLM({
        prompt: analysisPrompt,
        file_urls: [fileUrl],
        response_json_schema: {
          type: 'object',
          properties: {
            key_needs: { type: 'array', items: { type: 'string' } },
            priority_populations: { type: 'array', items: { type: 'string' } },
            service_gaps: { type: 'array', items: { type: 'string' } },
            interventions: { type: 'array', items: { type: 'string' } },
            statistics: { type: 'array', items: { type: 'string' } }
          }
        }
      });

      const fileData = {
        name: file.name,
        url: fileUrl,
        type: file.type,
        uploadedAt: new Date().toISOString(),
        analysis: analysis.output || analysis
      };

      setUploadedFiles(prev => [...prev, fileData]);
      
      if (onDataAdded) {
        onDataAdded(fileData);
      }

      toast.success('CHNA document analyzed successfully!', { id: 'chna-upload' });

    } catch (error) {
      console.error('Upload error:', error);
      toast.error('Failed to upload or analyze document', { id: 'chna-upload' });
    } finally {
      setIsUploading(false);
    }
  };

  const handleRemoveFile = (index) => {
    setUploadedFiles(prev => prev.filter((_, idx) => idx !== index));
    toast.success('File removed');
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="w-5 h-5" />
          CHNA Document Upload
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-gray-600">
          Upload Community Health Needs Assessments to enrich your presentation with external insights
        </p>

        <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-emerald-500 transition-colors">
          <Input
            type="file"
            accept=".pdf,.docx,.txt"
            onChange={handleFileUpload}
            disabled={isUploading}
            className="hidden"
            id="chna-upload"
          />
          <label htmlFor="chna-upload" className="cursor-pointer">
            {isUploading ? (
              <div className="flex flex-col items-center gap-2">
                <Loader2 className="w-8 h-8 text-emerald-600 animate-spin" />
                <p className="text-sm text-gray-600">Analyzing document...</p>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-2">
                <Upload className="w-8 h-8 text-gray-400" />
                <p className="text-sm text-gray-600">Click to upload CHNA document</p>
                <p className="text-xs text-gray-500">PDF, DOCX, or TXT</p>
              </div>
            )}
          </label>
        </div>

        {uploadedFiles.length > 0 && (
          <div className="space-y-2">
            <p className="text-sm font-medium text-gray-700">Uploaded Documents:</p>
            {uploadedFiles.map((file, idx) => (
              <div key={idx} className="flex items-center justify-between p-3 bg-emerald-50 border border-emerald-200 rounded-lg">
                <div className="flex items-center gap-2 flex-1">
                  <FileText className="w-4 h-4 text-emerald-600" />
                  <span className="text-sm text-gray-900 truncate">{file.name}</span>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleRemoveFile(idx)}
                  className="text-red-600 hover:text-red-700 hover:bg-red-50"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}