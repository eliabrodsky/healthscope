import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
  Plus,
  Trash2,
  Save,
  X,
  Eye,
  ChevronUp,
  ChevronDown,
  FileText
} from "lucide-react";
import { toast } from "sonner";

export default function PresentationEditor({ presentation, onSave, onClose, onPreview }) {
  const [title, setTitle] = useState(presentation.title);
  const [slides, setSlides] = useState(presentation.slides || []);
  const [selectedSlide, setSelectedSlide] = useState(0);

  const addSlide = () => {
    const newSlide = {
      id: Date.now(),
      title: `New Slide ${slides.length + 1}`,
      content: 'Enter slide content here...'
    };
    setSlides([...slides, newSlide]);
    setSelectedSlide(slides.length);
  };

  const removeSlide = (index) => {
    if (slides.length === 1) {
      toast.error('You must have at least one slide');
      return;
    }
    const newSlides = slides.filter((_, idx) => idx !== index);
    setSlides(newSlides);
    setSelectedSlide(Math.max(0, selectedSlide - 1));
  };

  const updateSlide = (index, field, value) => {
    const newSlides = [...slides];
    newSlides[index] = { ...newSlides[index], [field]: value };
    setSlides(newSlides);
  };

  const moveSlide = (index, direction) => {
    const newIndex = direction === 'up' ? index - 1 : index + 1;
    if (newIndex < 0 || newIndex >= slides.length) return;
    
    const newSlides = [...slides];
    [newSlides[index], newSlides[newIndex]] = [newSlides[newIndex], newSlides[index]];
    setSlides(newSlides);
    setSelectedSlide(newIndex);
  };

  const handleSave = () => {
    onSave({ title, slides });
  };

  const handlePreview = () => {
    onPreview({ ...presentation, title, slides });
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <Card className="border-2 border-emerald-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between gap-4">
              <div className="flex-1">
                <Input
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="text-2xl font-bold border-0 shadow-none p-0 h-auto focus-visible:ring-0"
                  placeholder="Presentation Title"
                />
                <p className="text-sm text-gray-600 mt-2">{presentation.assessment_title}</p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" onClick={onClose}>
                  <X className="w-4 h-4 mr-2" />
                  Close
                </Button>
                <Button variant="outline" onClick={handlePreview}>
                  <Eye className="w-4 h-4 mr-2" />
                  Preview
                </Button>
                <Button onClick={handleSave} className="bg-emerald-600 hover:bg-emerald-700">
                  <Save className="w-4 h-4 mr-2" />
                  Save
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="grid lg:grid-cols-4 gap-6">
          {/* Slide List */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Slides</CardTitle>
                <Button onClick={addSlide} size="sm" className="bg-emerald-600 hover:bg-emerald-700">
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-2">
              {slides.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <FileText className="w-8 h-8 mx-auto mb-2 text-gray-300" />
                  <p className="text-sm">No slides yet</p>
                  <Button onClick={addSlide} size="sm" className="mt-3" variant="outline">
                    Add First Slide
                  </Button>
                </div>
              ) : (
                slides.map((slide, idx) => (
                  <div
                    key={slide.id || idx}
                    className={`p-3 rounded-lg border-2 cursor-pointer transition-all ${
                      selectedSlide === idx
                        ? 'border-emerald-500 bg-emerald-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onClick={() => setSelectedSlide(idx)}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <Badge variant="outline" className="text-xs mb-1">
                          Slide {idx + 1}
                        </Badge>
                        <p className="text-sm font-medium truncate">{slide.title}</p>
                      </div>
                      <div className="flex flex-col gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            moveSlide(idx, 'up');
                          }}
                          disabled={idx === 0}
                          className="h-6 w-6 p-0"
                        >
                          <ChevronUp className="w-3 h-3" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            moveSlide(idx, 'down');
                          }}
                          disabled={idx === slides.length - 1}
                          className="h-6 w-6 p-0"
                        >
                          <ChevronDown className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>

          {/* Slide Editor */}
          <Card className="lg:col-span-3">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>
                  {slides.length > 0 ? `Editing Slide ${selectedSlide + 1}` : 'No Slide Selected'}
                </CardTitle>
                {slides.length > 0 && (
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => removeSlide(selectedSlide)}
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Delete Slide
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {slides.length > 0 && slides[selectedSlide] ? (
                <>
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-2 block">
                      Slide Title
                    </label>
                    <Input
                      value={slides[selectedSlide].title}
                      onChange={(e) => updateSlide(selectedSlide, 'title', e.target.value)}
                      placeholder="Enter slide title"
                      className="text-lg font-semibold"
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-2 block">
                      Slide Content
                    </label>
                    <Textarea
                      value={slides[selectedSlide].content}
                      onChange={(e) => updateSlide(selectedSlide, 'content', e.target.value)}
                      placeholder="Enter slide content"
                      rows={12}
                      className="font-mono text-sm"
                    />
                  </div>

                  {/* Preview */}
                  <div className="border-t pt-4">
                    <label className="text-sm font-medium text-gray-700 mb-3 block">
                      Live Preview
                    </label>
                    <div className="bg-white border-2 border-gray-200 rounded-lg p-8 min-h-[300px]">
                      <h2 className="text-3xl font-bold text-gray-900 mb-4">
                        {slides[selectedSlide].title}
                      </h2>
                      <div className="text-gray-700 whitespace-pre-wrap">
                        {slides[selectedSlide].content}
                      </div>
                    </div>
                  </div>
                </>
              ) : (
                <div className="text-center py-16 text-gray-500">
                  <FileText className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                  <p className="text-lg mb-2">No slides in this presentation</p>
                  <Button onClick={addSlide} className="bg-emerald-600 hover:bg-emerald-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Your First Slide
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}