import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { AlertTriangle, Users, Building2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export default function SlideHPSA({ assessment, censusData, organizations, zipCodes }) {
  const hpsaData = useMemo(() => {
    if (!censusData || Object.keys(censusData).length === 0) return null;

    const totalPop = Object.values(censusData).reduce((sum, d) => sum + (d.population || 0), 0);
    const primaryCareProviders = (organizations || []).filter(o => 
      o.type === 'fqhc' || o.type === 'clinic' || o.type === 'hospital'
    ).length;

    const pcpRatio = totalPop / Math.max(1, primaryCareProviders);
    const isHPSA = pcpRatio > 3500;

    const underservedZips = Object.entries(censusData)
      .filter(([_, data]) => {
        const poverty = data.povertyRate || 0;
        const uninsured = data.uninsuredRate || 0;
        return poverty > 20 || uninsured > 15;
      })
      .map(([zip, data]) => ({
        zip,
        population: data.population || 0,
        povertyRate: data.povertyRate || 0,
        uninsuredRate: data.uninsuredRate || 0,
        score: (data.povertyRate || 0) + (data.uninsuredRate || 0)
      }))
      .sort((a, b) => b.score - a.score)
      .slice(0, 10);

    const shortageMetrics = [
      {
        metric: 'Population-to-PCP Ratio',
        current: Math.round(pcpRatio),
        threshold: 3500,
        status: isHPSA ? 'Shortage' : 'Adequate'
      },
      {
        metric: 'High-Poverty ZIPs',
        current: Object.values(censusData).filter(d => (d.povertyRate || 0) > 20).length,
        threshold: Math.round(zipCodes.length * 0.2),
        status: Object.values(censusData).filter(d => (d.povertyRate || 0) > 20).length > zipCodes.length * 0.2 ? 'High Risk' : 'Moderate'
      },
      {
        metric: 'Avg Uninsured Rate',
        current: (Object.values(censusData).reduce((sum, d) => sum + (d.uninsuredRate || 0), 0) / Object.keys(censusData).length).toFixed(1),
        threshold: 10,
        status: (Object.values(censusData).reduce((sum, d) => sum + (d.uninsuredRate || 0), 0) / Object.keys(censusData).length) > 10 ? 'Above Average' : 'Below Average'
      }
    ];

    return {
      isHPSA,
      pcpRatio: Math.round(pcpRatio),
      underservedZips,
      shortageMetrics,
      totalPop,
      primaryCareProviders
    };
  }, [censusData, organizations, zipCodes]);

  if (!hpsaData) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-gray-500">
          No HPSA data available
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card className="bg-gradient-to-br from-orange-50 via-red-50 to-white border-2 border-orange-200">
        <CardHeader>
          <CardTitle className="text-2xl font-bold bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">
            Slide 4: HPSA & Shortage Area Analysis
          </CardTitle>
          <p className="text-sm text-gray-600 mt-1">Health Professional Shortage Area designation and underserved populations</p>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* HPSA Status Alert with Gradients */}
          <div className={`p-5 rounded-xl border-2 ${
            hpsaData.isHPSA 
              ? 'bg-gradient-to-br from-red-50 to-orange-50 border-red-300' 
              : 'bg-gradient-to-br from-green-50 to-emerald-50 border-green-300'
          }`}>
            <div className="flex items-start gap-4">
              <AlertTriangle className={`w-7 h-7 ${hpsaData.isHPSA ? 'text-red-600' : 'text-green-600'}`} />
              <div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">
                  {hpsaData.isHPSA ? 'HPSA Designation Likely' : 'Adequate Provider Coverage'}
                </h3>
                <p className="text-sm text-gray-700 mb-3">
                  Population-to-primary care provider ratio: <strong className="text-base">{hpsaData.pcpRatio.toLocaleString()}:1</strong>
                  {hpsaData.isHPSA && ' (exceeds HRSA threshold of 3,500:1)'}
                </p>
                <div className="flex gap-2 flex-wrap">
                  <Badge variant={hpsaData.isHPSA ? 'destructive' : 'default'} className="text-xs">
                    {hpsaData.primaryCareProviders} Primary Care Providers
                  </Badge>
                  <Badge variant="outline" className="text-xs">
                    {hpsaData.totalPop.toLocaleString()} Population
                  </Badge>
                </div>
              </div>
            </div>
          </div>

          {/* Shortage Metrics */}
          <Card className="border-2">
            <CardHeader>
              <CardTitle className="text-base font-semibold">Key Shortage Indicators</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {hpsaData.shortageMetrics.map((metric, idx) => (
                  <div key={idx} className="flex items-center justify-between p-3 bg-gradient-to-r from-gray-50 to-white rounded-lg border">
                    <div>
                      <p className="text-sm font-semibold text-gray-900">{metric.metric}</p>
                      <p className="text-xs text-gray-600 mt-1">
                        Current: <strong>{metric.current}</strong> | Threshold: {metric.threshold}
                      </p>
                    </div>
                    <Badge 
                      variant={metric.status.includes('Shortage') || metric.status.includes('High') || metric.status.includes('Above') ? 'destructive' : 'default'}
                      className="text-xs"
                    >
                      {metric.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Underserved ZIP Codes Chart */}
          <Card className="border-2">
            <CardHeader>
              <CardTitle className="text-base font-semibold">Most Underserved ZIP Codes</CardTitle>
              <p className="text-xs text-gray-600">Ranked by combined poverty and uninsured rates</p>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={hpsaData.underservedZips}>
                  <defs>
                    <linearGradient id="povertyGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#f59e0b" stopOpacity={0.9}/>
                      <stop offset="100%" stopColor="#ea580c" stopOpacity={0.7}/>
                    </linearGradient>
                    <linearGradient id="uninsuredGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#ef4444" stopOpacity={0.9}/>
                      <stop offset="100%" stopColor="#dc2626" stopOpacity={0.7}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="zip" tick={{ fontSize: 10 }} />
                  <YAxis tick={{ fontSize: 10 }} />
                  <Tooltip 
                    contentStyle={{ fontSize: 11, borderRadius: 8 }}
                    formatter={(value) => `${value}%`}
                  />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                  <Bar dataKey="povertyRate" fill="url(#povertyGrad)" name="Poverty Rate %" radius={[8, 8, 0, 0]} />
                  <Bar dataKey="uninsuredRate" fill="url(#uninsuredGrad)" name="Uninsured Rate %" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </CardContent>
      </Card>
    </div>
  );
}