import React, { useMemo, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, AreaChart, Area } from 'recharts';
import { Users, DollarSign, Heart, MapPin, Download, Settings, Table as TableIcon, Map as MapIcon, BarChart3 } from 'lucide-react';
import { toast } from 'sonner';
import { MapContainer, TileLayer } from 'react-leaflet';
import MapZipChoropleth from '@/components/maps/MapZipChoropleth';
import 'leaflet/dist/leaflet.css';

const GRADIENT_COLORS = {
  emerald: ['#10b981', '#059669'],
  blue: ['#3b82f6', '#2563eb'],
  purple: ['#8b5cf6', '#7c3aed'],
  orange: ['#f59e0b', '#ea580c'],
  pink: ['#ec4899', '#db2777']
};

export default function SlideOverview({ assessment, censusData, zipCodes }) {
  const [viewMode, setViewMode] = useState('charts');
  const [chartType, setChartType] = useState('bar');
  const [showSettings, setShowSettings] = useState(false);
  
  // Map settings
  const [mapMetric, setMapMetric] = useState('population');
  const [mapColorScale, setMapColorScale] = useState('Blues');
  const [showZipLabels, setShowZipLabels] = useState(true);
  const [showDataOverlay, setShowDataOverlay] = useState(true);

  const overviewData = useMemo(() => {
    if (!censusData || Object.keys(censusData).length === 0) return null;

    const validData = Object.values(censusData).filter(d => d.population > 0);
    
    const totalPopulation = validData.reduce((sum, d) => sum + (d.population || 0), 0);
    const avgIncome = validData.reduce((sum, d) => sum + (d.medianIncome || 0), 0) / validData.length;
    const avgPoverty = validData.reduce((sum, d) => sum + (d.povertyRate || 0), 0) / validData.length;
    const avgUninsured = validData.reduce((sum, d) => sum + (d.uninsuredRate || 0), 0) / validData.length;

    const popByZip = Object.entries(censusData)
      .map(([zip, data]) => ({ 
        zip, 
        population: data.population || 0,
        income: data.medianIncome || 0,
        povertyRate: data.povertyRate || 0,
        uninsuredRate: data.uninsuredRate || 0
      }))
      .sort((a, b) => b.population - a.population)
      .slice(0, 10);

    const incomeRanges = [
      { range: 'Under $25k', count: 0 },
      { range: '$25k-$50k', count: 0 },
      { range: '$50k-$75k', count: 0 },
      { range: '$75k-$100k', count: 0 },
      { range: 'Over $100k', count: 0 }
    ];

    Object.values(censusData).forEach(d => {
      if (!d.medianIncome) return;
      if (d.medianIncome < 25000) incomeRanges[0].count++;
      else if (d.medianIncome < 50000) incomeRanges[1].count++;
      else if (d.medianIncome < 75000) incomeRanges[2].count++;
      else if (d.medianIncome < 100000) incomeRanges[3].count++;
      else incomeRanges[4].count++;
    });

    return {
      totalPopulation,
      avgIncome,
      avgPoverty,
      avgUninsured,
      popByZip,
      incomeRanges: incomeRanges.filter(r => r.count > 0)
    };
  }, [censusData]);

  const downloadCSV = () => {
    const csvData = overviewData.popByZip.map(item => 
      `${item.zip},${item.population}`
    ).join('\n');
    
    const blob = new Blob([`ZIP Code,Population\n${csvData}`], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'population_data.csv';
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();
    toast.success('CSV downloaded!');
  };

  const downloadJSON = () => {
    const data = {
      summary: {
        totalPopulation: overviewData.totalPopulation,
        avgIncome: Math.round(overviewData.avgIncome),
        avgPoverty: overviewData.avgPoverty.toFixed(1),
        avgUninsured: overviewData.avgUninsured.toFixed(1),
        zipCount: zipCodes.length
      },
      populationByZip: overviewData.popByZip,
      incomeDistribution: overviewData.incomeRanges
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'overview_data.json';
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();
    toast.success('JSON downloaded!');
  };

  if (!overviewData) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-gray-500">
          No demographic data available
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card className="bg-gradient-to-br from-emerald-50 via-teal-50 to-white border-2 border-emerald-200">
        <CardHeader>
          <div className="flex items-start justify-between flex-wrap gap-3">
            <div>
              <CardTitle className="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
                Slide 1: Regional Overview
              </CardTitle>
              <p className="text-sm text-gray-600 mt-1">Key population metrics and distribution</p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={downloadCSV}>
                <Download className="w-3 h-3 mr-1" />
                CSV
              </Button>
              <Button variant="outline" size="sm" onClick={downloadJSON}>
                <Download className="w-3 h-3 mr-1" />
                JSON
              </Button>
              <Button variant="outline" size="sm" onClick={() => setShowSettings(!showSettings)}>
                <Settings className="w-3 h-3" />
              </Button>
            </div>
          </div>
          
          {showSettings && (
            <div className="mt-4 p-4 bg-white rounded-lg border space-y-3">
              <div>
                <label className="text-xs font-semibold text-gray-700 mb-2 block">View Mode</label>
                <div className="flex gap-2 flex-wrap">
                  <Button
                    variant={viewMode === 'charts' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setViewMode('charts')}
                  >
                    <BarChart3 className="w-3 h-3 mr-1" />
                    Charts
                  </Button>
                  <Button
                    variant={viewMode === 'table' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setViewMode('table')}
                  >
                    <TableIcon className="w-3 h-3 mr-1" />
                    Table
                  </Button>
                  <Button
                    variant={viewMode === 'map' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setViewMode('map')}
                  >
                    <MapIcon className="w-3 h-3 mr-1" />
                    Map
                  </Button>
                </div>
              </div>
              
              {viewMode === 'charts' && (
                <div>
                  <label className="text-xs font-semibold text-gray-700 mb-2 block">Chart Type</label>
                  <div className="flex gap-2 flex-wrap">
                    {['bar', 'area', 'line'].map(type => (
                      <Button
                        key={type}
                        variant={chartType === type ? 'default' : 'outline'}
                        size="sm"
                        onClick={() => setChartType(type)}
                        className="capitalize"
                      >
                        {type}
                      </Button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Key Metrics with Gradients */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="bg-gradient-to-br from-emerald-50 to-teal-50 p-4 rounded-xl border-2 border-emerald-200 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center gap-2 mb-1">
                <Users className="w-4 h-4 text-emerald-600" />
                <p className="text-xs font-medium text-gray-600">Total Population</p>
              </div>
              <p className="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
                {overviewData.totalPopulation.toLocaleString()}
              </p>
              <p className="text-xs text-gray-500 mt-1">Across {zipCodes.length} ZIPs</p>
            </div>
            
            <div className="bg-gradient-to-br from-blue-50 to-cyan-50 p-4 rounded-xl border-2 border-blue-200 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center gap-2 mb-1">
                <DollarSign className="w-4 h-4 text-blue-600" />
                <p className="text-xs font-medium text-gray-600">Avg. Med. Income</p>
              </div>
              <p className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
                ${Math.round(overviewData.avgIncome).toLocaleString()}
              </p>
              <p className="text-xs text-gray-500 mt-1">Median household</p>
            </div>
            
            <div className="bg-gradient-to-br from-orange-50 to-amber-50 p-4 rounded-xl border-2 border-orange-200 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center gap-2 mb-1">
                <Heart className="w-4 h-4 text-orange-600" />
                <p className="text-xs font-medium text-gray-600">Avg. Poverty</p>
              </div>
              <p className="text-2xl font-bold bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">
                {overviewData.avgPoverty.toFixed(1)}%
              </p>
              <p className="text-xs text-gray-500 mt-1">Below poverty line</p>
            </div>
            
            <div className="bg-gradient-to-br from-purple-50 to-pink-50 p-4 rounded-xl border-2 border-purple-200 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center gap-2 mb-1">
                <MapPin className="w-4 h-4 text-purple-600" />
                <p className="text-xs font-medium text-gray-600">Service Area</p>
              </div>
              <p className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                {zipCodes.length}
              </p>
              <p className="text-xs text-gray-500 mt-1">ZIP codes covered</p>
            </div>
          </div>

          {/* Main Content Area */}
          {viewMode === 'charts' && (
            <Card className="border-2">
              <CardHeader>
                <CardTitle className="text-base font-semibold">Population Distribution by ZIP Code (Top 10)</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={280}>
                  {chartType === 'bar' ? (
                    <BarChart data={overviewData.popByZip}>
                      <defs>
                        <linearGradient id="popGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#10b981" stopOpacity={0.9}/>
                          <stop offset="100%" stopColor="#059669" stopOpacity={0.7}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                      <XAxis dataKey="zip" tick={{ fontSize: 11 }} />
                      <YAxis tick={{ fontSize: 11 }} />
                      <Tooltip 
                        contentStyle={{ fontSize: 12, borderRadius: 8 }}
                        formatter={(value) => value.toLocaleString()}
                      />
                      <Bar dataKey="population" fill="url(#popGradient)" radius={[8, 8, 0, 0]} />
                    </BarChart>
                  ) : chartType === 'area' ? (
                    <AreaChart data={overviewData.popByZip}>
                      <defs>
                        <linearGradient id="areaGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#10b981" stopOpacity={0.8}/>
                          <stop offset="100%" stopColor="#10b981" stopOpacity={0.1}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                      <XAxis dataKey="zip" tick={{ fontSize: 11 }} />
                      <YAxis tick={{ fontSize: 11 }} />
                      <Tooltip 
                        contentStyle={{ fontSize: 12, borderRadius: 8 }}
                        formatter={(value) => value.toLocaleString()}
                      />
                      <Area type="monotone" dataKey="population" stroke="#10b981" fill="url(#areaGradient)" />
                    </AreaChart>
                  ) : (
                    <LineChart data={overviewData.popByZip}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                      <XAxis dataKey="zip" tick={{ fontSize: 11 }} />
                      <YAxis tick={{ fontSize: 11 }} />
                      <Tooltip 
                        contentStyle={{ fontSize: 12, borderRadius: 8 }}
                        formatter={(value) => value.toLocaleString()}
                      />
                      <Line type="monotone" dataKey="population" stroke="#10b981" strokeWidth={3} dot={{ r: 4 }} />
                    </LineChart>
                  )}
                </ResponsiveContainer>
              </CardContent>
            </Card>
          )}

          {viewMode === 'table' && (
            <Card className="border-2">
              <CardHeader>
                <CardTitle className="text-base font-semibold">Population Data Table</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-gradient-to-r from-emerald-50 to-teal-50">
                      <tr>
                        <th className="px-4 py-3 text-left font-semibold text-gray-900 border">Rank</th>
                        <th className="px-4 py-3 text-left font-semibold text-gray-900 border">ZIP Code</th>
                        <th className="px-4 py-3 text-right font-semibold text-gray-900 border">Population</th>
                        <th className="px-4 py-3 text-right font-semibold text-gray-900 border">% of Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      {overviewData.popByZip.map((item, idx) => (
                        <tr key={item.zip} className="hover:bg-emerald-50 transition-colors">
                          <td className="px-4 py-3 border font-medium">{idx + 1}</td>
                          <td className="px-4 py-3 border font-mono font-semibold text-emerald-700">{item.zip}</td>
                          <td className="px-4 py-3 border text-right font-semibold">{item.population.toLocaleString()}</td>
                          <td className="px-4 py-3 border text-right">
                            {((item.population / overviewData.totalPopulation) * 100).toFixed(1)}%
                          </td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot className="bg-gradient-to-r from-emerald-100 to-teal-100">
                      <tr>
                        <td colSpan="2" className="px-4 py-3 border font-bold text-gray-900">Total (Top 10)</td>
                        <td className="px-4 py-3 border text-right font-bold text-gray-900">
                          {overviewData.popByZip.reduce((sum, item) => sum + item.population, 0).toLocaleString()}
                        </td>
                        <td className="px-4 py-3 border text-right font-bold text-gray-900">
                          {((overviewData.popByZip.reduce((sum, item) => sum + item.population, 0) / overviewData.totalPopulation) * 100).toFixed(1)}%
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}

          {viewMode === 'map' && (
            <Card className="border-2">
              <CardHeader>
                <CardTitle className="text-base font-semibold">Geographic Distribution</CardTitle>
                <div className="mt-4 space-y-4 p-4 bg-white rounded-lg border">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-xs font-semibold text-gray-700 mb-2 block">Metric to Display</Label>
                      <Select value={mapMetric} onValueChange={setMapMetric}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="population">Total Population</SelectItem>
                          <SelectItem value="income">Median Income</SelectItem>
                          <SelectItem value="povertyRate">Poverty Rate</SelectItem>
                          <SelectItem value="uninsuredRate">Uninsured Rate</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label className="text-xs font-semibold text-gray-700 mb-2 block">Color Scale</Label>
                      <Select value={mapColorScale} onValueChange={setMapColorScale}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Blues">Blues</SelectItem>
                          <SelectItem value="Greens">Greens</SelectItem>
                          <SelectItem value="Reds">Reds</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <div className="flex gap-4 pt-2 border-t">
                    <div className="flex items-center gap-2">
                      <Switch
                        id="show-zip-labels"
                        checked={showZipLabels}
                        onCheckedChange={setShowZipLabels}
                      />
                      <Label htmlFor="show-zip-labels" className="text-xs cursor-pointer">Show ZIP Labels</Label>
                    </div>
                    <div className="flex items-center gap-2">
                      <Switch
                        id="show-data-overlay"
                        checked={showDataOverlay}
                        onCheckedChange={setShowDataOverlay}
                      />
                      <Label htmlFor="show-data-overlay" className="text-xs cursor-pointer">Show Data Overlay</Label>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {assessment?.processed_data?.boundaries ? (
                  <div className="h-[500px] w-full rounded-lg border-2 border-gray-200 overflow-hidden">
                    <MapContainer
                      center={[
                        assessment.geography?.latitude || 31.5,
                        assessment.geography?.longitude || -89.0
                      ]}
                      zoom={9}
                      style={{ height: '100%', width: '100%' }}
                    >
                      <TileLayer
                        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                      />
                      <MapZipChoropleth
                        zipBoundaries={assessment.processed_data.boundaries}
                        selectedZipCodes={zipCodes}
                        overlay={mapMetric}
                        colorScale={mapColorScale}
                        opacity={0.7}
                      />
                    </MapContainer>
                  </div>
                ) : (
                  <div className="bg-gray-100 rounded-lg p-8 text-center border-2 border-dashed border-gray-300">
                    <MapIcon className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                    <p className="text-gray-600 font-medium">Map data not available</p>
                    <p className="text-sm text-gray-500 mt-2">
                      Please load boundary data for this assessment first
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Income Distribution */}
          <div className="grid md:grid-cols-2 gap-4">
            <Card className="border-2">
              <CardHeader>
                <CardTitle className="text-base font-semibold">Income Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={240}>
                  <PieChart>
                    <defs>
                      {Object.entries(GRADIENT_COLORS).map(([key, [start, end]], idx) => (
                        <linearGradient key={key} id={`gradient-${idx}`} x1="0" y1="0" x2="1" y2="1">
                          <stop offset="0%" stopColor={start} />
                          <stop offset="100%" stopColor={end} />
                        </linearGradient>
                      ))}
                    </defs>
                    <Pie
                      data={overviewData.incomeRanges}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ percent }) => `${(percent * 100).toFixed(0)}%`}
                      outerRadius={90}
                      dataKey="count"
                    >
                      {overviewData.incomeRanges.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={`url(#gradient-${index})`} />
                      ))}
                    </Pie>
                    <Tooltip 
                      formatter={(value, name, props) => [
                        `${value} ZIPs (${((value / zipCodes.length) * 100).toFixed(1)}%)`,
                        props.payload.range
                      ]}
                      contentStyle={{ fontSize: 12, borderRadius: 8 }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="border-2">
              <CardHeader>
                <CardTitle className="text-base font-semibold">Key Statistics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-gradient-to-r from-blue-50 to-cyan-50 rounded-lg border border-blue-200">
                  <span className="text-xs font-medium text-gray-700">Median Income</span>
                  <span className="text-sm font-bold text-blue-700">${Math.round(overviewData.avgIncome).toLocaleString()}</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-gradient-to-r from-orange-50 to-amber-50 rounded-lg border border-orange-200">
                  <span className="text-xs font-medium text-gray-700">Poverty Rate</span>
                  <span className="text-sm font-bold text-orange-700">{overviewData.avgPoverty.toFixed(1)}%</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-gradient-to-r from-red-50 to-pink-50 rounded-lg border border-red-200">
                  <span className="text-xs font-medium text-gray-700">Uninsured Rate</span>
                  <span className="text-sm font-bold text-red-700">{overviewData.avgUninsured.toFixed(1)}%</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-gradient-to-r from-emerald-50 to-teal-50 rounded-lg border border-emerald-200">
                  <span className="text-xs font-medium text-gray-700">Total Population</span>
                  <span className="text-sm font-bold text-emerald-700">{overviewData.totalPopulation.toLocaleString()}</span>
                </div>
                <div className="p-3 bg-gray-50 rounded-lg border">
                  <p className="text-xs text-gray-600 leading-relaxed">
                    Data represents {zipCodes.length} ZIP codes in the {assessment.geography?.city || 'service'} area. 
                    Income levels show moderate economic diversity with targeted needs in lower-income areas.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}