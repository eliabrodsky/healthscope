import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { FileText, Database, Globe, Building2 } from 'lucide-react';

export default function SlideSources({ assessment }) {
  const dataSources = [
    {
      name: 'US Census Bureau',
      description: 'American Community Survey 5-Year Estimates (2022)',
      icon: Database,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
      dataTypes: ['Population', 'Income', 'Poverty Rates', 'Insurance Coverage']
    },
    {
      name: 'HRSA',
      description: 'Health Resources and Services Administration',
      icon: Building2,
      color: 'text-green-600',
      bgColor: 'bg-green-50',
      dataTypes: ['FQHC Locations', 'HPSA Designations', 'Provider Data']
    },
    {
      name: 'TIGER/Line Shapefiles',
      description: 'US Census Bureau Geographic Boundaries',
      icon: Globe,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50',
      dataTypes: ['ZCTA Boundaries', 'County Boundaries', 'Geographic Coordinates']
    },
    {
      name: 'OpenStreetMap',
      description: 'Collaborative mapping project',
      icon: Globe,
      color: 'text-orange-600',
      bgColor: 'bg-orange-50',
      dataTypes: ['Healthcare Facility Locations', 'Address Validation']
    }
  ];

  const customSources = assessment?.processed_data?.data_sources_detailed || [];

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-br from-gray-50 to-white border-gray-200">
        <CardHeader>
          <CardTitle className="text-2xl">Slide 6: Data Sources & Methodology</CardTitle>
          <p className="text-gray-600 mt-2">Data provenance and quality indicators</p>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Primary Data Sources */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Primary Data Sources</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {dataSources.map((source, idx) => (
                <div key={idx} className={`p-4 ${source.bgColor} border rounded-lg`}>
                  <div className="flex items-start gap-4">
                    <div className={`p-3 bg-white rounded-lg`}>
                      <source.icon className={`w-6 h-6 ${source.color}`} />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900 mb-1">{source.name}</h4>
                      <p className="text-sm text-gray-600 mb-3">{source.description}</p>
                      <div className="flex flex-wrap gap-2">
                        {source.dataTypes.map((type, typeIdx) => (
                          <span key={typeIdx} className="text-xs bg-white px-2 py-1 rounded border">
                            {type}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Custom Data Sources */}
          {customSources.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Additional Data Sources</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {customSources.map((source, idx) => (
                  <div key={idx} className="p-4 bg-gray-50 border rounded-lg">
                    <div className="flex items-start gap-3">
                      <FileText className="w-5 h-5 text-gray-600 mt-0.5" />
                      <div>
                        <h4 className="font-medium text-gray-900">{source.name || source.filename || 'Custom Data'}</h4>
                        <p className="text-sm text-gray-600">{source.description || source.type || 'Uploaded data source'}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {/* Methodology Notes */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Methodology</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm text-gray-700">
                <p>
                  <strong>Geographic Definition:</strong> Service area defined using ZIP Code Tabulation Areas (ZCTAs) 
                  based on {assessment?.geography?.city || 'specified location'} and 
                  {assessment?.geography?.radius_miles ? ` ${assessment.geography.radius_miles}-mile radius` : ' selected boundaries'}.
                </p>
                <p>
                  <strong>Population Data:</strong> Demographic statistics sourced from US Census Bureau's American Community 
                  Survey (ACS) 5-Year Estimates, providing the most recent comprehensive data at the ZCTA level.
                </p>
                <p>
                  <strong>Provider Data:</strong> Healthcare facility locations compiled from HRSA data finder, 
                  OpenStreetMap, and manual verification. Provider types classified according to HRSA definitions.
                </p>
                <p>
                  <strong>HPSA Analysis:</strong> Health Professional Shortage Area determination based on HRSA 
                  criteria: population-to-provider ratio threshold of 3,500:1 for primary care.
                </p>
                <p>
                  <strong>Data Quality:</strong> All data validated against multiple sources. Estimates used only 
                  when authoritative sources unavailable. Last updated: {new Date().toLocaleDateString()}.
                </p>
              </div>
            </CardContent>
          </Card>
        </CardContent>
      </Card>
    </div>
  );
}