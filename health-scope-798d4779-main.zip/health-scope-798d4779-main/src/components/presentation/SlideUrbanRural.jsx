import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ScatterChart, Scatter, Cell, LabelList } from 'recharts';
import { Building2, Trees } from 'lucide-react';

export default function SlideUrbanRural({ assessment, censusData, zipCodes }) {
  const urbanRuralData = useMemo(() => {
    if (!censusData || Object.keys(censusData).length === 0) return null;

    // Classify ZIP codes as urban/rural based on population density proxy
    const classified = Object.entries(censusData).map(([zip, data]) => {
      const population = data.population || 0;
      // Simple heuristic: > 5000 = urban, else rural
      const type = population > 5000 ? 'urban' : 'rural';
      
      return {
        zip,
        type,
        population,
        medianIncome: data.medianIncome || 0,
        povertyRate: data.povertyRate || 0,
        uninsuredRate: data.uninsuredRate || 0
      };
    });

    const urbanZips = classified.filter(z => z.type === 'urban');
    const ruralZips = classified.filter(z => z.type === 'rural');

    const urbanPop = urbanZips.reduce((sum, z) => sum + z.population, 0);
    const ruralPop = ruralZips.reduce((sum, z) => sum + z.population, 0);

    const urbanAvgIncome = urbanZips.length > 0 ? urbanZips.reduce((sum, z) => sum + z.medianIncome, 0) / urbanZips.length : 0;
    const ruralAvgIncome = ruralZips.length > 0 ? ruralZips.reduce((sum, z) => sum + z.medianIncome, 0) / ruralZips.length : 0;

    // Calculate age demographics (estimated distribution)
    const urbanChildren = Math.round(urbanPop * 0.23); // ~23% children (0-17)
    const ruralChildren = Math.round(ruralPop * 0.22);
    
    const urbanWorkingAdults = Math.round(urbanPop * 0.61); // ~61% working age (18-64)
    const ruralWorkingAdults = Math.round(ruralPop * 0.59);
    
    const urbanSeniors = Math.round(urbanPop * 0.16); // ~16% seniors (65+)
    const ruralSeniors = Math.round(ruralPop * 0.19);

    const comparison = [
      {
        metric: 'Population',
        Urban: urbanPop,
        Rural: ruralPop
      },
      {
        metric: 'Avg Income',
        Urban: Math.round(urbanAvgIncome),
        Rural: Math.round(ruralAvgIncome)
      },
      {
        metric: 'Children (0-17)',
        Urban: urbanChildren,
        Rural: ruralChildren
      },
      {
        metric: 'Working Adults (18-64)',
        Urban: urbanWorkingAdults,
        Rural: ruralWorkingAdults
      },
      {
        metric: 'Seniors (65+)',
        Urban: urbanSeniors,
        Rural: ruralSeniors
      }
    ];

    return {
      urbanZips,
      ruralZips,
      urbanPop,
      ruralPop,
      comparison,
      scatterData: classified
    };
  }, [censusData]);

  if (!urbanRuralData) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-gray-500">
          No data available for urban/rural analysis
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card className="bg-gradient-to-br from-blue-50 via-indigo-50 to-white border-2 border-blue-200">
        <CardHeader>
          <CardTitle className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
            Slide 2: Urban vs Rural Analysis
          </CardTitle>
          <p className="text-sm text-gray-600 mt-1">Population distribution and demographic comparison</p>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Summary Cards with Gradients */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 p-4 rounded-xl border-2 border-blue-200 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center gap-2 mb-2">
                <Building2 className="w-4 h-4 text-blue-600" />
                <h3 className="text-sm font-semibold text-gray-900">Urban Areas</h3>
              </div>
              <p className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                {urbanRuralData.urbanZips.length}
              </p>
              <p className="text-xs text-gray-600 mt-1">ZIP codes</p>
              <p className="text-lg font-bold text-blue-700 mt-2">{urbanRuralData.urbanPop.toLocaleString()}</p>
              <p className="text-xs text-gray-500">Total population</p>
            </div>
            <div className="bg-gradient-to-br from-emerald-50 to-teal-50 p-4 rounded-xl border-2 border-emerald-200 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center gap-2 mb-2">
                <Trees className="w-4 h-4 text-emerald-600" />
                <h3 className="text-sm font-semibold text-gray-900">Rural Areas</h3>
              </div>
              <p className="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
                {urbanRuralData.ruralZips.length}
              </p>
              <p className="text-xs text-gray-600 mt-1">ZIP codes</p>
              <p className="text-lg font-bold text-emerald-700 mt-2">{urbanRuralData.ruralPop.toLocaleString()}</p>
              <p className="text-xs text-gray-500">Total population</p>
            </div>
          </div>

          {/* Comparison Chart with Gradients */}
          <Card className="border-2">
            <CardHeader>
              <CardTitle className="text-base font-semibold">Urban vs Rural Comparison</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={320}>
                <BarChart data={urbanRuralData.comparison}>
                  <defs>
                    <linearGradient id="urbanGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#3b82f6" stopOpacity={0.9}/>
                      <stop offset="100%" stopColor="#6366f1" stopOpacity={0.7}/>
                    </linearGradient>
                    <linearGradient id="ruralGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#10b981" stopOpacity={0.9}/>
                      <stop offset="100%" stopColor="#14b8a6" stopOpacity={0.7}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis 
                    dataKey="metric" 
                    tick={{ fontSize: 10 }}
                    angle={-15}
                    textAnchor="end"
                    height={60}
                  />
                  <YAxis 
                    tick={{ fontSize: 10 }}
                    tickFormatter={(value) => value.toLocaleString()}
                  />
                  <Tooltip 
                    contentStyle={{ fontSize: 11, borderRadius: 8 }}
                    formatter={(value) => typeof value === 'number' ? value.toLocaleString() : value}
                  />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                  <Bar dataKey="Urban" fill="url(#urbanGrad)" radius={[8, 8, 0, 0]}>
                    <LabelList 
                      dataKey="Urban" 
                      position="top" 
                      fontSize={9}
                      fontWeight="bold"
                      fill="#1e40af"
                      formatter={(value) => value.toLocaleString()}
                    />
                  </Bar>
                  <Bar dataKey="Rural" fill="url(#ruralGrad)" radius={[8, 8, 0, 0]}>
                    <LabelList 
                      dataKey="Rural" 
                      position="top" 
                      fontSize={9}
                      fontWeight="bold"
                      fill="#047857"
                      formatter={(value) => value.toLocaleString()}
                    />
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Scatter Plot with Enhanced Styling */}
          <Card className="border-2">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-base font-semibold">Population vs. Income by ZIP Code</CardTitle>
                <div className="flex gap-2">
                  <Badge className="bg-blue-100 text-blue-700 border-blue-300">
                    <Building2 className="w-3 h-3 mr-1" />
                    Urban
                  </Badge>
                  <Badge className="bg-emerald-100 text-emerald-700 border-emerald-300">
                    <Trees className="w-3 h-3 mr-1" />
                    Rural
                  </Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={280}>
                <ScatterChart>
                  <defs>
                    <linearGradient id="urbanDot" x1="0" y1="0" x2="1" y2="1">
                      <stop offset="0%" stopColor="#3b82f6" />
                      <stop offset="100%" stopColor="#6366f1" />
                    </linearGradient>
                    <linearGradient id="ruralDot" x1="0" y1="0" x2="1" y2="1">
                      <stop offset="0%" stopColor="#10b981" />
                      <stop offset="100%" stopColor="#14b8a6" />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis 
                    dataKey="population" 
                    name="Population" 
                    tick={{ fontSize: 10 }}
                    tickFormatter={(value) => value.toLocaleString()}
                    label={{ value: 'Population', position: 'insideBottom', offset: -5, fontSize: 11 }}
                  />
                  <YAxis 
                    dataKey="medianIncome" 
                    name="Median Income" 
                    tick={{ fontSize: 10 }}
                    tickFormatter={(value) => value.toLocaleString()}
                    label={{ value: 'Median Income ($)', angle: -90, position: 'insideLeft', fontSize: 11 }}
                  />
                  <Tooltip 
                    cursor={{ strokeDasharray: '3 3' }}
                    contentStyle={{ fontSize: 11, borderRadius: 8 }}
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0].payload;
                        return (
                          <div className="bg-white p-3 rounded-lg shadow-lg border border-gray-200">
                            <p className="font-semibold text-gray-900 mb-2">ZIP {data.zip}</p>
                            <p className="text-xs text-gray-700">Population: {data.population.toLocaleString()}</p>
                            <p className="text-xs text-gray-700">Median Income: ${data.medianIncome.toLocaleString()}</p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Scatter 
                    name="Urban ZIPs" 
                    data={urbanRuralData.urbanZips} 
                    fill="url(#urbanDot)"
                    shape="circle"
                  >
                    {urbanRuralData.urbanZips.map((entry, index) => (
                      <Cell key={`urban-${index}`} opacity={0.7} />
                    ))}
                  </Scatter>
                  <Scatter 
                    name="Rural ZIPs" 
                    data={urbanRuralData.ruralZips} 
                    fill="url(#ruralDot)"
                    shape="circle"
                  >
                    {urbanRuralData.ruralZips.map((entry, index) => (
                      <Cell key={`rural-${index}`} opacity={0.7} />
                    ))}
                  </Scatter>
                </ScatterChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </CardContent>
      </Card>
    </div>
  );
}