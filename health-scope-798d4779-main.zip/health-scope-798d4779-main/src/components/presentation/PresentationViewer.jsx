import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  ChevronLeft, 
  ChevronRight, 
  Download,
  Share2,
  Maximize2,
  X
} from "lucide-react";

export default function PresentationViewer({ presentation, onClose }) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const slides = presentation.slides || [];

  const nextSlide = () => {
    if (currentSlide < slides.length - 1) {
      setCurrentSlide(currentSlide + 1);
    }
  };

  const prevSlide = () => {
    if (currentSlide > 0) {
      setCurrentSlide(currentSlide - 1);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-90 z-50 flex flex-col">
      {/* Header */}
      <div className="bg-gray-900 border-b border-gray-700 p-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="text-white hover:bg-gray-800"
            >
              <X className="w-4 h-4 mr-2" />
              Close
            </Button>
            <div>
              <h2 className="text-white font-semibold">{presentation.title}</h2>
              <p className="text-gray-400 text-sm">{presentation.assessment_title}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-white border-white">
              Slide {currentSlide + 1} / {slides.length || 1}
            </Badge>
            <Button variant="ghost" size="sm" className="text-white hover:bg-gray-800">
              <Share2 className="w-4 h-4 mr-2" />
              Share
            </Button>
            <Button variant="ghost" size="sm" className="text-white hover:bg-gray-800">
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          </div>
        </div>
      </div>

      {/* Slide Content */}
      <div className="flex-1 flex items-center justify-center p-8">
        <Card className="w-full max-w-5xl aspect-video bg-white shadow-2xl">
          <CardContent className="h-full flex items-center justify-center p-12">
            {slides.length === 0 ? (
              <div className="text-center">
                <Maximize2 className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-2xl font-bold text-gray-900 mb-2">
                  No Slides Yet
                </h3>
                <p className="text-gray-600">
                  This presentation doesn't have any slides. Edit it to add content.
                </p>
              </div>
            ) : (
              <div className="w-full h-full">
                <div className="text-4xl font-bold text-gray-900 mb-6">
                  {slides[currentSlide]?.title || `Slide ${currentSlide + 1}`}
                </div>
                <div className="text-lg text-gray-700">
                  {slides[currentSlide]?.content || 'Slide content will appear here'}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Navigation */}
      {slides.length > 0 && (
        <div className="bg-gray-900 border-t border-gray-700 p-4">
          <div className="max-w-7xl mx-auto flex items-center justify-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={prevSlide}
              disabled={currentSlide === 0}
              className="text-white hover:bg-gray-800 disabled:opacity-30"
            >
              <ChevronLeft className="w-5 h-5" />
            </Button>
            
            <div className="flex gap-2">
              {slides.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentSlide(idx)}
                  className={`w-2 h-2 rounded-full transition-all ${
                    idx === currentSlide 
                      ? 'bg-emerald-500 w-6' 
                      : 'bg-gray-600 hover:bg-gray-500'
                  }`}
                />
              ))}
            </div>

            <Button
              variant="ghost"
              size="sm"
              onClick={nextSlide}
              disabled={currentSlide === slides.length - 1}
              className="text-white hover:bg-gray-800 disabled:opacity-30"
            >
              <ChevronRight className="w-5 h-5" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}