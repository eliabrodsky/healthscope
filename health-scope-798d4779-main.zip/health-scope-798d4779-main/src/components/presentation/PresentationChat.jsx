import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { MessageSquare, Send, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

export default function PresentationChat({ assessment, activeSlide, onSlideChange }) {
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: 'Hi! I can help you refine your presentation, explain data insights, or navigate to specific slides. What would you like to know?'
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setIsLoading(true);

    try {
      const context = `
Assessment: ${assessment.title}
Location: ${assessment.geography?.city || 'N/A'}, ${assessment.geography?.state || 'N/A'}
ZIP Codes: ${assessment.processed_data?.zip_codes?.length || 0}
Organizations: ${assessment.organizations?.length || 0}
Current Slide: ${activeSlide}

Available slides: overview, urban-rural, providers, hpsa, needs, sources

User question: ${userMessage}
      `;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: context,
        add_context_from_internet: false
      });

      const assistantMessage = response.output || response || 'I apologize, I could not process that request.';
      
      setMessages(prev => [...prev, { role: 'assistant', content: assistantMessage }]);

      // Check if response suggests navigating to a slide
      const lowerResponse = assistantMessage.toLowerCase();
      if (lowerResponse.includes('slide') || lowerResponse.includes('navigate')) {
        const slides = ['overview', 'urban-rural', 'providers', 'hpsa', 'needs', 'sources'];
        const matchedSlide = slides.find(s => lowerResponse.includes(s.replace('-', ' ')));
        if (matchedSlide && onSlideChange) {
          setTimeout(() => onSlideChange(matchedSlide), 500);
        }
      }

    } catch (error) {
      console.error('Chat error:', error);
      toast.error('Failed to get response');
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: 'I apologize, I encountered an error. Please try again.' 
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const quickActions = [
    { label: 'Explain current slide', action: 'Explain the data shown on this slide' },
    { label: 'Show insights', action: 'What are the key insights from this assessment?' },
    { label: 'Navigate to needs', action: 'Take me to the needs and gaps slide' }
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MessageSquare className="w-5 h-5" />
          AI Presentation Assistant
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="h-64 overflow-y-auto space-y-3 p-4 bg-gray-50 rounded-lg">
            {messages.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] p-3 rounded-lg ${
                  msg.role === 'user' 
                    ? 'bg-emerald-600 text-white' 
                    : 'bg-white border'
                }`}>
                  <p className="text-sm">{msg.content}</p>
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white border p-3 rounded-lg">
                  <Loader2 className="w-4 h-4 animate-spin text-gray-600" />
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {messages.length === 1 && (
            <div className="space-y-2">
              <p className="text-xs text-gray-600">Quick actions:</p>
              {quickActions.map((action, idx) => (
                <Button
                  key={idx}
                  variant="outline"
                  size="sm"
                  className="w-full text-left justify-start text-xs"
                  onClick={() => {
                    setInput(action.action);
                    setTimeout(handleSend, 100);
                  }}
                >
                  {action.label}
                </Button>
              ))}
            </div>
          )}

          <div className="flex gap-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ask about the data..."
              disabled={isLoading}
            />
            <Button onClick={handleSend} disabled={isLoading || !input.trim()}>
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}