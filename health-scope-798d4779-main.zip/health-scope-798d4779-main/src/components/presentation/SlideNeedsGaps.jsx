import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Target, AlertTriangle, TrendingUp, Lightbulb } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export default function SlideNeedsGaps({ assessment, censusData, organizations }) {
  const needsData = useMemo(() => {
    if (!censusData || Object.keys(censusData).length === 0) return null;

    const validData = Object.values(censusData).filter(d => d.population > 0);
    const totalPop = validData.reduce((sum, d) => sum + (d.population || 0), 0);
    const avgPoverty = validData.reduce((sum, d) => sum + (d.povertyRate || 0), 0) / validData.length;
    const avgUninsured = validData.reduce((sum, d) => sum + (d.uninsuredRate || 0), 0) / validData.length;

    const pcpRatio = totalPop / Math.max(1, (organizations || []).filter(o => o.type === 'fqhc' || o.type === 'clinic').length);

    const keyNeeds = [];
    const serviceGaps = [];
    const opportunities = [];

    if (avgPoverty > 18) {
      keyNeeds.push({
        title: 'High Poverty Population',
        severity: 'high',
        description: `${avgPoverty.toFixed(1)}% poverty rate - significantly above national average`,
        impact: 'High need for sliding fee scale and subsidized care programs'
      });
    }

    if (avgUninsured > 10) {
      keyNeeds.push({
        title: 'Insurance Coverage Gap',
        severity: 'high',
        description: `${avgUninsured.toFixed(1)}% uninsured - access barriers likely`,
        impact: 'Opportunity for outreach and enrollment assistance'
      });
    }

    if (pcpRatio > 3500) {
      keyNeeds.push({
        title: 'Primary Care Shortage',
        severity: 'high',
        description: `${Math.round(pcpRatio)}:1 population-to-provider ratio`,
        impact: 'Immediate need for additional primary care capacity'
      });
    }

    const hasHospital = (organizations || []).some(o => o.type === 'hospital');
    const hasFQHC = (organizations || []).some(o => o.type === 'fqhc');
    const hasBH = (organizations || []).some(o => 
      o.services && o.services.some(s => s.toLowerCase().includes('mental') || s.toLowerCase().includes('behavioral'))
    );

    if (!hasHospital) {
      serviceGaps.push({
        service: 'Emergency & Inpatient Care',
        description: 'No hospital facilities in service area',
        priority: 'high'
      });
    }

    if (!hasFQHC) {
      serviceGaps.push({
        service: 'Community Health Center',
        description: 'No FQHC presence - gap in safety net coverage',
        priority: 'high'
      });
    }

    if (!hasBH) {
      serviceGaps.push({
        service: 'Behavioral Health Services',
        description: 'Limited or no mental health/substance abuse services',
        priority: 'medium'
      });
    }

    if (avgPoverty > 20 && !hasFQHC) {
      opportunities.push({
        title: 'FQHC Expansion Opportunity',
        description: 'High-need area without community health center coverage',
        potential: 'New FQHC or Look-Alike application',
        priority: 'high'
      });
    }

    if (pcpRatio > 4000) {
      opportunities.push({
        title: 'Mobile Health Unit',
        description: 'Severe provider shortage - mobile unit could extend reach',
        potential: 'Grant-funded mobile clinic with CHW support',
        priority: 'high'
      });
    }

    if (avgUninsured > 12) {
      opportunities.push({
        title: 'Enrollment & Navigation Program',
        description: 'High uninsured rate indicates need for outreach',
        potential: 'Community health worker-led enrollment assistance',
        priority: 'medium'
      });
    }

    return {
      keyNeeds,
      serviceGaps,
      opportunities
    };
  }, [censusData, organizations]);

  if (!needsData) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-gray-500">
          No needs assessment data available
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card className="bg-gradient-to-br from-red-50 via-orange-50 to-white border-2 border-red-200">
        <CardHeader>
          <CardTitle className="text-2xl font-bold bg-gradient-to-r from-red-600 to-orange-600 bg-clip-text text-transparent">
            Slide 5: Key Needs & Service Gaps
          </CardTitle>
          <p className="text-sm text-gray-600 mt-1">Critical needs and strategic opportunities</p>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Three-Column Layout for Better Organization */}
          <div className="grid md:grid-cols-3 gap-4">
            {/* Key Needs */}
            <Card className="border-2 border-red-200">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-semibold flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-red-600" />
                  Critical Needs
                </CardTitle>
              </CardHeader>
              <CardContent>
                {needsData.keyNeeds.length > 0 ? (
                  <div className="space-y-2">
                    {needsData.keyNeeds.map((need, idx) => (
                      <div key={idx} className="p-3 bg-gradient-to-br from-red-50 to-orange-50 border border-red-200 rounded-lg">
                        <div className="flex items-start justify-between mb-1">
                          <h4 className="text-xs font-bold text-gray-900">{need.title}</h4>
                          <Badge variant="destructive" className="text-xs h-5">{need.severity === 'high' ? 'High' : 'Med'}</Badge>
                        </div>
                        <p className="text-xs text-gray-700 mb-1">{need.description}</p>
                        <p className="text-xs text-red-700 font-medium">{need.impact}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-gray-500 text-center py-4">No critical needs identified</p>
                )}
              </CardContent>
            </Card>

            {/* Service Gaps */}
            <Card className="border-2 border-orange-200">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-semibold flex items-center gap-2">
                  <Target className="w-4 h-4 text-orange-600" />
                  Service Gaps
                </CardTitle>
              </CardHeader>
              <CardContent>
                {needsData.serviceGaps.length > 0 ? (
                  <div className="space-y-2">
                    {needsData.serviceGaps.map((gap, idx) => (
                      <div key={idx} className="p-3 bg-gradient-to-br from-orange-50 to-amber-50 border border-orange-200 rounded-lg">
                        <div className="flex items-start justify-between mb-1">
                          <h4 className="text-xs font-bold text-gray-900">{gap.service}</h4>
                          <Badge variant={gap.priority === 'high' ? 'destructive' : 'default'} className="text-xs h-5">
                            {gap.priority === 'high' ? 'High' : 'Med'}
                          </Badge>
                        </div>
                        <p className="text-xs text-gray-700">{gap.description}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-gray-500 text-center py-4">No major service gaps</p>
                )}
              </CardContent>
            </Card>

            {/* Opportunities */}
            <Card className="border-2 border-emerald-200">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-semibold flex items-center gap-2">
                  <Lightbulb className="w-4 h-4 text-emerald-600" />
                  Opportunities
                </CardTitle>
              </CardHeader>
              <CardContent>
                {needsData.opportunities.length > 0 ? (
                  <div className="space-y-2">
                    {needsData.opportunities.map((opp, idx) => (
                      <div key={idx} className="p-3 bg-gradient-to-br from-emerald-50 to-teal-50 border border-emerald-200 rounded-lg">
                        <div className="flex items-start justify-between mb-1">
                          <h4 className="text-xs font-bold text-gray-900">{opp.title}</h4>
                          <Badge className="bg-emerald-600 text-xs h-5">{opp.priority === 'high' ? 'Top' : 'Med'}</Badge>
                        </div>
                        <p className="text-xs text-gray-700 mb-1">{opp.description}</p>
                        <p className="text-xs text-emerald-700 font-semibold">→ {opp.potential}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-xs text-gray-500 text-center py-4">No opportunities identified</p>
                )}
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}