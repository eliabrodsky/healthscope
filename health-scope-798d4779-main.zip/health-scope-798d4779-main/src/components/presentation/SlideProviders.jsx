import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Building2, MapPin } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const GRADIENT_COLORS = [
  { id: 'grad1', start: '#ef4444', end: '#dc2626' },
  { id: 'grad2', start: '#10b981', end: '#059669' },
  { id: 'grad3', start: '#3b82f6', end: '#2563eb' },
  { id: 'grad4', start: '#f59e0b', end: '#ea580c' },
  { id: 'grad5', start: '#8b5cf6', end: '#7c3aed' }
];

export default function SlideProviders({ assessment, organizations, censusData }) {
  const providerData = useMemo(() => {
    if (!organizations || organizations.length === 0) return null;

    const byType = {};
    organizations.forEach(org => {
      const type = org.type || 'other';
      byType[type] = (byType[type] || 0) + 1;
    });

    const typeData = Object.entries(byType).map(([type, count]) => ({
      type: type.replace('_', ' ').toUpperCase(),
      count
    }));

    const servicesMap = {};
    organizations.forEach(org => {
      if (org.services && Array.isArray(org.services)) {
        org.services.forEach(service => {
          servicesMap[service] = (servicesMap[service] || 0) + 1;
        });
      }
    });

    const servicesData = Object.entries(servicesMap)
      .map(([service, count]) => ({ service, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);

    const totalPop = Object.values(censusData || {}).reduce((sum, d) => sum + (d.population || 0), 0);
    const providersPerCapita = totalPop > 0 ? Math.round(totalPop / organizations.length) : 0;

    return {
      totalProviders: organizations.length,
      byType: typeData,
      servicesData,
      providersPerCapita,
      totalPop
    };
  }, [organizations, censusData]);

  if (!providerData) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-gray-500">
          No provider data available
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card className="bg-gradient-to-br from-purple-50 via-pink-50 to-white border-2 border-purple-200">
        <CardHeader>
          <CardTitle className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            Slide 3: Healthcare Provider Analysis
          </CardTitle>
          <p className="text-sm text-gray-600 mt-1">Service area coverage and provider mix</p>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Summary Metrics with Gradients */}
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-gradient-to-br from-purple-50 to-pink-50 p-4 rounded-xl border-2 border-purple-200 shadow-sm">
              <div className="flex items-center gap-2 mb-1">
                <Building2 className="w-4 h-4 text-purple-600" />
                <p className="text-xs font-medium text-gray-600">Total Providers</p>
              </div>
              <p className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                {providerData.totalProviders}
              </p>
            </div>
            <div className="bg-gradient-to-br from-blue-50 to-cyan-50 p-4 rounded-xl border-2 border-blue-200 shadow-sm">
              <div className="flex items-center gap-2 mb-1">
                <MapPin className="w-4 h-4 text-blue-600" />
                <p className="text-xs font-medium text-gray-600">Pop. per Provider</p>
              </div>
              <p className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
                {providerData.providersPerCapita.toLocaleString()}
              </p>
            </div>
            <div className="bg-gradient-to-br from-amber-50 to-orange-50 p-4 rounded-xl border-2 border-amber-200 shadow-sm">
              <p className="text-xs font-medium text-gray-600 mb-1">Service Mix</p>
              <p className="text-2xl font-bold bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">
                {providerData.servicesData.length}
              </p>
              <p className="text-xs text-gray-500 mt-1">Unique services</p>
            </div>
          </div>

          {/* Provider Type Distribution */}
          <div className="grid md:grid-cols-2 gap-4">
            <Card className="border-2">
              <CardHeader>
                <CardTitle className="text-base font-semibold">Provider Type Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={220}>
                  <PieChart>
                    <defs>
                      {GRADIENT_COLORS.map((grad) => (
                        <linearGradient key={grad.id} id={grad.id} x1="0" y1="0" x2="1" y2="1">
                          <stop offset="0%" stopColor={grad.start} />
                          <stop offset="100%" stopColor={grad.end} />
                        </linearGradient>
                      ))}
                    </defs>
                    <Pie
                      data={providerData.byType}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ percent }) => `${(percent * 100).toFixed(0)}%`}
                      outerRadius={85}
                      dataKey="count"
                    >
                      {providerData.byType.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={`url(#${GRADIENT_COLORS[index % GRADIENT_COLORS.length].id})`} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ fontSize: 11, borderRadius: 8 }}
                      formatter={(value, name, props) => [
                        `${value} providers`,
                        props.payload.type
                      ]}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="border-2">
              <CardHeader>
                <CardTitle className="text-base font-semibold">Provider Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {providerData.byType.map((item, idx) => (
                    <div key={idx} className="flex items-center justify-between p-3 rounded-lg border-2 transition-all hover:shadow-md" 
                      style={{ 
                        background: `linear-gradient(135deg, ${GRADIENT_COLORS[idx % GRADIENT_COLORS.length].start}15, ${GRADIENT_COLORS[idx % GRADIENT_COLORS.length].end}10)`,
                        borderColor: `${GRADIENT_COLORS[idx % GRADIENT_COLORS.length].start}40`
                      }}>
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-3 h-3 rounded-full" 
                          style={{ 
                            background: `linear-gradient(135deg, ${GRADIENT_COLORS[idx % GRADIENT_COLORS.length].start}, ${GRADIENT_COLORS[idx % GRADIENT_COLORS.length].end})`
                          }}
                        />
                        <span className="text-sm font-semibold text-gray-900">{item.type}</span>
                      </div>
                      <Badge variant="outline" className="font-bold">{item.count}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Top Services */}
          {providerData.servicesData.length > 0 && (
            <Card className="border-2">
              <CardHeader>
                <CardTitle className="text-base font-semibold">Most Common Services Offered</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={280}>
                  <BarChart data={providerData.servicesData} layout="vertical">
                    <defs>
                      <linearGradient id="serviceGrad" x1="0" y1="0" x2="1" y2="0">
                        <stop offset="0%" stopColor="#8b5cf6" stopOpacity={0.9}/>
                        <stop offset="100%" stopColor="#ec4899" stopOpacity={0.7}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                    <XAxis type="number" tick={{ fontSize: 10 }} />
                    <YAxis 
                      dataKey="service" 
                      type="category" 
                      width={130} 
                      tick={{ fontSize: 10 }}
                    />
                    <Tooltip 
                      contentStyle={{ fontSize: 11, borderRadius: 8 }}
                      formatter={(value) => [`${value} providers`, 'Count']}
                    />
                    <Bar dataKey="count" fill="url(#serviceGrad)" radius={[0, 8, 8, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          )}
        </CardContent>
      </Card>
    </div>
  );
}