import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  X,
  Plus,
  Image as ImageIcon,
  BarChart3,
  Map,
  Type,
  MoveUp,
  MoveDown,
  Download,
  FileText,
  Trash2
} from 'lucide-react';
import { toast } from 'sonner';

const VISUAL_OPTIONS = [
  { id: 'demographic_bar', name: 'Demographics Bar Chart', icon: BarChart3, type: 'chart' },
  { id: 'provider_pie', name: 'Provider Distribution Pie', icon: BarChart3, type: 'chart' },
  { id: 'zip_map', name: 'ZIP Code Map', icon: Map, type: 'map' },
  { id: 'poverty_map', name: 'Poverty Rate Map', icon: Map, type: 'map' },
  { id: 'uninsured_map', name: 'Uninsured Rate Map', icon: Map, type: 'map' }
];

export default function SlideBuilder({ isOpen, onClose, assessmentTitle }) {
  const [slides, setSlides] = useState([
    {
      id: 1,
      type: 'title',
      title: assessmentTitle || 'Healthcare Provider Analysis',
      subtitle: 'Comprehensive Market Overview'
    }
  ]);
  const [currentSlideId, setCurrentSlideId] = useState(1);
  const [isExporting, setIsExporting] = useState(false);

  const currentSlide = slides.find(s => s.id === currentSlideId);

  const addSlide = (type) => {
    const newSlide = {
      id: Date.now(),
      type,
      title: '',
      content: '',
      visual: null,
      imageUrl: null
    };
    setSlides([...slides, newSlide]);
    setCurrentSlideId(newSlide.id);
    toast.success('Slide added');
  };

  const updateSlide = (updates) => {
    setSlides(slides.map(s => s.id === currentSlideId ? { ...s, ...updates } : s));
  };

  const deleteSlide = (slideId) => {
    if (slides.length === 1) {
      toast.error('Cannot delete the last slide');
      return;
    }
    setSlides(slides.filter(s => s.id !== slideId));
    if (currentSlideId === slideId) {
      setCurrentSlideId(slides[0].id);
    }
    toast.success('Slide deleted');
  };

  const moveSlide = (slideId, direction) => {
    const index = slides.findIndex(s => s.id === slideId);
    if (
      (direction === 'up' && index === 0) ||
      (direction === 'down' && index === slides.length - 1)
    ) {
      return;
    }
    const newSlides = [...slides];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    [newSlides[index], newSlides[targetIndex]] = [newSlides[targetIndex], newSlides[index]];
    setSlides(newSlides);
  };

  const handleExport = async (format) => {
    setIsExporting(true);
    toast.loading(`Generating ${format.toUpperCase()}...`, { id: 'export' });
    
    try {
      // Simulate export process
      await new Promise(resolve => setTimeout(resolve, 2000));
      toast.success(`${format.toUpperCase()} generated successfully!`, { id: 'export' });
      
      // In real implementation, this would call a backend function to generate the file
      // const response = await base44.functions.invoke('generatePresentation', { slides, format });
    } catch (error) {
      toast.error('Export failed', { id: 'export' });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[90vh] flex flex-col p-0">
        <DialogHeader className="px-6 py-4 border-b">
          <div className="flex items-center justify-between">
            <DialogTitle className="text-xl font-bold">Presentation Builder</DialogTitle>
            <div className="flex items-center gap-2">
              <Badge variant="outline">{slides.length} slides</Badge>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleExport('pdf')}
                disabled={isExporting}
              >
                <FileText className="w-4 h-4 mr-2" />
                Export PDF
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleExport('ppt')}
                disabled={isExporting}
              >
                <Download className="w-4 h-4 mr-2" />
                Export PPT
              </Button>
            </div>
          </div>
        </DialogHeader>

        <div className="flex-1 overflow-hidden flex">
          {/* Slide Thumbnails */}
          <div className="w-64 border-r bg-gray-50 overflow-y-auto p-4">
            <div className="space-y-2">
              {slides.map((slide, index) => (
                <div
                  key={slide.id}
                  className={`relative group cursor-pointer p-3 rounded-lg border-2 transition-all ${
                    currentSlideId === slide.id
                      ? 'border-emerald-500 bg-white shadow-md'
                      : 'border-gray-200 bg-white hover:border-gray-300'
                  }`}
                  onClick={() => setCurrentSlideId(slide.id)}
                >
                  <div className="flex items-start justify-between mb-2">
                    <Badge variant="outline" className="text-xs">
                      Slide {index + 1}
                    </Badge>
                    {slides.length > 1 && (
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6 opacity-0 group-hover:opacity-100"
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteSlide(slide.id);
                        }}
                      >
                        <Trash2 className="w-3 h-3 text-red-600" />
                      </Button>
                    )}
                  </div>
                  <p className="text-xs font-semibold text-gray-900 truncate">
                    {slide.title || `${slide.type} slide`}
                  </p>
                  <div className="mt-2 flex gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6"
                      onClick={(e) => {
                        e.stopPropagation();
                        moveSlide(slide.id, 'up');
                      }}
                      disabled={index === 0}
                    >
                      <MoveUp className="w-3 h-3" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6"
                      onClick={(e) => {
                        e.stopPropagation();
                        moveSlide(slide.id, 'down');
                      }}
                      disabled={index === slides.length - 1}
                    >
                      <MoveDown className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-4 space-y-2">
              <Button
                variant="outline"
                size="sm"
                className="w-full justify-start"
                onClick={() => addSlide('content')}
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Content Slide
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="w-full justify-start"
                onClick={() => addSlide('visual')}
              >
                <BarChart3 className="w-4 h-4 mr-2" />
                Add Visual Slide
              </Button>
            </div>
          </div>

          {/* Slide Editor */}
          <div className="flex-1 overflow-y-auto p-6">
            {currentSlide && (
              <div className="max-w-4xl mx-auto space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">
                      {currentSlide.type === 'title' ? 'Title Slide' : 
                       currentSlide.type === 'content' ? 'Content Slide' : 'Visual Slide'}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <label className="text-sm font-medium text-gray-700 mb-2 block">
                        Slide Title
                      </label>
                      <Input
                        value={currentSlide.title || ''}
                        onChange={(e) => updateSlide({ title: e.target.value })}
                        placeholder="Enter slide title..."
                        className="text-lg"
                      />
                    </div>

                    {currentSlide.type === 'title' && (
                      <div>
                        <label className="text-sm font-medium text-gray-700 mb-2 block">
                          Subtitle
                        </label>
                        <Input
                          value={currentSlide.subtitle || ''}
                          onChange={(e) => updateSlide({ subtitle: e.target.value })}
                          placeholder="Enter subtitle..."
                        />
                      </div>
                    )}

                    {(currentSlide.type === 'content' || currentSlide.type === 'visual') && (
                      <div>
                        <label className="text-sm font-medium text-gray-700 mb-2 block">
                          Content
                        </label>
                        <Textarea
                          value={currentSlide.content || ''}
                          onChange={(e) => updateSlide({ content: e.target.value })}
                          placeholder="Enter slide content..."
                          rows={6}
                        />
                      </div>
                    )}

                    {currentSlide.type === 'visual' && (
                      <div>
                        <label className="text-sm font-medium text-gray-700 mb-2 block">
                          Select Visual
                        </label>
                        <div className="grid grid-cols-2 gap-3">
                          {VISUAL_OPTIONS.map((visual) => (
                            <button
                              key={visual.id}
                              onClick={() => updateSlide({ visual: visual.id })}
                              className={`p-4 rounded-lg border-2 transition-all text-left ${
                                currentSlide.visual === visual.id
                                  ? 'border-emerald-500 bg-emerald-50'
                                  : 'border-gray-200 hover:border-gray-300 bg-white'
                              }`}
                            >
                              <div className="flex items-center gap-3">
                                <visual.icon className={`w-5 h-5 ${
                                  currentSlide.visual === visual.id
                                    ? 'text-emerald-600'
                                    : 'text-gray-600'
                                }`} />
                                <div>
                                  <p className="text-sm font-semibold text-gray-900">
                                    {visual.name}
                                  </p>
                                  <Badge variant="outline" className="mt-1 text-xs">
                                    {visual.type}
                                  </Badge>
                                </div>
                              </div>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    <div>
                      <label className="text-sm font-medium text-gray-700 mb-2 block">
                        Add Image (optional)
                      </label>
                      <div className="flex items-center gap-3">
                        <Input
                          type="url"
                          value={currentSlide.imageUrl || ''}
                          onChange={(e) => updateSlide({ imageUrl: e.target.value })}
                          placeholder="Paste image URL..."
                          className="flex-1"
                        />
                        <Button variant="outline" size="icon">
                          <ImageIcon className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Preview */}
                <Card className="border-2 border-gray-300">
                  <CardHeader className="bg-gray-50">
                    <CardTitle className="text-base">Preview</CardTitle>
                  </CardHeader>
                  <CardContent className="p-8 bg-white min-h-[400px]">
                    <div className="space-y-4">
                      {currentSlide.type === 'title' ? (
                        <div className="text-center py-20">
                          <h1 className="text-4xl font-bold text-gray-900 mb-4">
                            {currentSlide.title || 'Slide Title'}
                          </h1>
                          <p className="text-xl text-gray-600">
                            {currentSlide.subtitle || 'Subtitle'}
                          </p>
                        </div>
                      ) : (
                        <>
                          <h2 className="text-2xl font-bold text-gray-900">
                            {currentSlide.title || 'Slide Title'}
                          </h2>
                          {currentSlide.content && (
                            <p className="text-gray-700 whitespace-pre-wrap">
                              {currentSlide.content}
                            </p>
                          )}
                          {currentSlide.visual && (
                            <div className="mt-6 p-8 bg-gray-100 rounded-lg border-2 border-dashed border-gray-300 text-center">
                              <BarChart3 className="w-16 h-16 text-gray-400 mx-auto mb-3" />
                              <p className="text-sm text-gray-600">
                                {VISUAL_OPTIONS.find(v => v.id === currentSlide.visual)?.name} will appear here
                              </p>
                            </div>
                          )}
                          {currentSlide.imageUrl && (
                            <div className="mt-4">
                              <img
                                src={currentSlide.imageUrl}
                                alt="Slide"
                                className="rounded-lg border shadow-sm max-h-64 mx-auto"
                              />
                            </div>
                          )}
                        </>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}
          </div>
        </div>

        <DialogFooter className="px-6 py-4 border-t">
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}