import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Loader2, Activity, MapPin, CheckCircle } from "lucide-react";

const CDC_INDICATORS = {
  "Health Conditions": [
    { id: "DIABETES", label: "Diabetes", description: "Diagnosed diabetes among adults" },
    { id: "BPHIGH", label: "Hypertension", description: "High blood pressure among adults" },
    { id: "OBESITY", label: "Obesity", description: "Obesity among adults" },
    { id: "COPD", label: "COPD", description: "Chronic obstructive pulmonary disease" },
    { id: "CHD", label: "Coronary Heart Disease", description: "Coronary heart disease among adults" },
    { id: "STROKE", label: "Stroke", description: "Stroke among adults" },
    { id: "ASTHMA", label: "Asthma", description: "Current asthma among adults" }
  ],
  "Health Behaviors": [
    { id: "CSMOKING", label: "Smoking", description: "Current smoking among adults" },
    { id: "LPA", label: "Physical Inactivity", description: "No leisure-time physical activity" },
    { id: "BINGE", label: "Binge Drinking", description: "Binge drinking among adults" }
  ],
  "Well-being & Access": [
    { id: "GHLTH", label: "General Health", description: "Fair or poor self-rated health status" },
    { id: "MHLTH", label: "Mental Health", description: "Mental health not good for ≥14 days" },
    { id: "CHECKUP", label: "Routine Checkup", description: "Visited doctor for routine checkup within past year" }
  ]
};

export default function CdcDataLoader({ assessment, open, onClose, onDataLoaded }) {
  const [selectedIndicators, setSelectedIndicators] = useState([
    "DIABETES", "BPHIGH", "OBESITY", "CSMOKING", "LPA"
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const [step, setStep] = useState(1); // 1: review areas, 2: select indicators, 3: loading
  const [syncJob, setSyncJob] = useState(null);
  const [progress, setProgress] = useState(0);
  const [loadedStats, setLoadedStats] = useState({
    totalRecords: 0,
    zctasProcessed: 0,
    indicatorsLoaded: []
  });

  // Extract ZIP codes from various possible locations in the assessment
  const zipCodes = assessment?.processed_data?.zcta_codes || 
                  assessment?.geography?.zcta_codes ||
                  assessment?.processed_data?.zip_codes || 
                  assessment?.geography?.zip_codes || [];
  
  const hasBoundaries = zipCodes && zipCodes.length > 0;

  // Poll for progress while syncing
  useEffect(() => {
    if (!syncJob || syncJob.status !== 'in_progress') return;

    const pollInterval = setInterval(async () => {
      await processNextChunk();
    }, 2000);

    return () => clearInterval(pollInterval);
  }, [syncJob]);

  const processNextChunk = async () => {
    if (!syncJob?.job_id) return;

    try {
      const response = await base44.functions.invoke('processCdcChunk', {
        job_id: syncJob.job_id
      });

      if (response?.data?.success) {
        setProgress(response.data.progress || 0);

        // Update loaded stats
        setLoadedStats(prev => ({
          totalRecords: prev.totalRecords + (response.data.records_added || 0),
          zctasProcessed: response.data.zctas_completed || 0,
          indicatorsLoaded: syncJob?.selected_indicators || []
        }));

        setSyncJob(prev => ({...prev, status: response.data.is_complete ? 'complete' : 'in_progress'}));

        if (response.data.is_complete) {
          toast.success(`CDC data loaded: ${loadedStats.totalRecords + (response.data.records_added || 0)} records for ${response.data.zctas_completed} ZCTAs`);
          setIsLoading(false);
          if (onDataLoaded) onDataLoaded();
          onClose();
        }
      }
    } catch (error) {
      console.warn('Error processing chunk:', error);
    }
  };

  const toggleIndicator = (id) => {
    setSelectedIndicators(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const selectCategory = (category) => {
    const categoryIds = CDC_INDICATORS[category].map(ind => ind.id);
    const allSelected = categoryIds.every(id => selectedIndicators.includes(id));
    
    if (allSelected) {
      setSelectedIndicators(prev => prev.filter(id => !categoryIds.includes(id)));
    } else {
      setSelectedIndicators(prev => [...new Set([...prev, ...categoryIds])]);
    }
  };

  const selectAll = () => {
    const allIds = Object.values(CDC_INDICATORS).flat().map(ind => ind.id);
    if (selectedIndicators.length === allIds.length) {
      setSelectedIndicators([]);
    } else {
      setSelectedIndicators(allIds);
    }
  };

  const handleLoadData = async () => {
    if (selectedIndicators.length === 0) {
      toast.error("Please select at least one health indicator");
      return;
    }

    setIsLoading(true);
    setStep(3);
    const toastId = toast.loading('Starting CDC data sync...');

    try {
      console.log('Calling startCdcSync with:', {
        assessment_id: assessment.id,
        indicators: selectedIndicators,
        zctas: zipCodes
      });

      const response = await base44.functions.invoke('startCdcSync', {
        assessment_id: assessment.id,
        indicators: selectedIndicators,
        zctas: zipCodes
      });

      console.log('startCdcSync response:', JSON.stringify(response, null, 2));

      if (response?.data?.success) {
        toast.success('CDC sync started! Processing in background...', { id: toastId });
        setSyncJob({
          job_id: response.data.job_id,
          status: 'in_progress'
        });

        // Start processing immediately
        setTimeout(() => processNextChunk(), 1000);
      } else {
        const errorMsg = response?.data?.error || 'Failed to start sync';
        throw new Error(errorMsg);
      }
    } catch (error) {
      console.error('Error starting CDC sync:', error);
      console.error('Error response:', JSON.stringify(error.response, null, 2));
      console.error('Error data:', JSON.stringify(error.response?.data, null, 2));

      let errorMessage = 'Unknown error';
      if (error.response?.data?.error) {
        errorMessage = error.response.data.error;
      } else if (error.response?.data) {
        errorMessage = JSON.stringify(error.response.data);
      } else if (error.message) {
        errorMessage = error.message;
      }

      toast.error(`Failed to start sync: ${errorMessage}`, { id: toastId });
      setStep(2);
      setIsLoading(false);
    }
  };

  if (!assessment) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-blue-600" />
            Add CDC Health Needs Data
          </DialogTitle>
        </DialogHeader>

        {!hasBoundaries ? (
          <div className="py-8 text-center space-y-4">
            <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto">
              <MapPin className="w-8 h-8 text-amber-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                No Geographic Data Found
              </h3>
              <p className="text-sm text-gray-600 mb-4">
                This assessment doesn't have any ZIP codes or boundaries loaded yet.
                You need to load boundaries first before adding CDC health data.
              </p>
              <Button onClick={onClose}>
                Close
              </Button>
            </div>
          </div>
        ) : (
          <>
            {step === 1 && (
          <div className="space-y-6">
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Service Area Coverage</h3>
              <p className="text-sm text-gray-600 mb-4">
                We'll pull CDC PLACES health indicator data for the following ZIP codes in your assessment:
              </p>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-4 mb-4">
                    <MapPin className="w-5 h-5 text-blue-600" />
                    <div>
                      <p className="font-semibold text-gray-900">
                        {assessment.geography?.city}, {assessment.geography?.state}
                      </p>
                      <p className="text-sm text-gray-600">
                        {zipCodes.length} ZIP codes in assessment region
                      </p>
                    </div>
                  </div>
                  
                  <div className="bg-gray-50 rounded-lg p-3 max-h-32 overflow-y-auto">
                    <div className="flex flex-wrap gap-2">
                      {zipCodes.slice(0, 20).map(zip => (
                        <Badge key={zip} variant="secondary">{zip}</Badge>
                      ))}
                      {zipCodes.length > 20 && (
                        <Badge variant="outline">+{zipCodes.length - 20} more</Badge>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={onClose}>Cancel</Button>
              <Button onClick={() => setStep(2)}>
                Next: Select Indicators
              </Button>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-6">
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Select Health Indicators</h3>
              <p className="text-sm text-gray-600 mb-4">
                Choose which CDC health metrics you want to load for your assessment.
              </p>
            </div>

            <div className="flex items-center justify-between pb-4 border-b">
              <Button
                variant="outline"
                size="sm"
                onClick={selectAll}
              >
                {selectedIndicators.length === Object.values(CDC_INDICATORS).flat().length 
                  ? "Deselect All" 
                  : "Select All"}
              </Button>
              <p className="text-sm text-gray-600">
                {selectedIndicators.length} indicator{selectedIndicators.length !== 1 ? 's' : ''} selected
              </p>
            </div>

            <div className="space-y-6">
              {Object.entries(CDC_INDICATORS).map(([category, indicators]) => {
                const allSelected = indicators.every(ind => selectedIndicators.includes(ind.id));
                
                return (
                  <div key={category}>
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="font-semibold text-gray-900">{category}</h4>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => selectCategory(category)}
                      >
                        {allSelected ? "Deselect" : "Select"} Category
                      </Button>
                    </div>
                    
                    <div className="space-y-2">
                      {indicators.map(indicator => (
                        <div
                          key={indicator.id}
                          className="flex items-start gap-3 p-3 rounded-lg hover:bg-gray-50 cursor-pointer"
                          onClick={() => toggleIndicator(indicator.id)}
                        >
                          <Checkbox
                            checked={selectedIndicators.includes(indicator.id)}
                            onCheckedChange={() => toggleIndicator(indicator.id)}
                          />
                          <div className="flex-1">
                            <Label className="font-medium cursor-pointer">
                              {indicator.label}
                            </Label>
                            <p className="text-xs text-gray-600 mt-0.5">
                              {indicator.description}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t">
              <Button variant="outline" onClick={() => setStep(1)}>Back</Button>
              <Button 
                onClick={handleLoadData}
                disabled={selectedIndicators.length === 0}
              >
                Load CDC Data for My Assessment
              </Button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="py-8 md:py-12 text-center px-4">
            <Loader2 className="w-12 h-12 md:w-16 md:h-16 animate-spin text-blue-600 mx-auto mb-4" />
            <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-2">
              Loading Health Data...
            </h3>
            <p className="text-sm md:text-base text-gray-600 mb-4">
              Processing {zipCodes.length} ZIP codes in batches of 20
            </p>

            <div className="max-w-md mx-auto mb-6">
              <Progress value={progress} className="h-3" />
              <p className="text-sm text-gray-600 mt-2">
                {progress}% complete • {loadedStats.zctasProcessed} of {zipCodes.length} ZCTAs processed
              </p>
            </div>

            <div className="max-w-md mx-auto space-y-2 mb-6">
              <div className="flex items-center justify-center gap-2 text-xs md:text-sm text-gray-600">
                <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0" />
                <span>Chunked loading (lightweight & reliable)</span>
              </div>
              <div className="flex items-center justify-center gap-2 text-xs md:text-sm text-gray-600">
                <Loader2 className="w-4 h-4 animate-spin flex-shrink-0" />
                <span>Processing {selectedIndicators.length} health indicators</span>
              </div>
            </div>

            {loadedStats.totalRecords > 0 && (
              <div className="bg-blue-50 rounded-lg p-4 max-w-md mx-auto">
                <p className="text-sm font-semibold text-blue-900 mb-2">Data Loaded So Far:</p>
                <div className="grid grid-cols-2 gap-2 text-xs text-blue-800">
                  <div>
                    <div className="font-bold text-lg">{loadedStats.totalRecords}</div>
                    <div>Health Records</div>
                  </div>
                  <div>
                    <div className="font-bold text-lg">{loadedStats.indicatorsLoaded.length}</div>
                    <div>Indicators</div>
                  </div>
                </div>
                {loadedStats.indicatorsLoaded.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-blue-200">
                    <p className="text-xs text-blue-700 mb-1">Loading:</p>
                    <div className="flex flex-wrap gap-1">
                      {loadedStats.indicatorsLoaded.map(ind => (
                        <span key={ind} className="text-xs bg-blue-200 text-blue-800 px-2 py-0.5 rounded">
                          {ind}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}