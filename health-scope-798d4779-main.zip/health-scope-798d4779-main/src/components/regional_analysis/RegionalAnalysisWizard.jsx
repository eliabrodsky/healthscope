import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import Step1_SelectAssessment from "../regional_wizard/Step1_SelectAssessment";
import Step2_ReviewData from "../regional_wizard/Step2_ReviewData";
import Step3_Summary from "../regional_wizard/Step3_Summary";

const WIZARD_STEPS = [
  { id: 1, name: "Select Assessment", description: "Choose assessment and ZIP codes" },
  { id: 2, name: "Review Data", description: "Check data availability" },
  { id: 3, name: "Summary", description: "View and configure analysis" }
];

export default function RegionalAnalysisWizard({ onComplete, onCancel }) {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    assessment_id: null,
    assessment: null,
    zip_codes: [],
    data_status: null,
    demographics: [],
    health_data: [],
    boundaries: []
  });

  const updateFormData = (updates) => {
    setFormData(prev => ({ ...prev, ...updates }));
  };

  const handleNext = () => {
    setCurrentStep(prev => Math.min(prev + 1, WIZARD_STEPS.length));
  };

  const handlePrev = () => {
    setCurrentStep(prev => Math.max(prev - 1, 1));
  };

  const handleSave = async () => {
    try {
      // Only include demographics for selected ZIP codes
      const selectedDemographics = formData.demographics.filter(d => formData.zip_codes.includes(d.zcta5));

      // Filter out invalid and outlier values for accurate calculations
      const validDemographics = selectedDemographics.filter(d => 
        d.median_income > 0 && d.median_income < 500000
      );

      const regionalStats = {
        totalPopulation: selectedDemographics.reduce((sum, d) => sum + (d.population || 0), 0),
        avgIncome: validDemographics.length > 0 
          ? Math.round(validDemographics.reduce((sum, d) => sum + d.median_income, 0) / validDemographics.length)
          : 0,
        avgPoverty: selectedDemographics.length > 0
          ? parseFloat((selectedDemographics.reduce((sum, d) => sum + (d.poverty_rate || 0), 0) / selectedDemographics.length).toFixed(1))
          : 0,
        avgUninsured: selectedDemographics.length > 0
          ? parseFloat((selectedDemographics.reduce((sum, d) => sum + (d.uninsured_rate || 0), 0) / selectedDemographics.length).toFixed(1))
          : 0
      };

      await base44.entities.RegionalAnalysis.create({
        title: `${formData.assessment?.title} - Regional Analysis`,
        assessment_id: formData.assessment_id,
        assessment_title: formData.assessment?.title,
        zip_codes: formData.zip_codes,
        demographics_summary: {
          total_population: regionalStats.totalPopulation,
          avg_income: regionalStats.avgIncome,
          avg_poverty: regionalStats.avgPoverty,
          avg_uninsured: regionalStats.avgUninsured
        },
        status: 'draft'
      });

      toast.success('Regional analysis saved');
    } catch (error) {
      console.error('Save error:', error);
      toast.error('Failed to save: ' + (error.message || 'Unknown error'));
      throw error;
    }
  };

  const handlePublish = async () => {
    try {
      // Only include demographics for selected ZIP codes
      const selectedDemographics = formData.demographics.filter(d => formData.zip_codes.includes(d.zcta5));

      // Filter out invalid and outlier values for accurate calculations
      const validDemographics = selectedDemographics.filter(d => 
        d.median_income > 0 && d.median_income < 500000
      );

      const regionalStats = {
        totalPopulation: selectedDemographics.reduce((sum, d) => sum + (d.population || 0), 0),
        avgIncome: validDemographics.length > 0 
          ? Math.round(validDemographics.reduce((sum, d) => sum + d.median_income, 0) / validDemographics.length)
          : 0,
        avgPoverty: selectedDemographics.length > 0
          ? parseFloat((selectedDemographics.reduce((sum, d) => sum + (d.poverty_rate || 0), 0) / selectedDemographics.length).toFixed(1))
          : 0,
        avgUninsured: selectedDemographics.length > 0
          ? parseFloat((selectedDemographics.reduce((sum, d) => sum + (d.uninsured_rate || 0), 0) / selectedDemographics.length).toFixed(1))
          : 0
      };

      await base44.entities.RegionalAnalysis.create({
        title: `${formData.assessment?.title} - Regional Analysis`,
        assessment_id: formData.assessment_id,
        assessment_title: formData.assessment?.title,
        zip_codes: formData.zip_codes,
        demographics_summary: {
          total_population: regionalStats.totalPopulation,
          avg_income: regionalStats.avgIncome,
          avg_poverty: regionalStats.avgPoverty,
          avg_uninsured: regionalStats.avgUninsured
        },
        status: 'published'
      });

      toast.success('Regional analysis published!');
      onComplete();
    } catch (error) {
      console.error('Publish error:', error);
      toast.error('Failed to publish: ' + (error.message || 'Unknown error'));
      throw error;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Progress Steps */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              {WIZARD_STEPS.map((step, index) => (
                <React.Fragment key={step.id}>
                  <div className="flex items-center">
                    <div
                      className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold ${
                        currentStep >= step.id
                          ? 'bg-emerald-600 text-white'
                          : 'bg-gray-200 text-gray-600'
                      }`}
                    >
                      {step.id}
                    </div>
                    <div className="ml-3 hidden md:block">
                      <div className="font-semibold text-gray-900">{step.name}</div>
                      <div className="text-xs text-gray-600">{step.description}</div>
                    </div>
                  </div>
                  {index < WIZARD_STEPS.length - 1 && (
                    <div
                      className={`flex-1 h-1 mx-4 ${
                        currentStep > step.id ? 'bg-emerald-600' : 'bg-gray-200'
                      }`}
                    />
                  )}
                </React.Fragment>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Step Content */}
        {currentStep === 1 && (
          <Step1_SelectAssessment
            formData={formData}
            updateFormData={updateFormData}
            onNext={handleNext}
          />
        )}

        {currentStep === 2 && (
          <Step2_ReviewData
            formData={formData}
            updateFormData={updateFormData}
            onNext={handleNext}
            onPrev={handlePrev}
          />
        )}

        {currentStep === 3 && (
          <Step3_Summary
            formData={formData}
            updateFormData={updateFormData}
            onPrev={handlePrev}
            onSave={handleSave}
            onPublish={handlePublish}
          />
        )}
      </div>
    </div>
  );
}