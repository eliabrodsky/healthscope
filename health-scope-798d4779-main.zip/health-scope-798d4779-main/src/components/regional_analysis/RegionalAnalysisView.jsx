import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { ArrowLeft, MapPin, Calendar, Users, Edit, Map as MapIcon, Table as TableIcon, BarChart3, Trash2, EyeOff } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell, LabelList, ReferenceLine } from "recharts";
import InteractiveMap from "../maps/InteractiveMap";
import CityBubbleMap from "../maps/CityBubbleMap";
import { toast } from "sonner";
import LottieLoader from "../ui/LottieLoader";
import GooglePlacesEnricher from "../data/GooglePlacesEnricher";
import GooglePlacesWarningDialog from "../data/GooglePlacesWarningDialog";

export default function RegionalAnalysisView({ analysis, onBack, onEdit, onDelete, onUnpublish }) {
  const [demographics, setDemographics] = useState([]);
  const [healthData, setHealthData] = useState([]);
  const [boundaries, setBoundaries] = useState([]);
  const [organizations, setOrganizations] = useState([]);
  const [cityData, setCityData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [viewMode, setViewMode] = useState('summary');
  const [selectedHealthMetrics, setSelectedHealthMetrics] = useState([]);
  const [healthMapMetric, setHealthMapMetric] = useState('');
  const [mapSettings, setMapSettings] = useState({
    showZipLabels: false,
    showDataOverlay: true,
    colorScale: 'viridis'
  });
  const [showPlacesEnricher, setShowPlacesEnricher] = useState(false);
  const [showPlacesWarning, setShowPlacesWarning] = useState(false);
  const [placesResults, setPlacesResults] = useState([]);

  useEffect(() => {
    loadData();
  }, [analysis]);

  const loadData = async () => {
    if (!analysis?.zip_codes || analysis.zip_codes.length === 0) {
      setIsLoading(false);
      return;
    }
    
    setIsLoading(true);
    const zipCodes = analysis.zip_codes || [];
    
    try {
      // Load demographics in batches if needed
      toast.info('Loading demographics...');
      let demoData = [];
      try {
        if (zipCodes.length > 50) {
          for (let i = 0; i < zipCodes.length; i += 50) {
            const batch = zipCodes.slice(i, i + 50);
            const batchData = await base44.entities.ZipDemographics.filter({ zcta5: { $in: batch } });
            demoData = [...demoData, ...batchData.filter(d => batch.includes(d.zcta5))];
          }
        } else {
          const allDemoData = await base44.entities.ZipDemographics.filter({ zcta5: { $in: zipCodes } });
          demoData = allDemoData.filter(d => zipCodes.includes(d.zcta5));
        }
        setDemographics(demoData);
      } catch (err) {
        console.error('Demographics load failed:', err);
        toast.error('Failed to load demographics');
        setDemographics([]);
      }
      
      // Load boundaries in smaller batches with delays
      toast.info('Loading geographic boundaries...');
      let bounds = [];
      try {
        if (zipCodes.length > 20) {
          for (let i = 0; i < zipCodes.length; i += 15) {
            const batch = zipCodes.slice(i, i + 15);
            const batchBounds = await base44.entities.ZctaBoundary.filter({ zcta5: { $in: batch } });
            bounds = [...bounds, ...batchBounds.filter(b => batch.includes(b.zcta5))];
            // Small delay to avoid overwhelming the database
            if (i + 15 < zipCodes.length) {
              await new Promise(resolve => setTimeout(resolve, 300));
            }
          }
        } else {
          const allBounds = await base44.entities.ZctaBoundary.filter({ zcta5: { $in: zipCodes } });
          bounds = allBounds.filter(b => zipCodes.includes(b.zcta5));
        }
        setBoundaries(bounds);
      } catch (err) {
        console.error('Boundaries load failed:', err);
        toast.error('Failed to load boundaries');
        setBoundaries([]);
      }
      
      // Load health data with smart limits
      toast.info('Loading health indicators...');
      let health = [];
      try {
        const limit = zipCodes.length > 50 ? 2000 : 1000;
        if (zipCodes.length > 40) {
          for (let i = 0; i < zipCodes.length; i += 20) {
            const batch = zipCodes.slice(i, i + 20);
            const batchHealth = await base44.entities.CdcHealthData.filter(
              { zcta5: { $in: batch } },
              null,
              500
            );
            health = [...health, ...batchHealth.filter(h => batch.includes(h.zcta5))];
          }
        } else {
          const allHealth = await base44.entities.CdcHealthData.filter(
            { zcta5: { $in: zipCodes } },
            null,
            limit
          );
          health = allHealth.filter(h => zipCodes.includes(h.zcta5));
        }
        setHealthData(health);
      } catch (err) {
        console.error('Health data load failed:', err);
        toast.error('Failed to load health data');
        setHealthData([]);
      }
      
      // Load organizations with increased limit
      toast.info('Loading organizations...');
      let orgs = [];
      try {
        const allOrgs = await base44.entities.Organization.filter(
          { zip_code: { $in: zipCodes } },
          null,
          2000
        );
        orgs = allOrgs.filter(o => zipCodes.includes(o.zip_code));
        setOrganizations(orgs);
      } catch (err) {
        console.error('Organizations load failed:', err);
        toast.error('Failed to load organizations');
        setOrganizations([]);
      }
      
      // Load city data with increased limit
      toast.info('Loading city data...');
      try {
        const allCities = await base44.entities.ZctaPlaceRelationship.filter(
          { zcta5: { $in: zipCodes } },
          null,
          2000
        );
        const cities = (allCities || []).filter(c => zipCodes.includes(c.zcta5));
        setCityData(cities);
      } catch (err) {
        console.warn('Failed to load city data:', err);
        setCityData([]);
      }
      
      toast.success('Data loaded successfully');
    } catch (error) {
      console.error('Error loading data:', error);
      toast.error('Failed to load analysis data: ' + (error.message || 'Unknown error'));
    } finally {
      setIsLoading(false);
    }
  };

  // Only include demographics for selected ZIP codes in this analysis
  const selectedDemographics = demographics.filter(d => analysis.zip_codes.includes(d.zcta5));

  // Calculate regional stats - filter out invalid and outlier values
  const validDemographics = selectedDemographics.filter(d => 
    d.median_income > 0 && d.median_income < 500000 // Exclude unrealistic values
  );

  // Use stored summary if available, otherwise calculate from fresh data
  const regionalStats = analysis.demographics_summary || {
    total_population: selectedDemographics.reduce((sum, d) => sum + (d.population || 0), 0),
    avg_income: validDemographics.length > 0 
      ? Math.round(validDemographics.reduce((sum, d) => sum + d.median_income, 0) / validDemographics.length)
      : 0,
    avg_poverty: selectedDemographics.length > 0
      ? parseFloat((selectedDemographics.reduce((sum, d) => sum + (d.poverty_rate || 0), 0) / selectedDemographics.length).toFixed(1))
      : 0,
    avg_uninsured: selectedDemographics.length > 0
      ? parseFloat((selectedDemographics.reduce((sum, d) => sum + (d.uninsured_rate || 0), 0) / selectedDemographics.length).toFixed(1))
      : 0
  };

  // Age distribution charts - use snake_case keys
  const totalPop = regionalStats.total_population || 0;
  
  const ageDistribution = [
    { age: '0-17', male: Math.round(totalPop * 0.22 * 0.49), female: Math.round(totalPop * 0.22 * 0.51), malePct: 10.8, femalePct: 11.2 },
    { age: '18-44', male: Math.round(totalPop * 0.35 * 0.49), female: Math.round(totalPop * 0.35 * 0.51), malePct: 17.2, femalePct: 17.8 },
    { age: '45-64', male: Math.round(totalPop * 0.25 * 0.49), female: Math.round(totalPop * 0.25 * 0.51), malePct: 12.3, femalePct: 12.8 },
    { age: '65+', male: Math.round(totalPop * 0.18 * 0.49), female: Math.round(totalPop * 0.18 * 0.51), malePct: 8.8, femalePct: 9.2 }
  ];

  const insuranceDistribution = [
    { type: 'Private', value: Math.round(totalPop * 0.45), color: '#3b82f6' },
    { type: 'Medicare', value: Math.round(totalPop * 0.18), color: '#10b981' },
    { type: 'Medicaid', value: Math.round(totalPop * 0.20), color: '#f59e0b' },
    { type: 'Uninsured', value: Math.round(totalPop * parseFloat(regionalStats.avg_uninsured || 0) / 100), color: '#ef4444' }
  ];

  // Per-ZIP demographics data for charts
  const ageByZipData = selectedDemographics.map(demo => ({
    zip: demo.zcta5,
    '0-17': Math.round((demo.population || 0) * 0.22),
    '18-44': Math.round((demo.population || 0) * 0.35),
    '45-64': Math.round((demo.population || 0) * 0.25),
    '65+': Math.round((demo.population || 0) * 0.18)
  }));

  const insuranceByZipData = selectedDemographics.map(demo => ({
    zip: demo.zcta5,
    Private: Math.round((demo.population || 0) * 0.45),
    Medicare: Math.round((demo.population || 0) * 0.18),
    Medicaid: Math.round((demo.population || 0) * 0.20),
    Uninsured: Math.round((demo.population || 0) * (demo.uninsured_rate || 0) / 100)
  }));

  // Health data processing
  const healthByZip = {};
  healthData.forEach(item => {
    if (!healthByZip[item.zcta5]) healthByZip[item.zcta5] = {};
    healthByZip[item.zcta5][item.measure_id] = { value: item.data_value, name: item.measure };
  });

  const availableIndicators = [...new Set(healthData.map(h => h.measure_id))].map(id => {
    const sample = healthData.find(h => h.measure_id === id);
    return { id, name: sample.measure };
  });

  const healthAverages = {};
  availableIndicators.forEach(indicator => {
    const values = healthData.filter(h => h.measure_id === indicator.id).map(h => h.data_value);
    healthAverages[indicator.id] = values.length > 0 ? values.reduce((a, b) => a + b, 0) / values.length : 0;
  });

  const healthChartData = analysis.zip_codes.map(zip => {
    const dataPoint = { zipCode: zip };
    selectedHealthMetrics.forEach(metricId => {
      const zipData = healthByZip[zip]?.[metricId];
      dataPoint[metricId] = zipData?.value || 0;
      dataPoint[`${metricId}_avg`] = healthAverages[metricId] || 0;
    });
    return dataPoint;
  });

  const demographicCensusData = {};
  demographics.forEach(demo => {
    const pop = demo.population || 0;
    const income = demo.median_income || 0;
    const poverty = demo.poverty_rate !== undefined && demo.poverty_rate !== null ? demo.poverty_rate : 0;
    const uninsured = demo.uninsured_rate !== undefined && demo.uninsured_rate !== null ? demo.uninsured_rate : 0;
    
    demographicCensusData[demo.zcta5] = {
      population: pop,
      medianIncome: income,
      povertyRate: poverty,
      uninsuredRate: uninsured,
      source: demo.source?.includes('Census') || demo.acs_year ? 'US Census Bureau ACS' : (demo.source || 'Census Data')
    };
  });

  const healthCensusData = {};
  analysis.zip_codes.forEach(zip => {
    const zipHealth = healthByZip[zip] || {};
    const dataPoint = { source: 'CDC PLACES' };
    Object.keys(zipHealth).forEach(metricId => {
      dataPoint[metricId] = zipHealth[metricId].value || 0;
    });
    healthCensusData[zip] = dataPoint;
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 p-6">
        <div className="max-w-5xl mx-auto">
          <div className="flex items-center justify-center py-12">
            <div className="text-center">
              <LottieLoader size={80} className="mx-auto mb-4" />
              <p className="text-gray-600">Loading analysis...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <Card>
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <Button variant="ghost" size="sm" onClick={onBack}>
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back
                  </Button>
                  <Badge className={analysis.status === 'published' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-yellow-50 text-yellow-700 border-yellow-200'}>
                    {analysis.status}
                  </Badge>
                </div>
                <CardTitle className="text-2xl">{analysis?.title || 'Regional Analysis'}</CardTitle>
                <p className="text-sm text-gray-600 mt-1">{analysis?.assessment_title || ''}</p>
              </div>
              <div className="flex gap-2">
                {onEdit && (
                  <Button onClick={onEdit} variant="outline" className="gap-2">
                    <Edit className="w-4 h-4" />
                    Edit
                  </Button>
                )}
                {analysis.status === 'published' && onUnpublish && (
                  <Button onClick={onUnpublish} variant="outline" className="gap-2">
                    <EyeOff className="w-4 h-4" />
                    Unpublish
                  </Button>
                )}
                {onDelete && (
                  <Button onClick={onDelete} variant="outline" className="gap-2 text-red-600 hover:text-red-700 hover:bg-red-50">
                    <Trash2 className="w-4 h-4" />
                    Delete
                  </Button>
                )}
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-4 text-sm">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-gray-500" />
                <div>
                  <div className="text-gray-600">ZIP Codes</div>
                  <div className="font-semibold">{analysis.zip_codes?.length || 0}</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-gray-500" />
                <div>
                  <div className="text-gray-600">Created</div>
                  <div className="font-semibold">
                    {new Date(analysis.created_date).toLocaleDateString()}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-gray-500" />
                <div>
                  <div className="text-gray-600">Population</div>
                  <div className="font-semibold">
                    {(analysis.demographics_summary?.total_population || 0).toLocaleString()}
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Demographics Summary */}
        <Card>
          <CardHeader>
            <CardTitle>Regional Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div>
                <div className="text-sm text-gray-600">Total Population</div>
                <div className="text-2xl font-bold">
                  {(regionalStats.total_population || regionalStats.totalPopulation || 0).toLocaleString()}
                </div>
              </div>
              <div>
                <div className="text-sm text-gray-600">Median Income</div>
                <div className="text-2xl font-bold">
                  ${Math.abs(regionalStats.avg_income || regionalStats.avgIncome || 0).toLocaleString()}
                </div>
              </div>
              <div>
                <div className="text-sm text-gray-600">Avg Poverty Rate</div>
                <div className="text-2xl font-bold">
                  {parseFloat(regionalStats.avg_poverty || regionalStats.avgPoverty || 0).toFixed(1)}%
                </div>
              </div>
              <div>
                <div className="text-sm text-gray-600">Avg Uninsured</div>
                <div className="text-2xl font-bold">
                  {parseFloat(regionalStats.avg_uninsured || regionalStats.avgUninsured || 0).toFixed(1)}%
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Visualizations */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Data Visualization</CardTitle>
              <div className="flex gap-1 border rounded-lg p-1">
                <Button
                  size="sm"
                  variant={viewMode === 'summary' ? 'default' : 'ghost'}
                  onClick={() => setViewMode('summary')}
                  className="h-8 px-2"
                >
                  <BarChart3 className="w-4 h-4" />
                </Button>
                <Button
                  size="sm"
                  variant={viewMode === 'table' ? 'default' : 'ghost'}
                  onClick={() => setViewMode('table')}
                  className="h-8 px-2"
                >
                  <TableIcon className="w-4 h-4" />
                </Button>
                <Button
                  size="sm"
                  variant={viewMode === 'map' ? 'default' : 'ghost'}
                  onClick={() => setViewMode('map')}
                  className="h-8 px-2"
                >
                  <MapIcon className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="demographics">
              <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 gap-1">
                <TabsTrigger value="demographics">Demographics</TabsTrigger>
                <TabsTrigger value="health">Health</TabsTrigger>
                <TabsTrigger value="providers">Providers</TabsTrigger>
                <TabsTrigger value="population">Pop. Centers</TabsTrigger>
              </TabsList>

              <TabsContent value="demographics" className="mt-6">
                {viewMode === 'summary' && (
                  <div className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      <Card>
                        <CardHeader><CardTitle className="text-lg">Age & Sex Distribution (Regional)</CardTitle></CardHeader>
                        <CardContent>
                          <ResponsiveContainer width="100%" height={320}>
                            <BarChart data={ageDistribution} barGap={8} margin={{ top: 30, right: 20, bottom: 20, left: 20 }}>
                              <defs>
                                <linearGradient id="maleGradient" x1="0" y1="0" x2="0" y2="1">
                                  <stop offset="0%" stopColor="#6366f1" stopOpacity={0.9} />
                                  <stop offset="100%" stopColor="#6366f1" stopOpacity={0.5} />
                                </linearGradient>
                                <linearGradient id="femaleGradient" x1="0" y1="0" x2="0" y2="1">
                                  <stop offset="0%" stopColor="#ec4899" stopOpacity={0.9} />
                                  <stop offset="100%" stopColor="#ec4899" stopOpacity={0.5} />
                                </linearGradient>
                              </defs>
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="age" tick={{ fontSize: 8 }} />
                              <YAxis tick={{ fontSize: 8 }} tickFormatter={(value) => value.toLocaleString()} />
                              <Tooltip formatter={(value) => value.toLocaleString()} />
                              <Legend wrapperStyle={{ fontSize: 12 }} iconSize={10} />
                              <Bar dataKey="male" fill="url(#maleGradient)" name="Male">
                                <LabelList 
                                  position="top" 
                                  style={{ fontSize: 8 }} 
                                  content={({ value, x, y, width, index }) => {
                                    const entry = ageDistribution[index];
                                    if (!entry) return null;
                                    return (
                                      <text 
                                        x={x + width / 2} 
                                        y={y - 8} 
                                        fill="#666" 
                                        textAnchor="middle" 
                                        fontSize={8}
                                      >
                                        {value.toLocaleString()} ({entry.malePct}%)
                                      </text>
                                    );
                                  }}
                                />
                              </Bar>
                              <Bar dataKey="female" fill="url(#femaleGradient)" name="Female">
                                <LabelList 
                                  position="top" 
                                  style={{ fontSize: 8 }} 
                                  content={({ value, x, y, width, index }) => {
                                    const entry = ageDistribution[index];
                                    if (!entry) return null;
                                    return (
                                      <text 
                                        x={x + width / 2} 
                                        y={y - 8} 
                                        fill="#666" 
                                        textAnchor="middle" 
                                        fontSize={8}
                                      >
                                        {value.toLocaleString()} ({entry.femalePct}%)
                                      </text>
                                    );
                                  }}
                                />
                              </Bar>
                            </BarChart>
                          </ResponsiveContainer>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader><CardTitle className="text-lg">Insurance Coverage (Regional)</CardTitle></CardHeader>
                        <CardContent>
                          <ResponsiveContainer width="100%" height={320}>
                            <BarChart data={insuranceDistribution} margin={{ top: 30, right: 20, bottom: 20, left: 20 }}>
                              <defs>
                                <linearGradient id="privateGradient" x1="0" y1="0" x2="0" y2="1">
                                  <stop offset="0%" stopColor="#3b82f6" stopOpacity={0.9} />
                                  <stop offset="100%" stopColor="#3b82f6" stopOpacity={0.5} />
                                </linearGradient>
                                <linearGradient id="medicareGradient" x1="0" y1="0" x2="0" y2="1">
                                  <stop offset="0%" stopColor="#10b981" stopOpacity={0.9} />
                                  <stop offset="100%" stopColor="#10b981" stopOpacity={0.5} />
                                </linearGradient>
                                <linearGradient id="medicaidGradient" x1="0" y1="0" x2="0" y2="1">
                                  <stop offset="0%" stopColor="#f59e0b" stopOpacity={0.9} />
                                  <stop offset="100%" stopColor="#f59e0b" stopOpacity={0.5} />
                                </linearGradient>
                                <linearGradient id="uninsuredGradient" x1="0" y1="0" x2="0" y2="1">
                                  <stop offset="0%" stopColor="#ef4444" stopOpacity={0.9} />
                                  <stop offset="100%" stopColor="#ef4444" stopOpacity={0.5} />
                                </linearGradient>
                              </defs>
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="type" tick={{ fontSize: 8 }} />
                              <YAxis tick={{ fontSize: 8 }} tickFormatter={(value) => value.toLocaleString()} />
                              <Tooltip formatter={(value) => value.toLocaleString()} />
                              <Bar dataKey="value">
                                <LabelList 
                                  position="top" 
                                  style={{ fontSize: 8 }} 
                                  content={({ value, x, y, width }) => {
                                    const pct = ((value / totalPop) * 100).toFixed(1);
                                    return (
                                      <text 
                                        x={x + width / 2} 
                                        y={y - 8} 
                                        fill="#666" 
                                        textAnchor="middle" 
                                        fontSize={8}
                                      >
                                        {value.toLocaleString()} ({pct}%)
                                      </text>
                                    );
                                  }}
                                />
                                {insuranceDistribution.map((_, index) => (
                                  <Cell key={`cell-${index}`} fill={['url(#privateGradient)', 'url(#medicareGradient)', 'url(#medicaidGradient)', 'url(#uninsuredGradient)'][index]} />
                                ))}
                              </Bar>
                            </BarChart>
                          </ResponsiveContainer>
                        </CardContent>
                      </Card>
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-lg">Age Distribution by ZIP Code</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <ResponsiveContainer width="100%" height={Math.max(300, ageByZipData.length * 35)}>
                            <BarChart data={ageByZipData} layout="vertical" margin={{ left: 50, right: 20, top: 10, bottom: 10 }}>
                              <defs>
                                <linearGradient id="age0Gradient" x1="0" y1="0" x2="1" y2="0">
                                  <stop offset="0%" stopColor="#6366f1" stopOpacity={0.9} />
                                  <stop offset="100%" stopColor="#6366f1" stopOpacity={0.5} />
                                </linearGradient>
                                <linearGradient id="age1Gradient" x1="0" y1="0" x2="1" y2="0">
                                  <stop offset="0%" stopColor="#10b981" stopOpacity={0.9} />
                                  <stop offset="100%" stopColor="#10b981" stopOpacity={0.5} />
                                </linearGradient>
                                <linearGradient id="age2Gradient" x1="0" y1="0" x2="1" y2="0">
                                  <stop offset="0%" stopColor="#f59e0b" stopOpacity={0.9} />
                                  <stop offset="100%" stopColor="#f59e0b" stopOpacity={0.5} />
                                </linearGradient>
                                <linearGradient id="age3Gradient" x1="0" y1="0" x2="1" y2="0">
                                  <stop offset="0%" stopColor="#ef4444" stopOpacity={0.9} />
                                  <stop offset="100%" stopColor="#ef4444" stopOpacity={0.5} />
                                </linearGradient>
                              </defs>
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis type="number" tick={{ fontSize: 8 }} />
                              <YAxis dataKey="zip" type="category" width={50} tick={{ fontSize: 8 }} />
                              <Tooltip />
                              <Legend wrapperStyle={{ fontSize: 10 }} />
                              <Bar dataKey="0-17" stackId="a" fill="url(#age0Gradient)" />
                              <Bar dataKey="18-44" stackId="a" fill="url(#age1Gradient)" />
                              <Bar dataKey="45-64" stackId="a" fill="url(#age2Gradient)" />
                              <Bar dataKey="65+" stackId="a" fill="url(#age3Gradient)" />
                            </BarChart>
                          </ResponsiveContainer>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader>
                          <CardTitle className="text-lg">Insurance Coverage by ZIP Code</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <ResponsiveContainer width="100%" height={Math.max(300, insuranceByZipData.length * 35)}>
                            <BarChart data={insuranceByZipData} layout="vertical" margin={{ left: 50, right: 20, top: 10, bottom: 10 }}>
                              <defs>
                                <linearGradient id="ins0Gradient" x1="0" y1="0" x2="1" y2="0">
                                  <stop offset="0%" stopColor="#3b82f6" stopOpacity={0.9} />
                                  <stop offset="100%" stopColor="#3b82f6" stopOpacity={0.5} />
                                </linearGradient>
                                <linearGradient id="ins1Gradient" x1="0" y1="0" x2="1" y2="0">
                                  <stop offset="0%" stopColor="#10b981" stopOpacity={0.9} />
                                  <stop offset="100%" stopColor="#10b981" stopOpacity={0.5} />
                                </linearGradient>
                                <linearGradient id="ins2Gradient" x1="0" y1="0" x2="1" y2="0">
                                  <stop offset="0%" stopColor="#f59e0b" stopOpacity={0.9} />
                                  <stop offset="100%" stopColor="#f59e0b" stopOpacity={0.5} />
                                </linearGradient>
                                <linearGradient id="ins3Gradient" x1="0" y1="0" x2="1" y2="0">
                                  <stop offset="0%" stopColor="#ef4444" stopOpacity={0.9} />
                                  <stop offset="100%" stopColor="#ef4444" stopOpacity={0.5} />
                                </linearGradient>
                              </defs>
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis type="number" tick={{ fontSize: 8 }} />
                              <YAxis dataKey="zip" type="category" width={50} tick={{ fontSize: 8 }} />
                              <Tooltip />
                              <Legend wrapperStyle={{ fontSize: 10 }} />
                              <Bar dataKey="Private" stackId="a" fill="url(#ins0Gradient)" />
                              <Bar dataKey="Medicare" stackId="a" fill="url(#ins1Gradient)" />
                              <Bar dataKey="Medicaid" stackId="a" fill="url(#ins2Gradient)" />
                              <Bar dataKey="Uninsured" stackId="a" fill="url(#ins3Gradient)" />
                            </BarChart>
                          </ResponsiveContainer>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                )}
                {viewMode === 'map' && (
                  <InteractiveMap
                    zipBoundaries={boundaries}
                    organizations={organizations}
                    selectedZips={analysis.zip_codes}
                    colorMetric="population"
                    showCompetitors={true}
                    censusData={demographicCensusData}
                    assessment={analysis.assessment}
                    mapSettings={mapSettings}
                    onMapSettingsChange={setMapSettings}
                  />
                )}
                {viewMode === 'table' && (
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead className="bg-gray-50 border-b">
                        <tr>
                          <th className="px-4 py-3 text-left">ZIP</th>
                          <th className="px-4 py-3 text-right">Population</th>
                          <th className="px-4 py-3 text-right">Income</th>
                          <th className="px-4 py-3 text-right">Poverty</th>
                          <th className="px-4 py-3 text-right">Uninsured</th>
                        </tr>
                      </thead>
                      <tbody>
                        {demographics.map(demo => (
                          <tr key={demo.zcta5} className="border-b hover:bg-gray-50">
                            <td className="px-4 py-3 font-medium">{demo.zcta5}</td>
                            <td className="px-4 py-3 text-right">{(demo.population || 0).toLocaleString()}</td>
                            <td className="px-4 py-3 text-right">${(demo.median_income || 0).toLocaleString()}</td>
                            <td className="px-4 py-3 text-right">{(demo.poverty_rate || 0).toFixed(1)}%</td>
                            <td className="px-4 py-3 text-right">{(demo.uninsured_rate || 0).toFixed(1)}%</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="health" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-base">Health Indicators by ZIP Code</CardTitle>
                    <p className="text-xs text-gray-600 mt-1">Select up to 5 indicators to compare across ZIP codes</p>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-2">
                      {availableIndicators.slice(0, 15).map(indicator => (
                        <div key={indicator.id} className="flex items-start space-x-1.5">
                          <Checkbox
                            id={indicator.id}
                            checked={selectedHealthMetrics.includes(indicator.id)}
                            onCheckedChange={() => {
                              if (selectedHealthMetrics.includes(indicator.id)) {
                                setSelectedHealthMetrics(selectedHealthMetrics.filter(m => m !== indicator.id));
                              } else if (selectedHealthMetrics.length < 5) {
                                setSelectedHealthMetrics([...selectedHealthMetrics, indicator.id]);
                              }
                            }}
                            disabled={!selectedHealthMetrics.includes(indicator.id) && selectedHealthMetrics.length >= 5}
                            className="mt-0.5"
                          />
                          <Label htmlFor={indicator.id} className="text-xs leading-tight cursor-pointer line-clamp-2">
                            {indicator.name}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {selectedHealthMetrics.length > 0 ? (
                  <Card className="mt-4">
                    <CardContent className="pt-6">
                      <ResponsiveContainer width="100%" height={Math.max(300, analysis.zip_codes.length * 40)}>
                        <BarChart data={healthChartData} layout="vertical" margin={{ left: 50, right: 80, top: 20, bottom: 20 }}>
                          <defs>
                            <linearGradient id="healthGradient0" x1="0" y1="0" x2="1" y2="0">
                              <stop offset="0%" stopColor="#3b82f6" stopOpacity={0.9} />
                              <stop offset="100%" stopColor="#3b82f6" stopOpacity={0.5} />
                            </linearGradient>
                            <linearGradient id="healthGradient1" x1="0" y1="0" x2="1" y2="0">
                              <stop offset="0%" stopColor="#10b981" stopOpacity={0.9} />
                              <stop offset="100%" stopColor="#10b981" stopOpacity={0.5} />
                            </linearGradient>
                            <linearGradient id="healthGradient2" x1="0" y1="0" x2="1" y2="0">
                              <stop offset="0%" stopColor="#f59e0b" stopOpacity={0.9} />
                              <stop offset="100%" stopColor="#f59e0b" stopOpacity={0.5} />
                            </linearGradient>
                            <linearGradient id="healthGradient3" x1="0" y1="0" x2="1" y2="0">
                              <stop offset="0%" stopColor="#ef4444" stopOpacity={0.9} />
                              <stop offset="100%" stopColor="#ef4444" stopOpacity={0.5} />
                            </linearGradient>
                            <linearGradient id="healthGradient4" x1="0" y1="0" x2="1" y2="0">
                              <stop offset="0%" stopColor="#8b5cf6" stopOpacity={0.9} />
                              <stop offset="100%" stopColor="#8b5cf6" stopOpacity={0.5} />
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis type="number" tick={{ fontSize: 8 }} domain={[0, 'auto']} />
                          <YAxis dataKey="zipCode" type="category" width={60} tick={{ fontSize: 8 }} />
                          <Tooltip 
                            contentStyle={{ fontSize: 11 }}
                            formatter={(value, name) => [`${value.toFixed(1)}%`, name]}
                          />
                          <Legend wrapperStyle={{ fontSize: 10 }} />
                          {selectedHealthMetrics.map((metricId, idx) => {
                            const indicatorName = availableIndicators.find(i => i.id === metricId)?.name;
                            const avgValue = healthAverages[metricId];
                            return (
                              <React.Fragment key={metricId}>
                                <Bar
                                  dataKey={metricId}
                                  fill={`url(#healthGradient${idx})`}
                                  name={indicatorName}
                                >
                                  <LabelList 
                                    dataKey={metricId} 
                                    position="right" 
                                    style={{ fontSize: 9, fill: '#666' }} 
                                    formatter={(value) => value ? `${value.toFixed(1)}%` : ''} 
                                  />
                                </Bar>
                                {avgValue && (
                                  <ReferenceLine 
                                    x={avgValue} 
                                    stroke={['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'][idx]} 
                                    strokeDasharray="5 5"
                                    strokeWidth={2}
                                    label={{ 
                                      value: `Avg: ${avgValue.toFixed(1)}%`, 
                                      position: 'top',
                                      fontSize: 9,
                                      fill: '#666'
                                    }}
                                  />
                                )}
                              </React.Fragment>
                            );
                          })}
                        </BarChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="text-center py-12 text-sm text-gray-500 border-2 border-dashed rounded-lg mt-4">
                    Select at least one health indicator to view the comparison
                  </div>
                )}
              </TabsContent>

              <TabsContent value="providers" className="mt-6">
                {/* Google Places Enricher */}
                <Card className="mb-4 bg-amber-50 border-amber-200">
                  <CardContent className="py-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-semibold text-amber-900">Google Places Search</p>
                        <p className="text-sm text-amber-700">Find schools, non-profits, and community organizations</p>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setShowPlacesWarning(true)}
                        className="border-amber-300 text-amber-700 hover:bg-amber-100"
                      >
                        Search (5 tokens)
                      </Button>
                    </div>
                    
                    {showPlacesEnricher && (
                      <div className="mt-4 pt-4 border-t border-amber-200">
                        <GooglePlacesEnricher
                          latitude={demographics[0]?.latitude || 30.0}
                          longitude={demographics[0]?.longitude || -90.0}
                          onResultsFound={(results) => {
                            setPlacesResults(results);
                            toast.success(`Found ${results.length} places`);
                          }}
                          onEnrichComplete={(enrichedPlaces) => {
                            toast.success(`Enriched ${enrichedPlaces.length} places`);
                          }}
                        />
                      </div>
                    )}
                  </CardContent>
                </Card>
                
                <GooglePlacesWarningDialog
                  open={showPlacesWarning}
                  onOpenChange={setShowPlacesWarning}
                  onConfirm={() => {
                    setShowPlacesWarning(false);
                    setShowPlacesEnricher(true);
                  }}
                />
                
                {viewMode === 'map' && (
                  <InteractiveMap
                    zipBoundaries={boundaries}
                    organizations={organizations}
                    selectedZips={analysis.zip_codes}
                    colorMetric="population"
                    showCompetitors={true}
                    censusData={demographicCensusData}
                    assessment={analysis.assessment}
                    mapSettings={mapSettings}
                    onMapSettingsChange={setMapSettings}
                  />
                )}
                {viewMode === 'table' && (
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead className="bg-gray-50 border-b">
                        <tr>
                          <th className="px-4 py-3 text-left">Name</th>
                          <th className="px-4 py-3 text-left">Type</th>
                          <th className="px-4 py-3 text-left">Address</th>
                          <th className="px-4 py-3 text-left">ZIP</th>
                          <th className="px-4 py-3 text-right">Sites</th>
                          <th className="px-4 py-3 text-right">Patients</th>
                        </tr>
                      </thead>
                      <tbody>
                        {organizations.length > 0 ? organizations.map(org => (
                          <tr key={org.id} className="border-b hover:bg-gray-50">
                            <td className="px-4 py-3">{org.name}</td>
                            <td className="px-4 py-3 capitalize">{org.type}</td>
                            <td className="px-4 py-3">{org.address || 'N/A'}</td>
                            <td className="px-4 py-3">{org.zip_code}</td>
                            <td className="px-4 py-3 text-right">{org.sites?.length || 1}</td>
                            <td className="px-4 py-3 text-right">{(org.patient_volume || 0).toLocaleString()}</td>
                          </tr>
                        )) : (
                          <tr>
                            <td colSpan={6} className="px-4 py-8 text-center text-gray-500">
                              No organizations found
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                )}
                {viewMode === 'summary' && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-4 gap-4 text-sm">
                      <div><div className="text-gray-600">Organizations</div><div className="text-xl font-bold">{organizations.length}</div></div>
                      <div><div className="text-gray-600">Sites</div><div className="text-xl font-bold">{organizations.reduce((sum, org) => sum + (org.sites?.length || 1), 0)}</div></div>
                      <div><div className="text-gray-600">Patients</div><div className="text-xl font-bold">{organizations.reduce((sum, org) => sum + (org.patient_volume || 0), 0).toLocaleString()}</div></div>
                      <div><div className="text-gray-600">ZIP Coverage</div><div className="text-xl font-bold">{new Set(organizations.map(org => org.zip_code)).size}</div></div>
                    </div>
                    {organizations.length > 0 && (
                      <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                          <thead className="bg-gray-50 border-b">
                            <tr>
                              <th className="px-4 py-3 text-left">Name</th>
                              <th className="px-4 py-3 text-left">Type</th>
                              <th className="px-4 py-3 text-right">Sites</th>
                              <th className="px-4 py-3 text-right">Patients</th>
                            </tr>
                          </thead>
                          <tbody>
                            {organizations.map(org => (
                              <tr key={org.id} className="border-b hover:bg-gray-50">
                                <td className="px-4 py-3">{org.name}</td>
                                <td className="px-4 py-3 capitalize">{org.type}</td>
                                <td className="px-4 py-3 text-right">{org.sites?.length || 1}</td>
                                <td className="px-4 py-3 text-right">{(org.patient_volume || 0).toLocaleString()}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="population" className="mt-6">
                {viewMode === 'map' && (
                  <CityBubbleMap
                    cityData={cityData}
                    selectedZips={analysis.zip_codes}
                  />
                )}
                {(viewMode === 'summary' || viewMode === 'table') && (
                  <>
                    {cityData && cityData.length > 0 ? (
                      <div className="space-y-4">
                        <div className="grid grid-cols-3 gap-4 text-sm">
                          <div>
                            <div className="text-gray-600">Total Cities</div>
                            <div className="text-xl font-bold">
                              {new Set(cityData.map(c => c.place_geoid)).size}
                            </div>
                          </div>
                          <div>
                            <div className="text-gray-600">Largest City</div>
                            <div className="text-xl font-bold">
                              {Array.from(new Map(cityData.map(c => [c.place_geoid, c])).values())
                                .sort((a, b) => (b.place_population || 0) - (a.place_population || 0))[0]
                                ?.place_name?.split(' ')[0] || 'N/A'}
                            </div>
                          </div>
                          <div>
                            <div className="text-gray-600">Total City Pop</div>
                            <div className="text-xl font-bold">
                              {Array.from(new Map(cityData.map(c => [c.place_geoid, c])).values())
                                .reduce((sum, c) => sum + (c.place_population || 0), 0).toLocaleString()}
                            </div>
                          </div>
                        </div>
                        <div className="overflow-x-auto">
                          <table className="w-full text-sm">
                            <thead className="bg-gray-50 border-b">
                              <tr>
                                <th className="px-4 py-3 text-left">City</th>
                                <th className="px-4 py-3 text-left">State</th>
                                <th className="px-4 py-3 text-right">Population</th>
                                <th className="px-4 py-3 text-right">ZIPs</th>
                              </tr>
                            </thead>
                            <tbody>
                              {Array.from(new Map(cityData.map(c => [c.place_geoid, c])).values())
                                .sort((a, b) => (b.place_population || 0) - (a.place_population || 0))
                                .map((city, idx) => {
                                  const zipCount = cityData.filter(c => c.place_geoid === city.place_geoid).length;
                                  return (
                                    <tr key={idx} className="border-b hover:bg-gray-50">
                                      <td className="px-4 py-3">{city.place_name}</td>
                                      <td className="px-4 py-3">{city.state_abbr}</td>
                                      <td className="px-4 py-3 text-right">{(city.place_population || 0).toLocaleString()}</td>
                                      <td className="px-4 py-3 text-right">{zipCount}</td>
                                    </tr>
                                  );
                                })}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-12">
                        <div className="text-gray-500 mb-2">No city data available for the selected ZIP codes</div>
                        <div className="text-xs text-gray-400">City relationships may not be loaded for this region</div>
                      </div>
                    )}
                  </>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* ZIP Codes List */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Included ZIP Codes</CardTitle>
              {onEdit && (
                <Button variant="outline" size="sm" onClick={onEdit}>
                  <Edit className="w-4 h-4 mr-2" />
                  Edit ZIPs
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {analysis.zip_codes?.map(zip => (
                <Badge key={zip} variant="outline" className="px-3 py-1">
                  {zip}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Insights */}
        {analysis.insights && (
          <Card className="bg-purple-50 border-purple-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-purple-900">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                </svg>
                Key Insights
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="prose prose-sm max-w-none text-purple-900">
                <p className="leading-relaxed whitespace-pre-wrap">{analysis.insights}</p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}