import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertTriangle, RefreshCw, Clock, Database, Zap } from 'lucide-react';

export default function ServerErrorGuide({ stateAbbr, stateName, errorCode, errorMessage, onRetry, isRetrying }) {
    const [countdown, setCountdown] = useState(0);

    const getErrorInfo = () => {
        switch (errorCode) {
            case 'DB_TIMEOUT':
                return {
                    icon: Database,
                    color: 'red',
                    title: 'Database Timeout',
                    description: 'The database query took too long and timed out.',
                    causes: [
                        'Database is under heavy load',
                        'Missing database indexes (see other guide)',
                        'Network connectivity issues'
                    ],
                    solutions: [
                        'Wait 30 seconds and try again',
                        'Add database indexes for better performance',
                        'Try during off-peak hours'
                    ],
                    retryDelay: 30
                };
            case 'NO_PROGRESS':
                return {
                    icon: Clock,
                    color: 'amber',
                    title: 'No Progress Made',
                    description: 'The system couldn\'t process any data this cycle.',
                    causes: [
                        'Database timeout during writes',
                        'Census API rate limit reached',
                        'Network issues'
                    ],
                    solutions: [
                        'Wait 15 seconds and try again',
                        'Check your internet connection',
                        'Try a smaller state first'
                    ],
                    retryDelay: 15
                };
            case 'API_RATE_LIMIT':
                return {
                    icon: Zap,
                    color: 'amber',
                    title: 'Census API Rate Limit',
                    description: 'Too many requests to the Census API.',
                    causes: [
                        'Made too many requests in a short time',
                        'Census API has strict rate limits',
                        'No API key configured'
                    ],
                    solutions: [
                        'Wait 60 seconds and try again',
                        'System will automatically retry',
                        'Consider adding a Census API key (CENSUS_API_KEY)'
                    ],
                    retryDelay: 60
                };
            case 'API_NETWORK':
                return {
                    icon: AlertTriangle,
                    color: 'red',
                    title: 'Network Error',
                    description: 'Connection to Census API failed.',
                    causes: [
                        'Internet connectivity issues',
                        'Census API is down',
                        'Firewall or proxy blocking requests'
                    ],
                    solutions: [
                        'Check your internet connection',
                        'Wait a few minutes and try again',
                        'Try from a different network'
                    ],
                    retryDelay: 30
                };
            default:
                return {
                    icon: AlertTriangle,
                    color: 'red',
                    title: 'Server Error',
                    description: errorMessage || 'An unexpected server error occurred.',
                    causes: [
                        'Temporary server issue',
                        'Database connectivity problem',
                        'External API unavailable'
                    ],
                    solutions: [
                        'Wait a moment and try again',
                        'Check the browser console for details',
                        'Contact support if persists'
                    ],
                    retryDelay: 15
                };
        }
    };

    const info = getErrorInfo();
    const Icon = info.icon;

    const handleRetry = () => {
        setCountdown(info.retryDelay);
        const interval = setInterval(() => {
            setCountdown(prev => {
                if (prev <= 1) {
                    clearInterval(interval);
                    return 0;
                }
                return prev - 1;
            });
        }, 1000);
        
        onRetry();
    };

    return (
        <Card className={`border-${info.color}-200 bg-${info.color}-50`}>
            <CardHeader>
                <CardTitle className={`flex items-center gap-2 text-${info.color}-900`}>
                    <Icon className="w-5 h-5" />
                    {info.title} - {stateName}
                </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <Alert className={`bg-white border-${info.color}-200`}>
                    <AlertTriangle className={`w-4 h-4 text-${info.color}-600`} />
                    <AlertDescription className={`text-${info.color}-900`}>
                        <strong>What happened:</strong> {info.description}
                    </AlertDescription>
                </Alert>

                <div className="bg-white rounded-lg p-4 border border-gray-200 space-y-3">
                    <div>
                        <h3 className="font-semibold text-gray-900 mb-2 text-sm">🔍 Possible Causes:</h3>
                        <ul className="text-sm text-gray-600 space-y-1 ml-4 list-disc">
                            {info.causes.map((cause, idx) => (
                                <li key={idx}>{cause}</li>
                            ))}
                        </ul>
                    </div>

                    <div>
                        <h3 className="font-semibold text-gray-900 mb-2 text-sm">✅ How to Fix:</h3>
                        <ol className="text-sm text-gray-600 space-y-1 ml-4 list-decimal">
                            {info.solutions.map((solution, idx) => (
                                <li key={idx}>{solution}</li>
                            ))}
                        </ol>
                    </div>

                    <div className="pt-3 border-t border-gray-200">
                        <Button
                            onClick={handleRetry}
                            disabled={isRetrying || countdown > 0}
                            className={`w-full bg-${info.color}-600 hover:bg-${info.color}-700`}
                        >
                            {isRetrying ? (
                                <>
                                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                                    Retrying...
                                </>
                            ) : countdown > 0 ? (
                                <>
                                    <Clock className="w-4 h-4 mr-2" />
                                    Wait {countdown}s before retry
                                </>
                            ) : (
                                <>
                                    <RefreshCw className="w-4 h-4 mr-2" />
                                    Retry Loading Demographics
                                </>
                            )}
                        </Button>
                        {info.retryDelay && countdown === 0 && !isRetrying && (
                            <p className="text-xs text-gray-500 text-center mt-2">
                                Recommended wait: {info.retryDelay} seconds
                            </p>
                        )}
                    </div>
                </div>

                {errorCode === 'API_RATE_LIMIT' && (
                    <div className="bg-blue-50 rounded-lg p-3 border border-blue-200">
                        <p className="text-sm text-blue-900 font-medium mb-1">💡 Pro Tip:</p>
                        <p className="text-sm text-blue-800">
                            Add a Census API key to avoid rate limits. Get one free at{' '}
                            <a 
                                href="https://api.census.gov/data/key_signup.html" 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="underline font-medium"
                            >
                                api.census.gov
                            </a>
                            {' '}and set it as <code className="bg-blue-100 px-1 py-0.5 rounded">CENSUS_API_KEY</code> in your environment.
                        </p>
                    </div>
                )}
            </CardContent>
        </Card>
    );
}