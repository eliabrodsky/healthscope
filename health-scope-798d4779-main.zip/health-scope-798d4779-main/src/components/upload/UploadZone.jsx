import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Upload, FileText, ImageIcon, Database, FileArchive, FileJson } from "lucide-react";

export default function UploadZone({ onFileSelect, onDrop, fileInputRef }) {
  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <Card 
      className="bg-white border-2 border-dashed border-gray-300 hover:border-emerald-400 transition-all cursor-pointer"
      onClick={handleClick}
      onDrop={onDrop}
      onDragOver={handleDragOver}
    >
      <CardContent className="p-12 text-center">
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept=".pdf,.png,.jpg,.jpeg,.csv,.xlsx,.json,.geojson,.zip"
          onChange={(e) => onFileSelect(e.target.files)}
          className="hidden"
        />
        
        <div className="flex justify-center mb-6">
          <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center">
            <Upload className="w-10 h-10 text-emerald-600 stroke-1" />
          </div>
        </div>
        
        <h3 className="text-2xl font-bold text-gray-900 mb-4">Upload Health Data Files</h3>
        <p className="text-gray-600 text-lg mb-6 max-w-md mx-auto">
          Drop your files here or click to browse. We support PDFs, images, CSV, Excel, JSON/GeoJSON, and ZIP archives.
        </p>
        
        <div className="flex justify-center gap-6 mb-8">
          <div className="text-center">
            <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center mx-auto mb-2">
              <FileText className="w-6 h-6 text-red-500 stroke-1" />
            </div>
            <span className="text-gray-500 text-sm">PDF</span>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center mx-auto mb-2">
              <ImageIcon className="w-6 h-6 text-blue-500 stroke-1" />
            </div>
            <span className="text-gray-500 text-sm">Images</span>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center mx-auto mb-2">
              <Database className="w-6 h-6 text-green-500 stroke-1" />
            </div>
            <span className="text-gray-500 text-sm">CSV/Excel</span>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center mx-auto mb-2">
              <FileJson className="w-6 h-6 text-orange-500 stroke-1" />
            </div>
            <span className="text-gray-500 text-sm">JSON</span>
          </div>
          <div className="text-center">
            <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center mx-auto mb-2">
              <FileArchive className="w-6 h-6 text-purple-500 stroke-1" />
            </div>
            <span className="text-gray-500 text-sm">ZIP</span>
          </div>
        </div>
        
        <Button 
          type="button"
          className="bg-emerald-500 hover:bg-emerald-600 text-white shadow-sm"
        >
          <Upload className="w-5 h-5 mr-2 stroke-1" />
          Choose Files
        </Button>
      </CardContent>
    </Card>
  );
}