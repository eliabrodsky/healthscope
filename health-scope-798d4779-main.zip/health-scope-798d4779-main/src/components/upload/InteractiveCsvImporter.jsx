
import React, { useState, useMemo, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Upload, File, Loader2, Wand, ArrowRight, CheckCircle, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';
import { UploadFile } from '@/integrations/Core';
import { getCSVHeaders } from '@/functions/getCSVHeaders';
import { processMappedCsv } from '@/functions/processMappedCsv';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Label } from '@/components/ui/label';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

const entityFieldOptions = {
  Organization: [
    { value: 'name', label: 'Organization Name' },
    { value: 'type', label: 'Type (fqhc, hospital, etc.)' },
    { value: 'address', label: 'Address' },
    { value: 'city', label: 'City' },
    { value: 'state', label: 'State' },
    { value: 'zip_code', label: 'ZIP Code' },
    { value: 'services', label: 'Services (comma-separated)' },
    { value: 'patient_volume', label: 'Patient Volume' },
  ],
  ZipDemographics: [
    { value: 'zip_code', label: 'ZIP Code' },
    { value: 'population', label: 'Population' },
    { value: 'households', label: 'Households' },
    { value: 'median_income', label: 'Median Income' },
    { value: 'poverty_rate', label: 'Poverty Rate (%)' },
    { value: 'uninsured_rate', label: 'Uninsured Rate (%)' },
  ],
  // New option for site-level data
  FqhcSite: [
    { value: 'health_center_name', label: 'Health Center Name (Parent)' },
    { value: 'site_name', label: 'Site Name' },
    { value: 'site_address', label: 'Site Address' },
    { value: 'site_city', label: 'Site City' },
    { value: 'site_state', label: 'Site State' },
    { value: 'site_zip_code', label: 'Site ZIP Code' },
    { value: 'site_type', label: 'Site Type' },
    { value: 'patient_volume', label: 'Patient Volume (at Site)' },
    { value: 'services', label: 'Services (at Site)' }
  ]
};

const entityTypes = [
  { value: 'Organization', label: 'Competitor Organizations' },
  { value: 'ZipDemographics', label: 'ZIP Code Demographics' },
  { value: 'FqhcSite', label: 'FQHC Sites (for grouping competitors)' },
];

export default function InteractiveCsvImporter({
  open,
  onOpenChange,
  onImportComplete,
  targetEntity: defaultTargetEntityProp = 'Organization', // Renamed prop to avoid conflict with state
  onDataUpdate, // New prop for updating parent data
  assessmentId // New prop for assessment ID
}) {
  const [step, setStep] = useState('upload'); // 'upload', 'map', 'processing', 'complete'
  const [file, setFile] = useState(null);
  const [fileUrl, setFileUrl] = useState(null);
  const [csvHeaders, setCsvHeaders] = useState([]);
  const [sampleRows, setSampleRows] = useState([]);
  const [columnMapping, setColumnMapping] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [importResult, setImportResult] = useState(null);
  const [targetEntity, setTargetEntity] = useState(defaultTargetEntityProp); // Internal state for selected entity type

  const isParsingError = useMemo(() => csvHeaders.length <= 1 && file !== null, [csvHeaders, file]);

  const resetState = () => {
    setStep('upload');
    setFile(null);
    setFileUrl(null);
    setCsvHeaders([]);
    setSampleRows([]);
    setColumnMapping({});
    setIsLoading(false);
    setImportResult(null);
    setTargetEntity(defaultTargetEntityProp); // Reset target entity to its initial prop value
  };

  const handleClose = (isOpen) => {
    if (!isOpen) {
      resetState();
    }
    onOpenChange(isOpen);
  };

  const handleFileSelect = async (files) => {
    const uploadedFile = files[0];
    if (!uploadedFile || !uploadedFile.type.includes('csv')) {
      toast.error('Please upload a valid .csv file.');
      return;
    }

    setFile(uploadedFile);
    setIsLoading(true);
    toast.info(`Uploading ${uploadedFile.name}...`);

    try {
      const { file_url } = await UploadFile({ file: uploadedFile });
      setFileUrl(file_url);
      toast.success('Upload complete. Analyzing file...');

      const response = await getCSVHeaders({ file_url });
      const { headers, sampleRows } = response.data;

      if (!headers || headers.length === 0) {
        throw new Error('Could not read headers from the CSV file.');
      }

      setCsvHeaders(headers);
      setSampleRows(sampleRows);

      // Auto-map columns
      const initialMapping = {};
      const options = entityFieldOptions[targetEntity];
      headers.forEach(header => {
        const lowerHeader = header.toLowerCase().replace(/[^a-z0-9]/gi, '');
        const matchedOption = options.find(opt => {
            const optValue = opt.value.toLowerCase().replace('_', '');
            const optLabel = opt.label.toLowerCase().replace(/[^a-z0-9]/gi, '');
            return lowerHeader.includes(optValue) || lowerHeader.includes(optLabel) || optLabel.includes(lowerHeader);
        });
        if (matchedOption) {
          initialMapping[header] = matchedOption.value;
        }
      });
      setColumnMapping(initialMapping);

      setStep('map');
    } catch (error) {
      toast.error(`Error processing file: ${error.message}`);
      resetState();
    } finally {
      setIsLoading(false);
    }
  };

  const handleDragEnter = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileSelect(e.dataTransfer.files);
    }
  };

  const handleMappingChange = (header, entityField) => {
    setColumnMapping(prev => ({ ...prev, [header]: entityField }));
  };

  const handleProcessImport = async () => {
    // Validate mapped fields count and uniqueness
    const mappedFieldsValues = Object.values(columnMapping);
    const validMappedFields = mappedFieldsValues.filter(field => field !== 'ignore');

    if (validMappedFields.length === 0) {
      toast.error('Please map at least one column.');
      return;
    }
    if (new Set(validMappedFields).size !== validMappedFields.length) {
      toast.error('Each destination field can only be used once. Please correct duplicate mappings.');
      return;
    }

    setStep('processing');
    setIsLoading(true); // Using setIsLoading as per existing code
    const importToastId = toast.loading("Importing and processing data...", { id: 'import-toast' });

    // Construct the final mapping in the format {"entity_field": "csv_header"}
    const finalMapping = {};
    Object.entries(columnMapping).forEach(([csvHeader, entityField]) => {
      if (entityField !== 'ignore') {
        finalMapping[entityField] = csvHeader;
      }
    });

    try {
      // Ensure assessmentId is present before calling the function
      if (!assessmentId) {
          throw new Error("Assessment ID is missing. Cannot process file.");
      }
        
      const response = await processMappedCsv({
        file_url: fileUrl, // Using fileUrl as per existing code
        mapping: finalMapping,
        target_entity: targetEntity,
        assessment_id: assessmentId,
      });

      const result = response.data;

      if (result && result.success) {
        toast.success(`Successfully imported ${result.created_count} records.`, { id: importToastId });
        // NEW: Call onDataUpdate if provided and new_orgs exist
        if (onDataUpdate && result.new_orgs) {
          onDataUpdate(prev => ({
            ...prev,
            organizations: [...(prev.organizations || []), ...result.new_orgs]
          }));
        }
        onImportComplete(); // Call existing callback
        setImportResult(result); // Set result to show on complete screen
        setStep('complete'); // Show the complete screen
      } else {
        throw new Error(result?.error || "Import failed.");
      }
    } catch (error) {
      console.error(error); // Log the actual error object
      toast.error(`Import failed: ${error.message}`, { id: importToastId });
      setStep('map'); // Go back to mapping step on failure
    } finally {
      setIsLoading(false); // Using setIsLoading as per existing code
    }
  };

  const renderContent = () => {
    switch (step) {
      case 'upload':
        return (
          <>
            <div
              onDragEnter={handleDragEnter}
              onDragOver={handleDragEnter}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              onClick={() => document.getElementById('csv-importer-input')?.click()}
              className={`mt-6 p-10 border-2 border-dashed rounded-lg text-center cursor-pointer transition-colors ${isDragging ? 'border-emerald-500 bg-emerald-50' : 'border-gray-300 hover:border-emerald-400'}`}
            >
              <input
                id="csv-importer-input"
                type="file"
                className="hidden"
                onChange={(e) => handleFileSelect(e.target.files)}
                accept=".csv"
              />
              {isLoading ? (
                <div className="flex flex-col items-center gap-2">
                  <Loader2 className="w-8 h-8 animate-spin text-emerald-600" />
                  <p className="text-gray-600">Processing file...</p>
                </div>
              ) : (
                <div className="flex flex-col items-center gap-2">
                  <Upload className="w-8 h-8 text-gray-400" />
                  <p className="font-medium text-gray-700">Drop CSV file here, or click to upload</p>
                  <p className="text-sm text-gray-500">Select a .csv file to begin the import process.</p>
                </div>
              )}
            </div>
            <div className="mt-4">
              <Label>Select Data Type to Import</Label>
              <Select value={targetEntity} onValueChange={setTargetEntity}>
                <SelectTrigger>
                  <SelectValue placeholder="Select the type of data you are importing..." />
                </SelectTrigger>
                <SelectContent>
                  {entityTypes.map(type => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </>
        );
      case 'map':
        return (
          <div className="mt-4 space-y-4">
            <DialogDescription>
              Match the columns from your file to the destination fields in the application. We've tried to guess for you.
            </DialogDescription>
            {isParsingError && (
                <Alert variant="destructive">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>Parsing Error</AlertTitle>
                    <AlertDescription>
                        We couldn't automatically detect the columns in your file. Please ensure it's a valid CSV with standard delimiters like commas (,) or semicolons (;).
                    </AlertDescription>
                </Alert>
            )}
            <div className="border rounded-lg overflow-hidden">
              <ScrollArea className="h-96 w-full">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="min-w-[200px]">Your Column</TableHead>
                      <TableHead className="min-w-[200px]">Preview Data</TableHead>
                      <TableHead className="min-w-[200px]">Destination Field</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {csvHeaders.map((header, index) => (
                      <TableRow key={header}>
                        <TableCell className="font-medium min-w-[200px]">{header}</TableCell>
                        <TableCell className="text-gray-500 text-sm truncate max-w-xs min-w-[200px]">
                          {sampleRows[0]?.[index] || ''}
                        </TableCell>
                        <TableCell className="min-w-[200px]">
                          <Select
                            value={columnMapping[header] || ''}
                            onValueChange={(value) => handleMappingChange(header, value)}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Select destination..." />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="ignore">-- Ignore this column --</SelectItem>
                              {entityFieldOptions[targetEntity].map(opt => (
                                <SelectItem key={opt.value} value={opt.value}>
                                  {opt.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </ScrollArea>
            </div>
          </div>
        );
      case 'processing':
        return (
          <div className="flex flex-col items-center justify-center h-48 gap-4">
            <Loader2 className="w-12 h-12 animate-spin text-emerald-600" />
            <p className="text-lg font-medium text-gray-700">Importing your data...</p>
            <p className="text-sm text-gray-500">Please wait while we process your file.</p>
          </div>
        );
      case 'complete':
        return (
          <div className="flex flex-col items-center justify-center h-48 gap-4 text-center">
            {importResult?.success ? (
              <>
                <CheckCircle className="w-12 h-12 text-green-600" />
                <p className="text-lg font-medium text-gray-800">Import Successful!</p>
                <p className="text-sm text-gray-600">
                  {`We've successfully imported ${importResult.created_count} new ${targetEntity.toLowerCase()}(s) from your file.`}
                </p>
              </>
            ) : (
              <>
                <AlertTriangle className="w-12 h-12 text-red-600" />
                <p className="text-lg font-medium text-gray-800">Import Failed</p>
                <p className="text-sm text-red-600">
                  {importResult?.error || 'An unexpected error occurred. Please try again.'}
                </p>
              </>
            )}
          </div>
        );
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-6xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle className="text-xl flex items-center gap-2">
            <Wand className="w-5 h-5 text-emerald-600" />
            Interactive CSV Importer
          </DialogTitle>
        </DialogHeader>
        {renderContent()}
        <DialogFooter className="mt-6">
          {step === 'upload' && <Button variant="outline" onClick={() => handleClose(false)}>Cancel</Button>}
          {step === 'map' && (
            <>
              <Button variant="outline" onClick={resetState}>Start Over</Button>
              <Button onClick={handleProcessImport} className="bg-emerald-600 hover:bg-emerald-700" disabled={isLoading || isParsingError}>
                <ArrowRight className="w-4 h-4 mr-2" />
                Review and Import
              </Button>
            </>
          )}
          {step === 'complete' && <Button onClick={() => handleClose(false)}>Finish</Button>}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
