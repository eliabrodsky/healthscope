import React from "react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  FileText, 
  ImageIcon, 
  Database, 
  CheckCircle, 
  X, 
  Play,
  Loader2,
  FileArchive,
  AlertCircle,
  FileJson
} from "lucide-react";

const getFileIcon = (file) => {
  if (file.type === 'application/pdf') return FileText;
  if (file.type.startsWith('image/')) return ImageIcon;
  if (file.name.endsWith('.csv') || file.name.endsWith('.xlsx')) return Database;
  if (file.name.endsWith('.json') || file.type === 'application/json') return FileJson;
  if (file.name.endsWith('.zip') || file.type === 'application/zip' || file.type === 'application/x-zip-compressed') return FileArchive;
  return FileText;
};

const getFileColor = (file) => {
  if (file.type === 'application/pdf') return 'text-red-600';
  if (file.type.startsWith('image/')) return 'text-blue-600';
  if (file.name.endsWith('.csv') || file.name.endsWith('.xlsx')) return 'text-green-600';
  if (file.name.endsWith('.json') || file.type === 'application/json') return 'text-orange-600';
  if (file.name.endsWith('.zip') || file.type === 'application/zip' || file.type === 'application/x-zip-compressed') return 'text-purple-600';
  return 'text-gray-600';
};

const getFileSize = (bytes) => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

export default function FilePreview({ 
  file, 
  index, 
  isUploading, 
  isProcessing, 
  progress, 
  extractedData, 
  error,
  onProcess, 
  onRemove 
}) {
  const FileIcon = getFileIcon(file);
  const fileColor = getFileColor(file);
  const isComplete = progress === 100 && !isProcessing && extractedData;
  const hasFailed = error !== null && error !== undefined;
  const canProcess = !isUploading && !isProcessing && !extractedData && !hasFailed;
  const isZipFile = file.name.endsWith('.zip') || file.type === 'application/zip' || file.type === 'application/x-zip-compressed';
  const isJsonFile = file.name.endsWith('.json') || file.type === 'application/json';

  return (
    <div className={`flex items-center gap-4 p-4 rounded-lg border ${
      hasFailed ? 'bg-red-50 border-red-200' : 'bg-gray-50 border-gray-200'
    }`}>
      <div className="flex items-center gap-3 flex-1">
        <div className={`p-2 bg-white rounded-lg border ${
          hasFailed ? 'border-red-300' : 'border-gray-200'
        }`}>
          <FileIcon className={`w-6 h-6 stroke-1 ${
            hasFailed ? 'text-red-600' : fileColor
          }`} />
        </div>
        
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <h4 className="font-medium text-gray-800 text-sm">{file.name}</h4>
            {isComplete && (
              <Badge className="bg-emerald-100 text-emerald-800 border-emerald-200">
                <CheckCircle className="w-3 h-3 mr-1 stroke-1" />
                {isZipFile ? 'Uploaded' : isJsonFile ? 'Loaded' : 'Processed'}
              </Badge>
            )}
            {hasFailed && (
              <Badge className="bg-red-100 text-red-800 border-red-200">
                <AlertCircle className="w-3 h-3 mr-1 stroke-1" />
                Failed
              </Badge>
            )}
            {isZipFile && !isComplete && !isUploading && !hasFailed && (
              <Badge className="bg-purple-100 text-purple-800 border-purple-200">
                ZIP Archive
              </Badge>
            )}
            {isJsonFile && !isComplete && !isUploading && !hasFailed && (
              <Badge className="bg-orange-100 text-orange-800 border-orange-200">
                JSON Data
              </Badge>
            )}
          </div>
          
          <div className="flex items-center gap-4 text-xs text-gray-500">
            <span>{getFileSize(file.size)}</span>
            <span className="capitalize">{file.type.split('/')[1] || file.name.split('.').pop() || 'Unknown'}</span>
            {extractedData && !isZipFile && !isJsonFile && (
              <span className="text-emerald-700">Data extracted successfully</span>
            )}
            {extractedData && isZipFile && (
              <span className="text-purple-700">ZCTA boundary file ready</span>
            )}
            {extractedData && isJsonFile && (
              <span className="text-orange-700">{extractedData.message || 'JSON data loaded'}</span>
            )}
          </div>
          
          {(isUploading || isProcessing) && !hasFailed && (
            <div className="mt-2">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs text-gray-600">
                  {isUploading ? 'Uploading...' : 'Processing...'}
                </span>
                {isProcessing && <Loader2 className="w-3 h-3 animate-spin text-emerald-600" />}
                <span className="text-xs text-gray-500 ml-auto">{progress}%</span>
              </div>
              <Progress value={progress} className="h-1" />
            </div>
          )}
        </div>
      </div>
      
      <div className="flex items-center gap-2">
        {canProcess && (
          <Button
            onClick={onProcess}
            size="sm"
            className="bg-emerald-500 hover:bg-emerald-600 text-white"
          >
            <Play className="w-4 h-4 mr-1 stroke-1" />
            {isZipFile ? 'Upload' : isJsonFile ? 'Load' : 'Process'}
          </Button>
        )}
        
        <Button
          onClick={onRemove}
          size="icon"
          variant="ghost"
          className="text-gray-400 hover:text-red-500 hover:bg-red-50"
          disabled={isUploading || isProcessing}
        >
          <X className="w-4 h-4 stroke-1" />
        </Button>
      </div>
    </div>
  );
}