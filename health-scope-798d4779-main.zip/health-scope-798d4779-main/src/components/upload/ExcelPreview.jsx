import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Table, 
  FileSpreadsheet, 
  Download, 
  AlertCircle,
  CheckCircle,
  Upload
} from "lucide-react";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";

export default function ExcelPreview({ file, fileUrl, onDataImported }) {
  const [isLoading, setIsLoading] = useState(true);
  const [sheetData, setSheetData] = useState(null);
  const [activeSheet, setActiveSheet] = useState(0);
  const [isImporting, setIsImporting] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    parseExcelFile();
  }, [fileUrl]);

  const parseExcelFile = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      // Fetch the Excel file
      const response = await fetch(fileUrl);
      const arrayBuffer = await response.arrayBuffer();
      
      // Use browser's native capabilities to parse
      // For now, we'll use a server-side function
      const result = await base44.functions.invoke('parseExcelFile', {
        file_url: fileUrl
      });

      if (result?.data?.sheets) {
        setSheetData(result.data);
        toast.success(`Excel file parsed: ${result.data.sheets.length} sheets found`);
      } else {
        throw new Error('No sheets found in Excel file');
      }
    } catch (err) {
      console.error('Excel parsing error:', err);
      setError(err.message || 'Failed to parse Excel file');
      toast.error('Failed to parse Excel file');
    } finally {
      setIsLoading(false);
    }
  };

  const handleImportSheet = async (sheetIndex) => {
    setIsImporting(true);
    const loadingToast = 'import-sheet';
    
    try {
      const sheet = sheetData.sheets[sheetIndex];
      toast.loading(`Importing ${sheet.name}...`, { id: loadingToast });
      
      // Import organizations from this sheet
      const result = await base44.functions.invoke('importFqhcData', {
        file_url: fileUrl,
        sheet_name: sheet.name
      });

      if (result?.data?.success) {
        toast.success(
          `Imported ${result.data.count} organizations!`,
          { id: loadingToast, duration: 5000 }
        );
        if (onDataImported) {
          onDataImported(result.data);
        }
      } else {
        throw new Error(result?.data?.error || 'Import failed');
      }
    } catch (err) {
      console.error('Import error:', err);
      toast.error(
        `Failed to import: ${err.message}`,
        { id: loadingToast }
      );
    } finally {
      setIsImporting(false);
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 animate-pulse" />
            Parsing Excel File...
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-gray-500">
            Reading sheets and columns from {file.name}...
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Alert className="border-red-200 bg-red-50">
        <AlertCircle className="w-4 h-4 text-red-600" />
        <AlertDescription className="text-red-800">
          {error}
        </AlertDescription>
      </Alert>
    );
  }

  if (!sheetData?.sheets?.length) {
    return (
      <Alert className="border-amber-200 bg-amber-50">
        <AlertCircle className="w-4 h-4 text-amber-600" />
        <AlertDescription className="text-amber-800">
          No sheets found in Excel file
        </AlertDescription>
      </Alert>
    );
  }

  const currentSheet = sheetData.sheets[activeSheet];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5" />
            Excel File Preview - {file.name}
          </div>
          <Badge variant="outline">
            {sheetData.sheets.length} {sheetData.sheets.length === 1 ? 'Sheet' : 'Sheets'}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        
        {/* Sheet Tabs */}
        <Tabs value={activeSheet.toString()} onValueChange={(v) => setActiveSheet(parseInt(v))}>
          <TabsList className="w-full justify-start flex-wrap h-auto">
            {sheetData.sheets.map((sheet, idx) => (
              <TabsTrigger key={idx} value={idx.toString()} className="flex items-center gap-2">
                <Table className="w-4 h-4" />
                {sheet.name}
                <Badge variant="secondary" className="ml-2">
                  {sheet.rowCount} rows
                </Badge>
              </TabsTrigger>
            ))}
          </TabsList>

          {sheetData.sheets.map((sheet, idx) => (
            <TabsContent key={idx} value={idx.toString()} className="space-y-4">
              
              {/* Sheet Info */}
              <div className="grid grid-cols-3 gap-4">
                <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                  <div className="text-xs text-blue-600 font-medium">Rows</div>
                  <div className="text-xl font-bold text-blue-900">{sheet.rowCount}</div>
                </div>
                <div className="p-3 bg-green-50 rounded-lg border border-green-200">
                  <div className="text-xs text-green-600 font-medium">Columns</div>
                  <div className="text-xl font-bold text-green-900">{sheet.columns.length}</div>
                </div>
                <div className="p-3 bg-purple-50 rounded-lg border border-purple-200">
                  <div className="text-xs text-purple-600 font-medium">Data Cells</div>
                  <div className="text-xl font-bold text-purple-900">
                    {sheet.rowCount * sheet.columns.length}
                  </div>
                </div>
              </div>

              {/* Columns */}
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Columns Found</h4>
                <div className="flex flex-wrap gap-2">
                  {sheet.columns.map((col, colIdx) => (
                    <Badge key={colIdx} variant="outline" className="text-xs">
                      {col}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Sample Data */}
              {sheet.sampleRows && sheet.sampleRows.length > 0 && (
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">
                    Sample Data (First {sheet.sampleRows.length} rows)
                  </h4>
                  <div className="overflow-x-auto border rounded-lg">
                    <table className="w-full text-xs">
                      <thead className="bg-gray-100 border-b">
                        <tr>
                          {sheet.columns.map((col, colIdx) => (
                            <th key={colIdx} className="px-3 py-2 text-left font-semibold text-gray-700">
                              {col}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {sheet.sampleRows.map((row, rowIdx) => (
                          <tr key={rowIdx} className="border-b hover:bg-gray-50">
                            {sheet.columns.map((col, colIdx) => (
                              <td key={colIdx} className="px-3 py-2 text-gray-600">
                                {row[col]?.toString() || '-'}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Import Button */}
              <div className="pt-4 border-t">
                <Button
                  onClick={() => handleImportSheet(idx)}
                  disabled={isImporting}
                  className="bg-emerald-600 hover:bg-emerald-700"
                >
                  {isImporting ? (
                    <>
                      <AlertCircle className="w-4 h-4 mr-2 animate-spin" />
                      Importing...
                    </>
                  ) : (
                    <>
                      <Upload className="w-4 h-4 mr-2" />
                      Import {sheet.name} Data
                    </>
                  )}
                </Button>
                <p className="text-xs text-gray-500 mt-2">
                  This will parse and import FQHC organizations and patient ZIP data from this sheet
                </p>
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
    </Card>
  );
}