import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Sparkles, Download, Eye } from "lucide-react";

export default function DataExtraction({ extractedData }) {
  const allMetrics = extractedData.flatMap(data => data.metrics || []);
  const uniqueOrganizations = [...new Set(extractedData.map(data => data.organization).filter(Boolean))];

  return (
    <Card className="bg-white border-gray-200 shadow-sm">
      <CardHeader>
        <CardTitle className="text-gray-900 flex items-center gap-2">
          <Sparkles className="w-5 h-5 stroke-1" />
          Extracted Data Summary
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        
        {/* Summary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-gray-50 rounded-lg border border-gray-200 text-center">
            <div className="text-2xl font-bold text-gray-900">{extractedData.length}</div>
            <div className="text-sm text-gray-600">Files Processed</div>
          </div>
          <div className="p-4 bg-gray-50 rounded-lg border border-gray-200 text-center">
            <div className="text-2xl font-bold text-gray-900">{uniqueOrganizations.length}</div>
            <div className="text-sm text-gray-600">Organizations Found</div>
          </div>
          <div className="p-4 bg-gray-50 rounded-lg border border-gray-200 text-center">
            <div className="text-2xl font-bold text-gray-900">{allMetrics.length}</div>
            <div className="text-sm text-gray-600">Data Points</div>
          </div>
        </div>

        {/* Organizations */}
        {uniqueOrganizations.length > 0 && (
          <div>
            <h3 className="text-gray-800 font-semibold mb-3">Organizations Identified</h3>
            <div className="flex flex-wrap gap-2">
              {uniqueOrganizations.map((org, index) => (
                <Badge key={index} variant="outline" className="border-gray-300 text-gray-700">
                  {org}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Sample Metrics */}
        {allMetrics.length > 0 && (
          <div>
            <h3 className="text-gray-800 font-semibold mb-3">Sample Metrics Found</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {allMetrics.slice(0, 6).map((metric, index) => (
                <div key={index} className="p-3 bg-gray-50 rounded-lg border border-gray-200">
                  <div className="font-medium text-gray-800 text-sm">{metric.name}</div>
                  <div className="text-emerald-600 font-bold">
                    {metric.value} {metric.unit && <span className="text-gray-500">{metric.unit}</span>}
                  </div>
                </div>
              ))}
            </div>
            {allMetrics.length > 6 && (
              <p className="text-gray-500 text-sm mt-2">
                +{allMetrics.length - 6} more metrics extracted
              </p>
            )}
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-3 pt-4 border-t border-gray-200">
          <Button className="bg-emerald-500 hover:bg-emerald-600 text-white">
            <Eye className="w-4 h-4 mr-2 stroke-1" />
            View Full Analysis
          </Button>
          <Button variant="outline" className="border-gray-300 text-gray-700 hover:bg-gray-50">
            <Download className="w-4 h-4 mr-2 stroke-1" />
            Export Data
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}