import React, { useState, useEffect, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  MapPin,
  Edit,
  RefreshCw,
  Loader2,
  Sparkles,
  AlertTriangle,
  Database,
  Map as MapIcon,
  ChevronLeft,
  ChevronRight,
  Eye,
  EyeOff,
  Settings,
  Palette
} from 'lucide-react';
import { toast } from 'sonner';
import { base44 } from '@/api/base44Client';
import GeographyEditor from './GeographyEditor';

import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

// Perceptually-uniform divergent color palettes
const COLOR_PALETTES = {
  viridis: ['#440154', '#3b528b', '#21918c', '#5ec962', '#fde725'],
  plasma: ['#0d0887', '#6a00a8', '#b12a90', '#e16462', '#fca636', '#f0f921'],
  magma: ['#000004', '#3b0f70', '#8c2981', '#de4968', '#f98c0a', '#fcfdbf'],
  inferno: ['#000004', '#320a5a', '#781c6d', '#bd3655', '#ed6925', '#fbff2c'],
  bluePurple: ['#081d58', '#253494', '#225ea8', '#1d91c0', '#41b6c4', '#c7e9b4'],
  redYellowGreen: ['#d73027', '#fc8d59', '#fee08b', '#d9ef8b', '#91cf60', '#1a9850'],
  spectral: ['#d53e4f', '#f46d43', '#fdae61', '#fee08b', '#e6f598', '#abdda4', '#66c2a5', '#3288bd'],
};

// Legacy RGB scales
const COLOR_SCALES = {
  blue: { name: 'Blue Scale', low: [200, 230, 255], high: [8, 47, 120] },
  green: { name: 'Green Scale', low: [200, 255, 200], high: [0, 100, 0] },
  red: { name: 'Red Scale', low: [255, 230, 230], high: [180, 0, 0] },
  purple: { name: 'Purple Scale', low: [240, 230, 255], high: [75, 0, 130] },
  orange: { name: 'Orange Scale', low: [255, 245, 200], high: [255, 140, 0] },
  inverted_blue: { name: 'Inverted Blue', low: [8, 47, 120], high: [200, 230, 255] },
  inverted_green: { name: 'Inverted Green', low: [0, 100, 0], high: [200, 255, 200] },
  inverted_red: { name: 'Inverted Red', low: [180, 0, 0], high: [255, 230, 230] }
};

const ColorLegend = ({ metric, censusData, colorScaleName = 'viridis' }) => {
  const legendInfo = useMemo(() => {
    const legends = {
      population: { title: 'Population', unit: '' },
      medianIncome: { title: 'Median Income', unit: '$' },
      povertyRate: { title: 'Poverty Rate', unit: '%' },
      uninsuredRate: { title: 'Uninsured Rate', unit: '%' }
    };

    const legend = legends[metric] || legends.population;

    // Calculate actual min/max from the census data
    const values = Object.values(censusData || {})
      .map(data => data[metric])
      .filter(val => val !== null && val !== undefined && !isNaN(val));

    if (values.length === 0) {
      return {
        ...legend,
        minValue: 'N/A',
        maxValue: 'N/A'
      };
    }

    const minValue = Math.min(...values);
    const maxValue = Math.max(...values);

    return {
      ...legend,
      minValue: legend.unit === '$' ?
        new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0 }).format(minValue) :
        `${minValue.toLocaleString()}${legend.unit}`,
      maxValue: legend.unit === '$' ?
        new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0 }).format(maxValue) :
        `${maxValue.toLocaleString()}${legend.unit}`
    };
  }, [metric, censusData]);

  // Generate gradient background for legend
  const gradientBackground = useMemo(() => {
    // Check if it's a new palette-based scheme
    if (COLOR_PALETTES[colorScaleName]) {
      const palette = COLOR_PALETTES[colorScaleName];
      return `linear-gradient(to right, ${palette.join(', ')})`;
    }
    
    // Fall back to legacy RGB-based scales
    const scale = COLOR_SCALES[colorScaleName] || COLOR_SCALES.blue;
    return `linear-gradient(to right, rgb(${scale.low.join(',')}), rgb(${scale.high.join(',')}))`;
  }, [colorScaleName]);

  return (
    <div className="space-y-2">
      <p className="text-sm font-medium text-gray-700">Map Legend: {legendInfo.title}</p>
      <div className="flex items-center justify-between bg-gray-50 p-2 rounded-md border">
        <span className="text-xs text-gray-600">{legendInfo.minValue}</span>
        <div
          className="flex-1 h-2 mx-2 rounded"
          style={{ background: gradientBackground }}
        ></div>
        <span className="text-xs text-gray-600">{legendInfo.maxValue}</span>
      </div>
    </div>
  );
};

export default function GeographyControlsCard({
  assessment,
  onUpdate,
  onReloadMap,
  isLoadingBoundaries,
  isFindingZips, // This prop might not be used directly here anymore if findZipCodesInRadius is in GeographyEditor
  onFindZips, // This prop might not be used directly here anymore if findZipCodesInRadius is in GeographyEditor
  mapColorMetric,
  showRadiusReference,
  onShowRadiusChange,
  radiusMiles = 10,
  onRadiusMilesChange,
  zipCodes,
  censusData,
  onReloadAll,
  isReloadingAll,
  onLoadBoundaries,
  onPreprocessComplete,
  showCompetitors,
  onShowCompetitorsChange,
  mapSettings,
  onMapSettingsChange,
  onCollapseChange,
  onMapColorMetricChange
}) {
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [isLoadingStateBoundaries, setIsLoadingStateBoundaries] = useState(false);
  const [isPreprocessing, setIsPreprocessing] = useState(false);
  const [isCollapsed, setIsCollapsed] = useState(false);

  // Notify parent when collapse state changes
  useEffect(() => {
    if (onCollapseChange) {
      onCollapseChange(isCollapsed);
    }
  }, [isCollapsed, onCollapseChange]);

  const stateAbbreviations = {
    'Alabama': 'al', 'Alaska': 'ak', 'Arizona': 'az', 'Arkansas': 'ar', 'California': 'ca',
    'Colorado': 'co', 'Connecticut': 'ct', 'Delaware': 'de', 'Florida': 'fl', 'Georgia': 'ga',
    'Hawaii': 'hi', 'Idaho': 'id', 'Illinois': 'il', 'Indiana': 'in', 'Iowa': 'ia',
    'Kansas': 'ks', 'Kentucky': 'ky', 'Louisiana': 'la', 'Maine': 'me', 'Maryland': 'md',
    'Massachusetts': 'ma', 'Michigan': 'mi', 'Minnesota': 'mn', 'Mississippi': 'ms', 'Missouri': 'mo',
    'Montana': 'mt', 'Nebraska': 'ne', 'Nevada': 'nv', 'New Hampshire': 'nh', 'New Jersey': 'nj',
    'New Mexico': 'nm', 'New York': 'ny', 'North Carolina': 'nc', 'North Dakota': 'nd', 'Ohio': 'oh',
    'Oklahoma': 'ok', 'Oregon': 'or', 'Pennsylvania': 'pa', 'Rhode Island': 'ri', 'South Carolina': 'sc',
    'South Dakota': 'sd', 'Tennessee': 'tn', 'Texas': 'tx', 'Utah': 'ut', 'Vermont': 'vt',
    'Virginia': 'va', 'Washington': 'wa', 'West Virginia': 'wv', 'Wisconsin': 'wi', 'Wyoming': 'wy'
  };

  const handlePreprocessBoundaries = async (zipCodesToProcess) => {
    const currentZipCodes = zipCodesToProcess || zipCodes;

    if (!assessment?.geography?.state || !currentZipCodes || currentZipCodes.length === 0) {
      toast.error("State and ZIP codes are required for pre-processing.");
      return;
    }

    setIsPreprocessing(true);
    const loadingToastId = 'preprocessing-boundaries';
    toast.loading(`Pre-processing ${currentZipCodes.length} ZIP boundaries for instant loading...`, {
      id: loadingToastId,
      duration: 60000
    });

    try {
      const stateAbbr = stateAbbreviations[assessment.geography.state];
      if (!stateAbbr) {
        throw new Error(`State abbreviation not found for ${assessment.geography.state}`);
      }

      const response = await base44.functions.invoke('preprocessBoundaries', {
        stateAbbr: stateAbbr,
        stateName: assessment.geography.state,
        zipCodes: currentZipCodes,
        assessmentId: assessment.id
      });

      if (response?.data?.success) {
        const { feature_count, processing_time_ms, zip_codes_found } = response.data.data;

        toast.success(
          `✓ Pre-processed ${feature_count} boundaries in ${(processing_time_ms / 1000).toFixed(1)}s! Map will now load instantly.`,
          { id: loadingToastId, duration: 6000 }
        );

        if (onPreprocessComplete) {
          onPreprocessComplete(response.data.data.geojson);
        }

        setTimeout(() => {
          window.location.reload();
        }, 1000);

      } else {
        throw new Error(response?.data?.error || 'Failed to pre-process boundaries');
      }

    } catch (error) {
      console.error('Error pre-processing boundaries:', error);

      let errorMessage = error.message || 'Unknown error';
      if (errorMessage.includes('timeout') || errorMessage.includes('timed out')) {
        errorMessage = 'Pre-processing timed out. The state file may be very large. Try using "Load My ZIPs" instead.';
      } else if (errorMessage.includes('Network Error')) {
        errorMessage = 'Connection failed. Check your internet.';
      } else if (errorMessage.includes('memory')) {
        errorMessage = 'State file too large to process. Use "Load My ZIPs" for smaller batches.';
      }

      toast.error(
        `Pre-processing failed: ${errorMessage}`,
        { id: loadingToastId, duration: 10000 }
      );
    } finally {
      setIsPreprocessing(false);
    }
  };

  const handleLoadMyZipBoundaries = async (zipCodesToLoad) => {
    const currentZipCodes = zipCodesToLoad || zipCodes;

    if (!currentZipCodes || currentZipCodes.length === 0) {
      toast.error("No ZIP codes selected.");
      return;
    }

    if (onLoadBoundaries) {
      const loadingToastId = 'loading-my-zips';
      toast.loading(`Loading ${currentZipCodes.length} ZIP boundaries from database...`, {
        id: loadingToastId
      });

      try {
        const loadedBoundaries = await onLoadBoundaries();
        const loadedCount = loadedBoundaries?.length || 0;

        if (loadedCount === currentZipCodes.length) {
          toast.success(
            `✓ Perfect! All ${currentZipCodes.length} boundaries loaded!`,
            { id: loadingToastId, duration: 4000 }
          );
        } else if (loadedCount > 0) {
          const missing = currentZipCodes.length - loadedCount;
          toast.warning(
            `Loaded ${loadedCount}/${currentZipCodes.length} boundaries. ${missing} missing - try "Smart Pre-Process" for a complete solution.`,
            { id: loadingToastId, duration: 8000 }
          );
        } else {
          toast.error(
            `No boundaries found in database. Use "Smart Pre-Process" to download and prepare your data.`,
            { id: loadingToastId, duration: 8000 }
          );
        }
      } catch (error) {
        console.error('Error loading boundaries:', error);
        toast.error(
          `Failed to load boundaries: ${error.message}`,
          { id: loadingToastId, duration: 6000 }
        );
      }
    }
  };

  const handleLoadStateBoundaries = async () => {
    if (!assessment?.geography?.state) {
      toast.error("State information is required.");
      return;
    }

    setIsLoadingStateBoundaries(true);
    const loadingToastId = 'loading-state-boundaries';
    toast.loading(`Importing ZIP boundaries for ${assessment.geography.state} from GitHub...`, {
      id: loadingToastId,
      duration: 45000
    });

    try {
      const stateAbbr = stateAbbreviations[assessment.geography.state];
      if (!stateAbbr) {
        throw new Error(`State abbreviation not found for ${assessment.geography.state}`);
      }

      const response = await base44.functions.invoke('loadStateBoundaries', {
        stateAbbr: stateAbbr,
        stateName: assessment.geography.state
      });

      if (response?.data?.success) {
        toast.success(
          `✓ Imported ${response.data.loaded || 0} boundaries for ${assessment.geography.state}! Click again to import more.`,
          { id: loadingToastId, duration: 6000 }
        );
      } else {
        throw new Error(response?.data?.error || 'Failed to import boundaries');
      }

    } catch (error) {
      console.error('Error importing boundaries:', error);

      let errorMessage = error.message || 'Unknown error';
      if (errorMessage.includes('502')) {
        errorMessage = 'Server timeout. Try "Smart Pre-Process" instead for reliable results.';
      } else if (errorMessage.includes('Network Error')) {
        errorMessage = 'Connection failed. Check your internet.';
      } else if (errorMessage.includes('timeout')) {
        errorMessage = 'Request timed out. Try "Smart Pre-Process" for better reliability.';
      }

      toast.error(
        `Import failed: ${errorMessage}`,
        { id: loadingToastId, duration: 8000 }
      );
    } finally {
      setIsLoadingStateBoundaries(false);
    }
  };

  const handleFindZipsClick = async ({ city, state, radius_miles, currentZips }) => {
    if (radius_miles && city && state) {
      const loadingToastId = 'finding-zips-osm';
      toast.loading(
        `Searching for ZIP codes within ${radius_miles} miles...`,
        { id: loadingToastId, duration: 30000 }
      );

      try {
        const response = await base44.functions.invoke('findZipCodesInRadius', {
          city: city,
          state: state,
          radiusMiles: parseFloat(radius_miles)
        });

        if (response?.data?.success && response.data?.zipCodes) {
          const newZips = response.data.zipCodes;
          const combinedZips = [...new Set([...(currentZips || []), ...newZips])].sort();

          toast.success(
            `Found ${newZips.length} ZIP codes! Added ${combinedZips.length - (currentZips || []).length} new ones.`,
            { id: loadingToastId, duration: 5000 }
          );
          return combinedZips; // Return updated ZIPs
        } else if (response?.data?.error) {
          throw new Error(response.data.error);
        } else {
          throw new Error('Unexpected response format from ZIP search');
        }
      } catch (error) {
        console.error('Error finding ZIP codes:', error);

        let errorMessage = error.message || 'Unknown error occurred';

        if (errorMessage.includes('Network Error') || errorMessage.includes('connection failed')) {
          errorMessage = 'Cannot connect to the server. Please check your internet connection.';
        } else if (errorMessage.includes('Rate limit')) {
          errorMessage = 'Too many requests. Please wait 30 seconds before trying again.';
        } else if (errorMessage.includes('timeout')) {
          errorMessage = 'Request timed out. Try a smaller search radius.';
        } else if (errorMessage.includes('Location not found')) {
          errorMessage = `Could not find "${city}, ${state}". Please check the spelling.`;
        }

        toast.error(
          `Failed to find ZIP codes: ${errorMessage}`,
          { id: loadingToastId, duration: 8000 }
        );
        return currentZips; // Return original ZIPs on error
      }
    } else {
      toast.error("Please provide a city, state, and radius to find ZIP codes.");
      return currentZips; // Return original ZIPs
    }
  };


  const handleSaveGeography = async (newGeo) => {
    const oldZips = new Set(assessment?.geography?.zip_codes || []);
    const newZips = new Set(newGeo.zip_codes || []);

    const oldZipsArray = Array.from(oldZips).sort().join(',');
    const newZipsArray = Array.from(newZips).sort().join(',');

    const zipsChanged = oldZips.size !== newZips.size || oldZipsArray !== newZipsArray;

    let updatedTrimmedGeoJSON = assessment.processed_data?.trimmed_geojson;
    let updatedMetadata = assessment.processed_data?.geojson_metadata;

    // CRITICAL FIX: If ZIPs changed and we have pre-processed data, filter it to the new ZIP list
    if (zipsChanged && updatedTrimmedGeoJSON?.features) {
      const newZipSet = new Set(newGeo.zip_codes || []);
      const filteredFeatures = updatedTrimmedGeoJSON.features.filter(feature => {
        const zip = feature.properties.ZCTA5CE10;
        return newZipSet.has(zip);
      });

      if (filteredFeatures.length > 0) {
        // Update GeoJSON with filtered features
        updatedTrimmedGeoJSON = {
          ...updatedTrimmedGeoJSON,
          features: filteredFeatures
        };

        // Update metadata
        if (updatedMetadata) {
          const foundZips = filteredFeatures.map(f => f.properties.ZCTA5CE10);
          const missingZips = (newGeo.zip_codes || []).filter(z => !foundZips.includes(z));

          updatedMetadata = {
            ...updatedMetadata,
            zip_count: filteredFeatures.length,
            zip_codes_found: foundZips,
            zip_codes_missing: missingZips,
            last_filtered: new Date().toISOString()
          };
        }

        console.log(`Filtered pre-processed data: ${updatedTrimmedGeoJSON.features.length} boundaries kept (${filteredFeatures.length} new features)`);
      } else {
        // No matching features after filter, clear the data
        console.log('No matching boundaries after filtering, clearing pre-processed data');
        updatedTrimmedGeoJSON = null;
        updatedMetadata = null;
      }
    }

    const updatedProcessedData = {
      ...assessment.processed_data,
      zip_codes: newGeo.zip_codes || [],
      boundaries_loaded: updatedTrimmedGeoJSON ? true : false,
      trimmed_geojson: updatedTrimmedGeoJSON,
      geojson_metadata: updatedMetadata,
      // Only clear census data if no boundaries remain
      census_data: updatedTrimmedGeoJSON ? assessment.processed_data?.census_data : null
    };

    onUpdate(newGeo);

    try {
      await base44.entities.Assessment.update(assessment.id, {
        geography: newGeo,
        processed_data: updatedProcessedData
      });

      if (zipsChanged) {
        if (updatedTrimmedGeoJSON && updatedTrimmedGeoJSON.features.length > 0) {
          const keptCount = updatedTrimmedGeoJSON.features.length;
          const removedCount = oldZips.size - keptCount; // Note: This assumes all kept were from oldZips, which is true.
          // It represents the difference in *processed* boundaries.
          let message = `Geography updated! Kept ${keptCount} boundaries.`;
          if (oldZips.size > keptCount) {
            message += ` Removed ${oldZips.size - keptCount} (no longer in selection).`;
          }
          if (newZips.size > keptCount) {
            message += ` Added ${newZips.size - keptCount} new ZIPs to selection (not yet processed).`;
          }
          toast.success(
            `${message} Reloading...`,
            { duration: 3000 }
          );
        } else {
          toast.info(
            "Geography updated! Pre-processed data cleared. Use 'Smart Pre-Process' to load boundaries for the new ZIP selection. Reloading...",
            { duration: 4000 }
          );
        }

        setTimeout(() => {
          window.location.reload();
        }, 1000);
      } else {
        toast.success("Geography updated successfully!");
      }
    } catch (error) {
      console.error('Failed to save geography:', error);
      toast.error("Failed to save geography changes");
      return;
    }

    setIsEditorOpen(false);
  };

  const hasPreprocessedData = assessment?.processed_data?.trimmed_geojson?.features?.length > 0;
  const preprocessedCount = assessment?.processed_data?.trimmed_geojson?.features?.length || 0;

  return (
    <>
      <div className={`relative transition-all duration-300 ${isCollapsed ? 'w-16' : 'w-full'}`}>
        {/* Collapse/Expand Button */}
        <Button
          variant="outline"
          size="icon"
          onClick={() => setIsCollapsed(!isCollapsed)}
          className={`transition-all duration-300 h-10 w-10 rounded-full shadow-lg border-2 ${
            isCollapsed
              ? 'bg-emerald-500 hover:bg-emerald-600 border-emerald-600 text-white'
              : 'absolute -left-3 top-6 z-10 bg-white hover:bg-gray-50 border-gray-300'
          }`}
          title={isCollapsed ? "Open Settings" : "Close Settings"}
        >
          {isCollapsed ? (
            <Settings className="w-5 h-5" />
          ) : (
            <ChevronLeft className="w-4 h-4" />
          )}
        </Button>

        <Card className={`transition-all duration-300 ${
          isCollapsed
            ? 'opacity-0 pointer-events-none invisible'
            : 'opacity-100 relative'
        }`}>
          <CardHeader className="flex flex-row items-center justify-between pb-4">
            <CardTitle className="text-base font-medium">Geography Controls</CardTitle>
            <div className="flex gap-2">
              <Button variant="ghost" size="icon" onClick={onReloadMap} className="h-7 w-7" title="Reload Map Graphics">
                <RefreshCw className="w-4 h-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsEditorOpen(true)}
                className="h-7"
              >
                <Edit className="w-3 h-3 mr-1.5" />
                Edit Geography
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-md">
              <MapPin className="w-4 h-4 text-gray-500" />
              <span className="font-medium">{assessment?.geography?.city || 'N/A'}, {assessment?.geography?.state || 'N/A'}</span>
            </div>

            <div>
              <p className="text-sm text-gray-600">ZIP Codes Selected</p>
              <p className="font-semibold">{zipCodes.length || 0} areas</p>
              {hasPreprocessedData && (
                <Badge className="mt-2 bg-emerald-100 text-emerald-800 border-emerald-200 hover:bg-emerald-100">
                  ✓ Pre-processed ({preprocessedCount} boundaries ready)
                </Badge>
              )}
            </div>

            <Button
              onClick={onReloadAll}
              disabled={isReloadingAll || isLoadingBoundaries || isFindingZips || zipCodes.length === 0}
              variant="outline"
              className="w-full"
              size="sm"
            >
              {isReloadingAll ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <RefreshCw className="w-4 h-4 mr-2" />
              )}
              Refresh All Data
            </Button>

            {!isReloadingAll && assessment?.organizations?.length === 0 && (
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-md">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600 mt-0.5" />
                  <div className="text-sm">
                    <p className="font-medium text-amber-900">No Competitors Found</p>
                    <p className="text-amber-700 text-xs mt-1">
                      Click "Refresh All Data" to search for healthcare organizations in {assessment?.geography?.state || 'your area'} using OpenStreetMap,
                      or go to the Competitors tab to add them manually.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {mapColorMetric && <ColorLegend metric={mapColorMetric} censusData={censusData} colorScaleName={mapSettings?.colorScale} />}

            {/* Map Display Settings */}
            <div className="space-y-4 pt-4 border-t border-gray-100">
              <h4 className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                <Settings className="w-4 h-4" />
                Map Display
              </h4>

              {/* Show Competitors Toggle */}
              <div className="flex items-center justify-between">
                <Label htmlFor="competitors-toggle" className="text-sm text-gray-700 font-medium flex items-center gap-2">
                  {showCompetitors ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                  Show Competitors
                </Label>
                <Switch
                  id="competitors-toggle"
                  checked={showCompetitors}
                  onCheckedChange={onShowCompetitorsChange}
                />
              </div>

              {/* Color Scale Selection */}
              <div className="space-y-2">
                <Label className="text-sm text-gray-700 font-medium flex items-center gap-2">
                  <Palette className="w-4 h-4" />
                  Color Scale
                </Label>
                <Select
                  value={mapSettings?.colorScale || 'blue'}
                  onValueChange={(value) => onMapSettingsChange({ ...mapSettings, colorScale: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Choose color scale" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="viridis">Viridis (Colorblind-safe)</SelectItem>
                    <SelectItem value="plasma">Plasma (Hot)</SelectItem>
                    <SelectItem value="magma">Magma (Dark-Hot)</SelectItem>
                    <SelectItem value="inferno">Inferno (Fire)</SelectItem>
                    <SelectItem value="bluePurple">Blue-Purple</SelectItem>
                    <SelectItem value="redYellowGreen">Red-Yellow-Green</SelectItem>
                    <SelectItem value="spectral">Spectral (Divergent)</SelectItem>
                    <SelectItem value="blue">Blue (Classic)</SelectItem>
                    <SelectItem value="green">Green (Classic)</SelectItem>
                    <SelectItem value="red">Red (Classic)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Show ZIP Labels Toggle */}
              <div className="flex items-center justify-between">
                <Label htmlFor="zip-labels-toggle" className="text-sm text-gray-700 font-medium">
                  Show ZIP Code Labels
                </Label>
                <Switch
                  id="zip-labels-toggle"
                  checked={mapSettings?.showZipLabels || false}
                  onCheckedChange={(checked) => onMapSettingsChange({ ...mapSettings, showZipLabels: checked })}
                />
              </div>

              {/* Overlay Metric Selection */}
              <div className="space-y-2">
                <Label className="text-sm text-gray-700 font-medium">Overlay Metric</Label>
                <Select
                  value={mapColorMetric}
                  onValueChange={onMapColorMetricChange}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="population">Population</SelectItem>
                    <SelectItem value="medianIncome">Median Income</SelectItem>
                    <SelectItem value="povertyRate">Poverty Rate</SelectItem>
                    <SelectItem value="uninsuredRate">Uninsured Rate</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Show Data Overlay Toggle */}
              <div className="flex items-center justify-between">
                <Label htmlFor="data-overlay-toggle" className="text-sm text-gray-700 font-medium">
                  Show Data Values Overlay
                </Label>
                <Switch
                  id="data-overlay-toggle"
                  checked={mapSettings?.showDataOverlay || false}
                  onCheckedChange={(checked) => onMapSettingsChange({ ...mapSettings, showDataOverlay: checked })}
                />
              </div>
            </div>

            {/* Radius Reference Controls */}
            <div className="space-y-3 pt-4 border-t border-gray-100">
              <div className="flex items-center justify-between">
                <Label htmlFor="radius-toggle" className="text-sm text-gray-700 font-medium">Show Radius Reference</Label>
                <Switch
                  id="radius-toggle"
                  checked={showRadiusReference}
                  onCheckedChange={onShowRadiusChange}
                />
              </div>

              {showRadiusReference && (
                <div className="pl-4 border-l-2 border-emerald-200">
                  <Label className="text-xs text-gray-600 mb-2 block">Radius Size</Label>
                  <div className="flex gap-2">
                    {[10, 30, 50].map((miles) => (
                      <Button
                        key={miles}
                        variant={radiusMiles === miles ? "default" : "outline"}
                        size="sm"
                        onClick={() => onRadiusMilesChange(miles)}
                        className={radiusMiles === miles ? "bg-emerald-600 hover:bg-emerald-700" : ""}
                      >
                        {miles} mi
                      </Button>
                    ))}
                  </div>
                  <p className="text-xs text-gray-500 mt-2">
                    Showing {radiusMiles}-mile radius from {assessment?.geography?.city || 'center'}
                  </p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <GeographyEditor
        open={isEditorOpen}
        onClose={() => setIsEditorOpen(false)}
        assessment={assessment}
        currentZipCodes={zipCodes}
        onSave={handleSaveGeography}
        isFindingZips={isFindingZips}
        onFindZips={handleFindZipsClick}
        isLoadingBoundaries={isLoadingBoundaries}
        isLoadingStateBoundaries={isLoadingStateBoundaries}
        isPreprocessing={isPreprocessing}
        handlePreprocessBoundaries={handlePreprocessBoundaries}
        handleLoadMyZipBoundaries={handleLoadMyZipBoundaries}
        handleLoadStateBoundaries={handleLoadStateBoundaries}
        hasPreprocessedData={hasPreprocessedData}
        preprocessedCount={preprocessedCount}
        onPreprocessComplete={onPreprocessComplete}
      />
    </>
  );
}