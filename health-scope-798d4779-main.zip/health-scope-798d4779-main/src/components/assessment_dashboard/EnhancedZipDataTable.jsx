import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from '@/components/ui/badge';
import { BarChart, Loader2, RefreshCw, Database, Settings, BrainCircuit, Upload, TrendingUp, FileText, RefreshCcw, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Checkbox } from '@/components/ui/checkbox';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

const AVAILABLE_COLUMNS = [
  { id: 'population', label: 'Population', format: 'number', default: true },
  { id: 'medianIncome', label: 'Median Income', format: 'currency', default: true },
  { id: 'povertyRate', label: 'Poverty Rate', format: 'percent', default: true },
  { id: 'uninsuredRate', label: 'Uninsured Rate', format: 'percent', default: true },
  { id: 'medicareRate', label: 'Medicare Rate', format: 'percent', default: false },
  { id: 'medicaidRate', label: 'Medicaid Rate', format: 'percent', default: false },
];

export default function EnhancedZipDataTable({ 
  zipCodes, 
  mapColorMetric, 
  onMapColorMetricChange, 
  censusData, 
  isLoadingData, 
  onRefresh,
  onFindMissingData,
  assessment 
}) {
  const [filterText, setFilterText] = useState('');
  const [sortConfig, setSortConfig] = useState({ key: 'zip', direction: 'ascending' });
  const [selectedColumns, setSelectedColumns] = useState(
    AVAILABLE_COLUMNS.filter(col => col.default).map(col => col.id)
  );
  const [heatmapEnabled, setHeatmapEnabled] = useState(false);
  const [heatmapMetric, setHeatmapMetric] = useState('population');
  const [selectedZips, setSelectedZips] = useState(new Set());
  const [reloadingZips, setReloadingZips] = useState(new Set());

  const displayData = zipCodes.map(zip => {
    const rawData = censusData[zip] || {};
    
    // Validate and clean data - keep all valid numeric values
    const population = (rawData.population > 0 && rawData.population < 10000000) ? rawData.population : null;
    const medianIncome = (rawData.medianIncome > 0 && rawData.medianIncome < 1000000) ? rawData.medianIncome : null;
    const povertyRate = (rawData.povertyRate >= 0 && rawData.povertyRate <= 100) ? rawData.povertyRate : null;
    // Note: Some Census estimates can exceed 100% due to survey methodology
    const uninsuredRate = (rawData.uninsuredRate >= 0 && rawData.uninsuredRate <= 150) ? rawData.uninsuredRate : null;
    const medicareRate = (rawData.medicareRate >= 0 && rawData.medicareRate <= 150) ? rawData.medicareRate : null;
    const medicaidRate = (rawData.medicaidRate >= 0 && rawData.medicaidRate <= 150) ? rawData.medicaidRate : null;
    
    return {
      zip,
      population,
      medianIncome,
      povertyRate,
      uninsuredRate,
      medicareRate,
      medicaidRate,
      source: rawData.source || 'No data'
    };
  });

  const sortedAndFilteredData = useMemo(() => {
    let items = [...displayData];

    if (filterText) {
      items = items.filter(item => item.zip.toLowerCase().includes(filterText.toLowerCase()));
    }

    if (sortConfig.key) {
      items.sort((a, b) => {
        let valA = a[sortConfig.key];
        let valB = b[sortConfig.key];

        if (typeof valA === 'number' && typeof valB === 'number') {
          return sortConfig.direction === 'ascending' ? valA - valB : valB - valA;
        }

        if (typeof valA === 'string' && typeof valB === 'string') {
          return sortConfig.direction === 'ascending' 
            ? valA.localeCompare(valB) 
            : valB.localeCompare(valA);
        }

        return 0;
      });
    }
    return items;
  }, [displayData, filterText, sortConfig]);

  const getHeatmapColor = (value, metric) => {
    if (!heatmapEnabled || value === null || value === undefined) return '';

    const values = displayData
      .map(d => d[metric])
      .filter(v => typeof v === 'number');
    
    if (values.length === 0) return '';

    const min = Math.min(...values);
    const max = Math.max(...values);
    const normalized = (value - min) / (max - min);

    // Red to yellow to green gradient
    const r = normalized < 0.5 ? 255 : Math.round(255 - (normalized - 0.5) * 2 * 255);
    const g = normalized < 0.5 ? Math.round(normalized * 2 * 255) : 255;
    const b = 0;

    return `rgba(${r}, ${g}, ${b}, ${0.2 + normalized * 0.3})`;
  };

  const formatValue = (value, format) => {
    if (value === null || value === undefined || value === 0) return 'N/A';
    
    switch (format) {
      case 'currency':
        return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0 }).format(value);
      case 'percent':
        return `${value}%`;
      case 'number':
        return new Intl.NumberFormat('en-US').format(value);
      default:
        return value;
    }
  };

  const getSourceIcon = (source) => {
    if (!source || source === 'No data') {
      return <Database className="w-3.5 h-3.5 text-gray-400" />;
    }
    if (source.includes('Census')) {
      return <Database className="w-3.5 h-3.5 text-blue-600" />;
    }
    if (source.includes('Upload') || source.includes('CSV')) {
      return <Upload className="w-3.5 h-3.5 text-emerald-600" />;
    }
    if (source.includes('Estimate')) {
      return <TrendingUp className="w-3.5 h-3.5 text-amber-600" />;
    }
    return <FileText className="w-3.5 h-3.5 text-gray-600" />;
  };

  const handleReloadZip = async (zipCode) => {
    setReloadingZips(prev => new Set([...prev, zipCode]));
    toast.loading(`Reloading data for ${zipCode}...`, { id: `reload-${zipCode}` });

    try {
      const demographics = await base44.entities.ZipDemographics.filter({
        zcta5: zipCode
      });

      if (demographics && demographics.length > 0) {
        const demo = demographics[0];
        const newData = {
          population: demo.population || null,
          medianIncome: demo.median_income || null,
          povertyRate: demo.poverty_rate || null,
          uninsuredRate: demo.uninsured_rate || null,
          source: demo.source || 'Database'
        };

        // Callback to parent to update
        onRefresh?.();
        toast.success(`Reloaded ${zipCode}`, { id: `reload-${zipCode}` });
      } else {
        toast.warning(`No data found for ${zipCode}`, { id: `reload-${zipCode}` });
      }
    } catch (error) {
      console.error('Error reloading ZIP:', error);
      toast.error(`Failed to reload ${zipCode}`, { id: `reload-${zipCode}` });
    } finally {
      setReloadingZips(prev => {
        const updated = new Set(prev);
        updated.delete(zipCode);
        return updated;
      });
    }
  };

  const handleReloadSelected = async () => {
    if (selectedZips.size === 0) return;
    
    const zipArray = Array.from(selectedZips);
    toast.loading(`Reloading ${zipArray.length} ZIP codes...`, { id: 'reload-selected' });

    for (const zip of zipArray) {
      await handleReloadZip(zip);
    }

    setSelectedZips(new Set());
    toast.success(`Reloaded ${zipArray.length} ZIP codes`, { id: 'reload-selected' });
  };

  const toggleZipSelection = (zip) => {
    setSelectedZips(prev => {
      const updated = new Set(prev);
      if (updated.has(zip)) {
        updated.delete(zip);
      } else {
        updated.add(zip);
      }
      return updated;
    });
  };

  const isRowIncomplete = (data) => {
    return !data.population || 
           !data.medianIncome || 
           !data.povertyRate || 
           !data.uninsuredRate;
  };

  const handleColumnToggle = (columnId) => {
    setSelectedColumns(prev => {
      if (prev.includes(columnId)) {
        return prev.filter(id => id !== columnId);
      } else if (prev.length < 4) {
        return [...prev, columnId];
      }
      return prev;
    });
  };

  const missingDataCount = useMemo(() => {
    let count = 0;
    displayData.forEach(item => {
      selectedColumns.forEach(colId => {
        if (item[colId] === null || item[colId] === undefined) {
          count++;
        }
      });
    });
    return count;
  }, [displayData, selectedColumns]);

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
          <CardTitle className="flex items-center gap-2">
            <BarChart className="w-5 h-5" />
            ZIP Code Demographics
            {missingDataCount > 0 && (
              <Badge variant="outline" className="text-amber-600 border-amber-200">
                {missingDataCount} missing values
              </Badge>
            )}
          </CardTitle>
          <div className="flex items-center gap-2 flex-wrap">
            <Input
              placeholder="Filter by ZIP..."
              value={filterText}
              onChange={(e) => setFilterText(e.target.value)}
              className="max-w-[150px] h-9"
            />

            {selectedZips.size > 0 && (
              <Button
                variant="default"
                size="sm"
                onClick={handleReloadSelected}
                className="gap-2 bg-blue-600 hover:bg-blue-700"
              >
                <RefreshCcw className="w-4 h-4" />
                Reload {selectedZips.size}
              </Button>
            )}

            {missingDataCount > 0 && onFindMissingData && (
              <Button
                variant="outline"
                size="sm"
                onClick={onFindMissingData}
                className="gap-2 text-amber-600 border-amber-300 hover:bg-amber-50"
              >
                <BrainCircuit className="w-4 h-4" />
                Find Missing Data
              </Button>
            )}

            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm" className="gap-2">
                  <Settings className="w-4 h-4" />
                  Columns
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Select Columns (Max 4)</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  {AVAILABLE_COLUMNS.map(col => (
                    <div key={col.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={col.id}
                        checked={selectedColumns.includes(col.id)}
                        onCheckedChange={() => handleColumnToggle(col.id)}
                        disabled={!selectedColumns.includes(col.id) && selectedColumns.length >= 4}
                      />
                      <Label htmlFor={col.id}>{col.label}</Label>
                    </div>
                  ))}
                </div>
              </DialogContent>
            </Dialog>

            <div className="flex items-center gap-2 border-l pl-2">
              <Label htmlFor="heatmap-toggle" className="text-xs">Heatmap</Label>
              <Switch
                id="heatmap-toggle"
                checked={heatmapEnabled}
                onCheckedChange={setHeatmapEnabled}
              />
            </div>

            <Button
              variant="outline"
              size="sm"
              onClick={onRefresh}
              disabled={isLoadingData}
            >
              {isLoadingData ? (
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
              ) : (
                <RefreshCw className="w-4 h-4 mr-2" />
              )}
              Refresh
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <TooltipProvider>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">
                    <Checkbox
                      checked={selectedZips.size === sortedAndFilteredData.length && sortedAndFilteredData.length > 0}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setSelectedZips(new Set(sortedAndFilteredData.map(d => d.zip)));
                        } else {
                          setSelectedZips(new Set());
                        }
                      }}
                      className="h-4 w-4"
                    />
                  </TableHead>
                  <TableHead 
                    onClick={() => setSortConfig({ key: 'zip', direction: sortConfig.key === 'zip' && sortConfig.direction === 'ascending' ? 'descending' : 'ascending' })}
                    className="cursor-pointer"
                  >
                    ZIP Code {sortConfig.key === 'zip' && (sortConfig.direction === 'ascending' ? '▲' : '▼')}
                  </TableHead>
                  {AVAILABLE_COLUMNS.filter(col => selectedColumns.includes(col.id)).map(col => (
                    <TableHead 
                      key={col.id}
                      onClick={() => setSortConfig({ key: col.id, direction: sortConfig.key === col.id && sortConfig.direction === 'ascending' ? 'descending' : 'ascending' })}
                      className="cursor-pointer text-right"
                    >
                      {col.label} {sortConfig.key === col.id && (sortConfig.direction === 'ascending' ? '▲' : '▼')}
                    </TableHead>
                  ))}
                  <TableHead className="text-center w-20">Source</TableHead>
                  <TableHead className="text-center w-16">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sortedAndFilteredData.map((data) => {
                  const incomplete = isRowIncomplete(data);
                  const isReloading = reloadingZips.has(data.zip);
                  const isSelected = selectedZips.has(data.zip);

                  return (
                    <TableRow 
                      key={data.zip}
                      className={`${incomplete ? 'bg-amber-50/40' : ''} ${isSelected ? 'bg-blue-50' : ''}`}
                    >
                      <TableCell>
                        <Checkbox
                          checked={isSelected}
                          onCheckedChange={() => toggleZipSelection(data.zip)}
                          className="h-4 w-4"
                        />
                      </TableCell>
                      <TableCell className="font-medium">{data.zip}</TableCell>
                      {AVAILABLE_COLUMNS.filter(col => selectedColumns.includes(col.id)).map(col => {
                        const value = formatValue(data[col.id], col.format);
                        return (
                          <TableCell 
                            key={col.id}
                            className="text-right"
                            style={{ backgroundColor: heatmapEnabled && col.id === heatmapMetric ? getHeatmapColor(data[col.id], col.id) : '' }}
                          >
                            <div className="flex items-center justify-end gap-1">
                              {value}
                              {value === 'N/A' && (
                                <AlertCircle className="w-3 h-3 text-amber-500" />
                              )}
                            </div>
                          </TableCell>
                        );
                      })}
                      <TableCell className="text-center">
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <div className="flex justify-center cursor-help">
                              {getSourceIcon(data.source)}
                            </div>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p className="text-xs">{data.source}</p>
                          </TooltipContent>
                        </Tooltip>
                      </TableCell>
                      <TableCell className="text-center">
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleReloadZip(data.zip)}
                              disabled={isReloading}
                              className="h-7 w-7 p-0"
                            >
                              {isReloading ? (
                                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                              ) : (
                                <RefreshCcw className={`w-3.5 h-3.5 ${incomplete ? 'text-amber-600' : 'text-gray-400'}`} />
                              )}
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p className="text-xs">Reload this ZIP</p>
                          </TooltipContent>
                        </Tooltip>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </TooltipProvider>
        </div>
        {sortedAndFilteredData.length === 0 && !isLoadingData && (
          <div className="text-center py-8 text-gray-500">
            {filterText ? `No ZIP codes match "${filterText}"` : 'No data available'}
          </div>
        )}
      </CardContent>
    </Card>
  );
}