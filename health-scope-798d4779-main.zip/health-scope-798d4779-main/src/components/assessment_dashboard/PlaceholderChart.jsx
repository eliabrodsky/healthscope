import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Edit } from 'lucide-react';

export default function PlaceholderChart({ title, icon: Icon, children }) {
  return (
    <Card className="border-gray-200 shadow-sm">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-base font-semibold text-gray-800 flex items-center gap-2">
          {Icon && <Icon className="w-4 h-4 stroke-1" />}
          {title}
        </CardTitle>
        <Button variant="ghost" size="sm" className="h-7">
          <Edit className="w-3 h-3 mr-1" /> Edit
        </Button>
      </CardHeader>
      <CardContent>
        <div className="h-60 bg-gray-50 rounded-lg border-2 border-dashed border-gray-200 flex items-center justify-center">
          <div className="text-center text-gray-500">
            {children}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}