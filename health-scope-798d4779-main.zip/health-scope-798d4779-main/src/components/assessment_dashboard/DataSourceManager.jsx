import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { 
  Eye, 
  RefreshCw, 
  Trash2, 
  MoreHorizontal,
  FileText,
  Database,
  Calendar,
  Users,
  Upload,
  Plus,
  RotateCcw
} from 'lucide-react';
import { toast } from 'sonner';
import { ZipDemographics } from '@/entities/ZipDemographics';
import { Organization } from '@/entities/Organization';
import InteractiveCsvImporter from '../upload/InteractiveCsvImporter';
import { processMappedCsv } from '@/functions/processMappedCsv';

export default function DataSourceManager({ assessment, onUpdateAssessment }) {
  const [previewData, setPreviewData] = useState(null);
  const [showPreview, setShowPreview] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isReloading, setIsReloading] = useState(false);
  const [reloadingSourceId, setReloadingSourceId] = useState(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  
  // State for new CSV upload
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);

  // Helper function to normalize data sources (handle both string and object formats)
  const normalizeDataSources = (dataSources) => {
    if (!Array.isArray(dataSources)) return [];
    
    return dataSources.map(ds => {
      if (typeof ds === 'string') {
        // Convert legacy string format to object format with clearer labeling
        return {
          id: `converted_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
          name: ds,
          type: 'imported_data', // Changed from 'legacy' to be clearer
          status: 'imported',
          uploaded_at: null,
          records_created: null,
          file_id: null,
          description: 'Previously imported data (converted from older format)'
        };
      }
      return ds; // Already an object
    }).filter(ds => ds && ds.name); // Filter out invalid entries
  };

  // Use normalized data sources for rendering
  const dataSources = normalizeDataSources(assessment?.data_sources || []);
  const uploadedFiles = (assessment?.uploaded_files || []).filter(f => f && f.name);

  const handlePreviewSource = async (source) => {
    setIsLoading(true);
    try {
      let data = [];
      
      if (source.type === 'demographics' || source.name.toLowerCase().includes('demographic') || source.name.toLowerCase().includes('population')) {
        data = await ZipDemographics.filter({}, '-created_date', 10);
        if (data.length === 0) {
          toast.info("No demographic data found in database. Try uploading demographic data first.");
          setIsLoading(false);
          return;
        }
      } else if (source.type === 'organizations' || source.name.toLowerCase().includes('fqhc') || source.name.toLowerCase().includes('organization')) {
        data = await Organization.filter({}, '-created_date', 10);
        if (data.length === 0) {
          toast.info("No organization data found in database. Try uploading organization data first.");
          setIsLoading(false);
          return;
        }
      } else if (source.type === 'imported_data') {
        // For converted legacy data, try to infer what type it might be based on name
        if (source.name.toLowerCase().includes('fqhc') || source.name.toLowerCase().includes('organization')) {
          data = await Organization.filter({}, '-created_date', 10);
        } else if (source.name.toLowerCase().includes('demographic') || source.name.toLowerCase().includes('population')) {
          data = await ZipDemographics.filter({}, '-created_date', 10);
        } else {
          toast.info(`Preview not available for "${source.name}". This appears to be converted data from an older format.`);
          setIsLoading(false);
          return;
        }
      } else {
        toast.info("Preview not available for this source type. Try uploading data through the CSV importer.");
        setIsLoading(false);
        return;
      }
      
      if (data.length > 0) {
        setPreviewData({ source, data });
        setShowPreview(true);
      } else {
        toast.info("No data available to preview for this source.");
      }
    } catch (error) {
      console.error("Preview error:", error);
      toast.error('Failed to load preview data');
    } finally {
      setIsLoading(false);
    }
  };

  const handleReloadSource = async (source) => {
    if (!source.file_id) {
      toast.error("Cannot reload this source - no original file reference available. This may be converted data from an older format.");
      return;
    }

    setIsReloading(true);
    setReloadingSourceId(source.id);
    toast.loading(`Reloading ${source.name}...`, { id: `reload-${source.id}` });

    try {
      // Determine the appropriate mapping based on the source type
      let mapping = {};
      let targetEntity = 'Organization';

      if (source.type === 'organizations' || source.name.toLowerCase().includes('fqhc')) {
        // Default FQHC/Organization mapping
        targetEntity = 'Organization';
        mapping = {
          health_center_name: 'name',
          site_name: 'name', 
          site_address: 'address',
          site_city: 'city',
          site_state: 'state',
          site_zip_code: 'zip_code',
          site_type: 'type'
        };
      } else if (source.type === 'demographics') {
        targetEntity = 'ZipDemographics';
        mapping = {
          zip_code: 'zip_code',
          population: 'population',
          median_income: 'median_income',
          poverty_rate: 'poverty_rate',
          uninsured_rate: 'uninsured_rate'
        };
      }

      // Call the processing function to reload the data
      const response = await processMappedCsv({
        file_url: source.file_id,
        mapping: mapping,
        target_entity: targetEntity,
        assessment_id: assessment.id
      });

      if (response.data && response.data.success) {
        // If organizations were created, add them to the assessment
        if (response.data.new_orgs && response.data.new_orgs.length > 0) {
          onUpdateAssessment(prevAssessment => {
            const existingOrgs = prevAssessment.organizations || [];
            const existingOrgNames = new Set(existingOrgs.map(org => org.name?.toLowerCase()));
            
            // Only add organizations that don't already exist
            const newUniqueOrgs = response.data.new_orgs.filter(org => 
              !existingOrgNames.has(org.name?.toLowerCase())
            );

            return {
              ...prevAssessment,
              organizations: [...existingOrgs, ...newUniqueOrgs]
            };
          });
        }

        toast.success(`Successfully reloaded ${source.name}! ${response.data.created_count} records restored.`, { 
          id: `reload-${source.id}` 
        });
      } else {
        throw new Error(response.data?.error || 'Unknown error during reload');
      }

    } catch (error) {
      console.error("Error reloading data source:", error);
      toast.error(`Failed to reload ${source.name}: ${error.message}`, { 
        id: `reload-${source.id}` 
      });
    } finally {
      setIsReloading(false);
      setReloadingSourceId(null);
    }
  };

  const handleDeleteSource = async (source) => {
    toast.loading(`Removing ${source.name}...`, { id: `delete-${source.id}` });
    try {
      onUpdateAssessment(prevAssessment => {
        // Normalize current data sources before filtering
        const currentValidSources = normalizeDataSources(prevAssessment?.data_sources || []);
        const updatedSources = currentValidSources.filter(s => s.id !== source.id);

        const currentUploadedFiles = prevAssessment?.uploaded_files || [];
        const updatedFiles = source.file_id 
          ? currentUploadedFiles.filter(f => f.url !== source.file_id)
          : currentUploadedFiles;

        return {
          ...prevAssessment,
          data_sources: updatedSources,
          uploaded_files: updatedFiles,
        };
      });

      toast.success(`${source.name} has been removed.`, { id: `delete-${source.id}` });
    } catch (error) {
      console.error("Error deleting data source:", error);
      toast.error('Failed to delete data source.', { id: `delete-${source.id}` });
    }
  };

  const handleRefreshDataSources = async () => {
    setIsRefreshing(true);
    toast.loading("Refreshing data sources...", { id: 'refresh-sources' });

    try {
      // Force refresh the assessment data from the backend
      const { Assessment } = await import('@/entities/Assessment');
      const refreshedAssessment = await Assessment.get(assessment.id);
      
      if (refreshedAssessment) {
        onUpdateAssessment(refreshedAssessment);
        toast.success("Data sources refreshed successfully!", { id: 'refresh-sources' });
      } else {
        throw new Error("Failed to fetch updated assessment data");
      }
    } catch (error) {
      console.error("Error refreshing data sources:", error);
      toast.error("Failed to refresh data sources.", { id: 'refresh-sources' });
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleNewUploadComplete = () => {
    setIsUploadModalOpen(false);
    toast.success("New data source uploaded successfully!");
    // The InteractiveCsvImporter will handle updating the assessment
  };

  const formatDate = (dateStr) => {
    if (!dateStr) return 'N/A';
    try {
      return new Date(dateStr).toLocaleDateString();
    } catch (error) {
      return 'Invalid Date';
    }
  };

  const getSourceIcon = (type) => {
    switch (type) {
      case 'demographics':
        return Users;
      case 'organizations':
        return Database;
      case 'file':
        return FileText;
      case 'imported_data': // Updated from 'legacy'
        return Database;
      default:
        return Database;
    }
  };

  const getSourceTypeLabel = (type) => {
    switch (type) {
      case 'demographics':
        return 'Demographics';
      case 'organizations':
        return 'Organizations';
      case 'file':
        return 'File Upload';
      case 'imported_data': // Updated from 'legacy'
        return 'Imported Data';
      default:
        return 'Data Source';
    }
  };

  // Combine filtered uploaded files with filtered configured sources
  const allSources = [
    ...dataSources,
    ...uploadedFiles
      .filter(file => !dataSources.some(ds => ds.file_id === file.url))
      .map(file => ({
        id: file.id || file.url,
        name: file.name,
        type: 'file',
        status: 'uploaded',
        uploaded_at: file.uploaded_at,
        file_id: file.url,
        sourceType: 'uploaded'
      }))
  ];

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="flex items-center gap-2">
              <Database className="w-5 h-5" />
              Data Source Management
            </CardTitle>
            <div className="flex gap-2">
              <Button 
                variant="outline"
                onClick={handleRefreshDataSources}
                disabled={isRefreshing}
                size="sm"
              >
                {isRefreshing ? (
                  <RotateCcw className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <RotateCcw className="w-4 h-4 mr-2" />
                )}
                Refresh Sources
              </Button>
              <Button 
                onClick={() => setIsUploadModalOpen(true)}
                className="bg-emerald-600 hover:bg-emerald-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Upload New Data Source
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {allSources.length > 0 ? (
            <div className="space-y-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Source</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {allSources.map((source) => {
                    const Icon = getSourceIcon(source.type);
                    const isCurrentlyReloading = isReloading && reloadingSourceId === source.id;
                    
                    return (
                      <TableRow key={source.id}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <Icon className="w-4 h-4 text-gray-500" />
                            <div>
                              <p className="font-medium">{source.name}</p>
                              {source.description && (
                                <p className="text-sm text-gray-500">{source.description}</p>
                              )}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className="capitalize">
                            {getSourceTypeLabel(source.type)}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge 
                            variant={source.status === 'available' || source.status === 'uploaded' || source.status === 'imported' ? 'default' : 'secondary'}
                            className={
                              source.status === 'available' || source.status === 'uploaded' || source.status === 'imported'
                                ? 'bg-green-100 text-green-800 border-green-200' 
                                : ''
                            }
                          >
                            {isCurrentlyReloading ? 'Reloading...' : (source.status || 'unknown')}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1 text-sm text-gray-500">
                            <Calendar className="w-3 h-3" />
                            {formatDate(source.uploaded_at || source.created_date || new Date().toISOString())}
                          </div>
                        </TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8" disabled={isCurrentlyReloading}>
                                <MoreHorizontal className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem 
                                onClick={() => handlePreviewSource(source)} 
                                disabled={isLoading}
                              >
                                <Eye className="w-4 h-4 mr-2" />
                                Preview Data
                              </DropdownMenuItem>
                              <DropdownMenuItem 
                                onClick={() => handleReloadSource(source)}
                                disabled={!source.file_id || isReloading}
                              >
                                <RefreshCw className={`w-4 h-4 mr-2 ${isCurrentlyReloading ? 'animate-spin' : ''}`} />
                                {isCurrentlyReloading ? 'Reloading...' : 'Reload & Restore Data'}
                              </DropdownMenuItem>
                              <DropdownMenuItem 
                                onClick={() => handleDeleteSource(source)}
                                className="text-red-600"
                                disabled={isReloading}
                              >
                                <Trash2 className="w-4 h-4 mr-2" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-8">
              <Database className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-600 mb-4">No data sources configured yet</p>
              <Button 
                onClick={() => setIsUploadModalOpen(true)}
                className="bg-emerald-600 hover:bg-emerald-700"
              >
                <Upload className="w-4 h-4 mr-2" />
                Upload Your First Data Source
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Preview Dialog */}
      <Dialog open={showPreview} onOpenChange={setShowPreview}>
        <DialogContent className="max-w-4xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle>Data Preview: {previewData?.source?.name}</DialogTitle>
          </DialogHeader>
          <div className="overflow-auto">
            {isLoading ? (
              <div className="text-center py-8 text-gray-500">Loading preview data...</div>
            ) : previewData?.data && previewData.data.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    {Object.keys(previewData.data[0]).map(key => (
                      <TableHead key={key} className="capitalize">
                        {key.replace(/_/g, ' ')}
                      </TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {previewData.data.slice(0, 10).map((row, index) => (
                    <TableRow key={index}>
                      {Object.values(row).map((value, cellIndex) => (
                        <TableCell key={cellIndex}>
                          {typeof value === 'object' ? JSON.stringify(value) : String(value)}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center py-8 text-gray-500">
                No data available to preview
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* New Upload Modal */}
      <InteractiveCsvImporter
        open={isUploadModalOpen}
        onOpenChange={setIsUploadModalOpen}
        onImportComplete={handleNewUploadComplete}
        targetEntity="Organization"
        onDataUpdate={onUpdateAssessment}
        assessmentId={assessment?.id}
      />
    </>
  );
}