
import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { BarChart, Palette, Loader2, RefreshCw, Database, ChevronDown, ArrowUpDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function ZipDataTable({ zipCodes, mapColorMetric, onMapColorMetricChange, censusData, isLoadingData, onRefresh }) {
  const [selectedDataSource, setSelectedDataSource] = useState('auto'); // 'auto', 'uploaded', 'census', 'curated', 'estimated'
  const [filterText, setFilterText] = useState(''); // New state for filter input
  const [sortConfig, setSortConfig] = useState({ key: 'zip', direction: 'ascending' }); // New state for sorting

  // Get available data sources
  const getAvailableDataSources = () => {
    const sources = new Set();
    Object.values(censusData).forEach(data => {
      if (data.source) {
        if (data.source.includes('Upload') || data.source.includes('CSV')) sources.add('uploaded');
        else if (data.source.includes('Census Bureau API')) sources.add('census');
        else if (data.source.includes('Curated')) sources.add('curated');
        else if (data.source.includes('Estimate')) sources.add('estimated');
      }
    });
    return Array.from(sources);
  };

  const availableDataSources = getAvailableDataSources();

  // Filter data based on selected source
  const filterDataBySource = (data, sourceFilter) => {
    if (sourceFilter === 'auto') return data;
    
    const filtered = {};
    Object.keys(data).forEach(zip => {
      const zipData = data[zip];
      const source = zipData.source || '';
      
      const shouldInclude = 
        (sourceFilter === 'uploaded' && (source.includes('Upload') || source.includes('CSV'))) ||
        (sourceFilter === 'census' && source.includes('Census Bureau API')) ||
        (sourceFilter === 'curated' && source.includes('Curated')) ||
        (sourceFilter === 'estimated' && source.includes('Estimate'));
        
      if (shouldInclude) {
        filtered[zip] = zipData;
      }
    });
    return filtered;
  };

  const filteredCensusData = filterDataBySource(censusData, selectedDataSource);
  
  // Base display data, includes all zipCodes from props, with data from filteredCensusData or fallback
  const displayData = zipCodes.map(zip => ({
    zip,
    ...(filteredCensusData[zip] || censusData[zip] || {
      population: isLoadingData ? 'Loading...' : 'N/A',
      medianIncome: isLoadingData ? 'Loading...' : 'N/A',
      povertyRate: isLoadingData ? 'Loading...' : 'N/A',
      uninsuredRate: isLoadingData ? 'Loading...' : 'N/A',
      source: isLoadingData ? 'Loading...' : 'No data'
    })
  }));

  // Memoized data for filtering and sorting
  const sortedAndFilteredData = useMemo(() => {
    let sortableItems = [...displayData];

    // Filtering
    if (filterText) {
      sortableItems = sortableItems.filter(item =>
        item.zip.toLowerCase().includes(filterText.toLowerCase())
      );
    }

    // Sorting
    if (sortConfig.key) {
      sortableItems.sort((a, b) => {
        let valA = a[sortConfig.key];
        let valB = b[sortConfig.key];

        // Convert to number for numeric fields, handle 'N/A' or 'Loading...'
        if (['population', 'medianIncome', 'povertyRate', 'uninsuredRate'].includes(sortConfig.key)) {
            // Ensure values are numbers for comparison. Remove non-numeric chars if they exist.
            valA = typeof valA === 'number' ? valA : parseFloat(String(valA).replace(/[^0-9.-]/g, ''));
            valB = typeof valB === 'number' ? valB : parseFloat(String(valB).replace(/[^0-9.-]/g, ''));

            // Treat non-numeric values as lowest for sorting (they'll go to the end)
            if (isNaN(valA) && isNaN(valB)) return 0;
            if (isNaN(valA)) return sortConfig.direction === 'ascending' ? 1 : -1;
            if (isNaN(valB)) return sortConfig.direction === 'ascending' ? -1 : 1;
        } else if (typeof valA === 'string' && typeof valB === 'string') {
            // Case-insensitive string comparison for zip
            valA = valA.toLowerCase();
            valB = valB.toLowerCase();
        }

        if (valA < valB) return sortConfig.direction === 'ascending' ? -1 : 1;
        if (valA > valB) return sortConfig.direction === 'ascending' ? 1 : -1;
        return 0;
      });
    }
    return sortableItems;
  }, [displayData, filterText, sortConfig]);

  // Function to handle sort requests
  const requestSort = (key) => {
    let direction = 'ascending';
    if (sortConfig.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending';
    }
    setSortConfig({ key, direction });
  };
  
  // Function to get the correct sort icon
  const getSortIcon = (key) => {
    if (sortConfig.key !== key) return <ArrowUpDown className="w-3 h-3 ml-1 opacity-30" />;
    return sortConfig.direction === 'ascending' ? '▲' : '▼';
  };

  const formatCurrency = (value) => {
    if (value === null || value === undefined || typeof value !== 'number') return 'N/A';
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value);
  };

  const formatNumber = (value) => {
    if (value === null || value === undefined || typeof value !== 'number') return 'N/A';
    return new Intl.NumberFormat('en-US').format(value);
  };

  const formatPercentage = (value) => {
    if (value === null || value === undefined || typeof value !== 'number') return 'N/A';
    return `${value}%`;
  };

  const getSourceBadge = (source) => {
    if (!source || source === 'Loading...') {
      return <Badge variant="secondary" className="text-xs">Loading...</Badge>;
    }
    
    if (source.includes('Upload') || source.includes('CSV')) {
      return <Badge variant="default" className="bg-emerald-100 text-emerald-800 border-emerald-200 text-xs">Custom Upload</Badge>;
    } else if (source.includes('Census Bureau API')) {
      return <Badge variant="default" className="bg-blue-100 text-blue-800 border-blue-200 text-xs">Census API</Badge>;
    } else if (source.includes('Curated')) {
      return <Badge variant="default" className="bg-purple-100 text-purple-800 border-purple-200 text-xs">Curated Data</Badge>;
    } else if (source.includes('Estimate')) {
      return <Badge variant="outline" className="text-orange-600 border-orange-200 text-xs">Estimate</Badge>;
    } else {
      return <Badge variant="secondary" className="text-xs">{source}</Badge>;
    }
  };

  const getDataSourceLabel = (key) => {
    const labels = {
      auto: 'All Sources (Best Available)',
      uploaded: 'Custom Uploads Only',
      census: 'Census API Only',
      curated: 'Curated Data Only',
      estimated: 'Estimates Only'
    };
    return labels[key] || key;
  };

  const getDataSourceCounts = () => {
    const counts = {
      uploaded: 0,
      census: 0,
      curated: 0,
      estimated: 0
    };
    
    Object.values(censusData).forEach(data => {
      const source = data.source || '';
      if (source.includes('Upload') || source.includes('CSV')) counts.uploaded++;
      else if (source.includes('Census Bureau API')) counts.census++;
      else if (source.includes('Curated')) counts.curated++;
      else if (source.includes('Estimate')) counts.estimated++;
    });
    
    return counts;
  };

  const sourceCounts = getDataSourceCounts();

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
          <CardTitle className="flex items-center gap-2">
            <BarChart className="w-5 h-5" />
            ZIP Code Demographics
          </CardTitle>
          <div className="flex items-center gap-2 flex-wrap">
            <Input
              placeholder="Filter by ZIP..."
              value={filterText}
              onChange={(e) => setFilterText(e.target.value)}
              className="max-w-[150px] h-9"
            />
            {availableDataSources.length > 1 && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="gap-2">
                    <Database className="w-4 h-4" />
                    Data Source
                    <ChevronDown className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-64">
                  <DropdownMenuLabel>Choose Data Source</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => setSelectedDataSource('auto')}>
                    <div className="flex items-center justify-between w-full">
                      <span>All Sources (Best)</span>
                      <Badge variant="secondary" className="text-xs">{zipCodes.length}</Badge>
                    </div>
                  </DropdownMenuItem>
                  {availableDataSources.includes('uploaded') && (
                    <DropdownMenuItem onClick={() => setSelectedDataSource('uploaded')}>
                      <div className="flex items-center justify-between w-full">
                        <span>Custom Uploads</span>
                        <Badge className="bg-emerald-100 text-emerald-800 text-xs">{sourceCounts.uploaded}</Badge>
                      </div>
                    </DropdownMenuItem>
                  )}
                  {availableDataSources.includes('census') && (
                    <DropdownMenuItem onClick={() => setSelectedDataSource('census')}>
                      <div className="flex items-center justify-between w-full">
                        <span>Census API</span>
                        <Badge className="bg-blue-100 text-blue-800 text-xs">{sourceCounts.census}</Badge>
                      </div>
                    </DropdownMenuItem>
                  )}
                  {availableDataSources.includes('curated') && (
                    <DropdownMenuItem onClick={() => setSelectedDataSource('curated')}>
                      <div className="flex items-center justify-between w-full">
                        <span>Curated Data</span>
                        <Badge className="bg-purple-100 text-purple-800 text-xs">{sourceCounts.curated}</Badge>
                      </div>
                    </DropdownMenuItem>
                  )}
                  {availableDataSources.includes('estimated') && (
                    <DropdownMenuItem onClick={() => setSelectedDataSource('estimated')}>
                      <div className="flex items-center justify-between w-full">
                        <span>Estimates</span>
                        <Badge className="bg-orange-100 text-orange-800 text-xs">{sourceCounts.estimated}</Badge>
                      </div>
                    </DropdownMenuItem>
                  )}
                </DropdownMenuContent>
              </DropdownMenu>
            )}
            
            <Button
              variant="outline"
              size="sm"
              onClick={onRefresh}
              disabled={isLoadingData || zipCodes.length === 0}
            >
              {isLoadingData ? (
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
              ) : (
                <RefreshCw className="w-4 h-4 mr-2" />
              )}
              Refresh Data
            </Button>
            
            <div className="flex items-center gap-2">
              <Palette className="w-4 h-4 text-gray-500"/>
              <label className="text-sm font-medium text-gray-700">Map Color:</label>
              <Select value={mapColorMetric} onValueChange={onMapColorMetricChange}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Select Metric" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="population">Population</SelectItem>
                  <SelectItem value="medianIncome">Median Income</SelectItem>
                  <SelectItem value="povertyRate">Poverty Rate</SelectItem>
                  <SelectItem value="uninsuredRate">Uninsured Rate</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
        
        {selectedDataSource !== 'auto' && (
          <div className="text-sm text-gray-600">
            Showing: {getDataSourceLabel(selectedDataSource)} 
            ({Object.keys(filteredCensusData).length} of {zipCodes.length} ZIP codes)
          </div>
        )}
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead onClick={() => requestSort('zip')} className="cursor-pointer select-none">
                    <div className="flex items-center">ZIP Code {getSortIcon('zip')}</div>
                </TableHead>
                <TableHead onClick={() => requestSort('population')} className="cursor-pointer select-none text-right">
                    <div className="flex items-center justify-end">Population {getSortIcon('population')}</div>
                </TableHead>
                <TableHead onClick={() => requestSort('medianIncome')} className="cursor-pointer select-none text-right">
                    <div className="flex items-center justify-end">Median Income {getSortIcon('medianIncome')}</div>
                </TableHead>
                <TableHead onClick={() => requestSort('povertyRate')} className="cursor-pointer select-none text-right">
                    <div className="flex items-center justify-end">Poverty Rate {getSortIcon('povertyRate')}</div>
                </TableHead>
                <TableHead onClick={() => requestSort('uninsuredRate')} className="cursor-pointer select-none text-right">
                    <div className="flex items-center justify-end">Uninsured Rate {getSortIcon('uninsuredRate')}</div>
                </TableHead>
                <TableHead className="text-center">Source</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedAndFilteredData.map((data) => (
                <TableRow key={data.zip} className={selectedDataSource !== 'auto' && !filteredCensusData[data.zip] ? 'opacity-50' : ''}>
                  <TableCell className="font-medium">{data.zip}</TableCell>
                  <TableCell className="text-right">{formatNumber(data.population)}</TableCell>
                  <TableCell className="text-right">{formatCurrency(data.medianIncome)}</TableCell>
                  <TableCell className="text-right">{formatPercentage(data.povertyRate)}</TableCell>
                  <TableCell className="text-right">{formatPercentage(data.uninsuredRate)}</TableCell>
                  <TableCell className="text-center">
                    {getSourceBadge(data.source)}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        {sortedAndFilteredData.length === 0 && !isLoadingData && (
            <div className="text-center py-8 text-gray-500">
                {filterText ? `No ZIP codes match "${filterText}"` : 'No ZIP codes selected or data available.'}
            </div>
        )}
        {isLoadingData && (
          <div className="text-center py-4 text-gray-500">
            <Loader2 className="w-6 h-6 animate-spin mx-auto mb-2" />
            Loading real-time demographic data...
          </div>
        )}
      </CardContent>
    </Card>
  );
}
