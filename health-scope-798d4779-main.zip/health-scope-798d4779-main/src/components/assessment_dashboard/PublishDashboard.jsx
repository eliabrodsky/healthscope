import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { 
  Globe, 
  Lock, 
  Copy, 
  ExternalLink, 
  Eye,
  Settings,
  Share2,
  Calendar,
  Users,
  Loader2
} from 'lucide-react';
import { toast } from 'sonner';
import { Assessment } from '@/entities/Assessment';
import { createPageUrl } from '@/utils';
import { base44 } from '@/api/base44Client';

export default function PublishDashboard({ assessment }) {
  const [isPublished, setIsPublished] = useState(false);
  const [isPublic, setIsPublic] = useState(true);
  const [publishSettings, setPublishSettings] = useState({
    title: '', // Initialized to empty string, will be updated in useEffect
    description: '', // Initialized to empty string, will be updated in useEffect
    show_competitors: true,
    show_demographics: true,
    show_market_analysis: true,
    allow_downloads: false,
    custom_branding: false,
    password_protected: false,
    password: ''
  });
  
  const [publicUrl, setPublicUrl] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  useEffect(() => {
    // Check if assessment is already published
    if (assessment?.published_settings) {
      setIsPublished(true);
      setIsPublic(assessment.published_settings.is_public || false);
      
      // Use functional update to avoid dependency issue and correctly merge
      setPublishSettings(prev => ({
        ...prev,
        title: assessment.title || '', // Take title from assessment if published
        description: assessment.description || '', // Take description from assessment if published
        ...assessment.published_settings
      }));
      
      // Generate public URL based on assessment ID
      const baseUrl = window.location.origin;
      // Fixed: Use createPageUrl for proper routing
      setPublicUrl(`${baseUrl}${createPageUrl(`PublicAssessmentView?id=${assessment.id}`)}`);
    } else if (assessment) {
      // Initialize with assessment data if not published (e.g., when first loading)
      setIsPublished(false);
      setIsPublic(true); // Default to public for new publish
      setPublishSettings(prev => ({
        ...prev,
        title: assessment.title || '',
        description: assessment.description || ''
      }));
      setPublicUrl('');
    }
  }, [assessment]); // Fixed dependency array

  const handlePublish = async () => {
    if (!assessment) return;

    setIsGenerating(true);
    toast.loading("Publishing dashboard...");

    try {
      // Get current user
      const currentUser = await base44.auth.me();
      
      // Update assessment with publish settings
      await base44.entities.Assessment.update(assessment.id, {
        status: 'published',
        published_settings: {
          ...publishSettings,
          is_public: isPublic,
          published_at: new Date().toISOString(),
          published_by: currentUser.email
        }
      });
      
      setIsPublished(true);
      const newPublicUrl = `${window.location.origin}${createPageUrl(`PublicAssessmentView?id=${assessment.id}`)}`;
      setPublicUrl(newPublicUrl);
      
      toast.success("Dashboard published! Redirecting to portfolio...", { duration: 2000 });
      
      // Redirect to public portfolio after publishing
      setTimeout(() => {
        window.location.href = createPageUrl('PublicPortfolio');
      }, 1500);
    } catch (error) {
      console.error("Error publishing dashboard:", error);
      toast.error("Failed to publish dashboard.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleUnpublish = async () => {
    if (!assessment) return;

    try {
      const updatedAssessment = {
        ...assessment,
        status: 'draft',
        published_settings: null
      };

      await base44.entities.Assessment.update(assessment.id, {
        status: 'draft',
        published_settings: null
      });
      
      setIsPublished(false);
      setPublicUrl('');
      toast.success("Dashboard unpublished.");
    } catch (error) {
      console.error("Error unpublishing dashboard:", error);
      toast.error("Failed to unpublish dashboard.");
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(publicUrl);
    toast.success("Public URL copied to clipboard!");
  };

  const handlePreview = () => {
    if (publicUrl) {
      window.open(publicUrl, '_blank');
    }
  };

  return (
    <div className="space-y-6">
      {/* Publish Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            {isPublished ? <Globe className="w-5 h-5 text-green-500" /> : <Lock className="w-5 h-5 text-gray-400" />}
            Dashboard Publishing
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {isPublished ? (
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Badge className="bg-green-100 text-green-800 border-green-200">
                  Published
                </Badge>
                <Badge variant="outline">
                  {isPublic ? (
                    <>
                      <Globe className="w-3 h-3 mr-1" />
                      Public
                    </>
                  ) : (
                    <>
                      <Lock className="w-3 h-3 mr-1" />
                      Private
                    </>
                  )}
                </Badge>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <Label className="text-sm font-medium">Public URL</Label>
                <div className="flex items-center gap-2 mt-2">
                  <Input 
                    value={publicUrl} 
                    readOnly 
                    className="bg-white"
                  />
                  <Button variant="outline" size="icon" onClick={copyToClipboard}>
                    <Copy className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" size="icon" onClick={handlePreview}>
                    <ExternalLink className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div className="flex gap-2">
                <Button variant="outline" onClick={handleUnpublish}>
                  Unpublish
                </Button>
                <Button variant="outline">
                  <Settings className="w-4 h-4 mr-2" />
                  Update Settings
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <p className="text-gray-600">
                Publish this dashboard to create a shareable link. Viewers won't need to log in.
              </p>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="public-toggle">Make Public</Label>
                  <p className="text-sm text-gray-500">
                    Allow anyone with the link to view this dashboard
                  </p>
                </div>
                <Switch
                  id="public-toggle"
                  checked={isPublic}
                  onCheckedChange={setIsPublic}
                />
              </div>

              <Button onClick={handlePublish} disabled={isGenerating} className="w-full">
                {isGenerating ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Publishing...
                  </>
                ) : (
                  <>
                    <Share2 className="w-4 h-4 mr-2" />
                    Publish Dashboard
                  </>
                )}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Publishing Settings */}
      <Card>
        <CardHeader>
          <CardTitle>Display Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="pub-title">Dashboard Title</Label>
            <Input
              id="pub-title"
              value={publishSettings.title}
              onChange={(e) => setPublishSettings({...publishSettings, title: e.target.value})}
              placeholder="Enter public title..."
            />
          </div>

          <div>
            <Label htmlFor="pub-description">Description</Label>
            <Textarea
              id="pub-description"
              value={publishSettings.description}
              onChange={(e) => setPublishSettings({...publishSettings, description: e.target.value})}
              placeholder="Describe what this dashboard shows..."
              rows={3}
            />
          </div>

          <div className="space-y-3">
            <Label>Visible Sections</Label>
            
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="show-competitors" className="text-sm font-normal">Competitor Organizations</Label>
                <Switch
                  id="show-competitors"
                  checked={publishSettings.show_competitors}
                  onCheckedChange={(checked) => setPublishSettings({...publishSettings, show_competitors: checked})}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="show-demographics" className="text-sm font-normal">Demographics Data</Label>
                <Switch
                  id="show-demographics"
                  checked={publishSettings.show_demographics}
                  onCheckedChange={(checked) => setPublishSettings({...publishSettings, show_demographics: checked})}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="show-market" className="text-sm font-normal">Market Analysis</Label>
                <Switch
                  id="show-market"
                  checked={publishSettings.show_market_analysis}
                  onCheckedChange={(checked) => setPublishSettings({...publishSettings, show_market_analysis: checked})}
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Usage Statistics (if published) */}
      {isPublished && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Eye className="w-5 h-5" />
              Usage Statistics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-blue-600">247</p>
                <p className="text-sm text-gray-500">Total Views</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-green-600">18</p>
                <p className="text-sm text-gray-500">This Week</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-purple-600">5.2m</p>
                <p className="text-sm text-gray-500">Avg. Time</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}