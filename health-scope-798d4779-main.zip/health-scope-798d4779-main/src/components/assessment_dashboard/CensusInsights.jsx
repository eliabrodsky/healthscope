import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  BookUser, 
  Edit, 
  Users, 
  DollarSign, 
  Percent, 
  TrendingUp, 
  TrendingDown,
  HeartPulse // New Icon for Unmet Needs
} from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';


const StatCard = ({ icon, label, value, change, trend }) => {
  const trendColor = trend === 'up' ? 'text-emerald-700' : 'text-red-700';
  const trendBg = trend === 'up' ? 'bg-emerald-50' : 'bg-red-50';

  return (
    <div className="p-4 bg-white rounded-lg border border-gray-200 flex flex-col justify-between">
      <div>
        <div className="flex items-center gap-2 mb-1">
          {icon}
          <span className="text-sm font-medium text-gray-700">{label}</span>
        </div>
        <div className="text-2xl font-bold text-gray-900">{value || 'N/A'}</div>
      </div>
      {change && (
        <div className={`flex items-center gap-1 text-xs mt-2 self-start ${trendColor}`}>
          {trend === 'up' ? (
            <TrendingUp className="w-3 h-3" />
          ) : (
            <TrendingDown className="w-3 h-3" />
          )}
          <span>{change} vs last period</span>
        </div>
      )}
    </div>
  );
};

export default function CensusInsights({ geography, selectedZipCodes, onEdit, data, isLoading }) {
  const insights = {
    population: data?.population,
    marketShare: data?.marketShare,
    unmetNeeds: data?.unmetNeeds,
    competitors: data?.competitors
  };

  if (isLoading) {
      return (
        <Card className="border-gray-200 shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-base font-semibold text-gray-800 flex items-center gap-2">
                    <BookUser className="w-4 h-4 stroke-1" />
                    Market Snapshot
                </CardTitle>
            </CardHeader>
            <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {[...Array(4)].map((_, i) => (
                        <div key={i} className="p-4 bg-white rounded-lg border border-gray-200">
                            <Skeleton className="h-4 w-2/3 mb-2" />
                            <Skeleton className="h-7 w-1/3 mb-3" />
                            <Skeleton className="h-3 w-1/2" />
                        </div>
                    ))}
                </div>
            </CardContent>
        </Card>
      );
  }

  return (
    <Card className="border-gray-200 shadow-sm">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-base font-semibold text-gray-800 flex items-center gap-2">
          <BookUser className="w-4 h-4 stroke-1" />
          Market Snapshot
        </CardTitle>
        <Button variant="ghost" size="sm" onClick={onEdit} className="h-7">
          <Edit className="w-3 h-3 mr-1" /> Edit
        </Button>
      </CardHeader>
      <CardContent>
        {insights ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <StatCard 
              icon={<Users className="w-5 h-5 text-emerald-600 stroke-1" />}
              label="Total Population"
              value={insights.population?.value}
              change={insights.population?.change}
              trend={insights.population?.trend}
            />
            <StatCard 
              icon={<Percent className="w-5 h-5 text-blue-600 stroke-1" />}
              label={insights.marketShare?.title || "Est. Market Share"}
              value={insights.marketShare?.value}
              change={insights.marketShare?.change}
              trend={insights.marketShare?.trend}
            />
            <StatCard 
              icon={<HeartPulse className="w-5 h-5 text-orange-600 stroke-1" />}
              label="Unmet Needs Index"
              value={insights.unmetNeeds?.value}
              change={insights.unmetNeeds?.change}
              trend={insights.unmetNeeds?.trend}
            />
            <StatCard 
              icon={<Users className="w-5 h-5 text-purple-600 stroke-1" />}
              label="Competitors"
              value={insights.competitors?.value}
              change={insights.competitors?.change}
              trend={insights.competitors?.trend}
            />
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500">
            <BookUser className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p className="text-sm">Market data not available</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}