
import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Filter, X, MapPin, Search, Target, Calculator, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { ZipCode } from '@/entities/ZipCode';

// Haversine formula to calculate distance between two points in miles
const calculateDistance = (lat1, lon1, lat2, lon2) => {
  const R = 3959; // Earth's radius in miles
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLon = (lon2 - lon1) * (Math.PI / 180);
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) * 
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
};

export default function GeographicFilters({ 
  selectedZipCodes, 
  availableZipCodes, 
  onZipCodesChange,
  geography,
  onGeographyChange
}) {
  const [filterMethod, setFilterMethod] = useState('radius');
  const [radius, setRadius] = useState(geography?.radius_miles || 50);
  const [radiusCenter, setRadiusCenter] = useState(geography?.city || '');
  const [availableCities, setAvailableCities] = useState([]);
  const [isCalculating, setIsCalculating] = useState(false);

  // Sync internal state with props from parent
  useEffect(() => {
    setRadius(geography?.radius_miles || 50);
    setRadiusCenter(geography?.city || '');
  }, [geography]);

  // Load cities for the selected state
  useEffect(() => {
    if (geography?.state) {
      ZipCode.filter({ state_name: geography.state }, 'city', -1, 0, ['city'])
        .then(zipCodes => {
          const cities = [...new Set(zipCodes.map(z => z.city))].sort();
          setAvailableCities(cities);
          if(cities.length > 0 && !geography.city) {
            // Automatically select the first city if none is set
            onGeographyChange({ ...geography, city: cities[0] });
          }
        }).catch(err => {
            console.error("Failed to load cities for dropdown", err);
            setAvailableCities([]); // Clear cities on error
        });
    } else {
        setAvailableCities([]);
    }
  }, [geography, onGeographyChange]);

  // Filter ZIP codes within radius using database queries and distance calculation
  const calculateRadiusZipCodes = useCallback(async () => {
    if (!radiusCenter || !radius || !geography?.state) {
      toast.error("Please select a center city and ensure a state is specified.");
      return;
    }

    setIsCalculating(true);
    try {
      // First, find the coordinates of the center city
      const centerCityRecords = await ZipCode.filter({ city: radiusCenter, state_name: geography.state }, null, 1);
      
      if (centerCityRecords.length === 0 || !centerCityRecords[0].coordinates?.latitude) {
        toast.error(`Could not find coordinates for ${radiusCenter}, ${geography.state}. Please try another city.`);
        setIsCalculating(false);
        return;
      }
      const { latitude: centerLat, longitude: centerLon } = centerCityRecords[0].coordinates;

      // Get all ZIP codes in the state to check distances
      const allStateZips = await ZipCode.filter({ state_name: geography.state });
      
      // Calculate distances and filter
      const zipCodesInRadius = allStateZips
        .filter(zip => zip.coordinates?.latitude && zip.coordinates?.longitude) // Ensure coordinates exist
        .filter(zip => {
            const distance = calculateDistance(centerLat, centerLon, zip.coordinates.latitude, zip.coordinates.longitude);
            return distance <= radius;
        })
        .map(zip => zip.zip_code);

      if (zipCodesInRadius.length > 0) {
        onZipCodesChange(zipCodesInRadius);
        toast.success(`Found ${zipCodesInRadius.length} ZIP codes within ${radius} miles of ${radiusCenter}`);
      } else {
        toast.warning(`No ZIP codes found within ${radius} miles of ${radiusCenter}`);
        onZipCodesChange([]); // Clear selected ZIP codes if none found
      }

    } catch (error) {
      console.error("Error calculating radius ZIP codes:", error);
      toast.error("Failed to calculate ZIP codes in radius.");
    } finally {
      setIsCalculating(false);
    }
  }, [radius, radiusCenter, onZipCodesChange, geography?.state]);

  const handleApplyRadiusFilter = () => {
    calculateRadiusZipCodes();
    // Also update the main assessment geography
    onGeographyChange({
      ...geography,
      city: radiusCenter,
      radius_miles: radius,
      radius_center: radiusCenter,
    });
  };

  const scopeDescription = () => {
    const parts = [];
    if (geography?.county) parts.push(`${geography.county} County`);
    if (geography?.state) parts.push(geography.state);
    return parts.join(', ');
  };
  
  const centeredOnDescription = () => {
    if (geography?.city) return `Centered on ${geography.city}`;
    if (geography?.radius_center) return `Centered on ${geography.radius_center}`;
    return null;
  }

  return (
    <Card className="border-gray-200 shadow-sm">
      <CardHeader>
        <CardTitle className="text-base font-semibold text-gray-800 flex items-center gap-2">
          <Filter className="w-4 h-4 stroke-1" />
          Geographic Filters
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Scope Display */}
        <div>
          <Label className="text-xs">Scope</Label>
          <div className="p-3 bg-gray-50 rounded-lg border">
            <p className="font-semibold text-gray-800 flex items-center gap-2">
              <MapPin className="w-4 h-4 text-emerald-600 stroke-1" />
              {scopeDescription() || "No scope defined"}
            </p>
            {centeredOnDescription() && <p className="text-xs text-gray-500 ml-6">{centeredOnDescription()}</p>}
          </div>
        </div>

        {/* Filter Method */}
        <div className="flex bg-gray-100 p-1 rounded-lg">
          <Button
            onClick={() => setFilterMethod('radius')}
            variant={filterMethod === 'radius' ? 'default' : 'ghost'}
            className="flex-1 h-8 text-xs"
          >
            <Target className="w-4 h-4 mr-2" /> Radius
          </Button>
          <Button
            onClick={() => setFilterMethod('search')}
            variant={filterMethod === 'search' ? 'default' : 'ghost'}
            className="flex-1 h-8 text-xs"
          >
            <Search className="w-4 h-4 mr-2" /> Search
          </Button>
        </div>

        {filterMethod === 'radius' && (
          <div className="space-y-3 p-4 border rounded-lg bg-white">
            <div>
              <Label htmlFor="center-city">Center City</Label>
              <Select value={radiusCenter} onValueChange={setRadiusCenter}>
                <SelectTrigger id="center-city">
                  <SelectValue placeholder="Select a city" />
                </SelectTrigger>
                <SelectContent>
                  {availableCities.length > 0 ? (
                    availableCities.map(city => (
                      <SelectItem key={city} value={city}>{city}</SelectItem>
                    ))
                  ) : (
                    <SelectItem value={null} disabled>No cities available for {geography?.state || 'the selected state'}</SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="radius">Radius (miles)</Label>
              <Input
                id="radius"
                type="number"
                value={radius}
                onChange={(e) => setRadius(Number(e.target.value))}
                min="1"
                max="500"
              />
            </div>
            <Button 
              onClick={handleApplyRadiusFilter}
              className="w-full"
              disabled={isCalculating || !radiusCenter}
            >
              {isCalculating ? (
                <>
                  <Calculator className="w-4 h-4 mr-2 animate-spin" />
                  Calculating...
                </>
              ) : (
                <>
                  <Target className="w-4 h-4 mr-2" />
                  Apply Radius Filter
                </>
              )}
            </Button>
          </div>
        )}

        {filterMethod === 'search' && (
          <div className="p-4 border rounded-lg bg-white">
            <p className="text-sm text-gray-600 mb-3">
              Search functionality is being improved. Please use the radius method for now.
            </p>
            <Button variant="outline" disabled className="w-full">
              <Search className="w-4 h-4 mr-2" />
              Search ZIP Codes (Coming Soon)
            </Button>
          </div>
        )}

        {/* ZIP Codes Summary */}
        <div className="pt-4 border-t">
          <div className="flex justify-between items-center mb-2">
            <Label className="text-sm font-medium">ZIP Codes ({selectedZipCodes?.length || 0})</Label>
            <div className="flex gap-2">
              <Button 
                size="sm" 
                variant="outline" 
                onClick={() => onZipCodesChange(availableZipCodes || [])}
                className="text-xs"
                disabled
              >
                All
              </Button>
              <Button 
                size="sm" 
                variant="outline" 
                onClick={() => onZipCodesChange([])}
                className="text-xs"
              >
                Clear
              </Button>
            </div>
          </div>
          
          {selectedZipCodes && selectedZipCodes.length > 0 ? (
            <div className="max-h-32 overflow-y-auto bg-gray-50 rounded-md p-2">
              <div className="flex flex-wrap gap-1">
                {selectedZipCodes.slice(0, 12).map(zip => (
                  <Badge key={zip} variant="secondary" className="text-xs">
                    {zip}
                    <button 
                      onClick={() => onZipCodesChange(selectedZipCodes.filter(z => z !== zip))}
                      className="ml-1 hover:text-red-600"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
                {selectedZipCodes.length > 12 && (
                  <Badge variant="outline" className="text-xs">
                    +{selectedZipCodes.length - 12} more
                  </Badge>
                )}
              </div>
            </div>
          ) : (
            <p className="text-sm text-gray-500 py-4 text-center bg-gray-50 rounded-md">
              No ZIP codes selected
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
