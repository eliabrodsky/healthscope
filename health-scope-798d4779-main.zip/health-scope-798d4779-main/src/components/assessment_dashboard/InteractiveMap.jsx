
import React, { useState, useEffect, useMemo } from 'react';
import { MapContainer, TileLayer, GeoJSON, Marker, Popup, useMap } from 'react-leaflet';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Map, Loader2, AlertTriangle, MapPin } from 'lucide-react';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix default Leaflet marker icon issue
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
});

const createCustomIcon = (color, size = 12) => {
  return L.divIcon({
    className: 'custom-marker',
    html: `<div style="background-color: ${color}; width: ${size}px; height: ${size}px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 6px rgba(0,0,0,0.4);"></div>`,
    iconSize: [size + 6, size + 6],
    iconAnchor: [(size + 6) / 2, (size + 6) / 2],
    popupAnchor: [0, -(size + 6) / 2]
  });
};

const organizationIcons = {
  hospital: createCustomIcon('#dc2626', 16),
  fqhc: createCustomIcon('#059669', 14),
  clinic: createCustomIcon('#2563eb', 12),
  safety_net: createCustomIcon('#d97706', 12),
  other: createCustomIcon('#6b7280', 10)
};

const stateCenters = {
    'Louisiana': [30.9843, -91.9623], 
    'Texas': [29.7604, -95.3698], // Changed to Houston coordinates instead of state center
    'Illinois': [40.6331, -89.3985], 
    'California': [36.7783, -119.4179],
    'Florida': [27.7663, -81.6868], 
    'New York': [43.2994, -74.2179],
    'Arkansas': [34.9697, -92.3731],
};

const cityCenters = {
    'Houston': [29.7604, -95.3698],
    'Dallas': [32.7767, -96.7970],
    'San Antonio': [29.4241, -98.4936],
    'Austin': [30.2672, -97.7431],
    'Chicago': [41.8781, -87.6298],
    'New York': [40.7128, -74.0060],
    'Los Angeles': [34.0522, -118.2437],
    'Dumas': [35.8656, -101.9738]
};

const MapUpdater = ({ center, zoom }) => {
    const map = useMap();
    useEffect(() => {
        if (center) {
            map.flyTo(center, zoom, {
                animate: true,
                duration: 1.5
            });
        }
    }, [center, zoom, map]);
    return null;
};

export default function InteractiveMap({
  organizations,
  zipBoundaries = [],
  selectedZips = [],
  overlay,
  colorScale,
  opacity,
  center,
}) {
  const [mapCenter, setMapCenter] = useState([39.8283, -98.5795]);
  const [mapZoom, setMapZoom] = useState(4);

  useEffect(() => {
    // First try to use city coordinates if available
    if (center?.city && cityCenters[center.city]) {
        setMapCenter(cityCenters[center.city]);
        setMapZoom(9);
    } 
    // Fall back to state coordinates
    else if (center?.state && stateCenters[center.state]) {
        setMapCenter(stateCenters[center.state]);
        setMapZoom(7);
    }
  }, [center]);

  const hasZipCodes = selectedZips.length > 0;
  const hasBoundaries = zipBoundaries.length > 0;

  const geoJsonLayer = useMemo(() => {
    if (!hasBoundaries) {
      return null;
    }
    
    const features = zipBoundaries.map(zb => {
      return {
        type: "Feature", 
        geometry: zb.geometry, 
        properties: { zip: zb.zip_code }
      };
    });
    
    return <GeoJSON 
        key={`geojson-layer-${zipBoundaries.length}`}
        data={{ type: "FeatureCollection", features }}
        style={() => ({
            color: '#1e40af', // Blue border
            weight: 2, // Increased weight for visibility
            fillColor: '#60a5fa', // Light blue fill
            fillOpacity: 0.3 // Increased opacity
        })}
        onEachFeature={(feature, layer) => {
            layer.bindPopup(`ZIP Code: ${feature.properties.zip}`);
            layer.on({
                mouseover: (e) => {
                    e.target.setStyle({ weight: 4, color: '#3b82f6', fillOpacity: 0.5 });
                },
                mouseout: (e) => {
                    e.target.setStyle({ weight: 2, color: '#1e40af', fillOpacity: 0.3 });
                }
            });
        }}
    />;
  }, [zipBoundaries, hasBoundaries]);

  return (
    <Card className="border-gray-200 shadow-sm relative overflow-hidden">
      <CardHeader className="flex flex-row items-center justify-between pb-4">
        <CardTitle className="text-gray-900 flex items-center gap-2">
          <Map className="w-5 h-5 stroke-1" />
          Geographic Overview
          {hasZipCodes && (
            <Badge variant="secondary" className="ml-2">
              {selectedZips.length} ZIP codes
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0 relative">
        {!hasZipCodes ? (
          <div className="h-[400px] flex items-center justify-center bg-red-50 border-t border-red-200">
            <div className="text-center p-6">
              <AlertTriangle className="w-12 h-12 text-red-600 mx-auto mb-4" />
              <h3 className="text-red-800 font-semibold">No ZIP Codes Available</h3>
              <p className="text-red-700">No ZIP codes are selected for this assessment.</p>
            </div>
          </div>
        ) : (
          <div className="h-[400px] relative">
            <MapContainer
              key={`${mapCenter[0]}-${mapCenter[1]}-${zipBoundaries.length}`}
              center={mapCenter}
              zoom={mapZoom}
              style={{ height: '100%', width: '100%' }}
              className="z-0"
              scrollWheelZoom={true}
            >
              <MapUpdater center={mapCenter} zoom={mapZoom} />
              <TileLayer
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              />
              
              {geoJsonLayer}
              
              {organizations.map((org) => (
                org.coordinates?.latitude && org.coordinates?.longitude &&
                <Marker
                  key={org.id}
                  position={[org.coordinates.latitude, org.coordinates.longitude]}
                  icon={organizationIcons[org.type] || organizationIcons.other}
                >
                  <Popup>
                    <div className="p-1">
                      <h3 className="font-semibold">{org.name}</h3>
                      <p className="text-sm text-gray-600 capitalize">{org.type}</p>
                    </div>
                  </Popup>
                </Marker>
              ))}
            </MapContainer>
            
            {!hasBoundaries && (
              <div className="absolute top-2 left-2 z-[1000] bg-yellow-50 border border-yellow-200 p-3 rounded-lg shadow-md text-sm">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-amber-600" />
                  <span className="text-amber-800">Showing facility locations. Click "Reprocess" to load ZIP boundaries.</span>
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
