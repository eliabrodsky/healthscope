import React from 'react';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, Users, DollarSign, Percent } from 'lucide-react';

const getColor = (value, min, max, colorScale) => {
  if (value === undefined || value === null) return '#f0f0f0';

  const normalized = Math.min(Math.max((value - min) / (max - min), 0), 1);
  const intensity = Math.floor(normalized * 255);

  if (colorScale === 'Reds') return `rgb(255, ${255 - intensity}, ${255 - intensity})`;
  if (colorScale === 'Greens') return `rgb(${255 - intensity}, 255, ${255 - intensity})`;
  return `rgb(${255 - intensity}, ${255 - intensity}, 255)`; // Blues
};

export default function MapLegend({ overlay, colorScale, min, max, selectedZipCodes }) {
  const steps = 5;
  const legendItems = [];

  const formatValue = (value) => {
    if (value >= 1000000) return `${(value / 1000000).toFixed(1)}M`;
    if (value >= 1000) return `${(value / 1000).toFixed(0)}K`;
    if (overlay === 'poverty' || overlay === 'uninsured') return `${value.toFixed(1)}%`;
    return value.toLocaleString();
  };

  for (let i = 0; i < steps; i++) {
    const value = min + ((max - min) * i) / (steps - 1);
    legendItems.push({
      color: getColor(value, min, max, colorScale),
      label: formatValue(value),
    });
  }

  const overlayTitle = {
    population: "Population",
    income: "Median Income",
    poverty: "Poverty Rate",
    uninsured: "Uninsured Rate"
  }[overlay] || "Data";

  return (
    <div className="absolute bottom-4 right-4 bg-white/80 backdrop-blur-sm p-3 rounded-lg shadow-lg border border-gray-200 z-[1000] w-48">
      <div className="font-semibold text-sm mb-2">{overlayTitle}</div>
      <div className="space-y-1">
        {legendItems.map((item, index) => (
          <div key={index} className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-sm" style={{ backgroundColor: item.color }} />
            <span className="text-xs text-gray-700">{item.label}</span>
          </div>
        ))}
      </div>
      <div className="mt-3 pt-2 border-t border-gray-200">
        <div className="font-semibold text-sm mb-2">Facilities</div>
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-red-600 border-2 border-white shadow-md"></div>
            <span className="text-xs text-gray-700">Hospital</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-600 border-2 border-white shadow-md"></div>
            <span className="text-xs text-gray-700">FQHC</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-blue-600 border-2 border-white shadow-md"></div>
            <span className="text-xs text-gray-700">Clinic</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-amber-500 border-2 border-white shadow-md"></div>
            <span className="text-xs text-gray-700">Safety Net</span>
          </div>
        </div>
      </div>
    </div>
  );
}