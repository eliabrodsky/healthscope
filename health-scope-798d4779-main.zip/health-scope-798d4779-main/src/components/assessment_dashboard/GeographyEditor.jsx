
import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MapPin, X, Plus, Loader2, Search, Save, XCircle, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { base44 } from '@/api/base44Client';

export default function GeographyEditor({ open, onClose, assessment, onSave }) {
  const [editableGeo, setEditableGeo] = useState({
    city: '',
    state: '',
    county: '',
    radius_miles: '',
    zip_codes: [],
    latitude: null,
    longitude: null,
    ...assessment?.geography
  });
  const [manualZip, setManualZip] = useState('');
  const [isFindingZips, setIsFindingZips] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [selectedZips, setSelectedZips] = useState(new Set());

  // Reset when opening
  useEffect(() => {
    if (open && assessment?.geography) {
      setEditableGeo({
        city: '',
        state: '',
        county: '',
        radius_miles: '',
        zip_codes: [],
        latitude: null,
        longitude: null,
        ...assessment.geography
      });
      setSelectedZips(new Set());
    }
  }, [open, assessment]);

  const handleFindZips = async () => {
    if (!editableGeo.city || !editableGeo.state || !editableGeo.radius_miles) {
      toast.error("Please provide city, state, and radius to find ZIP codes.");
      return;
    }

    setIsFindingZips(true);
    const searchToastId = 'finding-zips';
    toast.loading(`Searching for ZIP codes within ${editableGeo.radius_miles} miles...`, {
      id: searchToastId,
      duration: 30000
    });

    try {
      const response = await base44.functions.invoke('findZipCodesInRadius', {
        city: editableGeo.city,
        state: editableGeo.state,
        radiusMiles: parseFloat(editableGeo.radius_miles)
      });

      if (response?.data?.success && response.data?.zipCodes) {
        const newZips = response.data.zipCodes;
        const currentZips = editableGeo.zip_codes || [];
        const combinedZips = [...new Set([...currentZips, ...newZips])].sort();

        setEditableGeo({ ...editableGeo, zip_codes: combinedZips });
        toast.success(
          `Found ${newZips.length} ZIP codes! Added ${combinedZips.length - currentZips.length} new ones.`,
          { id: searchToastId, duration: 5000 }
        );
      } else {
        throw new Error(response?.data?.error || 'No ZIP codes found');
      }
    } catch (error) {
      console.error('Error finding ZIP codes:', error);
      toast.error(
        `Failed to find ZIP codes: ${error.message}`,
        { id: searchToastId, duration: 8000 }
      );
    } finally {
      setIsFindingZips(false);
    }
  };

  const addManualZip = () => {
    const zip = manualZip.trim();
    if (!/^\d{5}$/.test(zip)) {
      toast.error("Please enter a valid 5-digit ZIP code");
      return;
    }
    if (editableGeo.zip_codes.includes(zip)) {
      toast.info(`ZIP ${zip} already in list`);
      setManualZip('');
      return;
    }
    setEditableGeo({
      ...editableGeo,
      zip_codes: [...editableGeo.zip_codes, zip].sort()
    });
    setManualZip('');
    toast.success(`Added ZIP ${zip}`);
  };

  const removeZip = (zipToRemove) => {
    setEditableGeo({
      ...editableGeo,
      zip_codes: editableGeo.zip_codes.filter(z => z !== zipToRemove)
    });
    toast.success(`Removed ZIP ${zipToRemove}`);
  };

  const toggleZipSelection = (zip) => {
    const newSelected = new Set(selectedZips);
    if (newSelected.has(zip)) {
      newSelected.delete(zip);
    } else {
      newSelected.add(zip);
    }
    setSelectedZips(newSelected);
  };

  const removeSelectedZips = () => {
    if (selectedZips.size === 0) {
      toast.info("No ZIP codes selected");
      return;
    }
    setEditableGeo({
      ...editableGeo,
      zip_codes: editableGeo.zip_codes.filter(z => !selectedZips.has(z))
    });
    toast.success(`Removed ${selectedZips.size} ZIP codes`);
    setSelectedZips(new Set());
  };

  const selectAll = () => {
    setSelectedZips(new Set(editableGeo.zip_codes));
  };

  const deselectAll = () => {
    setSelectedZips(new Set());
  };

  const handleSave = async () => {
    if (editableGeo.zip_codes.length === 0) {
      toast.error("Please add at least one ZIP code");
      return;
    }

    setIsSaving(true);
    try {
      await onSave(editableGeo);
      toast.success("Geography updated successfully!");
      onClose();
    } catch (error) {
      console.error('Error saving geography:', error);
      toast.error("Failed to save geography");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl h-[90vh] flex flex-col z-[9999] bg-white">
        <DialogHeader>
          <DialogTitle className="text-xl flex items-center gap-2">
            <MapPin className="w-5 h-5 text-emerald-600" />
            Edit Geographic Coverage
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto space-y-6 py-4">
          {/* Location Information */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Location Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="city">City</Label>
                  <Input
                    id="city"
                    value={editableGeo.city || ''}
                    onChange={(e) => setEditableGeo({ ...editableGeo, city: e.target.value })}
                    placeholder="e.g., New Orleans"
                  />
                </div>
                <div>
                  <Label htmlFor="state">State</Label>
                  <Input
                    id="state"
                    value={editableGeo.state || ''}
                    onChange={(e) => setEditableGeo({ ...editableGeo, state: e.target.value })}
                    placeholder="e.g., Louisiana"
                  />
                </div>
                <div>
                  <Label htmlFor="county">County (Optional)</Label>
                  <Input
                    id="county"
                    value={editableGeo.county || ''}
                    onChange={(e) => setEditableGeo({ ...editableGeo, county: e.target.value })}
                    placeholder="e.g., Orleans"
                  />
                </div>
                <div>
                  <Label htmlFor="radius">Service Radius (miles)</Label>
                  <Input
                    id="radius"
                    type="number"
                    value={editableGeo.radius_miles || ''}
                    onChange={(e) => setEditableGeo({ ...editableGeo, radius_miles: e.target.value })}
                    placeholder="e.g., 50"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Find ZIPs */}
          <Card className="bg-blue-50 border-blue-200">
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Search className="w-4 h-4 text-blue-600" />
                Find ZIP Codes in Radius
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm text-blue-700">
                Use OpenStreetMap to automatically find all ZIP codes within your service radius
              </p>
              <Button
                onClick={handleFindZips}
                disabled={isFindingZips || !editableGeo.city || !editableGeo.state || !editableGeo.radius_miles}
                className="w-full"
              >
                {isFindingZips ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Searching...
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4 mr-2" />
                    Find ZIP Codes
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Add Manual ZIP */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Add ZIP Code Manually</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-2">
                <Input
                  value={manualZip}
                  onChange={(e) => setManualZip(e.target.value)}
                  placeholder="Enter 5-digit ZIP code"
                  maxLength={5}
                  onKeyPress={(e) => e.key === 'Enter' && addManualZip()}
                />
                <Button
                  onClick={addManualZip}
                  disabled={!/^\d{5}$/.test(manualZip)}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* ZIP Codes List */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">
                  Selected ZIP Codes ({editableGeo.zip_codes.length})
                </CardTitle>
                <div className="flex gap-2">
                  {selectedZips.size > 0 && (
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={removeSelectedZips}
                    >
                      <Trash2 className="w-3 h-3 mr-1" />
                      Remove {selectedZips.size} Selected
                    </Button>
                  )}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={selectedZips.size === editableGeo.zip_codes.length ? deselectAll : selectAll}
                  >
                    {selectedZips.size === editableGeo.zip_codes.length ? 'Deselect All' : 'Select All'}
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {editableGeo.zip_codes.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <MapPin className="w-12 h-12 mx-auto mb-2 text-gray-300" />
                  <p>No ZIP codes added yet</p>
                  <p className="text-sm">Use the search feature or add manually</p>
                </div>
              ) : (
                <div className="max-h-96 overflow-y-auto border rounded-lg p-3 bg-gray-50">
                  <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-2">
                    {editableGeo.zip_codes.map(zip => (
                      <div
                        key={zip}
                        className={`relative group ${
                          selectedZips.has(zip) ? 'ring-2 ring-blue-500' : ''
                        }`}
                      >
                        <Badge
                          variant="secondary"
                          className={`w-full justify-between cursor-pointer transition-all ${
                            selectedZips.has(zip) ? 'bg-blue-100 text-blue-900' : ''
                          }`}
                          onClick={() => toggleZipSelection(zip)}
                        >
                          {zip}
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              removeZip(zip);
                            }}
                            className="ml-1 rounded-full hover:bg-red-200 p-0.5"
                            title={`Remove ZIP ${zip}`}
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </Badge>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <DialogFooter className="border-t pt-4">
          <Button variant="outline" onClick={onClose} disabled={isSaving}>
            <XCircle className="w-4 h-4 mr-2" />
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={isSaving || editableGeo.zip_codes.length === 0}>
            {isSaving ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Save className="w-4 h-4 mr-2" />
                Save Geography
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
