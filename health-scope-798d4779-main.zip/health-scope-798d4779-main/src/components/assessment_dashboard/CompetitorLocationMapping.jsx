
import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin, TrendingUp, Users, Building } from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

// Helper function to format organization type display
const formatOrgType = (type) => {
  const typeMap = {
    'fqhc': 'FQHC',
    'hospital': 'Hospital',
    'clinic': 'Clinic',
    'urgent_care': 'Urgent Care',
    'safety_net': 'Safety Net',
    'other': 'Other'
  };
  return typeMap[type] || type?.replace(/_/g, ' ') || 'N/A';
};

export default function CompetitorLocationMapping({ organizations, zipCodes, assessment }) {
  // Calculate market dominance by ZIP code
  const zipMarketData = useMemo(() => {
    const marketMap = {};
    
    // Initialize all ZIP codes
    zipCodes.forEach(zip => {
      marketMap[zip] = {
        zip,
        competitors: [],
        totalSites: 0,
        dominantCompetitor: null,
        competitionLevel: 'Low' // Default to Low
      };
    });

    // Map competitors to ZIP codes
    (organizations || []).forEach(org => { // Added || [] to handle potential undefined organizations
      // Check main organization location
      if (org.zip_code && marketMap[org.zip_code]) {
        marketMap[org.zip_code].competitors.push({
          name: org.name,
          type: org.type,
          sites: 1,
          isMainLocation: true
        });
        marketMap[org.zip_code].totalSites += 1;
      }

      // Check all site locations
      if (org.sites && Array.isArray(org.sites)) {
        org.sites.forEach(site => {
          const siteZip = site.zip_code;
          if (siteZip && marketMap[siteZip]) {
            const existing = marketMap[siteZip].competitors.find(c => c.name === org.name);
            if (existing) {
              existing.sites += 1;
            } else {
              marketMap[siteZip].competitors.push({
                name: org.name,
                type: org.type,
                sites: 1,
                isMainLocation: false
              });
            }
            marketMap[siteZip].totalSites += 1;
          }
        });
      }
    });

    // Calculate dominance and competition levels
    Object.values(marketMap).forEach(zipData => {
      if (zipData.competitors.length > 0) {
        // Find dominant competitor (most sites in this ZIP)
        zipData.dominantCompetitor = zipData.competitors.reduce((prev, current) => 
          (prev.sites > current.sites) ? prev : current
        );

        // Determine competition level
        if (zipData.totalSites >= 5) zipData.competitionLevel = 'High';
        else if (zipData.totalSites >= 3) zipData.competitionLevel = 'Medium';
        // 'Low' is already the default, so no need for an explicit else if (>=1)
      }
    });

    return Object.values(marketMap).filter(zip => zip.competitors.length > 0);
  }, [organizations, zipCodes]);

  // Calculate overall market statistics
  const marketStats = useMemo(() => {
    const stats = {
      totalCompetitorSitesInArea: 0, // Renamed for clarity
      averageSitesPerZip: 0,
      mostContestedZip: null,
      marketLeader: null
    };

    stats.totalCompetitorSitesInArea = zipMarketData.reduce((sum, zip) => sum + zip.totalSites, 0);
    stats.averageSitesPerZip = zipMarketData.length > 0 ? (stats.totalCompetitorSitesInArea / zipMarketData.length).toFixed(1) : 0;
    
    // Find most contested ZIP
    stats.mostContestedZip = zipMarketData.reduce((prev, current) => 
      (!prev || current.totalSites > prev.totalSites) ? current : prev
    , null);

    // Calculate market leader across ALL added organizations
    const orgSiteCounts = {};
    if (organizations && organizations.length > 0) { // Check if organizations exist and are not empty
        organizations.forEach(org => {
            // Count main location + all linked sites. If no sites array or empty, count as 1 (main location).
            const siteCount = (org.sites && org.sites.length > 0) ? org.sites.length : 1;
            orgSiteCounts[org.name] = (orgSiteCounts[org.name] || 0) + siteCount;
        });
    }
    
    if (Object.keys(orgSiteCounts).length > 0) { // Check if there are any organizations with sites
        const leaderName = Object.keys(orgSiteCounts).reduce((a, b) => orgSiteCounts[a] > orgSiteCounts[b] ? a : b);
        if (leaderName) { // Ensure a leader name was found
            stats.marketLeader = {
                name: leaderName,
                sites: orgSiteCounts[leaderName]
            };
        }
    }

    return stats;
  }, [zipMarketData, organizations]);

  const getCompetitionBadge = (level) => {
    const styles = {
      High: 'bg-red-100 text-red-800 border-red-200',
      Medium: 'bg-yellow-100 text-yellow-800 border-yellow-200', 
      Low: 'bg-green-100 text-green-800 border-green-200'
    };
    return <Badge className={styles[level]}>{level} Competition</Badge>;
  };

  return (
    <div className="space-y-6">
      {/* Market Overview Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Sites in Area</p>
                <p className="text-2xl font-bold">{marketStats.totalCompetitorSitesInArea}</p>
              </div>
              <Building className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Avg Sites per ZIP</p>
                <p className="text-2xl font-bold">{marketStats.averageSitesPerZip}</p>
              </div>
              <MapPin className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Market Leader</p>
                <p className="text-lg font-bold truncate" title={marketStats.marketLeader?.name || 'N/A'}>
                  {marketStats.marketLeader?.name || 'N/A'}
                </p>
                <p className="text-sm text-gray-500">{marketStats.marketLeader ? `${marketStats.marketLeader.sites} sites` : ''}</p>
              </div>
              <TrendingUp className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Most Contested</p>
                <p className="text-2xl font-bold">{marketStats.mostContestedZip?.zip || 'N/A'}</p>
                <p className="text-sm text-gray-500">{marketStats.mostContestedZip ? `${marketStats.mostContestedZip.totalSites} sites` : ''}</p>
              </div>
              <Users className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ZIP Code Market Analysis Table */}
      <Card>
        <CardHeader>
          <CardTitle>Market Dominance by ZIP Code</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ZIP Code</TableHead>
                <TableHead>Competition Level</TableHead>
                <TableHead>Total Sites</TableHead>
                <TableHead>Dominant Competitor</TableHead>
                <TableHead>Market Share</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {zipMarketData.length > 0 ? (
                zipMarketData
                  .sort((a, b) => b.totalSites - a.totalSites)
                  .map((zipData) => (
                  <TableRow key={zipData.zip}>
                    <TableCell className="font-medium">{zipData.zip}</TableCell>
                    <TableCell>{getCompetitionBadge(zipData.competitionLevel)}</TableCell>
                    <TableCell>{zipData.totalSites}</TableCell>
                    <TableCell>
                      <div>
                        <p className="font-medium">{zipData.dominantCompetitor?.name || 'N/A'}</p>
                        <p className="text-sm text-gray-500">
                          {formatOrgType(zipData.dominantCompetitor?.type)} • {zipData.dominantCompetitor?.sites || 0} sites
                        </p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className="w-16 bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-blue-500 h-2 rounded-full" 
                            style={{
                              width: `${(zipData.dominantCompetitor && zipData.totalSites > 0) ? (zipData.dominantCompetitor.sites / zipData.totalSites) * 100 : 0}%`
                            }}
                          />
                        </div>
                        <span className="text-sm text-gray-600">
                          {Math.round((zipData.dominantCompetitor && zipData.totalSites > 0) ? (zipData.dominantCompetitor.sites / zipData.totalSites) * 100 : 0)}%
                        </span>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={5} className="h-24 text-center text-gray-500">
                    No competitor sites found within the selected service area ZIP codes.
                    <br />
                    <span className="text-sm">Try adding competitors located in the service area or expanding the geography.</span>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
