
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Users, Edit } from 'lucide-react';

export default function DemographicsChart({ data, onEdit }) {
  if (!data) return null;

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-gray-200 rounded-lg shadow-sm">
          <p className="font-medium text-gray-900">Age {label}</p>
          <p className="text-emerald-600 font-semibold">{payload[0].value}%</p>
        </div>
      );
    }
    return null;
  };

  return (
    <Card className="border-gray-200 shadow-sm">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-base font-semibold text-gray-800 flex items-center gap-2">
          <Users className="w-4 h-4 stroke-1" />
          Population by Age
        </CardTitle>
        <Button variant="ghost" size="sm" onClick={onEdit} className="h-7">
          <Edit className="w-3 h-3 mr-1" /> Edit
        </Button>
      </CardHeader>
      <CardContent>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis 
                dataKey="ageGroup" 
                stroke="#6b7280"
                fontSize={12}
              />
              <YAxis 
                stroke="#6b7280"
                fontSize={12}
                domain={[0, 35]}
              />
              <Tooltip content={<CustomTooltip />} />
              <Bar 
                dataKey="population" 
                fill="#10b981"
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
        
        <div className="mt-4 grid grid-cols-5 gap-2 text-xs">
          {data.map((item, index) => (
            <div key={index} className="text-center">
              <div className="font-semibold text-gray-900">{item.population}%</div>
              <div className="text-gray-600">{item.ageGroup}</div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
