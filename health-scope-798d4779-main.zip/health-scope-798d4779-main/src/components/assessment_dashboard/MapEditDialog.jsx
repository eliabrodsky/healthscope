import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export default function MapEditDialog({ open, onOpenChange, onSave, currentSettings }) {
  const [overlay, setOverlay] = useState(currentSettings.overlay);
  const [colorScale, setColorScale] = useState(currentSettings.colorScale);
  const [opacity, setOpacity] = useState([currentSettings.opacity * 100]);
  const [tileLayer, setTileLayer] = useState(currentSettings.tileLayer || 'street');

  useEffect(() => {
    setOverlay(currentSettings.overlay);
    setColorScale(currentSettings.colorScale);
    setOpacity([currentSettings.opacity * 100]);
    setTileLayer(currentSettings.tileLayer || 'street');
  }, [currentSettings, open]);

  const handleSave = () => {
    onSave({
      overlay,
      colorScale,
      opacity: opacity[0] / 100,
      tileLayer,
    });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="z-[9999] max-w-md" style={{ zIndex: 9999 }}>
        <DialogHeader>
          <DialogTitle>Edit Map Configuration</DialogTitle>
        </DialogHeader>
        <div className="space-y-6 py-4">
          <div className="space-y-2">
            <Label>Map Style</Label>
            <Select value={tileLayer} onValueChange={setTileLayer}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="z-[10000]">
                <SelectItem value="street">Street Map</SelectItem>
                <SelectItem value="satellite">Satellite</SelectItem>
                <SelectItem value="terrain">Terrain</SelectItem>
                <SelectItem value="minimal">Minimal</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Data Overlay</Label>
            <Select value={overlay} onValueChange={setOverlay}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="z-[10000]">
                <SelectItem value="population">Population</SelectItem>
                <SelectItem value="income">Median Income</SelectItem>
                <SelectItem value="poverty">Poverty Rate</SelectItem>
                <SelectItem value="uninsured">Uninsured Rate</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Color Scale</Label>
            <Select value={colorScale} onValueChange={setColorScale}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="z-[10000]">
                <SelectItem value="Blues">Blues</SelectItem>
                <SelectItem value="Reds">Reds</SelectItem>
                <SelectItem value="Greens">Greens</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="opacity">Overlay Transparency: {opacity[0]}%</Label>
            <Slider
              id="opacity"
              min={10}
              max={100}
              step={5}
              value={opacity}
              onValueChange={setOpacity}
            />
            <div className="text-xs text-gray-500 mt-1">
              Lower values make the colored areas more transparent
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave}>Save Changes</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}