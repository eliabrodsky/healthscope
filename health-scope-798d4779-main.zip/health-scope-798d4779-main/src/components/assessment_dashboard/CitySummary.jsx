import React, { useMemo, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { MapPin, Building2, RefreshCw, MoreVertical } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { base44 } from '@/api/base44Client';
import CityProfileDialog from './CityProfileDialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from 'sonner';

export default function CitySummary({ assessment, censusData, zipCodes, onRefreshDemographics }) {
  const [selectedCity, setSelectedCity] = useState(null);
  const [showCityProfile, setShowCityProfile] = useState(false);
  const [cityNames, setCityNames] = useState({});
  const [isRefreshingCities, setIsRefreshingCities] = useState(false);
  const [isRefreshingData, setIsRefreshingData] = useState(false);

  // Fetch Census-verified place names for ZCTAs
  React.useEffect(() => {
    if (!zipCodes || zipCodes.length === 0) return;
    
    const fetchPlaceNames = async () => {
      try {
        const stateAbbr = assessment?.geography?.state;
        
        // Use Census ZCTA-Place relationship data, filter by ZCTAs only
        // (We don't filter by state_abbr because the service area might cross state lines)
        const placeData = await base44.entities.ZctaPlaceRelationship.filter({
          zcta5: { '$in': zipCodes }
        });
        
        const names = {};
        placeData.forEach(place => {
          // Skip if place_name is missing or looks like a parish/county
          if (!place.place_name) return;
          
          // Filter out county/parish names (they don't end with city, town, village, or CDP)
          const isActualPlace = /(city|town|village|CDP)/i.test(place.place_name);
          if (!isActualPlace) return;
          
          // If this ZCTA already has a place assigned, keep the one with higher population or primary flag
          const existing = names[place.zcta5];
          if (existing && existing.population > (place.place_population || 0) && !place.is_primary) {
            return;
          }
          
          // Store the actual place name (removing suffixes like 'city', 'town')
          const cleanName = place.place_name.replace(/ (city|town|village|CDP)$/i, '').trim();
          names[place.zcta5] = {
            name: cleanName,
            fullName: place.place_name,
            population: place.place_population || 0,
            placeType: place.place_type || 'other',
            isPrimary: place.is_primary || false
          };
        });
        
        setCityNames(names);
      } catch (error) {
        console.warn('Could not fetch place names from Census data:', error);
        // Fallback to ZipCode entity if Census data not available
        try {
          const zipData = await base44.entities.ZipCode.filter({
            zip_code: { '$in': zipCodes }
          });
          
          const names = {};
          zipData.forEach(zip => {
            names[zip.zip_code] = {
              name: zip.city,
              fullName: zip.city,
              population: 0,
              placeType: 'unknown'
            };
          });
          setCityNames(names);
        } catch (fallbackError) {
          console.warn('Fallback city fetch also failed:', fallbackError);
        }
      }
    };
    
    fetchPlaceNames();
  }, [zipCodes]);

  const citySummary = useMemo(() => {
    if (!assessment?.geography || !censusData || !zipCodes || zipCodes.length === 0) {
      return null;
    }

    // Calculate aggregate statistics for the service area
    let totalAreaPopulation = 0;
    let totalIncome = 0;
    let totalPoverty = 0;
    let totalUninsured = 0;
    let dataCount = 0;

    zipCodes.forEach(zip => {
      const data = censusData[zip];
      if (data && typeof data.population === 'number') {
        totalAreaPopulation += data.population || 0;
        if (typeof data.medianIncome === 'number' && data.medianIncome > 0) {
          totalIncome += data.medianIncome;
          dataCount++;
        }
        if (typeof data.povertyRate === 'number') {
          totalPoverty += data.povertyRate;
        }
        if (typeof data.uninsuredRate === 'number') {
          totalUninsured += data.uninsuredRate;
        }
      }
    });

    const avgIncome = dataCount > 0 ? Math.abs(Math.round(totalIncome / dataCount)) : 0;
    const avgPoverty = zipCodes.length > 0 ? (totalPoverty / zipCodes.length).toFixed(1) : 0;
    const avgUninsured = zipCodes.length > 0 ? (totalUninsured / zipCodes.length).toFixed(1) : 0;

    // 1. PREFER SAVED CITIES from assessment.processed_data
    if (assessment?.processed_data?.major_cities && assessment.processed_data.major_cities.length > 0) {
      return {
        totalAreaPopulation,
        avgIncome,
        avgPoverty,
        avgUninsured,
        zipCount: zipCodes.length,
        majorCities: assessment.processed_data.major_cities.slice(0, 5)
      };
    }

    // 2. Fallback: Group by actual Census place name
    const cityGroupMap = new Map();
    
    zipCodes.forEach(zip => {
      const placeInfo = cityNames[zip];
      
      if (placeInfo && placeInfo.name) {
        const cityName = placeInfo.name;
        const population = placeInfo.population > 0 ? placeInfo.population : (censusData[zip]?.population || 0);
        
        if (cityGroupMap.has(cityName)) {
          const existing = cityGroupMap.get(cityName);
          existing.zips.push(zip);
          if (population > existing.population) {
            existing.population = population;
          }
        } else {
          cityGroupMap.set(cityName, {
            name: cityName,
            population: population,
            zip: zip,
            zips: [zip],
            placeType: placeInfo.placeType
          });
        }
      }
    });
    
    const majorCities = Array.from(cityGroupMap.values())
      .filter(city => city.population > 1000)
      .sort((a, b) => b.population - a.population)
      .slice(0, 10);

    return {
      totalAreaPopulation,
      avgIncome,
      avgPoverty,
      avgUninsured,
      zipCount: zipCodes.length,
      majorCities
    };
  }, [assessment, censusData, zipCodes, cityNames]);

  if (!citySummary || !assessment?.geography) {
    return null;
  }

  const { city, state, radius_miles } = assessment.geography;

  const handleCityClick = (cityInfo) => {
    setSelectedCity(cityInfo);
    setShowCityProfile(true);
  };

  const handleRefreshCities = async () => {
    if (!zipCodes || zipCodes.length === 0) return;
    
    setIsRefreshingCities(true);
    toast.loading('Reloading city data...', { id: 'refresh-cities' });
    
    try {
      // 1. Identify relevant states to ensure data is loaded
      const states = new Set();
      // Always include the primary assessment state
      if (assessment?.geography?.state) {
        states.add(assessment.geography.state);
      }
      
      // Also check census data for any other states in the radius
      if (censusData) {
        Object.values(censusData).forEach(d => {
          if (d && d.state_abbr) states.add(d.state_abbr);
        });
      }

      // 2. Trigger backend load for each identified state
      const stateArray = Array.from(states);
      if (stateArray.length > 0) {
        await Promise.all(stateArray.map(state => 
          base44.functions.invoke('loadZctaPlaceRelationships', { state_abbr: state })
            .catch(err => console.warn(`Failed to load relationships for ${state}:`, err))
        ));
      }

      // 3. Force refresh place names from Census data
      const placeData = await base44.entities.ZctaPlaceRelationship.filter({
        zcta5: { '$in': zipCodes },
        is_primary: true
      });
      
      const names = {};
      placeData.forEach(place => {
        const cleanName = place.place_name.replace(/ (city|town|village|CDP)$/i, '').trim();
        names[place.zcta5] = {
          name: cleanName,
          fullName: place.place_name,
          population: place.place_population || 0,
          placeType: place.place_type
        };
      });
      setCityNames(names);
      toast.success(`Reloaded ${Object.keys(names).length} cities`, { id: 'refresh-cities' });
    } catch (error) {
      console.error('Error refreshing cities:', error);
      toast.error('Failed to reload cities', { id: 'refresh-cities' });
    } finally {
      setIsRefreshingCities(false);
    }
  };

  const handleRefreshDemographics = async () => {
    setIsRefreshingData(true);
    toast.loading('Refreshing demographic data...', { id: 'refresh-demo' });
    
    try {
      if (onRefreshDemographics) {
        await onRefreshDemographics();
      }
      toast.success('Demographic data refreshed', { id: 'refresh-demo' });
    } catch (error) {
      console.error('Error refreshing demographics:', error);
      toast.error('Failed to refresh data', { id: 'refresh-demo' });
    } finally {
      setIsRefreshingData(false);
    }
  };

  const handleRefreshAll = async () => {
    await Promise.all([
      handleRefreshCities(),
      handleRefreshDemographics()
    ]);
  };

  return (
    <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
      <CardHeader className="pb-3">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <CardTitle className="text-base flex items-center gap-2 flex-wrap">
            <MapPin className="w-5 h-5 text-blue-600 flex-shrink-0" />
            <span className="break-words">Service Area Summary: {city}, {state}</span>
          </CardTitle>
          <div className="flex items-center gap-2 flex-shrink-0">
            <Badge className="text-xs bg-blue-600 text-white hover:bg-blue-700 whitespace-nowrap">
              {radius_miles ? `${radius_miles} mi radius` : 'Regional'}
            </Badge>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon"
                  className="h-8 w-8"
                  disabled={isRefreshingCities || isRefreshingData}
                >
                  {(isRefreshingCities || isRefreshingData) ? (
                    <RefreshCw className="h-4 w-4 animate-spin" />
                  ) : (
                    <MoreVertical className="h-4 w-4" />
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem onClick={handleRefreshCities} disabled={isRefreshingCities}>
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Reload Cities
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleRefreshDemographics} disabled={isRefreshingData}>
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Refresh Demographics
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleRefreshAll} disabled={isRefreshingCities || isRefreshingData}>
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Refresh All Data
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-4">
          <div className="bg-white rounded-lg p-2.5 sm:p-3 shadow-sm">
            <div className="text-xs text-gray-500 mb-1">Area Population</div>
            <div className="text-base sm:text-lg font-bold text-gray-900 break-words">
              {citySummary.totalAreaPopulation.toLocaleString()}
            </div>
            <div className="text-xs text-gray-500 mt-1">{citySummary.zipCount} ZIP codes</div>
          </div>
          <div className="bg-white rounded-lg p-2.5 sm:p-3 shadow-sm">
            <div className="text-xs text-gray-500 mb-1">Avg. Income</div>
            <div className="text-base sm:text-lg font-bold text-gray-900 break-words">
              ${citySummary.avgIncome.toLocaleString()}
            </div>
          </div>
          <div className="bg-white rounded-lg p-2.5 sm:p-3 shadow-sm">
            <div className="text-xs text-gray-500 mb-1">Avg. Poverty Rate</div>
            <div className="text-base sm:text-lg font-bold text-gray-900">
              {citySummary.avgPoverty}%
            </div>
          </div>
          <div className="bg-white rounded-lg p-2.5 sm:p-3 shadow-sm">
            <div className="text-xs text-gray-500 mb-1">Avg. Uninsured</div>
            <div className="text-base sm:text-lg font-bold text-gray-900">
              {citySummary.avgUninsured}%
            </div>
          </div>
        </div>

        {citySummary.majorCities.length > 0 && (
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Building2 className="w-4 h-4 text-blue-600" />
                <h4 className="text-sm font-semibold text-gray-700">Major Cities in Area</h4>
              </div>
              <Badge variant="secondary" className="text-xs">
                {citySummary.majorCities.length} {citySummary.majorCities.length === 1 ? 'city' : 'cities'}
              </Badge>
            </div>
            <div className="flex flex-wrap gap-2">
              {citySummary.majorCities.map((cityInfo, idx) => (
                <Button
                  key={`${cityInfo.name}-${idx}`}
                  variant="outline"
                  size="sm"
                  onClick={() => handleCityClick(cityInfo)}
                  className="bg-white hover:bg-blue-50 text-xs sm:text-sm"
                >
                  <MapPin className="w-3 h-3 mr-1 flex-shrink-0" />
                  <span className="truncate max-w-[120px] sm:max-w-none">{cityInfo.name}</span>
                  <span className="ml-1.5 text-xs text-gray-500 whitespace-nowrap">
                    ({cityInfo.population.toLocaleString()})
                  </span>
                </Button>
              ))}
            </div>
          </div>
        )}
      </CardContent>

      <CityProfileDialog
        open={showCityProfile}
        onClose={() => setShowCityProfile(false)}
        cityName={selectedCity?.name}
        cityZip={selectedCity?.zip}
      />
    </Card>
  );
}