import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Card, CardContent } from '@/components/ui/card';
import { Loader2, Users, DollarSign, Shield, Activity } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function CityProfileDialog({ open, onClose, cityName, cityZip, cityZips }) {
  const [isLoading, setIsLoading] = useState(false);
  const [profileData, setProfileData] = useState(null);

  useEffect(() => {
    if (open && (cityZip || cityZips?.length > 0)) {
      loadCityProfile();
    }
  }, [open, cityZip, cityZips]);

  const loadCityProfile = async () => {
    setIsLoading(true);
    try {
      // Fetch demographic data for this city's ZIP code(s)
      const zipsToFetch = cityZips?.length > 0 ? cityZips : (cityZip ? [cityZip] : []);
      
      if (zipsToFetch.length === 0) {
        setProfileData(null);
        setIsLoading(false);
        return;
      }

      const demographics = await base44.entities.ZipDemographics.filter({
        zcta5: { $in: zipsToFetch }
      }, null, 100);

      if (demographics && demographics.length > 0) {
        // Aggregate data across all ZIPs for this city
        const aggregated = demographics.reduce((acc, d) => {
          acc.population += d.population || 0;
          acc.povertyCount += d.poverty_count || 0;
          acc.povertyTotal += d.poverty_total || 0;
          acc.uninsuredCount += d.uninsured_count || 0;
          acc.insuredTotal += d.insured_total || 0;
          acc.medianIncomeSum += (d.median_income || 0) * (d.population || 0);
          return acc;
        }, { population: 0, povertyCount: 0, povertyTotal: 0, uninsuredCount: 0, insuredTotal: 0, medianIncomeSum: 0 });

        const totalPop = aggregated.population;
        const povertyRate = aggregated.povertyTotal > 0 ? (aggregated.povertyCount / aggregated.povertyTotal) * 100 : 0;
        const uninsuredRate = aggregated.insuredTotal > 0 ? (aggregated.uninsuredCount / aggregated.insuredTotal) * 100 : 0;
        const medianIncome = totalPop > 0 ? Math.round(aggregated.medianIncomeSum / totalPop) : 0;

        const data = { population: totalPop, poverty_rate: povertyRate, uninsured_rate: uninsuredRate, median_income: medianIncome, source: demographics[0].source };

        if (totalPop > 0) {
          const maleEstimate = Math.round(totalPop * 0.49);
          const femaleEstimate = Math.round(totalPop * 0.51);

          // Age distribution estimates (based on US averages)
          const ageGroups = {
            '0-17': Math.round(totalPop * 0.22),
            '18-34': Math.round(totalPop * 0.23),
            '35-54': Math.round(totalPop * 0.26),
            '55-64': Math.round(totalPop * 0.13),
            '65+': Math.round(totalPop * 0.16)
          };

          // Insurance mix estimates
          const uninsuredRateVal = data.uninsured_rate || 0;
          const uninsuredCount = Math.round(totalPop * (uninsuredRateVal / 100));
          const insuredCount = totalPop - uninsuredCount;
          
          // Estimate insurance breakdown (rough approximations)
          const medicareEstimate = Math.round(totalPop * 0.18); // ~18% on Medicare
          const medicaidEstimate = Math.round(totalPop * 0.21); // ~21% on Medicaid
          const privateEstimate = insuredCount - medicareEstimate - medicaidEstimate;

          setProfileData({
            population: totalPop,
            male: maleEstimate,
            female: femaleEstimate,
            ageGroups,
            povertyRate: data.poverty_rate || 0,
            medianIncome: data.median_income || 0,
            insurance: {
              uninsured: uninsuredCount,
              uninsuredRate: uninsuredRateVal,
              medicare: medicareEstimate,
              medicaid: medicaidEstimate,
              private: privateEstimate > 0 ? privateEstimate : 0
            },
            source: data.source || 'Census Bureau'
          });
        } else {
          setProfileData(null);
        }
      } else {
        setProfileData(null);
      }
    } catch (error) {
      console.error('Error loading city profile:', error);
      setProfileData(null);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl">
            {cityName} Demographics Profile
          </DialogTitle>
        </DialogHeader>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
          </div>
        ) : profileData ? (
          <div className="space-y-4">
            {/* Total Population */}
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-2 mb-3">
                  <Users className="w-5 h-5 text-blue-600" />
                  <h3 className="font-semibold text-gray-900">Total Population</h3>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <div className="text-2xl font-bold text-gray-900">
                      {profileData.population.toLocaleString()}
                    </div>
                    <div className="text-sm text-gray-500">Total</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-blue-600">
                      {profileData.male.toLocaleString()}
                    </div>
                    <div className="text-sm text-gray-500">Male ({((profileData.male / profileData.population) * 100).toFixed(0)}%)</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-pink-600">
                      {profileData.female.toLocaleString()}
                    </div>
                    <div className="text-sm text-gray-500">Female ({((profileData.female / profileData.population) * 100).toFixed(0)}%)</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Age Distribution */}
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-2 mb-3">
                  <Activity className="w-5 h-5 text-purple-600" />
                  <h3 className="font-semibold text-gray-900">Population by Age Group</h3>
                </div>
                <div className="space-y-2">
                  {Object.entries(profileData.ageGroups).map(([age, count]) => {
                    const percentage = ((count / profileData.population) * 100).toFixed(1);
                    return (
                      <div key={age} className="flex items-center justify-between">
                        <div className="flex items-center gap-3 flex-1">
                          <span className="text-sm font-medium text-gray-700 w-16">{age}</span>
                          <div className="flex-1 bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-purple-600 h-2 rounded-full transition-all"
                              style={{ width: `${percentage}%` }}
                            />
                          </div>
                        </div>
                        <div className="text-sm text-gray-600 w-24 text-right">
                          {count.toLocaleString()} ({percentage}%)
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Economic Indicators */}
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-2 mb-3">
                  <DollarSign className="w-5 h-5 text-green-600" />
                  <h3 className="font-semibold text-gray-900">Economic Indicators</h3>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-sm text-gray-500 mb-1">Median Income</div>
                    <div className="text-xl font-bold text-gray-900">
                      {profileData.medianIncome > 0 ? `$${profileData.medianIncome.toLocaleString()}` : 'N/A'}
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-500 mb-1">Poverty Rate</div>
                    <div className="text-xl font-bold text-red-600">
                      {profileData.povertyRate > 0 ? `${profileData.povertyRate}%` : 'N/A'}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Insurance Coverage */}
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center gap-2 mb-3">
                  <Shield className="w-5 h-5 text-emerald-600" />
                  <h3 className="font-semibold text-gray-900">Insurance Coverage</h3>
                </div>
                <div className="space-y-3">
                  <div className="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                    <span className="text-sm font-medium text-gray-700">Uninsured</span>
                    <div className="text-right">
                      <div className="text-lg font-bold text-red-600">
                        {profileData.insurance.uninsured.toLocaleString()}
                      </div>
                      <div className="text-xs text-gray-500">{profileData.insurance.uninsuredRate}%</div>
                    </div>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                    <span className="text-sm font-medium text-gray-700">Medicare</span>
                    <div className="text-right">
                      <div className="text-lg font-bold text-blue-600">
                        {profileData.insurance.medicare.toLocaleString()}
                      </div>
                      <div className="text-xs text-gray-500">
                        {((profileData.insurance.medicare / profileData.population) * 100).toFixed(1)}%
                      </div>
                    </div>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                    <span className="text-sm font-medium text-gray-700">Medicaid</span>
                    <div className="text-right">
                      <div className="text-lg font-bold text-green-600">
                        {profileData.insurance.medicaid.toLocaleString()}
                      </div>
                      <div className="text-xs text-gray-500">
                        {((profileData.insurance.medicaid / profileData.population) * 100).toFixed(1)}%
                      </div>
                    </div>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg">
                    <span className="text-sm font-medium text-gray-700">Private Insurance</span>
                    <div className="text-right">
                      <div className="text-lg font-bold text-purple-600">
                        {profileData.insurance.private.toLocaleString()}
                      </div>
                      <div className="text-xs text-gray-500">
                        {((profileData.insurance.private / profileData.population) * 100).toFixed(1)}%
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="text-xs text-gray-500 text-center pt-2">
              Data Source: {profileData.source}
            </div>
          </div>
        ) : (
          <div className="text-center py-12 text-gray-500">
            No demographic data available for {cityName}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}