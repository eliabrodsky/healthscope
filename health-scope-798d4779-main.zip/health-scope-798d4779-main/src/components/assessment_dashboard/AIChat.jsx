import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { BrainCircuit, User, Loader2, Wand2, Trash2, Lightbulb, Database } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import ReactMarkdown from 'react-markdown';

export default function AIChat({ onAddZips, onAddOrgs, assessment, quickPrompt, onQuickPromptUsed, onUpdateCensusData }) {
  const [messages, setMessages] = useState([
    { role: 'assistant', content: 'Hi! I can help you find ZIP codes, healthcare organizations, and analyze your service area. What would you like to know?' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef(null);

  // Load chat history on component mount
  useEffect(() => {
    const savedMessages = assessment?.processed_data?.chat_history;
    if (savedMessages && Array.isArray(savedMessages) && savedMessages.length > 0) {
      // Map old 'ai' role to 'assistant' and 'text' to 'content' for compatibility
      setMessages(savedMessages.map(msg => ({
        role: msg.role === 'ai' ? 'assistant' : msg.role,
        content: msg.content || msg.text || '' // Prefer 'content', fallback to 'text'
      })));
    }
    // No else block needed; initial state handles the default welcome message
  }, [assessment]);

  // Handle quick prompts from DataEnhancement component
  useEffect(() => {
    if (quickPrompt) {
      setInput(quickPrompt);
      // Optionally auto-focus the input
      setTimeout(() => {
        const inputElement = document.querySelector('#ai-chat-input');
        if (inputElement) inputElement.focus();
      }, 100);
      // Clear the quick prompt after using it
      if (onQuickPromptUsed) onQuickPromptUsed();
    }
  }, [quickPrompt, onQuickPromptUsed]);

  // Save chat history to assessment whenever messages change
  useEffect(() => {
    // Only save if there's an assessment ID and more than just the initial welcome message (i.e., user has interacted)
    if (messages.length > 1 && assessment?.id) {
      // Save to assessment processed_data
      const updatedAssessment = {
        ...assessment,
        processed_data: {
          ...assessment.processed_data,
          chat_history: messages
        }
      };
      // This would ideally trigger a save, but for now just keep in local state
    }
  }, [messages, assessment]);

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const clearChatHistory = () => {
    setMessages([
      { role: 'assistant', content: 'Hi! I can help you find ZIP codes, healthcare organizations, and analyze your service area. What would you like to know?' }
    ]);
  };

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage = { role: 'user', content: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const context = `You are a healthcare data assistant helping with a community health assessment.

Current Assessment Details:
- Location: ${assessment?.geography?.city || 'Not specified'}, ${assessment?.geography?.state || 'Not specified'}
- Current ZIP codes: ${assessment?.geography?.zip_codes?.length || 0} ZIPs
- Organizations tracked: ${assessment?.organizations?.length || 0}

User Question: ${input}

IMPORTANT: If the user asks about finding, loading, or filling missing demographic/census data, respond with JSON in this exact format:
{
  "census_data": {
    "71638": {
      "population": 5234,
      "medianIncome": 45000,
      "povertyRate": 23.5,
      "uninsuredRate": 12.3,
      "source": "US Census Bureau ACS 5-Year 2022"
    }
  },
  "message": "Found demographic data for X ZIP codes"
}

For ZIP codes:
{
  "action": "add_zips",
  "zip_codes": ["12345", "12346"],
  "message": "Found 2 ZIP codes"
}

For organizations:
{
  "action": "add_orgs",
  "organizations": [{"name": "Example Hospital", "type": "hospital"}],
  "message": "Found 2 organizations"
}

For general questions, provide helpful markdown-formatted text.`;

      let response;
      try {
        response = await base44.integrations.Core.InvokeLLM({
          prompt: context,
          add_context_from_internet: true
        });
      } catch (networkError) {
        if (networkError.message?.includes('Network Error') || networkError.code === 'ERR_NETWORK') {
          throw new Error('Cannot connect to AI service. Please check your internet connection.');
        } else if (networkError.message?.includes('Rate limit')) {
          throw new Error('Too many AI requests. Please wait a moment and try again.');
        } else if (networkError.message?.includes('timeout')) {
          throw new Error('AI request timed out. Please try a simpler question or try again.');
        }
        throw networkError;
      }

      let aiContent;
      let shouldProcessAction = false;
      let parsedResponse = response;
      let hasCensusData = false;
      let extractedCensusData = null;

      try {
        // Attempt to parse response if it's a string
        if (typeof response === 'string') {
            try {
                // Strip markdown code blocks if present
                let cleanedResponse = response.trim();
                if (cleanedResponse.startsWith('```')) {
                  // Remove code block markers
                  cleanedResponse = cleanedResponse.replace(/^```(?:json)?\s*\n?/, '').replace(/\n?```\s*$/, '');
                }
                parsedResponse = JSON.parse(cleanedResponse);
            } catch (e) {
                // Not JSON, check if it contains census data patterns
                if (response.includes('median') || response.includes('poverty') || response.includes('ZIP code') || response.includes('demographic')) {
                  // Extract ZIP codes and values from text
                  const zipMatches = response.match(/\b\d{5}\b/g);
                  if (zipMatches && zipMatches.length > 0) {
                    // User should be offered to populate data
                    hasCensusData = true;
                    extractedCensusData = { needsManualExtraction: true, rawText: response };
                  }
                }
                aiContent = response;
            }
        }

        if (parsedResponse && typeof parsedResponse === 'object' && parsedResponse !== null) {
          // Check for census data
          if (parsedResponse.census_data) {
            hasCensusData = true;
            extractedCensusData = parsedResponse.census_data;
            aiContent = parsedResponse.message || 'Found demographic data. Click "Apply to Table" below to update your data.';
          } else if (parsedResponse.action) {
            shouldProcessAction = true;
            aiContent = parsedResponse.message || 'Action completed';
          } else {
            aiContent = JSON.stringify(parsedResponse, null, 2);
          }
        } else if (typeof response === 'string') {
            aiContent = response;
        } else {
          aiContent = 'I received your question but had trouble forming a response. Could you rephrase?';
        }
      } catch (parseError) {
        console.warn('Error parsing AI response:', parseError);
        aiContent = typeof response === 'string' ? response : 'Received response but could not parse it properly.';
      }

      const assistantMessage = {
        role: 'assistant',
        content: aiContent,
        parsedData: (shouldProcessAction || hasCensusData) ? { census_data: extractedCensusData, ...parsedResponse } : null
      };
      setMessages(prev => [...prev, assistantMessage]);

      if (shouldProcessAction && parsedResponse.action) {
        try {
          if (parsedResponse.action === 'add_zips' && parsedResponse.zip_codes && Array.isArray(parsedResponse.zip_codes)) {
            onAddZips(parsedResponse.zip_codes, parsedResponse.message);
          } else if (parsedResponse.action === 'add_orgs' && parsedResponse.organizations && Array.isArray(parsedResponse.organizations)) {
            onAddOrgs(parsedResponse.organizations, parsedResponse.message);
          }
        } catch (actionError) {
          console.error('Error processing AI action:', actionError);
          toast.error('AI suggested an action but it could not be completed.');
        }
      }

    } catch (error) {
      console.error('AI Chat Error:', error);

      let errorMessage = error.message || 'An unexpected error occurred';

      // User-friendly error messages
      if (errorMessage.includes('Network Error') || errorMessage.includes('Cannot connect')) {
        errorMessage = 'Connection failed. Please check your internet and try again.';
      } else if (errorMessage.includes('API key')) {
        errorMessage = 'AI service configuration error. Please contact support.';
      } else if (errorMessage.includes('Rate limit')) {
          errorMessage = 'Too many AI requests. Please wait a moment and try again.';
      } else if (errorMessage.includes('timed out')) {
          errorMessage = 'AI request timed out. Please try a simpler question or try again.';
      }

      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `Sorry, I encountered an error: ${errorMessage}`
      }]);

      toast.error(errorMessage, { duration: 5000 });
    } finally {
      setIsLoading(false);
    }
  };

  const quickSuggestions = [
    { text: `Find FQHCs in ${assessment?.geography?.city || 'my area'}`, icon: Lightbulb },
    { text: `Load census data for ${assessment?.geography?.state || 'my state'}`, icon: Lightbulb },
    { text: `Identify service area ZIPs`, icon: Lightbulb }
  ];

  const handleApplyCensusData = async (messageIndex) => {
    const message = messages[messageIndex];
    if (!message?.parsedData?.census_data) return;

    const censusData = message.parsedData.census_data;

    // If needs manual extraction, ask AI to parse it
    if (censusData.needsManualExtraction) {
      setIsLoading(true);
      try {
        const extractPrompt = `Extract the demographic data from this text and return ONLY valid JSON in this exact format:
{
  "census_data": {
    "ZIP_CODE": {
      "population": number,
      "medianIncome": number,
      "povertyRate": number,
      "uninsuredRate": number,
      "source": "string"
    }
  }
}

Text to extract from:
${censusData.rawText}

Return ONLY the JSON, no additional text.`;

        const response = await base44.integrations.Core.InvokeLLM({
          prompt: extractPrompt
        });

        let parsed;
        if (typeof response === 'string') {
          // Strip markdown code blocks if present
          let cleanedResponse = response.trim();
          if (cleanedResponse.startsWith('```')) {
            cleanedResponse = cleanedResponse.replace(/^```(?:json)?\s*\n?/, '').replace(/\n?```\s*$/, '');
          }
          parsed = JSON.parse(cleanedResponse);
        } else {
          parsed = response;
        }

        if (parsed?.census_data && onUpdateCensusData) {
          onUpdateCensusData(parsed.census_data);
          toast.success(`Applied data for ${Object.keys(parsed.census_data).length} ZIP codes!`);
        }
      } catch (error) {
        console.error('Error extracting census data:', error);
        toast.error('Failed to extract census data from response');
      } finally {
        setIsLoading(false);
      }
    } else if (onUpdateCensusData) {
      // Direct census data object
      onUpdateCensusData(censusData);
      toast.success(`Applied data for ${Object.keys(censusData).length} ZIP codes!`);
    }
  };

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-lg">
            <BrainCircuit className="w-5 h-5"/> AI Assistant
          </CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={clearChatHistory}
            className="text-gray-500 hover:text-gray-700 h-8 w-8 p-0"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="flex flex-col flex-1 px-4 pb-4 pt-0">
        <ScrollArea className="flex-1 mb-3 pr-2">
          <div className="space-y-3">
            {messages.map((msg, index) => (
              <div key={index}>
                <div className={`flex items-start gap-2 ${msg.role === 'user' ? 'justify-end' : ''}`}>
                  {msg.role === 'assistant' && <div className="w-7 h-7 rounded-full bg-emerald-100 flex items-center justify-center flex-shrink-0"><Wand2 className="w-3.5 h-3.5 text-emerald-600"/></div>}
                  <div className={`p-2.5 rounded-lg max-w-[85%] ${msg.role === 'user' ? 'bg-blue-500 text-white' : 'bg-gray-100'}`}>
                    {msg.role === 'user' ? (
                      <p className="text-sm whitespace-pre-line">{msg.content}</p>
                    ) : (
                      <div className="text-sm prose prose-sm max-w-none [&>*:first-child]:mt-0 [&>*:last-child]:mb-0">
                        <ReactMarkdown
                          components={{
                            p: ({ children }) => <p className="mb-2 last:mb-0">{children}</p>,
                            ul: ({ children }) => <ul className="list-disc ml-4 mb-2">{children}</ul>,
                            ol: ({ children }) => <ol className="list-decimal ml-4 mb-2">{children}</ol>,
                            li: ({ children }) => <li className="mb-1">{children}</li>,
                            strong: ({ children }) => <strong className="font-semibold">{children}</strong>,
                            code: ({ children }) => <code className="bg-gray-200 px-1 rounded text-xs">{children}</code>,
                            table: ({ children }) => (
                              <div className="overflow-x-auto my-3">
                                <table className="min-w-full divide-y divide-gray-300 border border-gray-300 rounded-lg text-xs">
                                  {children}
                                </table>
                              </div>
                            ),
                            thead: ({ children }) => (
                              <thead className="bg-gray-50">
                                {children}
                              </thead>
                            ),
                            tbody: ({ children }) => (
                              <tbody className="divide-y divide-gray-200 bg-white">
                                {children}
                              </tbody>
                            ),
                            tr: ({ children }) => (
                              <tr>
                                {children}
                              </tr>
                            ),
                            th: ({ children }) => (
                              <th className="px-3 py-2 text-left font-semibold text-gray-900">
                                {children}
                              </th>
                            ),
                            td: ({ children }) => (
                              <td className="px-3 py-2 text-gray-700">
                                {children}
                              </td>
                            )
                          }}
                        >
                          {msg.content}
                        </ReactMarkdown>
                        {msg.parsedData?.census_data && (
                          <div className="mt-3 pt-2 border-t border-gray-300">
                            <Button
                              size="sm"
                              onClick={() => handleApplyCensusData(index)}
                              className="bg-blue-600 hover:bg-blue-700 text-white h-8"
                              disabled={isLoading}
                            >
                              {isLoading ? (
                                <>
                                  <Loader2 className="w-3 h-3 mr-1.5 animate-spin" />
                                  Processing...
                                </>
                              ) : (
                                <>
                                  <Database className="w-3 h-3 mr-1.5" />
                                  Apply to Table
                                </>
                              )}
                            </Button>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                  {msg.role === 'user' && <div className="w-7 h-7 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0"><User className="w-3.5 h-3.5 text-blue-600"/></div>}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex items-start gap-2">
                <div className="w-7 h-7 rounded-full bg-emerald-100 flex items-center justify-center flex-shrink-0"><Loader2 className="w-3.5 h-3.5 text-emerald-600 animate-spin"/></div>
                <div className="p-2.5 rounded-lg max-w-[85%] bg-gray-100">
                  <p className="text-sm text-gray-500">Thinking...</p>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>

        {/* Quick suggestions - compact and below messages */}
        {messages.length === 1 && (
          <div className="mb-3 flex flex-wrap gap-1.5">
            {quickSuggestions.map((suggestion, idx) => (
              <Button
                key={idx}
                variant="outline"
                size="sm"
                onClick={() => setInput(suggestion.text)}
                className="h-7 text-xs"
              >
                <suggestion.icon className="w-3 h-3 mr-1" />
                {suggestion.text}
              </Button>
            ))}
          </div>
        )}

        <div className="flex gap-2">
          <Input
            id="ai-chat-input"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && !isLoading && handleSend()}
            placeholder="Ask me anything..."
            disabled={isLoading}
            className="h-9 text-sm"
          />
          <Button onClick={handleSend} disabled={isLoading} size="sm" className="h-9 px-4">
            {isLoading ? <Loader2 className="w-4 h-4 animate-spin"/> : 'Send'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}