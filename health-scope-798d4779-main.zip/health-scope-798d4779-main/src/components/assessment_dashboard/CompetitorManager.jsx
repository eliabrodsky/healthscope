
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge'; // Added Badge import
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { toast } from 'sonner';
import { Building, Plus, Trash2, MapPin, Eye, Loader2, MapPinned, Search } from 'lucide-react';
import { base44 } from '@/api/base44Client';

// Helper function to format organization type display
const formatOrgType = (type) => {
  const typeMap = {
    'fqhc': 'FQHC',
    'hospital': 'Hospital',
    'clinic': 'Clinic',
    'urgent_care': 'Urgent Care',
    'safety_net': 'Safety Net',
    'other': 'Other'
  };
  return typeMap[type] || type?.replace(/_/g, ' ') || 'N/A';
};

export default function CompetitorManager({ assessment, onOrganizationsUpdate }) {
  const [organizations, setOrganizations] = useState(assessment?.organizations || []);
  const [isSearching, setIsSearching] = useState(false);
  const [isEnriching, setIsEnriching] = useState(false); // Renamed from isFetchingLocations
  const [newOrgName, setNewOrgName] = useState('');
  const [newOrgType, setNewOrgType] = useState('fqhc');

  useEffect(() => {
    setOrganizations(assessment?.organizations || []);
  }, [assessment]);

  const handleAddOrganization = () => {
    if (!newOrgName) {
      toast.error("Organization name is required.");
      return;
    }
    const newOrg = {
      id: `manual_${Date.now()}`,
      name: newOrgName,
      type: newOrgType, // Consider adding a select input for type
      address: '',
      city: assessment?.geography?.city || '',
      state: assessment?.geography?.state || '',
      source: 'Manual Entry'
    };
    const updatedOrgs = [...organizations, newOrg];
    setOrganizations(updatedOrgs);
    onOrganizationsUpdate(updatedOrgs);
    setNewOrgName('');
    toast.success(`${newOrgName} added to the list.`);
  };

  const handleRemoveOrganization = (orgId) => {
    const orgToRemove = organizations.find(o => o.id === orgId);
    const updatedOrgs = organizations.filter(o => o.id !== orgId);
    setOrganizations(updatedOrgs);
    onOrganizationsUpdate(updatedOrgs);
    toast.info(`${orgToRemove.name} removed.`);
  };

  const handleSearchCompetitors = async () => {
    if (!assessment?.geography?.city || !assessment?.geography?.state || !assessment?.geography?.latitude || !assessment?.geography?.longitude) {
      toast.error("Assessment geography information (city, state, coordinates) is required to search for competitors.");
      return;
    }

    setIsSearching(true);
    toast.loading("Searching for healthcare facilities...", { id: 'search-competitors', duration: 15000 });

    try {
      let response;
      try {
        response = await base44.functions.invoke('findHealthcareFacilities', {
          latitude: assessment.geography.latitude,
          longitude: assessment.geography.longitude,
          radiusMiles: assessment.geography.radius_miles || 50,
          facilityTypes: ['hospital', 'clinic', 'urgent_care'] // Added urgent_care as a common type
        });
      } catch (networkError) {
        if (networkError.message?.includes('Network Error') || networkError.code === 'ERR_NETWORK') {
          throw new Error('Cannot connect to server. Please check your internet connection and try again.');
        }
        throw networkError;
      }

      if (response?.data?.success && response.data?.facilities) {
        const facilities = response.data.facilities;
        
        if (facilities.length === 0) {
          toast.info("No new healthcare facilities found in the search area.", { id: 'search-competitors' });
          return;
        }

        const currentOrgNames = new Set(organizations.map(o => o.name?.toLowerCase()).filter(Boolean));
        
        const newOrgs = facilities
          .filter(facility => facility.name && !currentOrgNames.has(facility.name.toLowerCase()))
          .map(facility => ({
            id: `osm_${Math.random().toString(36).substr(2, 9)}`, // Simpler unique ID
            name: facility.name,
            type: facility.type,
            address: facility.address || '',
            city: facility.city || assessment.geography.city,
            state: facility.state || assessment.geography.state,
            zip_code: facility.zip_code || '',
            coordinates: facility.latitude && facility.longitude ? {
              latitude: facility.latitude,
              longitude: facility.longitude
            } : null,
            source: 'OpenStreetMap',
            distance_miles: facility.distance ? facility.distance.toFixed(1) : null
          }));

        if (newOrgs.length > 0) {
          const updatedOrgs = [...organizations, ...newOrgs];
          setOrganizations(updatedOrgs);
          onOrganizationsUpdate(updatedOrgs);
          toast.success(`Found ${newOrgs.length} new competitors!`, { id: 'search-competitors' });
        } else {
          toast.info(`Found ${facilities.length} facilities, but they're already in your list.`, { id: 'search-competitors' });
        }
      } else {
        throw new Error(response?.data?.error || 'Unexpected response from search');
      }
    } catch (error) {
      console.error("Error searching competitors:", error);
      
      let errorMessage = error.message || 'Unknown error';
      
      if (errorMessage.includes('Network Error') || errorMessage.includes('Cannot connect')) {
        errorMessage = 'Network connection failed. Please check your internet and try again.';
      } else if (errorMessage.includes('temporarily unavailable')) {
        errorMessage = 'Service temporarily unavailable. Please try again in a few minutes.';
      } else if (errorMessage.includes('timeout')) {
        errorMessage = 'Search timed out. Try reducing the search radius.';
      }
      
      toast.error(`Failed to search: ${errorMessage}`, { id: 'search-competitors', duration: 6000 });
    } finally {
      setIsSearching(false);
    }
  };


  const handleEnrichLocations = async () => { // Renamed from handleFetchAllLocations
    if (organizations.length === 0) {
      toast.error("No competitors to enrich locations for.");
      return;
    }

    setIsEnriching(true); // Updated state variable
    const enrichToastId = 'enrich-locations'; // Updated toast ID
    toast.loading(`Finding site locations for ${organizations.length} competitors...`, { id: enrichToastId, duration: 120000 });

    try {
      let response;
      try {
        response = await base44.functions.invoke('enrichCompetitorLocations', {
          organizations: organizations,
          state: assessment?.geography?.state || 'Arkansas' // Default to Arkansas for demo/safety
        });
      } catch (networkError) {
        if (networkError.message?.includes('Network Error') || networkError.code === 'ERR_NETWORK') {
          throw new Error('Cannot connect to server. Check your internet connection.');
        }
        throw networkError;
      }


      if (response?.data?.success && response.data?.organizations) {
        setOrganizations(response.data.organizations);
        onOrganizationsUpdate(response.data.organizations);
        toast.success(
          `${response.data.message}! Found ${response.data.totalSitesFound || 0} total locations across ${organizations.length} organizations.`,
          { id: enrichToastId, duration: 5000 }
        );
      } else {
        throw new Error(response?.data?.error || 'Failed to enrich locations');
      }

    } catch (error) {
      console.error("Error enriching competitor locations:", error);
      
      let errorMessage = error.message || 'Unknown error occurred';
      
      if (errorMessage.includes('Network Error') || errorMessage.includes('Cannot connect')) {
        errorMessage = 'Network connection failed. Please try again.';
      } else if (errorMessage.includes('Rate limit')) {
        errorMessage = 'Too many requests. Please wait and try again.';
      } else if (errorMessage.includes('temporarily unavailable')) {
        errorMessage = 'Enrichment service temporarily unavailable. Please try again later.';
      }

      toast.error(
        `Failed to enrich competitor locations: ${errorMessage}. Try processing fewer organizations at once or check your connection.`,
        { id: enrichToastId, duration: 8000 }
      );
    } finally {
      setIsEnriching(false); // Updated state variable
    }
  };

  const renderValue = (value) => {
    if (value === null || value === undefined || value === '') return <span className="text-gray-400">N/A</span>;
    if (typeof value === 'object') return JSON.stringify(value);
    return String(value);
  };
  
  // Calculate total sites across all organizations
  const totalSites = organizations.reduce((sum, org) => {
    return sum + (org.sites?.length || 0);
  }, organizations.length); // Add organization count itself as minimum for organizations without explicit sites

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-start">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Building className="w-5 h-5" />
                Competitor Management
              </CardTitle>
              <CardDescription>
                Review and manage healthcare organizations in your service area.
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={handleSearchCompetitors}
                disabled={isSearching || !assessment?.geography?.city || !assessment?.geography?.state}
              >
                {isSearching ? (
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Search className="w-4 h-4 mr-2" />
                )}
                Search for Competitors
              </Button>
              <Button
                onClick={handleEnrichLocations} // Updated function call
                disabled={isEnriching || organizations.length === 0} // Updated state variable
                className="bg-emerald-600 hover:bg-emerald-700"
              >
                {isEnriching ? ( // Updated state variable
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <MapPinned className="w-4 h-4 mr-2" />
                )}
                Fetch All Site Locations
              </Button>
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="outline">
                    <Eye className="w-4 h-4 mr-2" />
                    Preview Competitor Data
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl">
                  <DialogHeader>
                    <DialogTitle>
                      Competitor Data Preview ({organizations.length} organizations, {totalSites} total locations)
                    </DialogTitle>
                  </DialogHeader>
                  <div className="max-h-[70vh] overflow-y-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Name</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Location</TableHead>
                          <TableHead>Sites</TableHead>
                          <TableHead>Source</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {organizations.map(org => (
                          <TableRow key={org.id}>
                            <TableCell className="font-medium">{renderValue(org.name)}</TableCell>
                            <TableCell>
                              <Badge variant="outline" className="capitalize">
                                {formatOrgType(org.type)}
                              </Badge>
                            </TableCell>
                            <TableCell>{renderValue(org.city)}, {renderValue(org.state)}</TableCell>
                            <TableCell>
                              {org.sites && org.sites.length > 0 ? (
                                <span className="text-emerald-600 font-medium">{org.sites.length} sites</span>
                              ) : (
                                <span className="text-gray-400">Main location only</span>
                              )}
                            </TableCell>
                            <TableCell>{renderValue(org.source)}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="mb-6 p-4 border rounded-lg bg-gray-50">
          <h4 className="font-semibold text-sm mb-2">Add Organization Manually</h4>
          <div className="flex gap-2">
            <Input
              placeholder="Organization Name"
              value={newOrgName}
              onChange={(e) => setNewOrgName(e.target.value)}
              className="flex-1"
            />
            <select
              value={newOrgType}
              onChange={(e) => setNewOrgType(e.target.value)}
              className="border border-gray-300 rounded-md px-3 py-2 text-sm"
            >
              <option value="fqhc">FQHC</option>
              <option value="hospital">Hospital</option>
              <option value="clinic">Clinic</option>
              <option value="urgent_care">Urgent Care</option>
              <option value="safety_net">Safety Net</option>
              <option value="other">Other</option>
            </select>
            <Button onClick={handleAddOrganization}><Plus className="w-4 h-4 mr-2" />Add</Button>
          </div>
        </div>

        {/* Info banner about location enrichment */}
        {organizations.some(org => !org.sites || org.sites.length === 0) && (
          <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-md">
            <div className="flex items-start gap-2">
              <MapPinned className="w-4 h-4 text-blue-600 mt-0.5" />
              <div className="text-sm">
                <p className="font-medium text-blue-900">Enhance Your Competitor Data</p>
                <p className="text-blue-700 text-xs mt-1">
                  Click "Fetch All Site Locations" to automatically find all clinic sites, delivery locations, and facilities for each competitor organization. This will show all their service points on the map.
                </p>
              </div>
            </div>
          </div>
        )}

        <div className="space-y-3">
          <h4 className="font-semibold text-sm">
            Identified Organizations ({organizations.length}) 
            {totalSites > organizations.length && (
              <span className="text-gray-500 font-normal"> • {totalSites} total locations</span>
            )}
          </h4>
          {organizations.length > 0 ? (
            <div className="border rounded-md">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>Sites</TableHead>
                    <TableHead>Source</TableHead>
                    <TableHead className="text-right">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {organizations.map((org) => (
                    <TableRow key={org.id}>
                      <TableCell className="font-medium">{org.name}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="capitalize">
                          {formatOrgType(org.type)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1 text-xs text-gray-600">
                          <MapPin className="w-3 h-3" />
                          {org.city || 'N/A'}, {org.state || 'N/A'}
                        </div>
                      </TableCell>
                      <TableCell>
                        {org.sites && org.sites.length > 0 ? (
                          <span className="text-emerald-600 font-medium text-sm">{org.sites.length} sites</span>
                        ) : (
                          <span className="text-gray-400 text-sm">1 location</span>
                        )}
                      </TableCell>
                       <TableCell className="text-xs">{org.source || 'N/A'}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon" onClick={() => handleRemoveOrganization(org.id)}>
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <p className="text-sm text-gray-500 text-center py-4">
              No organizations identified yet. Add one manually or use the AI data refresh tools.
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
