import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { base44 } from '@/api/base44Client';
import { 
  Users, 
  DollarSign, 
  TrendingDown, 
  Home,
  Loader2,
  MapPin
} from 'lucide-react';
import { toast } from 'sonner';

export default function ZctaDetailCard({ zip, onClose }) {
  const [zcta, setZcta] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (zip) {
      loadZctaDetails();
    }
  }, [zip]);

  const loadZctaDetails = async () => {
    setIsLoading(true);
    try {
      const response = await base44.functions.invoke('getZctaDetails', { zip });
      
      if (response?.data?.success) {
        setZcta(response.data.data);
      } else {
        toast.error('Failed to load ZCTA details');
      }
    } catch (error) {
      console.error('Error loading ZCTA:', error);
      toast.error('Error loading ZCTA details');
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <Loader2 className="w-8 h-8 animate-spin text-emerald-600 mx-auto mb-2" />
          <p className="text-gray-600 text-sm">Loading ZCTA details...</p>
        </CardContent>
      </Card>
    );
  }

  if (!zcta) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <p className="text-gray-600">No data available for this ZIP code</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-2 border-emerald-200">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <MapPin className="w-5 h-5 text-emerald-600" />
            ZIP {zcta.zip} - {zcta.state_abbr}
          </CardTitle>
          <Button variant="ghost" size="sm" onClick={onClose}>
            ×
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Population */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-blue-50 p-4 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Users className="w-4 h-4 text-blue-600" />
              <span className="text-sm text-blue-700 font-medium">Population</span>
            </div>
            <p className="text-2xl font-bold text-blue-900">
              {zcta.pop_total?.toLocaleString() || 'N/A'}
            </p>
          </div>

          <div className="bg-green-50 p-4 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <DollarSign className="w-4 h-4 text-green-600" />
              <span className="text-sm text-green-700 font-medium">Median Income</span>
            </div>
            <p className="text-2xl font-bold text-green-900">
              ${zcta.median_hh_income?.toLocaleString() || 'N/A'}
            </p>
          </div>
        </div>

        {/* Poverty & Housing */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-red-50 p-4 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <TrendingDown className="w-4 h-4 text-red-600" />
              <span className="text-sm text-red-700 font-medium">Poverty Rate</span>
            </div>
            <p className="text-2xl font-bold text-red-900">
              {zcta.poverty_rate}%
            </p>
            <p className="text-xs text-red-600 mt-1">
              {zcta.poverty_below?.toLocaleString()} below poverty line
            </p>
          </div>

          <div className="bg-purple-50 p-4 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Home className="w-4 h-4 text-purple-600" />
              <span className="text-sm text-purple-700 font-medium">Housing Units</span>
            </div>
            <p className="text-2xl font-bold text-purple-900">
              {zcta.housing_units_total?.toLocaleString() || 'N/A'}
            </p>
            <p className="text-xs text-purple-600 mt-1">
              {zcta.owner_occupied_rate}% owner-occupied
            </p>
          </div>
        </div>

        {/* Demographics */}
        <div className="border-t pt-4">
          <h4 className="font-semibold text-gray-900 mb-3">Demographics</h4>
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Male</span>
              <Badge variant="outline">
                {zcta.age_male_total?.toLocaleString()} ({((zcta.age_male_total / zcta.age_total) * 100).toFixed(0)}%)
              </Badge>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Female</span>
              <Badge variant="outline">
                {zcta.age_female_total?.toLocaleString()} ({((zcta.age_female_total / zcta.age_total) * 100).toFixed(0)}%)
              </Badge>
            </div>
          </div>
        </div>

        {/* Race/Ethnicity */}
        <div className="border-t pt-4">
          <h4 className="font-semibold text-gray-900 mb-3">Race & Ethnicity</h4>
          <div className="space-y-2">
            {zcta.race_white_nonhisp > 0 && (
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">White (Non-Hispanic)</span>
                <Badge variant="outline">
                  {zcta.race_white_nonhisp?.toLocaleString()} ({((zcta.race_white_nonhisp / zcta.race_total) * 100).toFixed(0)}%)
                </Badge>
              </div>
            )}
            {zcta.race_black > 0 && (
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Black</span>
                <Badge variant="outline">
                  {zcta.race_black?.toLocaleString()} ({((zcta.race_black / zcta.race_total) * 100).toFixed(0)}%)
                </Badge>
              </div>
            )}
            {zcta.race_hispanic > 0 && (
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Hispanic</span>
                <Badge variant="outline">
                  {zcta.race_hispanic?.toLocaleString()} ({((zcta.race_hispanic / zcta.race_total) * 100).toFixed(0)}%)
                </Badge>
              </div>
            )}
          </div>
        </div>

        {/* Education */}
        {zcta.edu_total_25plus > 0 && (
          <div className="border-t pt-4">
            <h4 className="font-semibold text-gray-900 mb-3">Education (Age 25+)</h4>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">High School Graduate</span>
                <Badge variant="outline">
                  {zcta.edu_hs_grad?.toLocaleString()} ({((zcta.edu_hs_grad / zcta.edu_total_25plus) * 100).toFixed(0)}%)
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">Bachelor's Degree</span>
                <Badge variant="outline">
                  {zcta.edu_bachelors?.toLocaleString()} ({((zcta.edu_bachelors / zcta.edu_total_25plus) * 100).toFixed(0)}%)
                </Badge>
              </div>
              {zcta.edu_doctorate > 0 && (
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Doctorate</span>
                  <Badge variant="outline">
                    {zcta.edu_doctorate?.toLocaleString()} ({((zcta.edu_doctorate / zcta.edu_total_25plus) * 100).toFixed(0)}%)
                  </Badge>
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}