import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle, 
  Users, 
  Heart, 
  Building2,
  Target,
  Baby,
  UserCheck
} from 'lucide-react';

export default function KeyInsights({ assessment, censusData, organizations }) {
  const insights = useMemo(() => {
    if (!censusData || Object.keys(censusData).length === 0) {
      return null;
    }

    const zipCodes = Object.keys(censusData);
    const validData = Object.values(censusData).filter(d => d.population > 0);
    
    if (validData.length === 0) return null;

    // Calculate aggregates
    const totalPopulation = validData.reduce((sum, d) => sum + (d.population || 0), 0);
    const avgIncome = validData.reduce((sum, d) => sum + (d.medianIncome || 0), 0) / validData.length;
    const avgPoverty = validData.reduce((sum, d) => sum + (d.povertyRate || 0), 0) / validData.length;
    const avgUninsured = validData.reduce((sum, d) => sum + (d.uninsuredRate || 0), 0) / validData.length;

    // Find stress points
    const lowIncomeZips = Object.entries(censusData)
      .filter(([_, d]) => d.medianIncome && d.medianIncome < 35000)
      .map(([zip, _]) => zip);

    const highPovertyZips = Object.entries(censusData)
      .filter(([_, d]) => d.povertyRate && d.povertyRate > 25)
      .map(([zip, _]) => zip);

    const highUninsuredZips = Object.entries(censusData)
      .filter(([_, d]) => d.uninsuredRate && d.uninsuredRate > 15)
      .map(([zip, _]) => zip);

    // Provider analysis
    const hospitals = organizations?.filter(o => o.type === 'hospital') || [];
    const fqhcs = organizations?.filter(o => o.type === 'fqhc') || [];
    const clinics = organizations?.filter(o => o.type === 'clinic') || [];
    
    const pcpRatio = totalPopulation / Math.max(1, fqhcs.length + clinics.length);

    // Demographic insights
    const demographicInsights = [];
    
    if (avgIncome < 45000) {
      demographicInsights.push({
        icon: AlertTriangle,
        color: 'text-orange-600',
        bgColor: 'bg-orange-50',
        title: 'Low Median Income Area',
        value: `$${Math.round(avgIncome).toLocaleString()}`,
        description: `Below state average - indicates high need for subsidized care`,
        severity: 'high'
      });
    }

    if (lowIncomeZips.length > 0) {
      demographicInsights.push({
        icon: Users,
        color: 'text-red-600',
        bgColor: 'bg-red-50',
        title: 'Economic Stress Cluster',
        value: `${lowIncomeZips.length} ZIPs`,
        description: `ZIP codes with median income under $35k`,
        zips: lowIncomeZips.slice(0, 5),
        severity: 'high'
      });
    }

    if (avgPoverty > 18) {
      demographicInsights.push({
        icon: TrendingDown,
        color: 'text-red-600',
        bgColor: 'bg-red-50',
        title: 'High Poverty Rate',
        value: `${avgPoverty.toFixed(1)}%`,
        description: `Significantly above national average (12.6%)`,
        severity: 'high'
      });
    }

    if (avgUninsured > 10) {
      demographicInsights.push({
        icon: Heart,
        color: 'text-orange-600',
        bgColor: 'bg-orange-50',
        title: 'Insurance Coverage Gap',
        value: `${avgUninsured.toFixed(1)}%`,
        description: `Uninsured rate indicates access barriers`,
        severity: 'medium'
      });
    }

    // Provider gap insights
    const providerInsights = [];

    if (pcpRatio > 3500) {
      providerInsights.push({
        icon: Building2,
        color: 'text-red-600',
        bgColor: 'bg-red-50',
        title: 'Primary Care Shortage',
        value: `${Math.round(pcpRatio).toLocaleString()}:1`,
        description: `Population-to-provider ratio exceeds HRSA HPSA threshold (3,500:1)`,
        severity: 'high'
      });
    }

    if (hospitals.length === 0) {
      providerInsights.push({
        icon: Building2,
        color: 'text-orange-600',
        bgColor: 'bg-orange-50',
        title: 'No Hospital Access',
        value: '0 hospitals',
        description: `Residents must travel outside area for emergency/inpatient care`,
        severity: 'high'
      });
    }

    if (fqhcs.length === 0) {
      providerInsights.push({
        icon: UserCheck,
        color: 'text-orange-600',
        bgColor: 'bg-orange-50',
        title: 'No FQHC Coverage',
        value: '0 FQHCs',
        description: `Opportunity for safety-net expansion`,
        severity: 'medium'
      });
    }

    // Generate opportunities
    const opportunities = [];

    if (avgPoverty > 20 && pcpRatio > 4000) {
      opportunities.push({
        icon: Target,
        title: 'High-Need Primary Care Expansion',
        description: 'High poverty + provider shortage = strong case for FQHC or mobile unit',
        priority: 'high'
      });
    }

    if (avgUninsured > 12 && fqhcs.length === 0) {
      opportunities.push({
        icon: Heart,
        title: 'Safety Net Gap',
        description: 'High uninsured population with no FQHC presence - clear service need',
        priority: 'high'
      });
    }

    if (lowIncomeZips.length >= 5) {
      opportunities.push({
        icon: Users,
        title: 'Community Health Worker Program',
        description: 'Large low-income cluster ideal for CHW-led outreach and care coordination',
        priority: 'medium'
      });
    }

    if (hospitals.length > 0 && fqhcs.length < 2) {
      opportunities.push({
        icon: Building2,
        title: 'Hospital-FQHC Partnership',
        description: 'Hospital present but limited primary care - opportunity for integrated model',
        priority: 'medium'
      });
    }

    return {
      demographicInsights,
      providerInsights,
      opportunities,
      stats: {
        totalPopulation,
        avgIncome,
        avgPoverty,
        avgUninsured,
        pcpRatio
      }
    };
  }, [censusData, organizations]);

  if (!insights) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5" />
            Key Insights & Gaps
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-500 text-center py-8">
            Load demographic data to generate insights
          </p>
        </CardContent>
      </Card>
    );
  }

  const InsightCard = ({ insight }) => (
    <Card className={`${insight.bgColor} border-l-4 ${insight.severity === 'high' ? 'border-l-red-500' : 'border-l-orange-500'}`}>
      <CardContent className="pt-6">
        <div className="flex items-start gap-4">
          <div className={`p-3 rounded-lg ${insight.bgColor}`}>
            <insight.icon className={`w-6 h-6 ${insight.color}`} />
          </div>
          <div className="flex-1">
            <div className="flex items-start justify-between gap-2">
              <h3 className="font-semibold text-gray-900">{insight.title}</h3>
              {insight.severity === 'high' && (
                <Badge variant="destructive" className="text-xs">High Priority</Badge>
              )}
            </div>
            <p className="text-2xl font-bold text-gray-900 mt-1">{insight.value}</p>
            <p className="text-sm text-gray-600 mt-2">{insight.description}</p>
            {insight.zips && (
              <div className="mt-2 flex flex-wrap gap-1">
                {insight.zips.map(zip => (
                  <Badge key={zip} variant="outline" className="text-xs">
                    {zip}
                  </Badge>
                ))}
                {insight.zips.length < Object.keys(censusData).filter(z => censusData[z].medianIncome < 35000).length && (
                  <Badge variant="outline" className="text-xs">+{Object.keys(censusData).filter(z => censusData[z].medianIncome < 35000).length - insight.zips.length} more</Badge>
                )}
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );

  const OpportunityCard = ({ opportunity }) => (
    <div className="flex items-start gap-3 p-4 bg-emerald-50 border border-emerald-200 rounded-lg">
      <div className="p-2 bg-emerald-100 rounded-lg">
        <opportunity.icon className="w-5 h-5 text-emerald-700" />
      </div>
      <div className="flex-1">
        <div className="flex items-start justify-between gap-2">
          <h4 className="font-semibold text-gray-900 text-sm">{opportunity.title}</h4>
          {opportunity.priority === 'high' && (
            <Badge className="bg-emerald-600 text-xs">Top Priority</Badge>
          )}
        </div>
        <p className="text-sm text-gray-700 mt-1">{opportunity.description}</p>
      </div>
    </div>
  );

  return (
    <div className="space-y-8">
      {/* Overview Stats */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm text-gray-600">Total Population</p>
            <p className="text-2xl font-bold text-gray-900">{insights.stats.totalPopulation.toLocaleString()}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm text-gray-600">Avg. Median Income</p>
            <p className="text-2xl font-bold text-gray-900">${Math.round(insights.stats.avgIncome).toLocaleString()}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm text-gray-600">Avg. Poverty Rate</p>
            <p className="text-2xl font-bold text-gray-900">{insights.stats.avgPoverty.toFixed(1)}%</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm text-gray-600">Avg. Uninsured</p>
            <p className="text-2xl font-bold text-gray-900">{insights.stats.avgUninsured.toFixed(1)}%</p>
          </CardContent>
        </Card>
      </div>

      {/* Demographic Stress Points */}
      {insights.demographicInsights.length > 0 && (
        <div>
          <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
            <Users className="w-6 h-6 text-gray-700" />
            Population & Demographic Stress Points
          </h2>
          <div className="grid md:grid-cols-2 gap-4">
            {insights.demographicInsights.map((insight, idx) => (
              <InsightCard key={idx} insight={insight} />
            ))}
          </div>
        </div>
      )}

      {/* Provider Gaps */}
      {insights.providerInsights.length > 0 && (
        <div>
          <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
            <Building2 className="w-6 h-6 text-gray-700" />
            Provider Gaps & Market Dynamics
          </h2>
          <div className="grid md:grid-cols-2 gap-4">
            {insights.providerInsights.map((insight, idx) => (
              <InsightCard key={idx} insight={insight} />
            ))}
          </div>
        </div>
      )}

      {/* Key Opportunities */}
      {insights.opportunities.length > 0 && (
        <div>
          <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2">
            <Target className="w-6 h-6 text-emerald-600" />
            Key Opportunities
          </h2>
          <div className="grid md:grid-cols-2 gap-4">
            {insights.opportunities.map((opp, idx) => (
              <OpportunityCard key={idx} opportunity={opp} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}