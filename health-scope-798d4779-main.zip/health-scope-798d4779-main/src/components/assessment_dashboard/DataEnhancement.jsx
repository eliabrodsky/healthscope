import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Lightbulb, Users, BarChart, Database, Sparkles } from 'lucide-react';

const EnhancementAction = ({ icon: Icon, title, description, example, onQuickAction, assessment }) => {
  const getLocationAwareExample = () => {
    const city = assessment?.geography?.city || 'your area';
    const state = assessment?.geography?.state || 'your state';
    
    if (title.includes('Competitors')) {
      return `Find FQHCs in ${city}, ${state}`;
    } else if (title.includes('Demographic')) {
      return `Load census data for ${city}, ${state}`;
    } else if (title.includes('ZIP')) {
      return `Find ZIP codes in ${city}, ${state}`;
    }
    return example;
  };

  const locationAwareExample = getLocationAwareExample();

  return (
    <div className="flex items-start gap-4 p-4 border rounded-lg bg-gray-50">
      <div className="text-emerald-600 bg-emerald-100 p-2 rounded-lg">
        <Icon className="w-6 h-6" />
      </div>
      <div className="flex-1">
        <h4 className="font-semibold text-gray-800">{title}</h4>
        <p className="text-sm text-gray-600 mt-1">{description}</p>
        <div className="flex items-center gap-2 mt-2">
          <p className="text-xs text-gray-500 italic">
            Example: "{locationAwareExample}"
          </p>
          <Button 
            size="sm" 
            variant="outline" 
            className="text-xs h-6 px-2"
            onClick={() => onQuickAction(locationAwareExample)}
          >
            Try This
          </Button>
        </div>
      </div>
    </div>
  );
};

export default function DataEnhancement({ assessment, onQuickAction }) {
  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-purple-600" />
          Data Enhancement Agents
        </CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-sm text-gray-600 mb-6">
          Use our AI agents to automatically find, load, and enrich data for your assessment. 
          Click "Try This" to use pre-filled prompts for {assessment?.geography?.city || 'your area'}.
        </p>
        <div className="space-y-4">
          <EnhancementAction
            icon={Users}
            title="Find Competitors"
            description="Discover healthcare organizations like FQHCs in your service area."
            example="Find FQHCs in New Orleans"
            onQuickAction={onQuickAction}
            assessment={assessment}
          />
          <EnhancementAction
            icon={Database}
            title="Load Demographic Data"
            description="Pull the latest demographic data (population, income, poverty rates) from the US Census."
            example="Load census data for Gulfport, MS"
            onQuickAction={onQuickAction}
            assessment={assessment}
          />
          <EnhancementAction
            icon={BarChart}
            title="Identify Service Area ZIPs"
            description="Find all ZIP codes within a specific city or radius to define your market."
            example="Find ZIP codes in St. Tammany Parish"
            onQuickAction={onQuickAction}
            assessment={assessment}
          />
        </div>
      </CardContent>
    </Card>
  );
}