import React, { useState } from 'react';
import { Card, CardHeader, CardTitle } from '@/components/ui/card';
import { TrendingUp, TrendingDown, Info } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

export default function KpiCard({ 
  title, 
  value, 
  change, 
  trend, 
  source,
  icon: Icon,
  isLoading = false 
}) {
  if (isLoading) {
    return (
      <Card className="border-gray-200 shadow-sm">
        <CardHeader className="pb-3">
          <Skeleton className="h-4 w-3/4 mb-2" />
          <Skeleton className="h-8 w-1/2" />
          <Skeleton className="h-4 w-1/2 mt-4" />
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card className="border-gray-200 shadow-sm hover:shadow-md transition-all duration-300">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <p className="text-sm font-medium text-gray-600">{title}</p>
              {source && (
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Info className="w-3 h-3 text-gray-400 cursor-help" />
                    </TooltipTrigger>
                    <TooltipContent>
                      <p className="text-xs max-w-48">{source}</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              )}
            </div>
            <CardTitle className="text-3xl font-bold text-gray-900 mt-2">
              {value}
            </CardTitle>
          </div>
          {Icon && (
            <div className="p-3 rounded-xl bg-gray-50 border border-gray-100">
              <Icon className="w-6 h-6 text-gray-600 stroke-1" />
            </div>
          )}
        </div>
        {change && change !== "N/A" && (
          <div className="flex items-center mt-4 text-sm">
            {trend === 'up' ? (
              <TrendingUp className="w-4 h-4 mr-1 text-emerald-500 stroke-1" />
            ) : (
              <TrendingDown className="w-4 h-4 mr-1 text-red-500 stroke-1" />
            )}
            <span className={trend === 'up' ? 'text-emerald-600' : 'text-red-600'}>
              {change}
            </span>
            <span className="text-gray-500 ml-1">vs previous year</span>
          </div>
        )}
      </CardHeader>
    </Card>
  );
}