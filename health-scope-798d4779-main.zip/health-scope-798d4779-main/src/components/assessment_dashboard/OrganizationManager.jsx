import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Organization } from '@/entities/Organization';
import { Plus, Users, Search, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

export default function OrganizationManager({ assessment, onOrganizationsChange }) {
    const [isOpen, setIsOpen] = useState(false);
    const [allOrganizations, setAllOrganizations] = useState([]);
    const [selectedOrgs, setSelectedOrgs] = useState(assessment?.organizations || []);
    const [isLoading, setIsLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        if (isOpen) {
            loadAllOrganizations();
        }
        // Sync with parent state when component mounts or assessment changes
        setSelectedOrgs(assessment?.organizations || []);
    }, [isOpen, assessment?.organizations]);

    const loadAllOrganizations = async () => {
        setIsLoading(true);
        try {
            const orgs = await Organization.list();
            setAllOrganizations(orgs);
        } catch (error) {
            toast.error("Failed to load organizations.");
            console.error(error);
        }
        setIsLoading(false);
    };

    const handleSave = () => {
        onOrganizationsChange(selectedOrgs);
        setIsOpen(false);
        toast.success("Organization list updated.");
    };

    const handleCheckboxChange = (orgName, checked) => {
        if (checked) {
            setSelectedOrgs(prev => [...prev, orgName]);
        } else {
            setSelectedOrgs(prev => prev.filter(name => name !== orgName));
        }
    };

    const filteredOrganizations = allOrganizations.filter(org => 
        org.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        org.city?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        org.state?.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div>
            <div className="p-3 bg-gray-50 rounded-lg border text-center">
                {assessment.organizations && assessment.organizations.length > 0 ? (
                    <div className="text-left text-sm text-gray-800">
                        {assessment.organizations.length} selected
                    </div>
                ) : (
                    <div className="text-sm text-gray-500">No organizations selected yet</div>
                )}
            </div>
            
            <Dialog open={isOpen} onOpenChange={setIsOpen}>
                <DialogTrigger asChild>
                    <Button variant="outline" className="w-full mt-2 border-gray-300 text-gray-700 hover:bg-gray-50">
                        <Plus className="w-4 h-4 mr-2" />
                        Add / Manage Organizations
                    </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[600px]">
                    <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                            <Users className="w-5 h-5" />
                            Manage Organizations
                        </DialogTitle>
                    </DialogHeader>
                    <div className="py-4 space-y-4">
                        <div className="relative">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                            <Input 
                                placeholder="Search by name, city, or state..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="pl-10"
                            />
                        </div>

                        <ScrollArea className="h-72 border rounded-md">
                            <div className="p-4 space-y-3">
                                {isLoading ? (
                                    <div className="flex justify-center items-center h-full">
                                        <Loader2 className="w-6 h-6 animate-spin text-gray-400" />
                                    </div>
                                ) : (
                                    filteredOrganizations.map(org => (
                                        <div key={org.id} className="flex items-center space-x-3 p-2 rounded-md hover:bg-gray-50">
                                            <Checkbox
                                                id={org.id}
                                                checked={selectedOrgs.includes(org.name)}
                                                onCheckedChange={(checked) => handleCheckboxChange(org.name, checked)}
                                            />
                                            <label htmlFor={org.id} className="flex-1 cursor-pointer">
                                                <div className="font-medium">{org.name}</div>
                                                <div className="text-xs text-gray-500">
                                                    {org.city}, {org.state} - <span className="capitalize">{org.type}</span>
                                                </div>
                                            </label>
                                        </div>
                                    ))
                                )}
                                {!isLoading && filteredOrganizations.length === 0 && (
                                    <div className="text-center text-sm text-gray-500 py-8">
                                        No organizations found.
                                    </div>
                                )}
                            </div>
                        </ScrollArea>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setIsOpen(false)}>Cancel</Button>
                        <Button onClick={handleSave}>Save Changes</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    );
}