
import React from 'react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from '@/components/ui/badge';
import { Save, Share, Download, Edit, Rocket, RefreshCw, Loader2 } from 'lucide-react'; // Import RefreshCw and Loader2

export default function AssessmentDashboardHeader({ 
  assessment, 
  onStatusChange, 
  onSave, 
  onPublish, 
  onEdit, 
  onReprocess, 
  isReprocessing 
}) {
  const statusColors = {
    draft: "bg-yellow-100 text-yellow-800 border-yellow-200",
    published: "bg-emerald-100 text-emerald-800 border-emerald-200",
    archived: "bg-gray-100 text-gray-800 border-gray-200"
  };

  return (
    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">{assessment.title}</h1>
      </div>
      
      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 w-full sm:w-auto">
        <Button 
          variant="outline" 
          className="border-blue-300 text-blue-700 hover:bg-blue-50 flex-1 sm:flex-none" 
          onClick={onReprocess}
          disabled={isReprocessing}
        >
          {isReprocessing ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 stroke-1 animate-spin" />
              Processing...
            </>
          ) : (
            <>
              <RefreshCw className="w-4 h-4 mr-2 stroke-1" />
              Reprocess
            </>
          )}
        </Button>
        
        <div className="flex items-center gap-2 w-full sm:w-auto">
            <Select value={assessment.status} onValueChange={onStatusChange}>
                <SelectTrigger className="w-full sm:w-[130px] bg-white border-gray-300 text-gray-700">
                    <SelectValue placeholder="Set status" />
                </SelectTrigger>
                <SelectContent>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="published">Published</SelectItem>
                    <SelectItem value="archived">Archived</SelectItem>
                </SelectContent>
            </Select>
            <Badge className={`${statusColors[assessment.status]} hidden sm:inline-flex capitalize`}>
                {assessment.status}
            </Badge>
        </div>
        <div className="flex gap-2 w-full sm:w-auto">
            <Button variant="outline" className="border-gray-300 text-gray-700 hover:bg-gray-50 flex-1 sm:flex-none" onClick={onSave}>
              <Save className="w-4 h-4 mr-2 stroke-1" />
              Save Draft
            </Button>
            {assessment.status === 'draft' && (
              <Button className="bg-emerald-500 hover:bg-emerald-600 text-white flex-1 sm:flex-none" onClick={onPublish}>
                <Rocket className="w-4 h-4 mr-2 stroke-1" />
                Publish
              </Button>
            )}
        </div>
      </div>
    </div>
  );
}
