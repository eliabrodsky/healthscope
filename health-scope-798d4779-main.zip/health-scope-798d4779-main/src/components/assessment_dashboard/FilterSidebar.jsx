import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { SlidersHorizontal, Edit, MapPin } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import DataSourceManager from './DataSourceManager';
import OrganizationManager from './OrganizationManager';

export default function FilterSidebar({ 
  assessment, 
  onOrganizationsChange,
  onGeographyChange,
  mapOverlay,
  onMapOverlayChange,
  mapOrganizationTypes,
  onMapOrganizationTypesChange,
}) {
  const getGeographyDisplay = () => {
    if (!assessment?.geography) return "Not specified";
    const { state, county, city } = assessment.geography;
    const parts = [city, county, state].filter(Boolean);
    if (parts.length > 0) return parts.join(', ');
    return "Custom Region";
  };

  const handleEditSection = (section) => {
    // Placeholder for future edit functionality
    console.log(`Edit ${section} functionality will be implemented`);
  };

  return (
    <div className="space-y-6">
      <Card className="border-gray-200 shadow-sm">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-base font-semibold text-gray-800 flex items-center gap-2">
            <SlidersHorizontal className="w-4 h-4 stroke-1" />
            Assessment Configuration
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6 pt-4">
          
          {/* Territory */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <h4 className="text-sm font-medium text-gray-600">Territory</h4>
              <Button variant="ghost" size="sm" onClick={() => handleEditSection('territory')} className="h-7 -mr-2">
                <Edit className="w-3 h-3 mr-1" /> Edit
              </Button>
            </div>
            <div className="flex items-start gap-2 text-gray-800 p-3 bg-gray-50 rounded-lg border border-gray-200">
              <MapPin className="w-4 h-4 text-gray-500 stroke-1 flex-shrink-0 mt-0.5" />
              <span className="font-medium break-words text-sm">{getGeographyDisplay()}</span>
            </div>
          </div>

          {/* Organizations */}
          <div className="space-y-2">
            <h4 className="text-sm font-medium text-gray-600">Organizations ({assessment.organizations?.length || 0})</h4>
            <OrganizationManager 
              assessment={assessment}
              onOrganizationsChange={onOrganizationsChange}
            />
          </div>
          
          {/* Map Filters */}
          <div className="space-y-2">
            <h4 className="text-sm font-medium text-gray-600">Map Filters</h4>
            <div className="space-y-4 p-3 bg-gray-50 rounded-lg border border-gray-200">
              {/* Overlay Selection */}
              <div>
                <label className="text-xs font-medium text-gray-700 mb-1.5 block">Data Overlay</label>
                <Select value={mapOverlay} onValueChange={onMapOverlayChange}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="population">Population</SelectItem>
                    <SelectItem value="income">Median Income</SelectItem>
                    <SelectItem value="poverty">Poverty Rate</SelectItem>
                    <SelectItem value="uninsured">Uninsured Rate</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Organization Type Filters */}
              <div>
                <label className="text-xs font-medium text-gray-700 mb-1.5 block">Show Facilities</label>
                <div className="flex flex-wrap gap-1.5">
                  {['hospital', 'fqhc', 'clinic', 'safety_net'].map((type) => (
                    <Button
                      key={type}
                      variant={mapOrganizationTypes.includes(type) ? "default" : "outline"}
                      size="sm"
                      onClick={() => {
                        const newTypes = mapOrganizationTypes.includes(type)
                          ? mapOrganizationTypes.filter(t => t !== type)
                          : [...mapOrganizationTypes, type];
                        onMapOrganizationTypesChange(newTypes);
                      }}
                      className="text-xs capitalize h-8 px-2.5"
                    >
                      {type === 'fqhc' ? 'FQHC' : type.replace('_', ' ')}
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Data Sources */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <h4 className="text-sm font-medium text-gray-600">Data Sources</h4>
              <Button variant="ghost" size="sm" onClick={() => handleEditSection('data_sources')} className="h-7 -mr-2">
                <Edit className="w-3 h-3 mr-1" /> Edit
              </Button>
            </div>
            <DataSourceManager dataSources={assessment.data_sources || []} />
          </div>
          
        </CardContent>
      </Card>
    </div>
  );
}