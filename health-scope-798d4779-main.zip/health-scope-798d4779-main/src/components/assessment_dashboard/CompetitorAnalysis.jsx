
import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
} from 'recharts';
import { 
  DollarSign, 
  Users, 
  Building, 
  Stethoscope, 
  MapPin,
  TrendingUp // Kept TrendingUp for the main card title
} from 'lucide-react';
// toast and MessageSquare/MapIcon related logic removed as per outline's implied structure change.

// Generate mock demographic data for organizations
const generateDemographics = (org) => ({
  race: {
    white: Math.floor(Math.random() * 40) + 30,
    black: Math.floor(Math.random() * 30) + 15,
    hispanic: Math.floor(Math.random() * 25) + 10,
    asian: Math.floor(Math.random() * 15) + 5,
    other: Math.floor(Math.random() * 10) + 5
  },
  insurance: {
    medicaid: Math.floor(Math.random() * 40) + 30,
    medicare: Math.floor(Math.random() * 25) + 15,
    private: Math.floor(Math.random() * 30) + 20,
    uninsured: Math.floor(Math.random() * 15) + 5
  },
  language: {
    english: Math.floor(Math.random() * 20) + 75,
    spanish: Math.floor(Math.random() * 20) + 10,
    other: Math.floor(Math.random() * 10) + 5
  },
  age: {
    '0-17': Math.floor(Math.random() * 15) + 20,
    '18-34': Math.floor(Math.random() * 15) + 25,
    '35-54': Math.floor(Math.random() * 15) + 25,
    '55+': Math.floor(Math.random() * 15) + 20
  }
});

const KPICard = ({ title, value, icon: Icon }) => (
  <Card className="flex flex-col items-center p-4 text-center">
    <Icon className="h-6 w-6 text-blue-500 mb-2" />
    <div className="text-sm font-medium text-gray-500">{title}</div>
    <div className="text-2xl font-bold">{value}</div>
  </Card>
);

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="rounded-lg border bg-background p-2 text-sm shadow-md">
        <p className="font-bold">{label}</p>
        {payload.map((entry, index) => (
          <p key={`item-${index}`} style={{ color: entry.color }}>
            {entry.name}: {entry.value.toLocaleString()}
          </p>
        ))}
        {data.marketShare && <p>Market Share: {data.marketShare.toFixed(1)}%</p>}
        {data.revenue && <p>Est. Revenue: ${data.revenue.toLocaleString()}</p>}
      </div>
    );
  }
  return null;
};

export default function CompetitorAnalysis({ organizations, assessment }) {
  const [analysisType, setAnalysisType] = useState('services');
  const [demographicView, setDemographicView] = useState('race');
  // customQuestion and showMap related states and handlers removed as per outline's implied structure change.

  const analysisData = useMemo(() => {
    const totalMarketSize = (assessment?.processed_data?.zip_codes?.length || 2) * 15000; // Estimated market size

    const processedOrganizations = organizations.map(org => {
      const patient_volume = org.patient_volume || 0;
      const demographics = generateDemographics(org);
      const estimatedRevenue = patient_volume * 1200; // $1200 average revenue per patient
      return {
        ...org,
        patient_volume,
        demographics,
        estimatedRevenue,
      };
    });

    const totalCompetitorVolume = processedOrganizations.reduce((sum, org) => sum + org.patient_volume, 0);

    const detailed = processedOrganizations.map(org => ({
      ...org,
      market_share: totalCompetitorVolume > 0 ? ((org.patient_volume / totalCompetitorVolume) * 100) : 0,
      est_revenue: org.estimatedRevenue,
    }));

    const summary = {
      totalCompetitors: organizations.length,
      totalPatientVolume: totalCompetitorVolume,
      totalServices: [...new Set(organizations.flatMap(org => org.services || []))].length,
      estimatedMarketRevenue: detailed.reduce((sum, org) => sum + org.est_revenue, 0),
    };

    const allServices = [...new Set(organizations.flatMap(org => org.services || []))];
    const serviceComparison = allServices.map(service => {
      const data = { service };
      organizations.forEach(org => {
        data[org.name] = (org.services || []).includes(service) ? 1 : 0;
      });
      return data;
    });

    return { summary, detailed, serviceComparison };
  }, [organizations, assessment]);

  const { summary, detailed: detailedData, serviceComparison } = analysisData;

  const patientVolumeData = useMemo(() => 
    detailedData.map(org => ({
      name: org.name.length > 20 ? `${org.name.substring(0, 18)}...` : org.name,
      'Patient Volume': org.patient_volume,
      marketShare: org.market_share,
      revenue: org.est_revenue,
    })), [detailedData]);

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d']; // Kept for consistency if future PieChart is added

  return (
    <Card className="space-y-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="w-5 h-5" />
          Competitor Analysis Dashboard
        </CardTitle>
        <CardDescription>
          Gain insights into your competitors' service offerings, patient volumes, demographics, and market share.
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Summary KPIs */}
        <div className="grid md:grid-cols-4 gap-4">
          <KPICard 
            title="Total Competitors" 
            value={summary.totalCompetitors} 
            icon={Building} 
          />
          <KPICard 
            title="Total Patient Volume" 
            value={summary.totalPatientVolume.toLocaleString()} 
            icon={Users} 
          />
          <KPICard 
            title="Total Services Offered" 
            value={summary.totalServices} 
            icon={Stethoscope} 
          />
          <KPICard 
            title="Est. Market Revenue" 
            value={`$${(summary.estimatedMarketRevenue / 1000000).toFixed(1)}M`} 
            icon={DollarSign} 
          />
        </div>

        {/* Main Analysis Tabs */}
        <Tabs value={analysisType} onValueChange={setAnalysisType} className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="services">Services</TabsTrigger>
            <TabsTrigger value="patient_volume">Patient Volume</TabsTrigger>
            <TabsTrigger value="demographics">Demographics</TabsTrigger>
            <TabsTrigger value="market_share">Market Share</TabsTrigger>
          </TabsList>

          {/* Service Comparison */}
          <TabsContent value="services" className="pt-4">
            <h3 className="text-lg font-semibold mb-2">Service Offerings Comparison</h3>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="min-w-[150px]">Service</TableHead>
                    {organizations.map(org => (
                      <TableHead key={org.id} className="text-center min-w-[100px]">
                        {org.name.length > 15 ? org.name.substring(0, 15) + '...' : org.name}
                      </TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {serviceComparison.map(service => (
                    <TableRow key={service.service}>
                      <TableCell className="font-medium">{service.service}</TableCell>
                      {organizations.map(org => (
                        <TableCell key={org.id} className="text-center">
                          {(org.services || []).includes(service.service) ? (
                            <Badge className="bg-emerald-100 text-emerald-800">✓</Badge>
                          ) : (
                            <span className="text-gray-300">—</span>
                          )}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          {/* Patient Volume Comparison */}
          <TabsContent value="patient_volume" className="pt-4">
            <h3 className="text-lg font-semibold mb-2">Patient Volume & Market Share</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={patientVolumeData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="name" 
                  angle={-45} 
                  textAnchor="end" 
                  height={80} 
                  interval={0}
                  style={{ fontSize: '12px' }}
                />
                <YAxis />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <Bar dataKey="Patient Volume" fill="#8884d8" />
              </BarChart>
            </ResponsiveContainer>
          </TabsContent>

          {/* Demographics Comparison */}
          <TabsContent value="demographics" className="pt-4">
            <div className="flex justify-between items-center mb-2">
              <h3 className="text-lg font-semibold">Patient Demographics Comparison</h3>
              <Select value={demographicView} onValueChange={setDemographicView}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="race">Race</SelectItem>
                  <SelectItem value="insurance">Insurance</SelectItem>
                  <SelectItem value="language">Language</SelectItem>
                  <SelectItem value="age">Age Groups</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="min-w-[120px]">Organization</TableHead>
                    {Object.keys(detailedData[0]?.demographics?.[demographicView] || {}).map(category => (
                      <TableHead key={category} className="text-center capitalize min-w-[80px]">{category}</TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {detailedData.map(org => (
                    <TableRow key={org.id}>
                      <TableCell className="font-medium">
                        {org.name.length > 20 ? org.name.substring(0, 20) + '...' : org.name}
                      </TableCell>
                      {Object.entries(org.demographics[demographicView]).map(([category, percentage]) => (
                        <TableCell key={category} className="text-center">
                          {percentage}%
                        </TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          {/* Market Share Analysis */}
          <TabsContent value="market_share" className="pt-4">
            <h3 className="text-lg font-semibold mb-2">Detailed Market Analysis</h3>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="min-w-[150px]">Organization</TableHead>
                    <TableHead className="text-right min-w-[100px]">Patient Volume</TableHead>
                    <TableHead className="text-right min-w-[100px]">Market Share</TableHead>
                    <TableHead className="text-right min-w-[120px]">Est. Revenue</TableHead>
                    <TableHead className="min-w-[150px]">Primary Services</TableHead>
                    <TableHead className="min-w-[120px]">Location</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {detailedData.map(org => (
                    <TableRow key={org.id}>
                      <TableCell className="font-medium">{org.name}</TableCell>
                      <TableCell className="text-right">{org.patient_volume.toLocaleString()}</TableCell>
                      <TableCell className="text-right">{org.market_share.toFixed(1)}%</TableCell>
                      <TableCell className="text-right">${(org.est_revenue / 1000000).toFixed(1)}M</TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {(org.services || []).slice(0, 2).map(service => (
                            <Badge key={service} variant="secondary" className="text-xs">
                              {service}
                            </Badge>
                          ))}
                          {(org.services || []).length > 2 && (
                            <Badge variant="outline" className="text-xs">
                              +{(org.services || []).length - 2}
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-gray-400" />
                          <span className="text-sm">{org.city}, {org.state}</span>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
