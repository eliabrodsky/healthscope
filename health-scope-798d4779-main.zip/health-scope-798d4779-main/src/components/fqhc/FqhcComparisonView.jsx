import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { X, TrendingUp, TrendingDown, Minus } from 'lucide-react';

export default function FqhcComparisonView({ fqhcs, onRemove }) {
  const formatNumber = (num) => {
    if (!num && num !== 0) return '—';
    return num.toLocaleString();
  };

  const formatCurrency = (num) => {
    if (!num) return '—';
    if (num >= 1000000) return `$${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `$${(num / 1000).toFixed(0)}K`;
    return `$${num.toLocaleString()}`;
  };

  const formatPercent = (num) => {
    if (!num && num !== 0) return '—';
    return `${num.toFixed(1)}%`;
  };

  // Calculate averages for comparison
  const averages = {
    total_patients: fqhcs.reduce((sum, f) => sum + (f.total_patients || 0), 0) / fqhcs.length,
    total_fte: fqhcs.reduce((sum, f) => sum + (f.workforce?.total_fte || 0), 0) / fqhcs.length,
    cost_per_patient: fqhcs.reduce((sum, f) => sum + (f.financials?.cost_per_patient || 0), 0) / fqhcs.length,
    htn_control: fqhcs.reduce((sum, f) => sum + (f.clinical_metrics?.htn_control_pct || 0), 0) / fqhcs.length,
    diabetes_poor: fqhcs.reduce((sum, f) => sum + (f.clinical_metrics?.diabetes_poor_control_pct || 0), 0) / fqhcs.length,
  };

  const getTrend = (value, avg, higherIsBetter = true) => {
    if (!value || !avg) return null;
    const diff = ((value - avg) / avg) * 100;
    if (Math.abs(diff) < 5) return { icon: Minus, color: 'text-gray-400' };
    if (higherIsBetter) {
      return diff > 0 
        ? { icon: TrendingUp, color: 'text-emerald-600' }
        : { icon: TrendingDown, color: 'text-red-600' };
    } else {
      return diff < 0 
        ? { icon: TrendingUp, color: 'text-emerald-600' }
        : { icon: TrendingDown, color: 'text-red-600' };
    }
  };

  const comparisonMetrics = [
    { key: 'total_patients', label: 'Total Patients', getValue: f => f.total_patients, format: formatNumber, higherIsBetter: true, avg: averages.total_patients },
    { key: 'sites', label: 'Sites', getValue: f => f.sites?.length || 1, format: formatNumber, higherIsBetter: null },
    { key: 'total_fte', label: 'Total FTEs', getValue: f => f.workforce?.total_fte, format: v => v?.toFixed(1) || '—', higherIsBetter: null, avg: averages.total_fte },
    { key: 'physician_fte', label: 'Physician FTEs', getValue: f => f.workforce?.physician_fte, format: v => v?.toFixed(1) || '—', higherIsBetter: null },
    { key: 'medicaid_pct', label: 'Medicaid %', getValue: f => f.payer_mix && f.total_patients ? (f.payer_mix.medicaid / f.total_patients) * 100 : null, format: formatPercent, higherIsBetter: null },
    { key: 'uninsured_pct', label: 'Uninsured %', getValue: f => f.payer_mix && f.total_patients ? (f.payer_mix.uninsured / f.total_patients) * 100 : null, format: formatPercent, higherIsBetter: null },
    { key: 'htn_control', label: 'HTN Control %', getValue: f => f.clinical_metrics?.htn_control_pct, format: formatPercent, higherIsBetter: true, avg: averages.htn_control },
    { key: 'diabetes_poor', label: 'Diabetes Poor Control %', getValue: f => f.clinical_metrics?.diabetes_poor_control_pct, format: formatPercent, higherIsBetter: false, avg: averages.diabetes_poor },
    { key: 'total_revenue', label: 'Total Revenue', getValue: f => f.financials?.total_revenue, format: formatCurrency, higherIsBetter: true },
    { key: 'cost_per_patient', label: 'Cost per Patient', getValue: f => f.financials?.cost_per_patient, format: formatCurrency, higherIsBetter: false, avg: averages.cost_per_patient },
  ];

  return (
    <div className="space-y-6">
      <div className="text-sm text-gray-600">
        Comparing {fqhcs.length} FQHCs. Trends shown relative to group average.
      </div>

      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr className="border-b-2 border-gray-200">
              <th className="text-left py-3 px-4 font-semibold text-gray-700 sticky left-0 bg-white">
                Metric
              </th>
              {fqhcs.map((fqhc, idx) => (
                <th key={idx} className="text-center py-3 px-4 min-w-[180px]">
                  <div className="flex flex-col items-center gap-1">
                    <span className="font-semibold text-gray-900 text-sm">
                      {(fqhc.health_center_name || fqhc.name).substring(0, 25)}...
                    </span>
                    <Badge variant="outline" className="text-xs">
                      {fqhc.city}, {fqhc.state}
                    </Badge>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-6 w-6 p-0 text-gray-400 hover:text-red-600"
                      onClick={() => onRemove(fqhc.id || fqhc.bhcmis_id)}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {comparisonMetrics.map((metric, idx) => (
              <tr key={metric.key} className={idx % 2 === 0 ? 'bg-gray-50' : 'bg-white'}>
                <td className="py-3 px-4 font-medium text-gray-700 sticky left-0 bg-inherit">
                  {metric.label}
                </td>
                {fqhcs.map((fqhc, fIdx) => {
                  const value = metric.getValue(fqhc);
                  const trend = metric.avg && metric.higherIsBetter !== null 
                    ? getTrend(value, metric.avg, metric.higherIsBetter)
                    : null;
                  
                  return (
                    <td key={fIdx} className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <span className="font-semibold">{metric.format(value)}</span>
                        {trend && (
                          <trend.icon className={`w-4 h-4 ${trend.color}`} />
                        )}
                      </div>
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Summary Cards */}
      <div className="grid md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Largest by Patients</CardTitle>
          </CardHeader>
          <CardContent>
            {(() => {
              const largest = [...fqhcs].sort((a, b) => (b.total_patients || 0) - (a.total_patients || 0))[0];
              return (
                <div>
                  <p className="font-semibold">{largest?.health_center_name || largest?.name}</p>
                  <p className="text-2xl font-bold text-emerald-600">
                    {formatNumber(largest?.total_patients)}
                  </p>
                </div>
              );
            })()}
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Best HTN Control</CardTitle>
          </CardHeader>
          <CardContent>
            {(() => {
              const best = [...fqhcs].filter(f => f.clinical_metrics?.htn_control_pct)
                .sort((a, b) => (b.clinical_metrics?.htn_control_pct || 0) - (a.clinical_metrics?.htn_control_pct || 0))[0];
              return best ? (
                <div>
                  <p className="font-semibold">{best?.health_center_name || best?.name}</p>
                  <p className="text-2xl font-bold text-blue-600">
                    {formatPercent(best?.clinical_metrics?.htn_control_pct)}
                  </p>
                </div>
              ) : <p className="text-gray-500">No data</p>;
            })()}
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Lowest Cost per Patient</CardTitle>
          </CardHeader>
          <CardContent>
            {(() => {
              const lowest = [...fqhcs].filter(f => f.financials?.cost_per_patient)
                .sort((a, b) => (a.financials?.cost_per_patient || Infinity) - (b.financials?.cost_per_patient || Infinity))[0];
              return lowest ? (
                <div>
                  <p className="font-semibold">{lowest?.health_center_name || lowest?.name}</p>
                  <p className="text-2xl font-bold text-amber-600">
                    {formatCurrency(lowest?.financials?.cost_per_patient)}
                  </p>
                </div>
              ) : <p className="text-gray-500">No data</p>;
            })()}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}