import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  ArrowLeft, 
  Plus, 
  Users, 
  MapPin, 
  DollarSign,
  Stethoscope,
  Clock,
  TrendingUp,
  ExternalLink
} from 'lucide-react';

export default function FqhcDetailPanel({ fqhc, onBack, onAddToComparison, onViewServiceArea, onViewYoY, embedded }) {
  const formatNumber = (num) => {
    if (!num && num !== 0) return '—';
    return num.toLocaleString();
  };

  const formatCurrency = (num) => {
    if (!num) return '—';
    if (num >= 1000000) return `$${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `$${(num / 1000).toFixed(0)}K`;
    return `$${num.toLocaleString()}`;
  };

  const formatPercent = (num) => {
    if (!num && num !== 0) return '—';
    return `${num.toFixed(1)}%`;
  };

  return (
    <div className="p-6">
      {/* Header - Compact */}
      <div className="mb-6">
        <div className="flex items-center gap-3 mb-3">
          <Button variant="ghost" size="sm" onClick={onBack} className="h-8 px-2">
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="flex-1 min-w-0">
            <h2 className="text-xl font-bold text-gray-900 truncate">
              {fqhc.health_center_name || fqhc.name}
            </h2>
            <p className="text-sm text-gray-500">
              {fqhc.city}, {fqhc.state} {fqhc.zip_code}
              {fqhc.urban_rural_flag && (
                <Badge variant="outline" className="ml-2 text-xs">{fqhc.urban_rural_flag}</Badge>
              )}
            </p>
          </div>
        </div>
        
        {/* Quick Actions */}
        <div className="flex flex-wrap gap-2">
          {onViewServiceArea && fqhc.service_area_zips?.length > 0 && (
            <Button size="sm" className="h-8 bg-emerald-600 hover:bg-emerald-700" onClick={onViewServiceArea}>
              <MapPin className="w-3 h-3 mr-1" /> Service Area
            </Button>
          )}
          {onViewYoY && (
            <Button size="sm" variant="outline" className="h-8" onClick={onViewYoY}>
              <TrendingUp className="w-3 h-3 mr-1" /> Trends
            </Button>
          )}
          <Button size="sm" variant="outline" className="h-8" onClick={onAddToComparison}>
            <Plus className="w-3 h-3 mr-1" /> Compare
          </Button>
        </div>
      </div>

      {/* Key Metrics - Inline */}
      <div className="grid grid-cols-4 gap-3 mb-6">
        <div className="text-center p-3 bg-blue-50 rounded-lg">
          <p className="text-xl font-bold text-blue-700">{formatNumber(fqhc.total_patients)}</p>
          <p className="text-xs text-blue-600">Patients</p>
        </div>
        <div className="text-center p-3 bg-purple-50 rounded-lg">
          <p className="text-xl font-bold text-purple-700">{fqhc.sites?.length || 1}</p>
          <p className="text-xs text-purple-600">Sites</p>
        </div>
        <div className="text-center p-3 bg-emerald-50 rounded-lg">
          <p className="text-xl font-bold text-emerald-700">{fqhc.workforce?.total_fte?.toFixed(0) || '—'}</p>
          <p className="text-xs text-emerald-600">FTEs</p>
        </div>
        <div className="text-center p-3 bg-amber-50 rounded-lg">
          <p className="text-xl font-bold text-amber-700">{formatCurrency(fqhc.financials?.total_revenue)}</p>
          <p className="text-xs text-amber-600">Revenue</p>
        </div>
      </div>

      {/* Source Badge */}
      {fqhc.uds_year && (
        <div className="flex items-center gap-2 text-xs mb-4">
          <Badge variant="outline" className="bg-emerald-50 text-emerald-700 border-emerald-200">
            UDS {fqhc.uds_year}
          </Badge>
          {fqhc.bhcmis_id && (
            <span className="text-gray-400">ID: {fqhc.bhcmis_id}</span>
          )}
        </div>
      )}

      <Tabs defaultValue="overview">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="patients">Patients</TabsTrigger>
          <TabsTrigger value="workforce">Workforce</TabsTrigger>
          <TabsTrigger value="clinical">Clinical</TabsTrigger>
          <TabsTrigger value="financial">Financial</TabsTrigger>
          <TabsTrigger value="sites">Sites ({fqhc.sites?.length || 0})</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4 mt-4">
          {/* Payer Mix */}
          {fqhc.payer_mix && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Payer Mix</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-4 gap-4">
                  <div className="text-center p-3 bg-blue-50 rounded-lg">
                    <p className="text-xl font-bold text-blue-700">
                      {formatPercent((fqhc.payer_mix.medicaid / fqhc.total_patients) * 100)}
                    </p>
                    <p className="text-sm text-blue-600">Medicaid</p>
                    <p className="text-xs text-gray-500">{formatNumber(fqhc.payer_mix.medicaid)}</p>
                  </div>
                  <div className="text-center p-3 bg-green-50 rounded-lg">
                    <p className="text-xl font-bold text-green-700">
                      {formatPercent((fqhc.payer_mix.medicare / fqhc.total_patients) * 100)}
                    </p>
                    <p className="text-sm text-green-600">Medicare</p>
                    <p className="text-xs text-gray-500">{formatNumber(fqhc.payer_mix.medicare)}</p>
                  </div>
                  <div className="text-center p-3 bg-purple-50 rounded-lg">
                    <p className="text-xl font-bold text-purple-700">
                      {formatPercent((fqhc.payer_mix.private / fqhc.total_patients) * 100)}
                    </p>
                    <p className="text-sm text-purple-600">Private</p>
                    <p className="text-xs text-gray-500">{formatNumber(fqhc.payer_mix.private)}</p>
                  </div>
                  <div className="text-center p-3 bg-amber-50 rounded-lg">
                    <p className="text-xl font-bold text-amber-700">
                      {formatPercent((fqhc.payer_mix.uninsured / fqhc.total_patients) * 100)}
                    </p>
                    <p className="text-sm text-amber-600">Uninsured</p>
                    <p className="text-xs text-gray-500">{formatNumber(fqhc.payer_mix.uninsured)}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Service Area */}
          {fqhc.service_area_zips?.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Service Area ({fqhc.service_area_zips.length} ZIP codes)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto max-h-64">
                  <table className="w-full text-sm">
                    <thead className="bg-gray-100 sticky top-0">
                      <tr>
                        <th className="text-left p-2">ZIP</th>
                        <th className="text-right p-2">Patients</th>
                        <th className="text-right p-2">Medicaid</th>
                        <th className="text-right p-2">Medicare</th>
                        <th className="text-right p-2">Uninsured</th>
                      </tr>
                    </thead>
                    <tbody>
                      {fqhc.service_area_zips.slice(0, 25).map((zip, idx) => (
                        <tr key={idx} className="border-b border-gray-100 hover:bg-gray-50">
                          <td className="p-2 font-medium">{zip.zip_code}</td>
                          <td className="p-2 text-right">{formatNumber(zip.patients || zip.total_patients)}</td>
                          <td className="p-2 text-right text-blue-600">{formatNumber(zip.medicaid)}</td>
                          <td className="p-2 text-right text-green-600">{formatNumber(zip.medicare)}</td>
                          <td className="p-2 text-right text-amber-600">{formatNumber(zip.uninsured)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {fqhc.service_area_zips.length > 25 && (
                  <p className="text-sm text-gray-500 mt-2">
                    +{fqhc.service_area_zips.length - 25} more ZIP codes
                  </p>
                )}
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="patients" className="space-y-4 mt-4">
          {fqhc.demographics && (
            <div className="grid md:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Age Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span>Children (0-17)</span>
                      <span className="font-semibold">{formatNumber(fqhc.demographics.age_0_17)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Adults (18-64)</span>
                      <span className="font-semibold">{formatNumber(fqhc.demographics.age_18_64)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Seniors (65+)</span>
                      <span className="font-semibold">{formatNumber(fqhc.demographics.age_65_plus)}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Special Populations</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span>Homeless</span>
                      <span className="font-semibold">{formatNumber(fqhc.demographics.homeless)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Migrant/Seasonal</span>
                      <span className="font-semibold">{formatNumber(fqhc.demographics.migrant)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Agricultural Workers</span>
                      <span className="font-semibold">{formatNumber(fqhc.demographics.agricultural_worker)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Public Housing</span>
                      <span className="font-semibold">{formatNumber(fqhc.demographics.public_housing)}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>

        <TabsContent value="workforce" className="space-y-4 mt-4">
          {fqhc.workforce && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Workforce Composition</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <p className="text-2xl font-bold text-blue-700">{fqhc.workforce.physician_fte?.toFixed(1) || '—'}</p>
                    <p className="text-sm text-blue-600">Physicians FTE</p>
                  </div>
                  <div className="p-4 bg-green-50 rounded-lg">
                    <p className="text-2xl font-bold text-green-700">{fqhc.workforce.np_pa_fte?.toFixed(1) || '—'}</p>
                    <p className="text-sm text-green-600">NP/PA FTE</p>
                  </div>
                  <div className="p-4 bg-purple-50 rounded-lg">
                    <p className="text-2xl font-bold text-purple-700">{fqhc.workforce.dental_fte?.toFixed(1) || '—'}</p>
                    <p className="text-sm text-purple-600">Dental FTE</p>
                  </div>
                  <div className="p-4 bg-amber-50 rounded-lg">
                    <p className="text-2xl font-bold text-amber-700">{fqhc.workforce.behavioral_health_fte?.toFixed(1) || '—'}</p>
                    <p className="text-sm text-amber-600">Behavioral Health FTE</p>
                  </div>
                  <div className="p-4 bg-teal-50 rounded-lg">
                    <p className="text-2xl font-bold text-teal-700">{fqhc.workforce.enabling_services_fte?.toFixed(1) || '—'}</p>
                    <p className="text-sm text-teal-600">Enabling Services FTE</p>
                  </div>
                  <div className="p-4 bg-gray-100 rounded-lg">
                    <p className="text-2xl font-bold text-gray-700">{fqhc.workforce.total_fte?.toFixed(1) || '—'}</p>
                    <p className="text-sm text-gray-600">Total FTE</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="clinical" className="space-y-4 mt-4">
          {fqhc.clinical_metrics && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Clinical Quality Measures</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium">Hypertension Control</p>
                      <p className="text-sm text-gray-500">BP controlled among hypertensive patients</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-emerald-600">
                        {formatPercent(fqhc.clinical_metrics.htn_control_pct)}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium">Diabetes Poor Control</p>
                      <p className="text-sm text-gray-500">A1c &gt; 9% (lower is better)</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-red-600">
                        {formatPercent(fqhc.clinical_metrics.diabetes_poor_control_pct)}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium">Colorectal Cancer Screening</p>
                      <p className="text-sm text-gray-500">Patients 50-75 screened</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-blue-600">
                        {formatPercent(fqhc.clinical_metrics.colorectal_screening_pct)}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium">Depression Screening</p>
                      <p className="text-sm text-gray-500">Adults screened with follow-up</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold text-purple-600">
                        {formatPercent(fqhc.clinical_metrics.depression_screening_pct)}
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="financial" className="space-y-4 mt-4">
          {fqhc.financials ? (
            <div className="grid md:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Revenue</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span>Total Revenue</span>
                      <span className="font-bold text-lg">{formatCurrency(fqhc.financials.total_revenue)}</span>
                    </div>
                    <hr />
                    <div className="flex justify-between items-center">
                      <span>Federal Grants</span>
                      <span className="font-semibold">{formatCurrency(fqhc.financials.federal_grants)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Medicaid</span>
                      <span className="font-semibold">{formatCurrency(fqhc.financials.medicaid_revenue)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Medicare</span>
                      <span className="font-semibold">{formatCurrency(fqhc.financials.medicare_revenue)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Self-Pay</span>
                      <span className="font-semibold">{formatCurrency(fqhc.financials.self_pay_revenue)}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Expenses & Efficiency</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span>Total Expenses</span>
                      <span className="font-bold text-lg">{formatCurrency(fqhc.financials.total_expenses)}</span>
                    </div>
                    <hr />
                    <div className="flex justify-between items-center">
                      <span>Cost per Patient</span>
                      <span className="font-semibold">{formatCurrency(fqhc.financials.cost_per_patient)}</span>
                    </div>
                    {fqhc.total_patients > 0 && fqhc.financials.total_revenue > 0 && (
                      <div className="flex justify-between items-center">
                        <span>Revenue per Patient</span>
                        <span className="font-semibold text-emerald-600">
                          {formatCurrency(fqhc.financials.total_revenue / fqhc.total_patients)}
                        </span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <DollarSign className="w-12 h-12 mx-auto mb-2 text-gray-300" />
              <p>Financial data not available</p>
              <p className="text-sm mt-1">Enrich with FQHC API to load financials</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="sites" className="space-y-4 mt-4">
          {fqhc.sites?.length > 0 ? (
            <div className="grid gap-3">
              {fqhc.sites.map((site, idx) => (
                <Card key={idx} className="border-gray-200">
                  <CardContent className="py-3 px-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1 min-w-0">
                        <h4 className="font-semibold text-sm">{site.site_name}</h4>
                        {(site.address || site.city) && (
                          <p className="text-xs text-gray-600 mt-0.5">
                            {site.address && `${site.address}, `}{site.city}, {site.state} {site.zip_code}
                          </p>
                        )}
                        <div className="flex flex-wrap gap-1.5 mt-2">
                          {site.site_type && <Badge variant="outline" className="text-xs">{site.site_type}</Badge>}
                          {site.location_setting && <Badge variant="secondary" className="text-xs">{site.location_setting}</Badge>}
                        </div>
                      </div>
                      {site.weekly_hours && (
                        <div className="text-right flex-shrink-0 ml-2">
                          <div className="flex items-center gap-1 text-gray-600 text-xs">
                            <Clock className="w-3 h-3" />
                            <span>{site.weekly_hours} hrs/wk</span>
                          </div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              No site information available
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}