import React, { useState } from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { Button } from '@/components/ui/button';
import { Search, MapPin, RotateCcw, Loader2, X } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

export default function FqhcFilters({ 
  filters, 
  onFilterChange, 
  className 
}) {
  const [citySearch, setCitySearch] = useState('');
  const [isSearchingCity, setIsSearchingCity] = useState(false);

  const handleCitySearch = async () => {
    if (!citySearch) return;
    
    let city = citySearch;
    let state = '';
    
    if (citySearch.includes(',')) {
      const parts = citySearch.split(',');
      city = parts[0].trim();
      state = parts[1].trim();
    }

    setIsSearchingCity(true);
    try {
      const { data } = await base44.functions.invoke('getCityCoordinates', { city, state });

      if (data && data.latitude && data.longitude) {
        onFilterChange({
          ...filters,
          proximity: {
            active: true,
            city: data.city_name || city,
            state: data.state || state,
            latitude: data.latitude,
            longitude: data.longitude,
            radius: filters.proximity?.radius || 25
          }
        });
        toast.success(`Set proximity to ${data.city_name}, ${data.state}`);
      } else {
        toast.error('City not found');
      }
    } catch (err) {
      console.error(err);
      toast.error('Failed to find city');
    } finally {
      setIsSearchingCity(false);
    }
  };

  const clearProximity = () => {
    setCitySearch('');
    onFilterChange({
      ...filters,
      proximity: { ...filters.proximity, active: false }
    });
  };

  const handlePatientMinChange = (val) => {
    const num = parseInt(val) || 0;
    onFilterChange({ ...filters, patients: [Math.min(num, filters.patients[1]), filters.patients[1]] });
  };

  const handlePatientMaxChange = (val) => {
    const num = parseInt(val) || 200000;
    onFilterChange({ ...filters, patients: [filters.patients[0], Math.max(num, filters.patients[0])] });
  };

  const handleSiteMinChange = (val) => {
    const num = parseInt(val) || 0;
    onFilterChange({ ...filters, sites: [Math.min(num, filters.sites[1]), filters.sites[1]] });
  };

  const handleSiteMaxChange = (val) => {
    const num = parseInt(val) || 50;
    onFilterChange({ ...filters, sites: [filters.sites[0], Math.max(num, filters.sites[0])] });
  };

  return (
    <div className={`space-y-6 ${className}`}>
      <div className="flex items-center justify-between">
        <h3 className="font-semibold text-sm uppercase text-gray-500">Filters</h3>
        <Button 
          variant="ghost" 
          size="sm" 
          className="h-7 text-xs"
          onClick={() => onFilterChange({
            patients: [0, 200000],
            sites: [0, 50],
            proximity: { active: false, radius: 25 }
          })}
        >
          <RotateCcw className="w-3 h-3 mr-1" /> Reset
        </Button>
      </div>

      {/* Patient Count */}
      <div className="space-y-3">
        <Label className="text-xs font-medium">Total Patients</Label>
        <div className="flex items-center gap-2">
          <Input
            type="number"
            value={filters.patients[0]}
            onChange={(e) => handlePatientMinChange(e.target.value)}
            className="h-8 text-xs w-20"
            min={0}
          />
          <span className="text-xs text-gray-400">to</span>
          <Input
            type="number"
            value={filters.patients[1]}
            onChange={(e) => handlePatientMaxChange(e.target.value)}
            className="h-8 text-xs w-20"
            min={0}
          />
        </div>
        <Slider
          value={filters.patients}
          max={200000}
          step={1000}
          onValueChange={(val) => onFilterChange({ ...filters, patients: val })}
          className="mt-2"
        />
      </div>

      {/* Site Count */}
      <div className="space-y-3">
        <Label className="text-xs font-medium">Total Sites</Label>
        <div className="flex items-center gap-2">
          <Input
            type="number"
            value={filters.sites[0]}
            onChange={(e) => handleSiteMinChange(e.target.value)}
            className="h-8 text-xs w-16"
            min={0}
          />
          <span className="text-xs text-gray-400">to</span>
          <Input
            type="number"
            value={filters.sites[1]}
            onChange={(e) => handleSiteMaxChange(e.target.value)}
            className="h-8 text-xs w-16"
            min={0}
          />
        </div>
        <Slider
          value={filters.sites}
          max={50}
          step={1}
          onValueChange={(val) => onFilterChange({ ...filters, sites: val })}
          className="mt-2"
        />
      </div>

      {/* Proximity */}
      <div className="space-y-3">
        <Label className="text-xs font-medium">Proximity to City</Label>
        
        {!filters.proximity?.active ? (
          <div className="flex gap-2">
            <Input 
              placeholder="City, State" 
              value={citySearch}
              onChange={(e) => setCitySearch(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleCitySearch()}
              className="h-8 text-xs"
            />
            <Button size="sm" variant="secondary" onClick={handleCitySearch} disabled={isSearchingCity} className="h-8 px-3">
              {isSearchingCity ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
            </Button>
          </div>
        ) : (
          <div className="bg-blue-50 p-3 rounded-lg border border-blue-100 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-blue-600" />
                <span className="text-xs font-medium text-blue-900">
                  {filters.proximity.city}, {filters.proximity.state}
                </span>
              </div>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-6 w-6 text-blue-400 hover:text-blue-600"
                onClick={clearProximity}
              >
                <X className="w-3 h-3" />
              </Button>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-blue-700">Radius</span>
                <div className="flex items-center gap-1">
                  <Input
                    type="number"
                    value={filters.proximity.radius}
                    onChange={(e) => onFilterChange({
                      ...filters,
                      proximity: { ...filters.proximity, radius: parseInt(e.target.value) || 25 }
                    })}
                    className="h-6 w-14 text-xs text-center"
                    min={1}
                    max={100}
                  />
                  <span className="text-xs text-blue-600">mi</span>
                </div>
              </div>
              <Slider
                value={[filters.proximity.radius]}
                max={100}
                min={1}
                step={5}
                onValueChange={(val) => onFilterChange({
                  ...filters,
                  proximity: { ...filters.proximity, radius: val[0] }
                })}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}