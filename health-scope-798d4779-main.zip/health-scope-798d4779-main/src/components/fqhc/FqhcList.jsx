import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Search, MapPin } from 'lucide-react';

export default function FqhcList({ fqhcs, onSelect, onAddToComparison, selectedId, comparisonIds = [] }) {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredFqhcs = fqhcs
    .filter(f => {
      const name = (f.health_center_name || f.name || '').toLowerCase();
      const city = (f.city || '').toLowerCase();
      return name.includes(searchTerm.toLowerCase()) || city.includes(searchTerm.toLowerCase());
    })
    .sort((a, b) => (b.total_patients || 0) - (a.total_patients || 0));

  const formatPatients = (num) => {
    if (!num) return '—';
    if (num >= 1000) return `${(num / 1000).toFixed(1)}k`;
    return num.toLocaleString();
  };

  return (
    <div className="flex flex-col h-full">
      {/* Search */}
      <div className="p-3 border-b bg-white sticky top-0 z-10">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search..."
            className="pl-9 h-9 text-sm"
          />
        </div>
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto">
        {filteredFqhcs.map((fqhc, idx) => {
          const id = fqhc.bhcmis_id || fqhc.id || idx;
          const isSelected = selectedId === id || selectedId === fqhc.bhcmis_id;
          const isInComparison = comparisonIds.includes(fqhc.bhcmis_id);

          return (
            <div
              key={id}
              className={`px-3 py-2.5 border-b cursor-pointer transition-colors ${
                isSelected 
                  ? 'bg-emerald-50 border-l-2 border-l-emerald-500' 
                  : 'hover:bg-slate-50 border-l-2 border-l-transparent'
              }`}
            >
              <div className="flex items-center gap-2">
                <Checkbox
                  checked={isInComparison}
                  onCheckedChange={() => onAddToComparison(fqhc)}
                  onClick={(e) => e.stopPropagation()}
                  className="flex-shrink-0"
                />
                <div 
                  className="flex-1 min-w-0"
                  onClick={() => onSelect(fqhc)}
                >
                  <h3 className={`font-medium text-sm leading-tight truncate ${isSelected ? 'text-emerald-800' : 'text-slate-800'}`}>
                    {fqhc.health_center_name || fqhc.name}
                  </h3>
                  <div className="flex items-center justify-between mt-0.5">
                    <p className="text-xs text-slate-500 flex items-center gap-1">
                      <MapPin className="w-3 h-3" />
                      <span className="truncate">{fqhc.city}, {fqhc.state}</span>
                    </p>
                    <p className="text-xs font-semibold text-slate-600">{formatPatients(fqhc.total_patients)}</p>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
        
        {filteredFqhcs.length === 0 && (
          <div className="text-center py-8 text-gray-500 text-sm">
            No results
          </div>
        )}
      </div>
    </div>
  );
}