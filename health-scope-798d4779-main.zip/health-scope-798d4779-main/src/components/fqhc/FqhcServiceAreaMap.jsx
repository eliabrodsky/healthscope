import React, { useState, useEffect, useMemo } from 'react';
import { MapContainer, TileLayer, Marker, Popup, GeoJSON, useMap } from 'react-leaflet';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Users, DollarSign, Heart, Building2, X, Layers } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

const fqhcIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-green.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
});

function FitBounds({ bounds }) {
  const map = useMap();
  useEffect(() => {
    if (bounds && bounds.length > 0) {
      map.fitBounds(bounds, { padding: [20, 20] });
    }
  }, [bounds, map]);
  return null;
}

export default function FqhcServiceAreaMap({ fqhc, onClose }) {
  const [isLoading, setIsLoading] = useState(true);
  const [boundaries, setBoundaries] = useState([]);
  const [demographics, setDemographics] = useState({});
  const [cdcData, setCdcData] = useState({});
  const [overlayType, setOverlayType] = useState('patients');

  const serviceAreaZips = fqhc?.service_area_zips || [];

  useEffect(() => {
    if (serviceAreaZips.length > 0) {
      loadServiceAreaData();
    } else {
      setIsLoading(false);
    }
  }, [fqhc?.bhcmis_id]);

  // Parse WKT POLYGON to GeoJSON
  const parseWktToGeoJson = (wkt, zip) => {
    if (!wkt) return null;
    try {
      // Handle POLYGON and MULTIPOLYGON
      if (wkt.startsWith('POLYGON')) {
        const coordsStr = wkt.replace('POLYGON ((', '').replace('))', '');
        const coords = coordsStr.split(', ').map(pair => {
          const [lng, lat] = pair.split(' ').map(Number);
          return [lng, lat];
        });
        return {
          type: 'Feature',
          properties: { ZCTA5CE20: zip, zcta5: zip },
          geometry: { type: 'Polygon', coordinates: [coords] }
        };
      } else if (wkt.startsWith('MULTIPOLYGON')) {
        // Handle MULTIPOLYGON
        const content = wkt.replace('MULTIPOLYGON (((', '').replace(')))', '');
        const polygons = content.split(')), ((').map(polyStr => {
          return polyStr.split(', ').map(pair => {
            const [lng, lat] = pair.split(' ').map(Number);
            return [lng, lat];
          });
        });
        return {
          type: 'Feature',
          properties: { ZCTA5CE20: zip, zcta5: zip },
          geometry: { type: 'MultiPolygon', coordinates: polygons.map(p => [p]) }
        };
      }
    } catch (e) {
      console.warn(`Failed to parse WKT for ${zip}:`, e);
    }
    return null;
  };

  const loadServiceAreaData = async () => {
    setIsLoading(true);
    const zipCodes = serviceAreaZips.map(z => z.zip_code);

    try {
      // Fetch boundaries from BigQuery API
      const batchSize = 50;
      let allBoundaries = [];

      for (let i = 0; i < zipCodes.length; i += batchSize) {
        const batch = zipCodes.slice(i, i + batchSize);
        try {
          const response = await fetch(`https://getzctas-1038555279570.us-south1.run.app/?zips=${batch.join(',')}`);
          if (response.ok) {
            const data = await response.json();
            
            // API returns array with {zip, state_abbr, wkt} format
            if (Array.isArray(data)) {
              for (const item of data) {
                if (item.wkt) {
                  const feature = parseWktToGeoJson(item.wkt, item.zip);
                  if (feature) {
                    allBoundaries.push(feature);
                  }
                } else if (item.type === 'Feature' && item.geometry) {
                  // Already GeoJSON
                  allBoundaries.push(item);
                }
              }
            } else if (data?.features) {
              allBoundaries = [...allBoundaries, ...data.features];
            }
          }
        } catch (e) {
          console.warn('Failed to fetch boundaries for batch:', e);
        }
      }
      setBoundaries(allBoundaries);
      console.log(`Loaded ${allBoundaries.length} boundaries for ${zipCodes.length} ZIPs`);

      // Fetch demographics
      const demoData = await base44.entities.ZipDemographics.filter(
        { zcta5: { $in: zipCodes } },
        null,
        500
      );
      const demoMap = {};
      demoData.forEach(d => { demoMap[d.zcta5] = d; });
      setDemographics(demoMap);

      // Fetch CDC health data
      const cdcHealthData = await base44.entities.CdcHealthData.filter(
        { zcta5: { $in: zipCodes } },
        null,
        1000
      );
      const cdcMap = {};
      cdcHealthData.forEach(d => {
        if (!cdcMap[d.zcta5]) cdcMap[d.zcta5] = {};
        cdcMap[d.zcta5][d.measure_id] = d.data_value;
      });
      setCdcData(cdcMap);

    } catch (error) {
      console.error('Error loading service area data:', error);
      toast.error('Failed to load service area data');
    } finally {
      setIsLoading(false);
    }
  };

  const getZipValue = (zipCode) => {
    const zipData = serviceAreaZips.find(z => z.zip_code === zipCode);
    const demo = demographics[zipCode];
    const cdc = cdcData[zipCode];

    switch (overlayType) {
      case 'patients':
        return zipData?.total_patients || 0;
      case 'medicaid':
        return zipData?.medicaid || 0;
      case 'uninsured':
        return zipData?.uninsured || 0;
      case 'population':
        return demo?.population || 0;
      case 'poverty':
        return demo?.poverty_rate || 0;
      case 'uninsured_rate':
        return demo?.uninsured_rate || 0;
      case 'median_income':
        return demo?.median_income || 0;
      case 'obesity':
        return cdc?.OBESITY || 0;
      case 'diabetes':
        return cdc?.DIABETES || 0;
      default:
        return 0;
    }
  };

  const getColor = (value, maxValue) => {
    if (!value || !maxValue) return '#f0f9ff';
    const ratio = value / maxValue;
    
    if (overlayType === 'median_income') {
      // Green scale for income (higher is better)
      if (ratio > 0.8) return '#166534';
      if (ratio > 0.6) return '#22c55e';
      if (ratio > 0.4) return '#86efac';
      if (ratio > 0.2) return '#bbf7d0';
      return '#dcfce7';
    } else if (overlayType === 'poverty' || overlayType === 'uninsured_rate' || overlayType === 'obesity' || overlayType === 'diabetes') {
      // Red scale for negative indicators
      if (ratio > 0.8) return '#991b1b';
      if (ratio > 0.6) return '#dc2626';
      if (ratio > 0.4) return '#f87171';
      if (ratio > 0.2) return '#fca5a5';
      return '#fecaca';
    } else {
      // Blue scale for patient counts
      if (ratio > 0.8) return '#1e40af';
      if (ratio > 0.6) return '#3b82f6';
      if (ratio > 0.4) return '#60a5fa';
      if (ratio > 0.2) return '#93c5fd';
      return '#bfdbfe';
    }
  };

  const maxValue = useMemo(() => {
    const values = serviceAreaZips.map(z => getZipValue(z.zip_code)).filter(v => v > 0);
    return Math.max(...values, 1);
  }, [serviceAreaZips, overlayType, demographics, cdcData]);

  const geoJsonStyle = (feature) => {
    const zipCode = feature.properties?.ZCTA5CE20 || feature.properties?.zcta5;
    const value = getZipValue(zipCode);
    return {
      fillColor: getColor(value, maxValue),
      weight: 2,
      opacity: 1,
      color: '#374151',
      fillOpacity: 0.7
    };
  };

  const onEachFeature = (feature, layer) => {
    const zipCode = feature.properties?.ZCTA5CE20 || feature.properties?.zcta5;
    const zipData = serviceAreaZips.find(z => z.zip_code === zipCode);
    const demo = demographics[zipCode];
    const cdc = cdcData[zipCode];

    const popupContent = `
      <div style="min-width: 200px;">
        <h4 style="font-weight: bold; margin-bottom: 8px;">ZIP: ${zipCode}</h4>
        <div style="font-size: 12px;">
          <p><strong>FQHC Patients:</strong> ${(zipData?.total_patients || 0).toLocaleString()}</p>
          <p style="margin-left: 12px;">Medicaid: ${(zipData?.medicaid || 0).toLocaleString()}</p>
          <p style="margin-left: 12px;">Medicare: ${(zipData?.medicare || 0).toLocaleString()}</p>
          <p style="margin-left: 12px;">Private: ${(zipData?.private || 0).toLocaleString()}</p>
          <p style="margin-left: 12px;">Uninsured: ${(zipData?.uninsured || 0).toLocaleString()}</p>
          <hr style="margin: 8px 0;" />
          <p><strong>Population:</strong> ${(demo?.population || 0).toLocaleString()}</p>
          <p><strong>Median Income:</strong> $${(demo?.median_income || 0).toLocaleString()}</p>
          <p><strong>Poverty Rate:</strong> ${(demo?.poverty_rate || 0).toFixed(1)}%</p>
          <p><strong>Uninsured Rate:</strong> ${(demo?.uninsured_rate || 0).toFixed(1)}%</p>
          ${cdc?.OBESITY ? `<p><strong>Obesity Rate:</strong> ${cdc.OBESITY.toFixed(1)}%</p>` : ''}
          ${cdc?.DIABETES ? `<p><strong>Diabetes Rate:</strong> ${cdc.DIABETES.toFixed(1)}%</p>` : ''}
        </div>
      </div>
    `;
    layer.bindPopup(popupContent);
  };

  const bounds = useMemo(() => {
    if (boundaries.length === 0) return null;
    const coords = [];
    boundaries.forEach(feature => {
      if (feature.geometry?.type === 'Polygon') {
        feature.geometry.coordinates[0].forEach(c => coords.push([c[1], c[0]]));
      } else if (feature.geometry?.type === 'MultiPolygon') {
        feature.geometry.coordinates.forEach(poly => {
          poly[0].forEach(c => coords.push([c[1], c[0]]));
        });
      }
    });
    return coords.length > 0 ? coords : null;
  }, [boundaries]);

  const center = fqhc?.coordinates 
    ? [fqhc.coordinates.latitude, fqhc.coordinates.longitude]
    : [33.5, -92.0];

  // Summary stats
  const totalPatients = serviceAreaZips.reduce((sum, z) => sum + (z.total_patients || 0), 0);
  const totalZips = serviceAreaZips.length;
  const totalPop = Object.values(demographics).reduce((sum, d) => sum + (d.population || 0), 0);

  return (
    <Card className="h-full">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg flex items-center gap-2">
              <Building2 className="w-5 h-5 text-emerald-600" />
              Service Area: {fqhc?.health_center_name || fqhc?.name}
            </CardTitle>
            <p className="text-sm text-gray-600 mt-1">
              {totalZips} ZIP codes • {totalPatients.toLocaleString()} patients • {totalPop.toLocaleString()} population
            </p>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>

        {/* Overlay selector */}
        <div className="flex items-center gap-3 mt-3">
          <Layers className="w-4 h-4 text-gray-500" />
          <Select value={overlayType} onValueChange={setOverlayType}>
            <SelectTrigger className="w-[200px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="patients">FQHC Patients</SelectItem>
              <SelectItem value="medicaid">Medicaid Patients</SelectItem>
              <SelectItem value="uninsured">Uninsured Patients</SelectItem>
              <SelectItem value="population">Total Population</SelectItem>
              <SelectItem value="poverty">Poverty Rate</SelectItem>
              <SelectItem value="uninsured_rate">Uninsured Rate</SelectItem>
              <SelectItem value="median_income">Median Income</SelectItem>
              <SelectItem value="obesity">Obesity Rate (CDC)</SelectItem>
              <SelectItem value="diabetes">Diabetes Rate (CDC)</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="h-[500px] flex items-center justify-center">
            <Loader2 className="w-8 h-8 animate-spin text-emerald-600" />
          </div>
        ) : (
          <div className="h-[500px] rounded-lg overflow-hidden border">
            <MapContainer center={center} zoom={9} style={{ height: '100%', width: '100%' }}>
              <TileLayer
                attribution='&copy; OpenStreetMap'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />
              
              {bounds && <FitBounds bounds={bounds} />}

              {/* Service area polygons */}
              {boundaries.map((feature, idx) => {
                // Only render if valid geometry exists
                if (!feature?.geometry?.coordinates) return null;
                return (
                  <GeoJSON
                    key={`${feature.properties?.ZCTA5CE20 || feature.properties?.zcta5 || idx}-${overlayType}`}
                    data={feature}
                    style={geoJsonStyle}
                    onEachFeature={onEachFeature}
                  />
                );
              })}

              {/* FQHC marker */}
              {fqhc?.coordinates && (
                <Marker 
                  position={[fqhc.coordinates.latitude, fqhc.coordinates.longitude]}
                  icon={fqhcIcon}
                >
                  <Popup>
                    <div className="font-semibold">{fqhc.health_center_name || fqhc.name}</div>
                    <div className="text-sm">{fqhc.city}, {fqhc.state}</div>
                  </Popup>
                </Marker>
              )}

              {/* Site markers */}
              {fqhc?.sites?.filter(s => s.coordinates).map((site, idx) => (
                <Marker
                  key={idx}
                  position={[site.coordinates.latitude, site.coordinates.longitude]}
                >
                  <Popup>
                    <div className="font-semibold">{site.site_name}</div>
                    <div className="text-sm">{site.city}, {site.state}</div>
                  </Popup>
                </Marker>
              ))}
            </MapContainer>
          </div>
        )}

        {/* Legend */}
        <div className="mt-3 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs">
            <span className="text-gray-600">Low</span>
            <div className="flex">
              {overlayType === 'median_income' ? (
                <>
                  <div className="w-6 h-4 bg-[#dcfce7]"></div>
                  <div className="w-6 h-4 bg-[#bbf7d0]"></div>
                  <div className="w-6 h-4 bg-[#86efac]"></div>
                  <div className="w-6 h-4 bg-[#22c55e]"></div>
                  <div className="w-6 h-4 bg-[#166534]"></div>
                </>
              ) : ['poverty', 'uninsured_rate', 'obesity', 'diabetes'].includes(overlayType) ? (
                <>
                  <div className="w-6 h-4 bg-[#fecaca]"></div>
                  <div className="w-6 h-4 bg-[#fca5a5]"></div>
                  <div className="w-6 h-4 bg-[#f87171]"></div>
                  <div className="w-6 h-4 bg-[#dc2626]"></div>
                  <div className="w-6 h-4 bg-[#991b1b]"></div>
                </>
              ) : (
                <>
                  <div className="w-6 h-4 bg-[#bfdbfe]"></div>
                  <div className="w-6 h-4 bg-[#93c5fd]"></div>
                  <div className="w-6 h-4 bg-[#60a5fa]"></div>
                  <div className="w-6 h-4 bg-[#3b82f6]"></div>
                  <div className="w-6 h-4 bg-[#1e40af]"></div>
                </>
              )}
            </div>
            <span className="text-gray-600">High</span>
          </div>
          <Badge variant="outline" className="text-xs">
            {boundaries.length} of {totalZips} boundaries loaded
          </Badge>
        </div>

        {/* Summary cards */}
        <div className="grid grid-cols-4 gap-3 mt-4">
          <div className="bg-blue-50 p-3 rounded-lg text-center">
            <Users className="w-4 h-4 mx-auto text-blue-600 mb-1" />
            <p className="text-lg font-bold text-blue-700">{totalPatients.toLocaleString()}</p>
            <p className="text-xs text-gray-600">Patients</p>
          </div>
          <div className="bg-green-50 p-3 rounded-lg text-center">
            <Building2 className="w-4 h-4 mx-auto text-green-600 mb-1" />
            <p className="text-lg font-bold text-green-700">{totalZips}</p>
            <p className="text-xs text-gray-600">ZIP Codes</p>
          </div>
          <div className="bg-purple-50 p-3 rounded-lg text-center">
            <Users className="w-4 h-4 mx-auto text-purple-600 mb-1" />
            <p className="text-lg font-bold text-purple-700">{totalPop.toLocaleString()}</p>
            <p className="text-xs text-gray-600">Population</p>
          </div>
          <div className="bg-amber-50 p-3 rounded-lg text-center">
            <Heart className="w-4 h-4 mx-auto text-amber-600 mb-1" />
            <p className="text-lg font-bold text-amber-700">
              {totalPop > 0 ? ((totalPatients / totalPop) * 100).toFixed(1) : 0}%
            </p>
            <p className="text-xs text-gray-600">Penetration</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}