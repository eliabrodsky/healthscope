import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { X, TrendingUp, TrendingDown, Minus, Loader2, Users, DollarSign, Stethoscope } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar } from 'recharts';
import { toast } from 'sonner';

export default function FqhcYoyComparison({ fqhc, onClose }) {
  const [yearlyData, setYearlyData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedMetric, setSelectedMetric] = useState('patients');

  useEffect(() => {
    if (fqhc) {
      loadYearlyData();
    }
  }, [fqhc]);

  const loadYearlyData = async () => {
    setIsLoading(true);
    const years = [2021, 2022, 2023, 2024];
    const data = [];

    const bhcmisId = fqhc.bhcmis_id;
    
    // Fetch summary data for all years in parallel (summary has all the aggregated data)
    const results = await Promise.allSettled(
      years.map(async (year) => {
        const url = `https://fqhc-api-1038555279570.us-south1.run.app/summary/by-bhcmis?year=${year}&bhcmis_id=${bhcmisId}`;
        const response = await fetch(url);
        if (!response.ok) return null;
        return { year, summary: await response.json() };
      })
    );

    for (const result of results) {
      if (result.status !== 'fulfilled' || !result.value) continue;
      
      const { year, summary } = result.value;
      
      // Summary API returns totals directly
      if (summary.bhcmis_id || summary.totals) {
        const totals = summary.totals || {};
        const payerMix = summary.payer_mix || {};
        const workforce = summary.workforce || {};
        const financial = summary.financial || {};
        
        data.push({
          year,
          total_patients: totals.patients || 0,
          medicaid: payerMix.medicaid || 0,
          medicare: payerMix.medicare || 0,
          uninsured: payerMix.uninsured || 0,
          private: payerMix.private || 0,
          service_zips: totals.service_zips || 0,
          total_fte: workforce.total_fte || 0,
          physicians_fte: workforce.physicians_fte || 0,
          total_revenue: (financial.amount || 0) * 1.05, // Estimate revenue from expenses
          total_expenses: financial.amount || 0
        });
      }
    }

    setYearlyData(data.sort((a, b) => a.year - b.year));
    setIsLoading(false);
    
    if (data.length === 0) {
      toast.warning('No historical data found for this FQHC');
    }
  };

  const calculateChange = (current, previous) => {
    if (!previous || previous === 0) return null;
    return ((current - previous) / previous) * 100;
  };

  const getTrendIcon = (change) => {
    if (change === null) return <Minus className="w-4 h-4 text-gray-400" />;
    if (change > 0) return <TrendingUp className="w-4 h-4 text-green-600" />;
    if (change < 0) return <TrendingDown className="w-4 h-4 text-red-600" />;
    return <Minus className="w-4 h-4 text-gray-400" />;
  };

  const formatNumber = (num) => {
    if (!num) return '—';
    return num.toLocaleString();
  };

  const formatCurrency = (num) => {
    if (!num) return '—';
    if (num >= 1000000) return `$${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `$${(num / 1000).toFixed(0)}K`;
    return `$${num.toLocaleString()}`;
  };

  if (isLoading) {
    return (
      <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-4xl">
          <CardContent className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-emerald-600" />
            <span className="ml-3">Loading historical data...</span>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 z-[60] flex items-center justify-center p-4 overflow-auto" onClick={(e) => { if (e.target === e.currentTarget) onClose?.(); }}>
      <Card className="w-full max-w-5xl max-h-[90vh] overflow-auto relative">
        <CardHeader className="border-b sticky top-0 bg-white z-10">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-emerald-600" />
                Year-over-Year Comparison
              </CardTitle>
              <p className="text-sm text-gray-600 mt-1">
                {fqhc?.health_center_name || fqhc?.name} • {yearlyData.length} years of data
              </p>
            </div>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => onClose?.()}
              className="hover:bg-gray-100"
              type="button"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-6 space-y-6">
          {yearlyData.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              No historical data available for this FQHC
            </div>
          ) : (
            <>
              {/* Summary Cards */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {yearlyData.length >= 2 && (
                  <>
                    <Card>
                      <CardContent className="pt-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm text-gray-600">Patient Growth</p>
                            <p className="text-2xl font-bold">
                              {calculateChange(
                                yearlyData[yearlyData.length - 1]?.total_patients,
                                yearlyData[yearlyData.length - 2]?.total_patients
                              )?.toFixed(1)}%
                            </p>
                          </div>
                          {getTrendIcon(calculateChange(
                            yearlyData[yearlyData.length - 1]?.total_patients,
                            yearlyData[yearlyData.length - 2]?.total_patients
                          ))}
                        </div>
                        <p className="text-xs text-gray-500 mt-1">
                          {yearlyData[yearlyData.length - 2]?.year} → {yearlyData[yearlyData.length - 1]?.year}
                        </p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="pt-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm text-gray-600">Uninsured Change</p>
                            <p className="text-2xl font-bold">
                              {calculateChange(
                                yearlyData[yearlyData.length - 1]?.uninsured,
                                yearlyData[yearlyData.length - 2]?.uninsured
                              )?.toFixed(1)}%
                            </p>
                          </div>
                          {getTrendIcon(calculateChange(
                            yearlyData[yearlyData.length - 1]?.uninsured,
                            yearlyData[yearlyData.length - 2]?.uninsured
                          ))}
                        </div>
                        <p className="text-xs text-gray-500 mt-1">
                          {yearlyData[yearlyData.length - 2]?.year} → {yearlyData[yearlyData.length - 1]?.year}
                        </p>
                      </CardContent>
                    </Card>
                  </>
                )}
                <Card>
                  <CardContent className="pt-4">
                    <p className="text-sm text-gray-600">Latest Year</p>
                    <p className="text-2xl font-bold">{yearlyData[yearlyData.length - 1]?.year}</p>
                    <p className="text-xs text-gray-500 mt-1">
                      {formatNumber(yearlyData[yearlyData.length - 1]?.total_patients)} patients
                    </p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-4">
                    <p className="text-sm text-gray-600">Years Available</p>
                    <p className="text-2xl font-bold">{yearlyData.length}</p>
                    <p className="text-xs text-gray-500 mt-1">
                      {yearlyData[0]?.year} - {yearlyData[yearlyData.length - 1]?.year}
                    </p>
                  </CardContent>
                </Card>
              </div>

              {/* Chart */}
              <Card>
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base">
                      {selectedMetric === 'patients' && 'Patient Trends'}
                      {selectedMetric === 'payer' && 'Payer Mix Trends'}
                      {selectedMetric === 'financials' && 'Financial Trends'}
                      {selectedMetric === 'workforce' && 'Workforce Trends'}
                    </CardTitle>
                    <Select value={selectedMetric} onValueChange={setSelectedMetric}>
                      <SelectTrigger className="w-40">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="patients">Total Patients</SelectItem>
                        <SelectItem value="payer">Payer Mix</SelectItem>
                        <SelectItem value="financials">Financials</SelectItem>
                        <SelectItem value="workforce">Workforce FTE</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      {selectedMetric === 'patients' ? (
                        <LineChart data={yearlyData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="year" />
                          <YAxis tickFormatter={(v) => v >= 1000 ? `${(v/1000).toFixed(0)}K` : v} />
                          <Tooltip formatter={(v) => formatNumber(v)} />
                          <Legend />
                          <Line type="monotone" dataKey="total_patients" stroke="#10b981" strokeWidth={2} name="Total Patients" />
                        </LineChart>
                      ) : selectedMetric === 'payer' ? (
                        <BarChart data={yearlyData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="year" />
                          <YAxis tickFormatter={(v) => v >= 1000 ? `${(v/1000).toFixed(0)}K` : v} />
                          <Tooltip formatter={(v) => formatNumber(v)} />
                          <Legend />
                          <Bar dataKey="medicaid" stackId="a" fill="#3b82f6" name="Medicaid" />
                          <Bar dataKey="medicare" stackId="a" fill="#22c55e" name="Medicare" />
                          <Bar dataKey="private" stackId="a" fill="#a855f7" name="Private" />
                          <Bar dataKey="uninsured" stackId="a" fill="#f59e0b" name="Uninsured" />
                        </BarChart>
                      ) : selectedMetric === 'workforce' ? (
                        <LineChart data={yearlyData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="year" />
                          <YAxis />
                          <Tooltip formatter={(v) => v?.toFixed(1)} />
                          <Legend />
                          <Line type="monotone" dataKey="total_fte" stroke="#10b981" strokeWidth={2} name="Total FTE" />
                          <Line type="monotone" dataKey="physicians_fte" stroke="#3b82f6" strokeWidth={2} name="Physicians FTE" />
                        </LineChart>
                      ) : (
                        <LineChart data={yearlyData}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="year" />
                          <YAxis tickFormatter={(v) => formatCurrency(v)} width={80} />
                          <Tooltip formatter={(v) => formatCurrency(v)} />
                          <Legend />
                          <Line type="monotone" dataKey="total_revenue" stroke="#10b981" strokeWidth={2} name="Total Revenue" />
                          <Line type="monotone" dataKey="total_expenses" stroke="#ef4444" strokeWidth={2} name="Total Expenses" />
                        </LineChart>
                      )}
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Data Table */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">Yearly Data</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead className="bg-gray-100">
                        <tr>
                          <th className="text-left p-3">Year</th>
                          <th className="text-right p-3">Total Patients</th>
                          <th className="text-right p-3">Medicaid</th>
                          <th className="text-right p-3">Medicare</th>
                          <th className="text-right p-3">Uninsured</th>
                          <th className="text-right p-3">Service ZIPs</th>
                          <th className="text-right p-3">YoY Change</th>
                        </tr>
                      </thead>
                      <tbody>
                        {yearlyData.map((row, idx) => {
                          const prevRow = yearlyData[idx - 1];
                          const change = calculateChange(row.total_patients, prevRow?.total_patients);
                          return (
                            <tr key={row.year} className="border-b hover:bg-gray-50">
                              <td className="p-3 font-medium">{row.year}</td>
                              <td className="p-3 text-right">{formatNumber(row.total_patients)}</td>
                              <td className="p-3 text-right text-blue-600">{formatNumber(row.medicaid)}</td>
                              <td className="p-3 text-right text-green-600">{formatNumber(row.medicare)}</td>
                              <td className="p-3 text-right text-amber-600">{formatNumber(row.uninsured)}</td>
                              <td className="p-3 text-right">{row.service_zips}</td>
                              <td className="p-3 text-right">
                                {change !== null ? (
                                  <span className={change >= 0 ? 'text-green-600' : 'text-red-600'}>
                                    {change >= 0 ? '+' : ''}{change.toFixed(1)}%
                                  </span>
                                ) : '—'}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}