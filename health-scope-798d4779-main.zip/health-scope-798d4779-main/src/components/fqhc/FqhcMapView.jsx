import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, CircleMarker, Popup, Circle, GeoJSON, useMap } from 'react-leaflet';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Building2, Users, MapPin, PanelLeftClose, PanelLeftOpen } from 'lucide-react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

function FitBounds({ markers }) {
  const map = useMap();
  
  useEffect(() => {
    if (markers.length > 0) {
      const bounds = L.latLngBounds(markers.map(m => [m.lat, m.lng]));
      map.fitBounds(bounds, { padding: [50, 50] });
    }
  }, [markers, map]);
  
  return null;
}

function MapResizer({ sidebarCollapsed }) {
  const map = useMap();
  
  useEffect(() => {
    setTimeout(() => {
      map.invalidateSize();
    }, 350);
  }, [sidebarCollapsed, map]);
  
  return null;
}



export default function FqhcMapView({ fqhcs, assessment, onSelectFqhc, selectedFqhc, onSidebarToggle, sidebarCollapsed = false }) {
  const [showSites, setShowSites] = useState(true);
  const [activeServiceArea, setActiveServiceArea] = useState(null); // bhcmis_id
  const [boundaries, setBoundaries] = useState([]);
  const [isLoadingBoundaries, setIsLoadingBoundaries] = useState(false);
  const [serviceAreaData, setServiceAreaData] = useState({}); // zip -> patient data
  const [showAssessmentBoundaries, setShowAssessmentBoundaries] = useState(false);
  const [assessmentBoundaries, setAssessmentBoundaries] = useState([]);
  const [assessmentDemographics, setAssessmentDemographics] = useState({});
  const [isLoadingAssessmentBoundaries, setIsLoadingAssessmentBoundaries] = useState(false);
  const [colorMetric, setColorMetric] = useState('patients'); // 'patients' | 'medicaid' | 'medicare' | 'uninsured'

  const loadServiceArea = async (fqhc, forceLoad = false) => {
    if (!forceLoad && activeServiceArea === fqhc.bhcmis_id) {
      setActiveServiceArea(null);
      setBoundaries([]);
      setServiceAreaData({});
      return;
    }

    setActiveServiceArea(fqhc.bhcmis_id);
    setIsLoadingBoundaries(true);
    setBoundaries([]);

    try {
      const serviceZips = fqhc.service_area_zips || [];
      const zipCodes = serviceZips.map(z => z.zip_code).filter(Boolean);
      
      if (zipCodes.length === 0) {
        setIsLoadingBoundaries(false);
        return;
      }

      // Build lookup for patient data per ZIP
      const zipData = {};
      serviceZips.forEach(z => {
        zipData[z.zip_code] = {
          patients: z.total_patients || z.patients || 0,
          medicaid: z.medicaid || 0,
          medicare: z.medicare || 0,
          uninsured: z.uninsured || 0
        };
      });
      setServiceAreaData(zipData);

      const batchSize = 50;
      let allBoundaries = [];

      for (let i = 0; i < zipCodes.length; i += batchSize) {
        const batch = zipCodes.slice(i, i + batchSize);
        try {
          const response = await fetch(`https://getzctas-1038555279570.us-south1.run.app/?zips=${batch.join(',')}`);
          if (response.ok) {
            const data = await response.json();
            let features = [];
            if (Array.isArray(data)) {
              features = data;
            } else if (data?.features) {
              features = data.features;
            } else if (typeof data === 'object') {
              // Handle keyed object response {zip: {geometry, ...}}
              features = Object.entries(data).map(([zip, info]) => ({
                type: 'Feature',
                properties: { zcta5: zip, ...info },
                geometry: info.geometry
              })).filter(f => f.geometry);
            }
            const validFeatures = features.filter(f => 
              f && f.type === 'Feature' && f.geometry && f.geometry.type && f.geometry.coordinates
            );
            allBoundaries = [...allBoundaries, ...validFeatures];
          }
        } catch (e) {
          console.warn('Failed to fetch boundaries:', e);
        }
      }
      setBoundaries(allBoundaries);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoadingBoundaries(false);
    }
  };

  // Auto-load service area when a single FQHC is selected
  useEffect(() => {
    if (selectedFqhc && selectedFqhc.service_area_zips?.length > 0) {
      loadServiceArea(selectedFqhc, true);
    } else if (!selectedFqhc) {
      // Clear FQHC-specific service area when deselected
      setActiveServiceArea(null);
      setBoundaries([]);
      setServiceAreaData({});
    }
  }, [selectedFqhc?.bhcmis_id]);

  // Clear old boundaries when switching FQHCs
  useEffect(() => {
    if (selectedFqhc) {
      // Reset assessment boundaries when selecting specific FQHC
      setAssessmentBoundaries([]);
      setShowAssessmentBoundaries(false);
    }
  }, [selectedFqhc?.bhcmis_id]);

  // Load assessment boundaries using external ZCTA API (same as service area loading)
  const loadAssessmentBoundaries = async () => {
    if (!assessment) return;
    
    const zips = assessment.geography?.zcta_codes || assessment.processed_data?.zip_codes || [];
    if (zips.length === 0) {
      console.log('No ZIP codes in assessment');
      return;
    }

    console.log(`Loading boundaries for ${zips.length} ZIPs from API`);
    setIsLoadingAssessmentBoundaries(true);
    
    try {
      const batchSize = 50;
      let allBoundaries = [];
      
      for (let i = 0; i < zips.length; i += batchSize) {
        const batch = zips.slice(i, i + batchSize);
        try {
          const response = await fetch(`https://getzctas-1038555279570.us-south1.run.app/?zips=${batch.join(',')}`);
          if (response.ok) {
            const data = await response.json();
            let features = [];
            if (Array.isArray(data)) {
              features = data;
            } else if (data?.features) {
              features = data.features;
            } else if (typeof data === 'object') {
              // Handle keyed object response {zip: {geometry, ...}}
              features = Object.entries(data).map(([zip, info]) => ({
                type: 'Feature',
                properties: { zcta5: zip, zip_code: zip, ...info },
                geometry: info.geometry
              })).filter(f => f.geometry);
            }
            const validFeatures = features.filter(f => 
              f && f.type === 'Feature' && f.geometry && f.geometry.type && f.geometry.coordinates
            );
            allBoundaries = [...allBoundaries, ...validFeatures];
            console.log(`Batch ${Math.floor(i/batchSize) + 1}: loaded ${validFeatures.length} boundaries`);
          }
        } catch (e) {
          console.warn('Failed to fetch batch:', e);
        }
      }
      
      console.log(`Total boundaries loaded: ${allBoundaries.length}`);
      setAssessmentBoundaries(allBoundaries);
      
    } catch (err) {
      console.error('Failed to load assessment boundaries:', err);
    } finally {
      setIsLoadingAssessmentBoundaries(false);
    }
  };

  const toggleAssessmentBoundaries = () => {
    // If we have service area boundaries already loaded (from selected FQHC), toggle those
    if (boundaries.length > 0) {
      setBoundaries([]);
      setActiveServiceArea(null);
      return;
    }
    
    // If we have a selected FQHC with service areas, load those boundaries
    if (selectedFqhc?.service_area_zips?.length > 0) {
      loadServiceArea(selectedFqhc, true);
      return;
    }
    
    // Otherwise toggle assessment boundaries
    if (showAssessmentBoundaries) {
      setShowAssessmentBoundaries(false);
    } else {
      setShowAssessmentBoundaries(true);
      if (assessmentBoundaries.length === 0) {
        loadAssessmentBoundaries();
      }
    }
  };
  
  // Build markers from FQHCs and their sites
  const markers = [];

  // If a specific FQHC is selected, show only its data, otherwise show all
  const fqhcsToShow = selectedFqhc ? [selectedFqhc] : fqhcs;

  fqhcsToShow.forEach(fqhc => {
    // Use HQ coordinates if available
    let fqhcLat = fqhc.coordinates?.latitude;
    let fqhcLng = fqhc.coordinates?.longitude;

    // Fallback: try to get coordinates from first site with coords
    if ((!fqhcLat || !fqhcLng) && fqhc.sites?.length > 0) {
      const siteWithCoords = fqhc.sites.find(s => s.coordinates?.latitude && s.coordinates?.longitude);
      if (siteWithCoords) {
        fqhcLat = siteWithCoords.coordinates.latitude;
        fqhcLng = siteWithCoords.coordinates.longitude;
      }
    }

    if (fqhcLat && fqhcLng) {
      markers.push({
        type: 'fqhc',
        fqhc,
        lat: fqhcLat,
        lng: fqhcLng,
        name: fqhc.health_center_name || fqhc.name
      });
    }

    // Add site markers
    if (showSites && fqhc.sites) {
      fqhc.sites.forEach(site => {
        // Check for coordinates in various formats
        const siteLat = site.coordinates?.latitude || site.latitude;
        const siteLng = site.coordinates?.longitude || site.longitude;

        if (siteLat && siteLng) {
          markers.push({
            type: 'site',
            fqhc,
            site,
            lat: siteLat,
            lng: siteLng,
            name: site.site_name
          });
        }
      });
    }
  });

  // Debug: log site count with coordinates
  const sitesWithCoords = fqhcsToShow.reduce((count, fqhc) => {
    return count + (fqhc.sites?.filter(s => s.coordinates?.latitude || s.latitude)?.length || 0);
  }, 0);
  console.log(`Sites with coordinates: ${sitesWithCoords} / ${fqhcsToShow.reduce((c, f) => c + (f.sites?.length || 0), 0)}`);
  
  // If no markers but we have fqhcs, try to center on assessment or use state center
  const hasValidMarkers = markers.length > 0;

  // Default center - use assessment center, or first FQHC state center
  let defaultCenter = [39.8283, -98.5795]; // US center fallback
  
  if (assessment?.geography?.latitude && assessment?.geography?.longitude) {
    defaultCenter = [assessment.geography.latitude, assessment.geography.longitude];
  } else if (hasValidMarkers) {
    defaultCenter = [markers[0].lat, markers[0].lng];
  } else if (fqhcs.length > 0) {
    // Use state-based center as fallback
    const STATE_CENTERS = {
      'LA': [30.9843, -91.9623], 'AR': [35.2010, -91.8318], 'TX': [31.9686, -99.9018],
      'CO': [39.5501, -105.7821], 'CA': [36.7783, -119.4179], 'NY': [42.1657, -74.9481],
      'FL': [27.6648, -81.5158], 'GA': [32.1656, -82.9001], 'AL': [32.3182, -86.9023],
      'MS': [32.3547, -89.3985], 'TN': [35.5175, -86.5804], 'KY': [37.8393, -84.2700],
      'OH': [40.4173, -82.9071], 'IL': [40.6331, -89.3985], 'MI': [44.3148, -85.6024]
    };
    const state = fqhcs[0].state;
    if (state && STATE_CENTERS[state]) {
      defaultCenter = STATE_CENTERS[state];
    }
  }

  const formatPatients = (num) => {
    if (!num) return '—';
    if (num >= 1000) return `${(num / 1000).toFixed(1)}k`;
    return num.toLocaleString();
  };

  // Get color and label for the current metric
  const getMetricLabel = () => {
    switch (colorMetric) {
      case 'medicaid': return 'Medicaid Patients';
      case 'medicare': return 'Medicare Patients';
      case 'uninsured': return 'Uninsured Patients';
      default: return 'Total Patients';
    }
  };

  const getMetricColor = () => {
    switch (colorMetric) {
      case 'medicaid': return { hue: 210, color: '#3b82f6', border: '#1d4ed8' }; // blue
      case 'medicare': return { hue: 142, color: '#22c55e', border: '#16a34a' }; // green
      case 'uninsured': return { hue: 35, color: '#f59e0b', border: '#d97706' }; // amber
      default: return { hue: 270, color: '#8b5cf6', border: '#7c3aed' }; // purple
    }
  };

  return (
    <div className="space-y-4">
      {/* Controls - Assessment Dashboard Style */}
      <div className="flex items-center justify-between flex-wrap gap-2 bg-white border rounded-lg p-2 mb-2 relative z-[1000]">
        <div className="flex items-center gap-2 flex-wrap">
          {onSidebarToggle && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onSidebarToggle}
              className="mr-1"
            >
              {sidebarCollapsed ? <PanelLeftOpen className="w-4 h-4" /> : <PanelLeftClose className="w-4 h-4" />}
            </Button>
          )}
          <Badge className="bg-green-100 text-green-700">
            <Building2 className="w-3 h-3 mr-1" />
            {fqhcs.length} FQHCs
          </Badge>
          <Badge className="bg-blue-100 text-blue-700">
            <MapPin className="w-3 h-3 mr-1" />
            {markers.filter(m => m.type === 'site').length} Sites
          </Badge>
          {showAssessmentBoundaries && assessmentBoundaries.length > 0 && (
            <Badge className="bg-purple-100 text-purple-700">
              {assessmentBoundaries.length} ZIPs
            </Badge>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Select value={colorMetric} onValueChange={setColorMetric}>
            <SelectTrigger className="w-[140px] h-8 text-xs bg-white">
              <SelectValue placeholder="Color by..." />
            </SelectTrigger>
            <SelectContent className="z-[1001]">
              <SelectItem value="patients">Total Patients</SelectItem>
              <SelectItem value="medicaid">Medicaid</SelectItem>
              <SelectItem value="medicare">Medicare</SelectItem>
              <SelectItem value="uninsured">Uninsured</SelectItem>
            </SelectContent>
          </Select>
          {/* Show Boundaries button - works for assessment OR selected FQHC with service area */}
          {(assessment || (selectedFqhc?.service_area_zips?.length > 0)) && (
            <Button
              variant="outline"
              size="sm"
              onClick={toggleAssessmentBoundaries}
              disabled={isLoadingAssessmentBoundaries || isLoadingBoundaries}
              className={showAssessmentBoundaries || boundaries.length > 0 ? 'bg-purple-50 border-purple-200' : ''}
            >
              {(isLoadingAssessmentBoundaries || isLoadingBoundaries) ? 'Loading...' : (showAssessmentBoundaries || boundaries.length > 0) ? 'Hide Boundaries' : 'Show Boundaries'}
            </Button>
          )}
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowSites(!showSites)}
          >
            {showSites ? 'Hide Sites' : 'Show Sites'}
          </Button>
        </div>
      </div>

      {/* Map */}
      <div className="h-[500px] rounded-lg overflow-hidden border">
        <MapContainer
          center={defaultCenter}
          zoom={8}
          style={{ height: '100%', width: '100%' }}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          
          {hasValidMarkers && <FitBounds markers={markers} />}
          <MapResizer sidebarCollapsed={sidebarCollapsed} />
          
          {/* Assessment center circle */}
          {assessment?.geography?.latitude && assessment?.geography?.radius_miles && !showAssessmentBoundaries && (
            <Circle
              center={[assessment.geography.latitude, assessment.geography.longitude]}
              radius={assessment.geography.radius_miles * 1609.34}
              pathOptions={{ color: '#10b981', fillColor: '#10b981', fillOpacity: 0.05 }}
            />
          )}

          {/* Assessment ZIP boundaries colored by service area data */}
          {showAssessmentBoundaries && assessmentBoundaries.length > 0 && (
            <GeoJSON 
              key={`assessment-boundaries-${assessmentBoundaries.length}-${colorMetric}`}
              data={{ 
                type: "FeatureCollection", 
                features: assessmentBoundaries 
              }}
              style={(feature) => {
                const zip = feature.properties?.zcta5 || feature.properties?.zip_code;
                const zipInfo = serviceAreaData[zip] || {};
                
                // Get value based on selected metric
                let value = 0;
                switch (colorMetric) {
                  case 'medicaid': value = zipInfo.medicaid || 0; break;
                  case 'medicare': value = zipInfo.medicare || 0; break;
                  case 'uninsured': value = zipInfo.uninsured || 0; break;
                  default: value = zipInfo.patients || 0;
                }
                
                // Calculate max for this metric
                const allValues = Object.values(serviceAreaData).map(d => {
                  switch (colorMetric) {
                    case 'medicaid': return d.medicaid || 0;
                    case 'medicare': return d.medicare || 0;
                    case 'uninsured': return d.uninsured || 0;
                    default: return d.patients || 0;
                  }
                });
                const maxValue = Math.max(...allValues, 1);
                
                const intensity = Math.min(value / maxValue, 1);
                const { hue, border } = getMetricColor();
                const lightness = 85 - (intensity * 45);
                
                return {
                  fillColor: `hsl(${hue}, 60%, ${lightness}%)`,
                  weight: 1,
                  opacity: 0.9,
                  color: border,
                  fillOpacity: value > 0 ? 0.7 : 0.15
                };
              }}
              onEachFeature={(feature, layer) => {
                const zip = feature.properties?.zcta5 || feature.properties?.zip_code;
                const zipInfo = serviceAreaData[zip] || {};
                
                layer.bindPopup(`
                  <div class="p-2">
                    <strong>ZIP ${zip}</strong><br/>
                    <span style="color: #7c3aed">Patients: ${zipInfo.patients?.toLocaleString() || 0}</span><br/>
                    <span style="color: #3b82f6">Medicaid: ${zipInfo.medicaid?.toLocaleString() || 0}</span><br/>
                    <span style="color: #22c55e">Medicare: ${zipInfo.medicare?.toLocaleString() || 0}</span><br/>
                    <span style="color: #f59e0b">Uninsured: ${zipInfo.uninsured?.toLocaleString() || 0}</span>
                  </div>
                `);
              }}
            />
          )}

          {/* Service Area Boundaries with patient-weighted colors */}
          {boundaries.map((feature, idx) => {
            const zip = feature.properties?.zcta5 || feature.properties?.ZCTA5CE20 || feature.properties?.ZCTA5CE10;
            const zipInfo = serviceAreaData[zip] || {};
            const patients = zipInfo.patients || 0;

            // Color intensity based on patient count
            const maxPatients = Math.max(...Object.values(serviceAreaData).map(d => d.patients || 0), 1);
            const intensity = Math.min(patients / maxPatients, 1);
            const fillOpacity = 0.15 + (intensity * 0.45);

            return (
              <GeoJSON
                key={`${activeServiceArea}-${zip || idx}`}
                data={feature}
                style={{
                  fillColor: '#3b82f6',
                  weight: 1.5,
                  opacity: 1,
                  color: '#1d4ed8',
                  fillOpacity
                }}
                onEachFeature={(feature, layer) => {
                  if (zip && zipInfo.patients) {
                    layer.bindPopup(`
                      <div class="p-2">
                        <strong>ZIP ${zip}</strong><br/>
                        Patients: ${zipInfo.patients?.toLocaleString() || 0}<br/>
                        Medicaid: ${zipInfo.medicaid?.toLocaleString() || 0}<br/>
                        Uninsured: ${zipInfo.uninsured?.toLocaleString() || 0}
                      </div>
                    `);
                  }
                }}
              />
            );
          })}
          
          {markers.map((marker, idx) => (
            <CircleMarker
              key={`marker-${marker.type}-${idx}`}
              center={[marker.lat, marker.lng]}
              radius={marker.type === 'fqhc' ? 8 : 6}
              pathOptions={{
                fillColor: marker.type === 'fqhc' ? '#10b981' : '#3b82f6',
                color: '#fff',
                weight: 2,
                opacity: 1,
                fillOpacity: 0.9
              }}
            >
              <Popup>
                <div className="p-2 min-w-[200px]">
                  {marker.type === 'fqhc' ? (
                    <>
                      <h4 className="font-semibold text-emerald-700">{marker.name}</h4>
                      <p className="text-sm text-gray-600">
                        {marker.fqhc.city}, {marker.fqhc.state}
                      </p>
                      <div className="flex items-center gap-2 mt-2 text-sm">
                        <Users className="w-4 h-4 text-blue-600" />
                        <span>{formatPatients(marker.fqhc.total_patients)} patients</span>
                      </div>
                      {marker.fqhc.sites?.length > 0 && (
                        <p className="text-xs text-gray-500 mt-1">
                          {marker.fqhc.sites.length} sites
                        </p>
                      )}
                      <div className="grid grid-cols-2 gap-2 mt-2">
                        <Button
                          size="sm"
                          variant="outline"
                          className={`text-xs ${activeServiceArea === marker.fqhc.bhcmis_id ? 'bg-blue-50 border-blue-200' : ''}`}
                          onClick={() => loadServiceArea(marker.fqhc)}
                          disabled={isLoadingBoundaries && activeServiceArea !== marker.fqhc.bhcmis_id}
                        >
                          {isLoadingBoundaries && activeServiceArea === marker.fqhc.bhcmis_id 
                            ? 'Loading...' 
                            : activeServiceArea === marker.fqhc.bhcmis_id 
                              ? 'Hide Area' 
                              : 'Show Area'}
                        </Button>
                        <Button
                          size="sm"
                          className="bg-emerald-600 hover:bg-emerald-700 text-xs"
                          onClick={() => onSelectFqhc(marker.fqhc)}
                        >
                          Details
                        </Button>
                      </div>
                    </>
                  ) : (
                    <>
                      <h4 className="font-semibold text-blue-700">{marker.name}</h4>
                      <p className="text-xs text-gray-500">
                        Site of {marker.fqhc.health_center_name || marker.fqhc.name}
                      </p>
                      {(marker.site.address || marker.site.city) && (
                        <p className="text-sm text-gray-600 mt-1">
                          {marker.site.address && <span>{marker.site.address}<br/></span>}
                          {marker.site.city}, {marker.site.state} {marker.site.zip_code}
                        </p>
                      )}
                      {marker.site.site_type && (
                        <Badge variant="outline" className="mt-2 text-xs">
                          {marker.site.site_type}
                        </Badge>
                      )}
                    </>
                  )}
                </div>
              </Popup>
            </CircleMarker>
          ))}

          {/* Site markers without coordinates - use ZIP centroid fallback */}
          {showSites && selectedFqhc?.sites?.filter(s => !s.coordinates?.latitude && s.zip_code).map((site, idx) => {
            // Try to find centroid from service area boundaries
            const matchingBoundary = boundaries.find(b => {
              const zip = b.properties?.zcta5 || b.properties?.ZCTA5CE20;
              return zip === site.zip_code;
            });

            if (!matchingBoundary?.properties?.centroid) return null;
            const centroid = matchingBoundary.properties.centroid;

            return (
              <CircleMarker
                key={`site-fallback-${idx}`}
                center={[centroid[1], centroid[0]]}
                radius={6}
                pathOptions={{
                  fillColor: '#3b82f6',
                  color: '#fff',
                  weight: 2,
                  opacity: 1,
                  fillOpacity: 0.9
                }}
              >
                <Popup>
                  <div className="p-2">
                    <h4 className="font-semibold text-blue-700">{site.site_name}</h4>
                    <p className="text-xs text-gray-500">
                      {site.city}, {site.state} {site.zip_code}
                    </p>
                    {site.site_type && (
                      <Badge variant="outline" className="mt-2 text-xs">
                        {site.site_type}
                      </Badge>
                    )}
                    <p className="text-xs text-amber-600 mt-1">Location approximate (ZIP centroid)</p>
                  </div>
                </Popup>
              </CircleMarker>
            );
          })}
        </MapContainer>
      </div>

      {/* Legend */}
      <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600 bg-white/90 rounded-lg px-3 py-2 border">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-emerald-500 rounded-full border-2 border-white shadow" />
          <span>FQHC HQ</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 bg-blue-500 rounded-full border-2 border-white shadow" />
          <span>Site</span>
        </div>
        {activeServiceArea && (
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-blue-500/30 border border-blue-600 rounded" />
            <span>Service Area ({boundaries.length} ZIPs)</span>
          </div>
        )}
        {showAssessmentBoundaries && (
          <div className="flex items-center gap-2">
            <div className="flex items-center">
              <div className="w-8 h-3 rounded-l" style={{background: `linear-gradient(to right, hsl(${getMetricColor().hue}, 60%, 85%), hsl(${getMetricColor().hue}, 60%, 40%))`}} />
            </div>
            <span>{getMetricLabel()} (low → high)</span>
          </div>
        )}
      </div>
    </div>
  );
}