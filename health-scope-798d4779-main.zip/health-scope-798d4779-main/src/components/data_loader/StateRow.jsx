import React from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ChevronDown, ChevronRight, Loader2, CheckCircle, HelpCircle } from 'lucide-react';
import { TableRow, TableCell } from '@/components/ui/table';

export default function StateRow({ 
    state, 
    status, 
    loading,
    onLoadBoundaries, 
    onLoadDemographics,
    expanded,
    onToggleExpand,
    counties,
    isLoadingHierarchy
}) {
    const stateStatus = status[state.abbr];
    const hasBoundaries = stateStatus?.boundaryCount > 0;
    const isLoadingThis = loading.boundaries === state.abbr || loading.demographics === state.abbr;
    const totalPopulation = stateStatus?.totalPopulation || 0;

    return (
        <>
            <TableRow className={`${isLoadingThis ? "bg-blue-50" : ""} ${expanded ? "bg-gray-50" : ""}`}>
                <TableCell className="font-medium">
                    <div className="flex items-center gap-2">
                        <Button
                            variant="ghost"
                            size="sm"
                            className="h-6 w-6 p-0"
                            onClick={() => onToggleExpand(state.abbr)}
                            disabled={isLoadingHierarchy}
                        >
                            {isLoadingHierarchy ? (
                                <Loader2 className="w-4 h-4 animate-spin" />
                            ) : expanded ? (
                                <ChevronDown className="w-4 h-4" />
                            ) : (
                                <ChevronRight className="w-4 h-4" />
                            )}
                        </Button>
                        <div>
                            <div className="font-semibold">{state.name} ({state.abbr})</div>
                            {totalPopulation > 0 && (
                                <div className="text-xs text-gray-500">
                                    Pop: {totalPopulation.toLocaleString()}
                                </div>
                            )}
                        </div>
                    </div>
                </TableCell>
                <TableCell>
                    <div className="flex items-center gap-2">
                        {hasBoundaries ? (
                            <>
                                <CheckCircle className="w-4 h-4 text-green-500" />
                                <span className="text-green-600 text-sm font-medium">
                                    {stateStatus.boundaryCount.toLocaleString()} ZCTAs
                                </span>
                            </>
                        ) : loading.boundaries === state.abbr ? (
                            <>
                                <Loader2 className="w-4 h-4 animate-spin text-blue-500" />
                                <span className="text-blue-600 text-sm">Loading...</span>
                            </>
                        ) : (
                            <>
                                <HelpCircle className="w-4 h-4 text-gray-400" />
                                <span className="text-gray-500 text-sm">Not Loaded</span>
                            </>
                        )}
                        <Button
                            onClick={() => onLoadBoundaries(state)}
                            disabled={loading.boundaries !== null}
                            size="sm"
                            variant={hasBoundaries ? "outline" : "default"}
                        >
                            {loading.boundaries === state.abbr ? (
                                <>
                                    <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                                    Loading
                                </>
                            ) : hasBoundaries ? 'Reload' : 'Load'}
                        </Button>
                    </div>
                </TableCell>
                <TableCell>
                    <div className="flex items-center gap-2">
                        {stateStatus?.demographicsLoaded ? (
                            <>
                                <CheckCircle className="w-4 h-4 text-green-500" />
                                <span className="text-green-600 text-sm font-medium">
                                    {stateStatus.demographicsCount?.toLocaleString() || 0} ZCTAs
                                </span>
                            </>
                        ) : loading.demographics === state.abbr ? (
                            <>
                                <Loader2 className="w-4 h-4 animate-spin text-blue-500" />
                                <span className="text-blue-600 text-sm">Loading...</span>
                            </>
                        ) : (
                            <>
                                <HelpCircle className="w-4 h-4 text-gray-400" />
                                <span className="text-gray-500 text-sm">Not Loaded</span>
                            </>
                        )}
                        <Button
                            onClick={() => onLoadDemographics(state)}
                            disabled={!hasBoundaries || loading.demographics !== null}
                            size="sm"
                            variant={stateStatus?.demographicsLoaded ? "outline" : "default"}
                            className={!hasBoundaries ? "" : stateStatus?.demographicsLoaded ? "" : "bg-emerald-600 hover:bg-emerald-700"}
                        >
                            {loading.demographics === state.abbr ? (
                                <>
                                    <Loader2 className="w-3 h-3 mr-1 animate-spin" />
                                    Loading
                                </>
                            ) : stateStatus?.demographicsLoaded ? 'Reload' : 'Load'}
                        </Button>
                    </div>
                </TableCell>
            </TableRow>
            
            {expanded && counties && counties.length > 0 && counties.map(county => (
                <TableRow key={county.fips} className="bg-gray-50">
                    <TableCell className="pl-12">
                        <div className="text-sm">{county.name}</div>
                        {county.population > 0 && (
                            <div className="text-xs text-gray-500">
                                Pop: {county.population.toLocaleString()}
                            </div>
                        )}
                    </TableCell>
                    <TableCell>
                        <Badge variant="outline" className="text-xs">
                            {county.zcta_count || 0} ZCTAs
                        </Badge>
                    </TableCell>
                    <TableCell>
                        {county.has_demographics ? (
                            <Badge className="bg-green-100 text-green-800 text-xs">
                                ✓ Loaded
                            </Badge>
                        ) : (
                            <Badge variant="outline" className="text-xs text-gray-500">
                                Not Loaded
                            </Badge>
                        )}
                    </TableCell>
                </TableRow>
            ))}
        </>
    );
}