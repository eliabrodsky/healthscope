import React, { useState, useCallback, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Search, MapPin, X, Loader2, CheckCircle, Plus, AlertTriangle, Database, Sparkles, Upload, FileJson } from 'lucide-react';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { base44 } from '@/api/base44Client';
import { MapContainer, TileLayer, Circle, Marker, useMap } from 'react-leaflet';
import { createPageUrl } from '@/utils';
import { Link } from 'react-router-dom';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

export default function Step1Geography({ formData, updateFormData }) {
    const [activeTab, setActiveTab] = useState('search');
    const [naturalLanguageInput, setNaturalLanguageInput] = useState('');
    const [isParsing, setIsParsing] = useState(false);
    const [geocodedCenter, setGeocodedCenter] = useState(null);
    const [zctaInput, setZctaInput] = useState('');
    const [parsedLocation, setParsedLocation] = useState(null);
    const [missingStateData, setMissingStateData] = useState(null);
    const [isLoadingState, setIsLoadingState] = useState(false);
    const [healthNeedsInput, setHealthNeedsInput] = useState('');
    const [isAnalyzingNeeds, setIsAnalyzingNeeds] = useState(false);
    const [suggestedAreas, setSuggestedAreas] = useState([]);
    const [isImporting, setIsImporting] = useState(false);

    const handleZctaCodeChange = useCallback((zctas) => {
        const uniqueZctas = [...new Set(zctas)].sort();
        updateFormData({ geography: { ...formData.geography, zcta_codes: uniqueZctas } });
    }, [formData.geography, updateFormData]);

    const loadStateData = async (stateAbbr, stateName) => {
        setIsLoadingState(true);
        const toastId = `loading-${stateAbbr}`;
        toast.loading(`Loading data for ${stateName}...`, { id: toastId });

        try {
            const boundaryResponse = await base44.functions.invoke('loadStateBoundaries', {
                stateAbbr: stateAbbr,
                stateName: stateName
            });

            if (!boundaryResponse?.data?.success) {
                throw new Error('Boundary loading failed');
            }

            const demoResponse = await base44.functions.invoke('loadDemographicsSimple', {
                stateAbbr: stateAbbr,
                stateName: stateName
            });

            if (demoResponse?.data?.success) {
                toast.success(`${stateName} data loaded! Try your search again.`, { id: toastId, duration: 5000 });
                setMissingStateData(null);
            } else {
                toast.warning(`Boundaries loaded for ${stateName}, but demographics failed`, { id: toastId });
            }
        } catch (error) {
            toast.error(`Failed to load ${stateName}: ${error.message}`, { id: toastId });
        } finally {
            setIsLoadingState(false);
        }
    };

    const parseNaturalLanguage = async () => {
        if (!naturalLanguageInput.trim()) return;

        setIsParsing(true);
        setParsedLocation(null);
        setMissingStateData(null);
        toast.info("AI is parsing your location...");
        
        try {
            const prompt = `Parse this geographic description: "${naturalLanguageInput}"
            
            Please extract and provide:
            1. The PRIMARY CITY name (e.g., from "15 mile radius around NEW Orleans Louisiana" extract "New Orleans")
            2. The STATE name in full form (e.g., "Louisiana") 
            3. The county if mentioned
            4. The radius in miles if specified (if not specified, use a 50-mile default radius for comprehensive coverage)
            5. The center point for radius calculations
            6. Latitude and longitude for the primary location
            
            The output must be a JSON object with keys: "latitude", "longitude", "state", "county", "city", "radius_miles", "radius_center".`;

            const response = await base44.functions.invoke('callOpenAI', { prompt });
            const result = response.data;
            
            console.log("AI parsing result:", result);
            
            const newGeography = { ...formData.geography };

            if (result.state) newGeography.state = result.state;
            if (result.county) newGeography.county = result.county;
            if (result.city) newGeography.city = result.city;
            if (result.radius_miles) {
                newGeography.radius_miles = String(result.radius_miles);
            } else {
                newGeography.radius_miles = "50";
            }
            
            if (result.latitude) newGeography.latitude = result.latitude;
            if (result.longitude) newGeography.longitude = result.longitude;
            
            if (result.radius_center && typeof result.radius_center === 'string') {
                newGeography.radius_center = result.radius_center;
            } else if (result.city && result.state) {
                newGeography.radius_center = `${result.city}, ${result.state}`;
            }

            setParsedLocation({ city: result.city, state: result.state, geocoded: !!(result.latitude && result.longitude) });

            if (result.latitude && result.longitude) {
                setGeocodedCenter([result.latitude, result.longitude]);
                
                const locationParts = [];
                if (result.city) locationParts.push(result.city);
                if (result.state) locationParts.push(result.state);
                const locationString = locationParts.join(', ') || 'Location';
                
                toast.success(`✅ Location identified: ${locationString}`);
                toast.info(`ZCTAs will be loaded in the next step`, { duration: 3000 });
            } else {
                 toast.warning("⚠️ AI could not determine precise coordinates. Please refine your query or use manual input.");
                 setGeocodedCenter(null);
            }

            newGeography.zcta_codes = [];
            updateFormData({ geography: newGeography });

        } catch (error) {
            console.error("Error parsing natural language:", error);
            
            if (error.message?.includes('No ZCTAs found') || error.message?.includes('Load State Data')) {
                const stateMatch = error.message.match(/for ([A-Z][a-z]+)/);
                if (stateMatch) {
                    setMissingStateData({ 
                        stateName: stateMatch[1],
                        message: error.message
                    });
                }
            }
            
            toast.error("❌ Could not parse the geographic description. Please try rephrasing or use manual input.");
        } finally {
            setIsParsing(false);
        }
    };
    
    const addZcta = () => {
        const zcta = zctaInput.trim();
        if (!/^\d{5}$/.test(zcta)) {
            toast.error("Please enter a valid 5-digit ZCTA code.");
            return;
        }
        if (formData.geography.zcta_codes?.includes(zcta)) {
            toast.info("ZCTA already added.");
            setZctaInput('');
            return;
        }
        handleZctaCodeChange([...(formData.geography.zcta_codes || []), zcta]);
        setZctaInput('');
        toast.success(`ZCTA ${zcta} added.`);
    };

    const removeZcta = (zctaToRemove) => {
        handleZctaCodeChange((formData.geography.zcta_codes || []).filter(z => z !== zctaToRemove));
        toast.info(`ZCTA ${zctaToRemove} removed.`);
    };

    const analyzeHealthNeeds = async () => {
        if (!healthNeedsInput.trim()) return;

        setIsAnalyzingNeeds(true);
        setSuggestedAreas([]);
        toast.info("AI is analyzing health needs and finding relevant areas...");

        try {
            const response = await base44.integrations.Core.InvokeLLM({
                prompt: `You are a public health expert. Based on the following health needs description, suggest 3-5 specific geographic areas (cities, counties, or regions) in the United States that would be good candidates for a community health needs assessment.

Health Needs Description: "${healthNeedsInput}"

For each suggested area, provide:
1. The location (city/county and state)
2. Why this area is relevant to the health needs described
3. Approximate latitude and longitude
4. Suggested radius in miles for the assessment area

Return as JSON array with objects containing: location, state, reason, latitude, longitude, radius_miles`,
                add_context_from_internet: true,
                response_json_schema: {
                    type: "object",
                    properties: {
                        suggestions: {
                            type: "array",
                            items: {
                                type: "object",
                                properties: {
                                    location: { type: "string" },
                                    state: { type: "string" },
                                    reason: { type: "string" },
                                    latitude: { type: "number" },
                                    longitude: { type: "number" },
                                    radius_miles: { type: "number" }
                                }
                            }
                        }
                    }
                }
            });

            if (response?.suggestions && response.suggestions.length > 0) {
                setSuggestedAreas(response.suggestions);
                toast.success(`Found ${response.suggestions.length} suggested areas`);
            } else {
                toast.warning("Could not find specific area suggestions. Try being more specific.");
            }
        } catch (error) {
            console.error("Error analyzing health needs:", error);
            toast.error("Failed to analyze health needs");
        } finally {
            setIsAnalyzingNeeds(false);
        }
    };

    const selectSuggestedArea = (area) => {
        const newGeography = {
            ...formData.geography,
            city: area.location,
            state: area.state,
            latitude: area.latitude,
            longitude: area.longitude,
            radius_miles: String(area.radius_miles || 50),
            radius_center: `${area.location}, ${area.state}`,
            zcta_codes: []
        };
        updateFormData({ geography: newGeography });
        setGeocodedCenter([area.latitude, area.longitude]);
        setParsedLocation({ city: area.location, state: area.state, geocoded: true });
        toast.success(`Selected ${area.location}, ${area.state}`);
    };

    const handleFileImport = async (event) => {
        const file = event.target.files?.[0];
        if (!file) return;

        setIsImporting(true);
        const toastId = toast.loading("Importing geographic data...");

        try {
            const fileText = await file.text();
            const fileName = file.name.toLowerCase();

            let geojsonData;
            
            if (fileName.endsWith('.geojson') || fileName.endsWith('.json')) {
                geojsonData = JSON.parse(fileText);
            } else if (fileName.endsWith('.zip')) {
                // For shapefiles, we'd need a library like shpjs
                toast.error("Shapefile (.shp) import requires the .zip to be converted to GeoJSON first", { id: toastId });
                setIsImporting(false);
                return;
            } else {
                toast.error("Unsupported file format. Please use GeoJSON.", { id: toastId });
                setIsImporting(false);
                return;
            }

            // Extract ZCTAs or coordinates from GeoJSON
            const extractedZctas = [];
            const coordinates = [];

            if (geojsonData.type === 'FeatureCollection' && geojsonData.features) {
                for (const feature of geojsonData.features) {
                    // Try to extract ZCTA from properties
                    const props = feature.properties || {};
                    const zcta = props.ZCTA5CE20 || props.ZCTA5CE10 || props.ZCTA || props.ZIP || props.zip_code || props.zcta5;
                    
                    if (zcta && /^\d{5}$/.test(String(zcta))) {
                        extractedZctas.push(String(zcta));
                    }

                    // Extract centroid for map display
                    if (feature.geometry) {
                        if (feature.geometry.type === 'Point') {
                            coordinates.push(feature.geometry.coordinates);
                        } else if (feature.geometry.type === 'Polygon') {
                            const coords = feature.geometry.coordinates[0];
                            const centroid = coords.reduce((acc, c) => [acc[0] + c[0], acc[1] + c[1]], [0, 0]);
                            coordinates.push([centroid[0] / coords.length, centroid[1] / coords.length]);
                        }
                    }
                }
            }

            if (extractedZctas.length > 0) {
                const uniqueZctas = [...new Set(extractedZctas)];
                handleZctaCodeChange(uniqueZctas);
                toast.success(`Imported ${uniqueZctas.length} ZCTA codes`, { id: toastId });

                // Center map on imported data
                if (coordinates.length > 0) {
                    const avgLon = coordinates.reduce((s, c) => s + c[0], 0) / coordinates.length;
                    const avgLat = coordinates.reduce((s, c) => s + c[1], 0) / coordinates.length;
                    setGeocodedCenter([avgLat, avgLon]);
                }
            } else if (coordinates.length > 0) {
                // No ZCTAs but we have coordinates - set center
                const avgLon = coordinates.reduce((s, c) => s + c[0], 0) / coordinates.length;
                const avgLat = coordinates.reduce((s, c) => s + c[1], 0) / coordinates.length;
                setGeocodedCenter([avgLat, avgLon]);
                
                const newGeography = {
                    ...formData.geography,
                    latitude: avgLat,
                    longitude: avgLon,
                    radius_miles: "50"
                };
                updateFormData({ geography: newGeography });
                toast.success("Imported geographic boundaries. ZCTAs will be loaded in the next step.", { id: toastId });
            } else {
                toast.warning("Could not extract ZCTA codes or coordinates from file", { id: toastId });
            }
        } catch (error) {
            console.error("Import error:", error);
            toast.error("Failed to import file: " + error.message, { id: toastId });
        } finally {
            setIsImporting(false);
            event.target.value = '';
        }
    };

    const MapUpdater = ({ center }) => {
        const map = useMap();
        useEffect(() => {
            if (center) {
                map.setView(center, map.getZoom() < 8 ? 8 : map.getZoom());
            }
        }, [center, map]);
        return null;
    };

    const zctaCodes = formData.geography.zcta_codes || [];

    return (
        <div className="space-y-6">
            <div>
                <h2 className="text-xl font-semibold text-gray-900">Define Geographic Area</h2>
                <p className="text-gray-600 mt-1">Specify the community or region for your health assessment using ZCTAs (ZIP Code Tabulation Areas).</p>
                <div className="mt-2 p-3 bg-amber-50 border border-amber-200 rounded-lg">
                    <p className="text-sm text-amber-800">
                        <strong>Note:</strong> Assessments are currently limited to a <strong>100-mile radius</strong>. ZIP codes falling outside this limit will not be included.
                    </p>
                </div>
            </div>

            {missingStateData && (
                <Alert className="border-amber-300 bg-amber-50">
                    <AlertTriangle className="w-5 h-5 text-amber-600" />
                    <AlertDescription>
                        <div className="space-y-3">
                            <p className="font-semibold text-amber-900">
                                State data not loaded yet
                            </p>
                            <p className="text-sm text-amber-800">
                                Before you can analyze {missingStateData.stateName}, you need to load its boundary and population data.
                            </p>
                            <div className="flex gap-3">
                                <Button
                                    onClick={() => {
                                        const stateAbbr = {
                                            'Louisiana': 'LA',
                                            'Arkansas': 'AR',
                                            'Texas': 'TX',
                                            'Mississippi': 'MS',
                                            'Alabama': 'AL'
                                        }[missingStateData.stateName];
                                        
                                        if (stateAbbr) {
                                            loadStateData(stateAbbr, missingStateData.stateName);
                                        }
                                    }}
                                    disabled={isLoadingState}
                                    size="sm"
                                    className="bg-emerald-600 hover:bg-emerald-700"
                                >
                                    {isLoadingState ? (
                                        <>
                                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                            Loading...
                                        </>
                                    ) : (
                                        <>
                                            <Database className="w-4 h-4 mr-2" />
                                            Load {missingStateData.stateName} Data
                                        </>
                                    )}
                                </Button>
                                <Link to={createPageUrl('InitialDataLoader')}>
                                    <Button variant="outline" size="sm">
                                        Go to Data Loader
                                    </Button>
                                </Link>
                            </div>
                        </div>
                    </AlertDescription>
                </Alert>
            )}
            
            <div className="border-b border-gray-200">
                <nav className="-mb-px flex space-x-6 overflow-x-auto">
                    <button
                        onClick={() => setActiveTab('search')}
                        className={`whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm ${activeTab === 'search' ? 'border-emerald-500 text-emerald-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}
                    >
                        <Search className="w-4 h-4 inline mr-1" />
                        Location Search
                    </button>
                    <button
                        onClick={() => setActiveTab('needs')}
                        className={`whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm ${activeTab === 'needs' ? 'border-emerald-500 text-emerald-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}
                    >
                        <Sparkles className="w-4 h-4 inline mr-1" />
                        AI Health Needs
                    </button>
                    <button
                        onClick={() => setActiveTab('import')}
                        className={`whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm ${activeTab === 'import' ? 'border-emerald-500 text-emerald-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}
                    >
                        <Upload className="w-4 h-4 inline mr-1" />
                        Import File
                    </button>
                    <button
                        onClick={() => setActiveTab('manual')}
                        className={`whitespace-nowrap py-3 px-1 border-b-2 font-medium text-sm ${activeTab === 'manual' ? 'border-emerald-500 text-emerald-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}
                    >
                        <Plus className="w-4 h-4 inline mr-1" />
                        Manual Entry
                    </button>
                </nav>
            </div>

            {activeTab === 'search' && (
                <div className="p-6 border border-gray-200 rounded-lg bg-white">
                    <Label htmlFor="natural-language-input" className="font-semibold text-gray-800">Describe your geographic area</Label>
                    <p className="text-sm text-gray-500 mb-3">e.g., "100 mile radius around Dumas, Arkansas", "Cook County, IL"</p>
                    <div className="flex gap-2">
                        <Input 
                            id="natural-language-input"
                            value={naturalLanguageInput}
                            onChange={(e) => setNaturalLanguageInput(e.target.value)}
                            placeholder="e.g., 50 mile radius around Pine Bluff, Arkansas"
                            onKeyPress={(e) => e.key === 'Enter' && parseNaturalLanguage()}
                        />
                        <Button onClick={parseNaturalLanguage} disabled={isParsing}>
                            {isParsing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                            <span className="ml-2">Find Area</span>
                        </Button>
                    </div>
                    {parsedLocation && (
                        <div className="mt-4 p-4 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-900">
                            <div className="flex items-center gap-2">
                                <CheckCircle className="w-5 h-5 text-emerald-600" />
                                <div className="flex-1">
                                    <h4 className="font-semibold">Area Identified</h4>
                                    <p className="text-sm">
                                        {parsedLocation.city || 'Unknown City'}
                                        {parsedLocation.city && parsedLocation.state ? ', ' : ''}
                                        {parsedLocation.state || 'Unknown State'}
                                    </p>
                                    <p className="text-xs text-emerald-700 mt-1">
                                        ZCTAs will be loaded in the next step
                                    </p>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            )}

            {activeTab === 'needs' && (
                <div className="p-6 border border-gray-200 rounded-lg bg-white space-y-4">
                    <div>
                        <Label htmlFor="health-needs-input" className="font-semibold text-gray-800 flex items-center gap-2">
                            <Sparkles className="w-4 h-4 text-purple-600" />
                            Describe Your Health Needs Focus
                        </Label>
                        <p className="text-sm text-gray-500 mb-3">
                            Describe the health issues, populations, or conditions you want to assess. AI will suggest relevant geographic areas.
                        </p>
                        <Textarea
                            id="health-needs-input"
                            value={healthNeedsInput}
                            onChange={(e) => setHealthNeedsInput(e.target.value)}
                            placeholder="e.g., 'Rural areas with high diabetes rates and limited access to primary care' or 'Underserved Hispanic communities with maternal health disparities' or 'Areas impacted by opioid crisis in the Southeast'"
                            rows={3}
                            className="mb-3"
                        />
                        <Button 
                            onClick={analyzeHealthNeeds} 
                            disabled={isAnalyzingNeeds || !healthNeedsInput.trim()}
                            className="bg-purple-600 hover:bg-purple-700"
                        >
                            {isAnalyzingNeeds ? (
                                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Analyzing...</>
                            ) : (
                                <><Sparkles className="w-4 h-4 mr-2" /> Find Matching Areas</>
                            )}
                        </Button>
                    </div>

                    {suggestedAreas.length > 0 && (
                        <div className="space-y-3">
                            <h4 className="font-semibold text-gray-800">Suggested Areas</h4>
                            <div className="grid gap-3">
                                {suggestedAreas.map((area, idx) => (
                                    <div key={idx} className="p-4 border rounded-lg hover:border-emerald-300 hover:bg-emerald-50 transition-colors">
                                        <div className="flex items-start justify-between gap-4">
                                            <div className="flex-1">
                                                <h5 className="font-semibold text-gray-900">
                                                    {area.location}, {area.state}
                                                </h5>
                                                <p className="text-sm text-gray-600 mt-1">{area.reason}</p>
                                                <p className="text-xs text-gray-500 mt-1">
                                                    Suggested radius: {area.radius_miles} miles
                                                </p>
                                            </div>
                                            <Button
                                                size="sm"
                                                onClick={() => selectSuggestedArea(area)}
                                                className="bg-emerald-600 hover:bg-emerald-700"
                                            >
                                                <MapPin className="w-4 h-4 mr-1" />
                                                Select
                                            </Button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
            )}

            {activeTab === 'import' && (
                <div className="p-6 border border-gray-200 rounded-lg bg-white space-y-4">
                    <div>
                        <Label className="font-semibold text-gray-800 flex items-center gap-2">
                            <FileJson className="w-4 h-4 text-blue-600" />
                            Import Geographic Boundaries
                        </Label>
                        <p className="text-sm text-gray-500 mb-3">
                            Upload a GeoJSON file containing ZCTA boundaries or geographic areas for your assessment.
                        </p>
                    </div>

                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-emerald-400 transition-colors">
                        <Upload className="w-12 h-12 mx-auto text-gray-400 mb-3" />
                        <p className="text-gray-600 mb-2">Drag & drop or click to upload</p>
                        <p className="text-xs text-gray-500 mb-4">Supports: GeoJSON (.geojson, .json)</p>
                        <input
                            type="file"
                            accept=".geojson,.json"
                            onChange={handleFileImport}
                            disabled={isImporting}
                            className="hidden"
                            id="file-import"
                        />
                        <label htmlFor="file-import">
                            <Button asChild disabled={isImporting}>
                                <span>
                                    {isImporting ? (
                                        <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Importing...</>
                                    ) : (
                                        <><Upload className="w-4 h-4 mr-2" /> Choose File</>
                                    )}
                                </span>
                            </Button>
                        </label>
                    </div>

                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                        <h4 className="font-semibold text-blue-900 text-sm mb-2">Supported Formats</h4>
                        <ul className="text-sm text-blue-800 space-y-1">
                            <li>• <strong>GeoJSON</strong> - Standard geographic data format with ZCTA properties</li>
                            <li>• Files should contain features with ZCTA5CE20, ZCTA, or ZIP properties</li>
                            <li>• You can export GeoJSON from QGIS, ArcGIS, or the Census Bureau</li>
                        </ul>
                    </div>
                </div>
            )}

            {activeTab === 'manual' && (
                <div className="p-6 border border-gray-200 rounded-lg bg-white">
                    <Label htmlFor="zcta-input" className="font-semibold text-gray-800">Add ZCTA Code</Label>
                    <p className="text-sm text-gray-500 mb-3">Enter a 5-digit ZCTA (ZIP Code Tabulation Area) to add to your list.</p>
                    <div className="flex gap-2">
                        <Input 
                            id="zcta-input"
                            value={zctaInput}
                            onChange={(e) => setZctaInput(e.target.value)}
                            placeholder="e.g., 71639"
                            onKeyPress={(e) => e.key === 'Enter' && addZcta()}
                            maxLength={5}
                        />
                        <Button onClick={addZcta}>
                            <Plus className="w-4 h-4" />
                            <span className="ml-2">Add ZCTA</span>
                        </Button>
                    </div>
                </div>
            )}

            <div className="h-[500px] rounded-lg overflow-hidden border border-gray-200 shadow-sm">
                <MapContainer center={geocodedCenter || [39.8283, -98.5795]} zoom={geocodedCenter ? 8 : 4} scrollWheelZoom={true} style={{ height: '100%', width: '100%' }}>
                    <TileLayer
                        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    />
                    {geocodedCenter && (
                        <>
                            <Marker position={geocodedCenter}></Marker>
                            {formData.geography?.radius_miles && (
                                <Circle 
                                    center={geocodedCenter} 
                                    radius={parseFloat(formData.geography.radius_miles) * 1609.34}
                                    pathOptions={{ color: 'emerald', fillColor: 'emerald', fillOpacity: 0.1 }}
                                />
                            )}
                            <MapUpdater center={geocodedCenter} />
                        </>
                    )}
                </MapContainer>
            </div>
        </div>
    );
}