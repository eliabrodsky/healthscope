import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Building2, Loader2, MapPin, Users, CheckCircle2, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';

export default function Step3LoadCities({ formData, updateFormData, onSaveProgress }) {
  const [isLoading, setIsLoading] = useState(false);
  const [cities, setCities] = useState([]);
  const [status, setStatus] = useState('idle');

  useEffect(() => {
    if (formData?.processed_data?.major_cities) {
      setCities(formData.processed_data.major_cities);
      setStatus('loaded');
    }
  }, [formData]);

  const handleLoadCities = async () => {
    const zctas = formData?.geography?.zcta_codes || formData?.geography?.zip_codes || [];
    if (zctas.length === 0) {
      toast.error('Please load ZCTA boundaries first', { position: 'top-center' });
      return;
    }

    setIsLoading(true);
    setStatus('loading');

    try {
      // Try ZCTA codes first, then fall back to zip_codes
      const zctaList = formData.geography.zcta_codes || formData.geography.zip_codes || [];
      
      if (zctaList.length === 0) {
        toast.error('No ZIP codes available to analyze', { position: 'top-center' });
        setStatus('error');
        return;
      }

      // Fetch demographic data first - query ALL ZCTAs, not just a sample
      const demographics = await base44.entities.ZipDemographics.filter({
        zcta5: { '$in': zctaList }
      }, null, 2000);

      console.log(`Loaded ${demographics.length} demographic records for ${zctaList.length} ZCTAs`);

      if (demographics.length === 0) {
        toast.error('No demographic data found. Load demographics first in Step 3.', { position: 'top-center' });
        setStatus('error');
        return;
      }

      // Ensure relationship data is loaded for all relevant states
      // This is critical for cross-state radiuses or when data hasn't been loaded yet
      const statesInArea = new Set();
      demographics.forEach(d => {
        if (d.state_abbr) statesInArea.add(d.state_abbr);
      });
      
      if (statesInArea.size > 0) {
        const stateArray = Array.from(statesInArea);
        console.log(`Ensuring city relationship data for states: ${stateArray.join(', ')}`);
        
        // Trigger background loading for each state (function handles deduplication)
        // We await this to ensure data is ready before querying
        await Promise.all(stateArray.map(state => 
          base44.functions.invoke('loadZctaPlaceRelationships', { state_abbr: state })
            .catch(err => console.warn(`Failed to load relationships for ${state}:`, err))
        ));
      }

      // Fetch ZCTA-Place relationships (actual cities/towns, not counties)
      // For multi-state regions, we query ALL ZCTAs across state lines
      const placeRelationships = await base44.entities.ZctaPlaceRelationship.filter({
        zcta5: { '$in': zctaList }
      }, null, 5000);

      console.log(`Loaded ${placeRelationships.length} place relationships`);

      // Create a map of ZCTA -> place info, filtering out parishes/counties
      const zctaPlaceMap = new Map();
      placeRelationships.forEach(p => {
        // Exclude parishes and counties (they typically have these in their names)
        const isCountyOrParish = /(parish|county)$/i.test(p.place_name);
        if (isCountyOrParish) return;
        
        // Prefer primary places or places with higher population
        const existing = zctaPlaceMap.get(p.zcta5);
        if (!existing || p.is_primary || (p.place_population > (existing.place_population || 0))) {
          zctaPlaceMap.set(p.zcta5, {
            place: p.place_name.replace(/ (city|town|village|CDP)$/i, '').trim(),
            state: p.state_abbr || formData.geography?.state || '',
            place_population: p.place_population || 0,
            place_geoid: p.place_geoid
          });
        }
      });
      
      console.log(`Created place map with ${zctaPlaceMap.size} ZCTA-place mappings`);

      // Group by place (actual cities/towns)
      const cityMap = new Map();
      
      // If no place relationships found, try to create basic entries from demographic state data
      if (zctaPlaceMap.size === 0) {
        console.log('No place relationships - creating basic city list from demographic data');
        
        // Group ZCTAs by state
        const stateGroups = new Map();
        for (const demo of demographics) {
          const state = demo.state_abbr || formData.geography?.state || '';
          if (!stateGroups.has(state)) {
            stateGroups.set(state, { population: 0, zip_codes: [] });
          }
          const group = stateGroups.get(state);
          group.population += demo.population || 0;
          group.zip_codes.push(demo.zcta5);
        }
        
        // Create city entries from state groups
        for (const [state, data] of stateGroups) {
          if (data.population > 0) {
            cityMap.set(`state-${state}`, {
              name: `${state} Service Area`,
              state: state,
              population: data.population,
              zip_codes: data.zip_codes
            });
          }
        }
      } else {
        // Normal flow with place relationships
        for (const demo of demographics) {
          const placeInfo = zctaPlaceMap.get(demo.zcta5);
          if (!placeInfo || !placeInfo.place) continue;
          
          const cityKey = placeInfo.place_geoid;
          
          if (cityMap.has(cityKey)) {
            const existing = cityMap.get(cityKey);
            existing.zip_codes.push(demo.zcta5);
            // Use the place population, not sum of ZCTA populations
            existing.population = Math.max(existing.population, placeInfo.place_population);
          } else {
            cityMap.set(cityKey, {
              name: placeInfo.place,
              state: placeInfo.state,
              population: placeInfo.place_population,
              zip_codes: [demo.zcta5]
            });
          }
        }
      }

      // Convert to array and sort by population
      // Lower threshold to 500 for smaller rural areas
      const cityList = Array.from(cityMap.values())
        .filter(city => city.population > 500) // Lower threshold for rural areas
        .sort((a, b) => b.population - a.population);

      setCities(cityList);
      
      updateFormData({
        processed_data: {
          ...formData.processed_data,
          major_cities: cityList,
          cities_loaded: true
        }
      });

      setStatus('loaded');
      
      if (cityList.length === 0) {
        toast.warning('No population centers found. This may indicate missing county grouping data.', { position: 'top-center', duration: 8000 });
      } else {
        toast.success(`Found ${cityList.length} population centers in the assessment area`, { position: 'top-center' });
      }
      
      if (onSaveProgress) {
        await onSaveProgress();
      }
    } catch (error) {
      console.error('Error loading cities:', error);
      toast.error(`Failed to load city data: ${error.message}`, { position: 'top-center' });
      setStatus('error');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Identify Major Cities</h2>
        <p className="text-gray-600">
          Discover the major population centers in your assessment area based on the loaded ZIP codes.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Building2 className="w-5 h-5" />
            City Population Analysis
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">
                {(formData?.geography?.zcta_codes || formData?.geography?.zip_codes || []).length} ZIP codes will be analyzed for city data
              </p>
              {status === 'loaded' && (
                <p className="text-sm text-emerald-600 flex items-center gap-1 mt-1">
                  <CheckCircle2 className="w-4 h-4" />
                  {cities.length} cities identified
                </p>
              )}
            </div>
            <Button 
              onClick={handleLoadCities}
              disabled={isLoading || ((formData?.geography?.zcta_codes || formData?.geography?.zip_codes || []).length === 0)}
              className="bg-emerald-600 hover:bg-emerald-700"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Loading Cities...
                </>
              ) : status === 'loaded' ? (
                <>
                  <CheckCircle2 className="w-4 h-4 mr-2" />
                  Reload Cities
                </>
              ) : (
                <>
                  <Building2 className="w-4 h-4 mr-2" />
                  Load City Data
                </>
              )}
            </Button>
          </div>

          {status === 'error' && (
            <div className="flex items-center gap-2 p-3 bg-red-50 text-red-800 rounded-lg border border-red-200">
              <AlertCircle className="w-4 h-4" />
              <span className="text-sm">Failed to load city data. Please try again.</span>
            </div>
          )}
        </CardContent>
      </Card>

      {cities.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Major Cities ({cities.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3 max-h-96 overflow-y-auto">
              {cities.map((city, idx) => (
                <div 
                  key={`${city.name}-${city.state}-${idx}`}
                  className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border border-gray-200"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center">
                      <MapPin className="w-4 h-4 text-emerald-600" />
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">
                        {city.name}, {city.state}
                      </p>
                      <p className="text-xs text-gray-500">
                        {city.county ? `${city.county} County` : city.state_name}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-2 text-sm text-gray-700">
                      <Users className="w-4 h-4" />
                      <span className="font-semibold">
                        {city.population.toLocaleString()}
                      </span>
                    </div>
                    <Badge variant="outline" className="text-xs mt-1">
                      {city.zip_codes.length} ZIP{city.zip_codes.length !== 1 ? 's' : ''}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}