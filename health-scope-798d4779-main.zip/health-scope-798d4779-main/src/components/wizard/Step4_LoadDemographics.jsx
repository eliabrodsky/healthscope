import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Database, Loader2, CheckCircle, AlertTriangle, Info } from 'lucide-react';
import { toast } from 'sonner';
import { base44 } from '@/api/base44Client';

export default function Step4LoadDemographics({ formData, updateFormData, assessmentId, onSaveProgress }) {
  const [isLoading, setIsLoading] = useState(false);

  const demographicsLoaded = formData.processed_data?.demographics_loaded || false;
  const zctaCodes = formData.geography?.zcta_codes || formData.geography?.zip_codes || [];

  const handleLoadDemographics = async () => {
    if (zctaCodes.length === 0) {
      toast.error("No ZCTA codes available. Please load boundaries first.", { position: 'top-center' });
      return;
    }

    setIsLoading(true);
    const timeoutId = setTimeout(() => {
      toast.info(`Still loading demographic data. This may take a few more moments...`, { id: 'demo-timeout' });
    }, 30000);
    
    toast.loading(`Loading population, income, poverty & insurance data for ${zctaCodes.length} ZCTAs...`, { id: 'load-demographics' });

    try {
      const response = await base44.functions.invoke('loadZctaDemographics', {
        zctas: zctaCodes,
        batchSize: 10
      });

      const data = response?.data;

      if (data?.success) {
        updateFormData({
          processed_data: {
            ...formData.processed_data,
            demographics_loaded: true,
            demographics_summary: {
              loaded: data.processed || 0,
              total: data.total || zctaCodes.length,
              source: 'ZCTA API (Census ACS 5-Year)'
            }
          }
        });
        
        clearTimeout(timeoutId);
        toast.success(
          `✓ Loaded demographics for ${data.processed} ZCTAs!`,
          { id: 'load-demographics' }
        );
        
        if (onSaveProgress) {
          setTimeout(() => onSaveProgress(), 500);
        }
      } else {
        throw new Error(data?.error || 'Failed to load demographics');
      }
    } catch (error) {
      console.error("Error loading demographics:", error);
      const message = error.message || 'Unknown error';
      
      clearTimeout(timeoutId);
      toast.error(
        `Failed to load demographics: ${message}`,
        { id: 'load-demographics', duration: 8000 }
      );
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-gray-900">Load Demographics</h2>
        <p className="text-gray-600 mt-1">
          Load population and socioeconomic data for your assessment area from our ZCTA demographics API.
        </p>
      </div>

      {/* Status Card */}
      <Card className={demographicsLoaded ? "bg-emerald-50 border-emerald-200" : "bg-blue-50 border-blue-200"}>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            {demographicsLoaded ? (
              <>
                <CheckCircle className="w-5 h-5 text-emerald-600" />
                <span className="text-emerald-900">Demographics Loaded</span>
              </>
            ) : (
              <>
                <AlertTriangle className="w-5 h-5 text-blue-600" />
                <span className="text-blue-900">Demographics Not Loaded Yet</span>
              </>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {demographicsLoaded ? (
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Badge className="bg-emerald-100 text-emerald-800 border-emerald-200">
                  {formData.processed_data?.demographics_summary?.loaded || 0} ZCTAs loaded
                </Badge>
                <Badge variant="outline">
                  ZCTA API (Census ACS)
                </Badge>
              </div>
              <p className="text-sm text-emerald-700">
                Demographic data successfully loaded. You can proceed to the next step.
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              <p className="text-sm text-blue-700">
                {zctaCodes.length} ZIP codes ready for demographic data loading.
              </p>
              <div className="flex items-start gap-2 text-xs text-blue-600 bg-blue-100 p-2 rounded">
                <Info className="w-4 h-4 mt-0.5 flex-shrink-0" />
                <span>This will load population, income, poverty, and insurance data from our ZCTA API (Census-based data).</span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Action Button */}
      <div className="flex justify-center">
        <Button
          onClick={handleLoadDemographics}
          disabled={isLoading || zctaCodes.length === 0}
          size="lg"
          className="bg-blue-600 hover:bg-blue-700 min-w-64"
        >
          {isLoading ? (
            <>
              <Loader2 className="w-5 h-5 mr-2 animate-spin" />
              Loading Demographics...
            </>
          ) : demographicsLoaded ? (
            <>
              <CheckCircle className="w-5 h-5 mr-2 text-white" />
              ✓ Demographics Loaded
            </>
          ) : (
            <>
              <Database className="w-5 h-5 mr-2" />
              Load Demographics Data
            </>
          )}
        </Button>
      </div>
    </div>
  );
}