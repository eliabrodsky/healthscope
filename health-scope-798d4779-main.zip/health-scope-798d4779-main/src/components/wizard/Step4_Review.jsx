import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { MapPin, AlertCircle, CheckCircle, Edit, Plus } from 'lucide-react';

// Fallback ZIP codes for major cities
const MAJOR_CITY_ZIPS = {
  'Houston': ['77001', '77002', '77003', '77004', '77005', '77006', '77007', '77008', '77009', '77010', '77020', '77025', '77030', '77035', '77040', '77045', '77050', '77055', '77060', '77065', '77070', '77075', '77080', '77085', '77090', '77095'],
  'Dallas': ['75001', '75006', '75019', '75201', '75202', '75203', '75204', '75205', '75206', '75207', '75208', '75209', '75210', '75211', '75212', '75214', '75215', '75216', '75217', '75218', '75219', '75220', '75221', '75222', '75223', '75224', '75225', '75226', '75227', '75228', '75229', '75230', '75231', '75232', '75233', '75234', '75235', '75236', '75237', '75238', '75240', '75241', '75242', '75243', '75244', '75245', '75246', '75247', '75248', '75249', '75250'],
  'Chicago': ['60601', '60602', '60603', '60604', '60605', '60606', '60607', '60608', '60609', '60610', '60611', '60612', '60613', '60614', '60615', '60616', '60617', '60618', '60619', '60620', '60621', '60622', '60623', '60624', '60625', '60626', '60628', '60629', '60630', '60631', '60632', '60633', '60634', '60636', '60637', '60638', '60639', '60640', '60641', '60642', '60643', '60644', '60645', '60646', '60647', '60649', '60651', '60652', '60653', '60654', '60655', '60656', '60657', '60659', '60660']
};

export default function Step4Review({ formData, updateFormData }) {
  const { title, description, data_sources, geography, elements_included } = formData;
  const [showGeographyEdit, setShowGeographyEdit] = useState(false);

  const getGeographyDescription = () => {
    const parts = [];
    
    if (geography.city) parts.push(geography.city);
    if (geography.county) parts.push(`${geography.county} County`);
    if (geography.state) parts.push(geography.state);
    
    if (parts.length === 0) {
      return "Geographic area not specified";
    }
    
    let description = parts.join(', ');
    
    if (geography.radius_miles && geography.radius_center) {
      description += ` (${geography.radius_miles}-mile radius around ${geography.radius_center})`;
    }
    
    return description;
  };

  const getGeographyStatus = () => {
    const hasLocation = geography.city || geography.county || geography.state;
    const hasZipCodes = geography.zip_codes && geography.zip_codes.length > 0;
    const hasFallbackZips = geography.city && MAJOR_CITY_ZIPS[geography.city];
    
    if (hasLocation && (hasZipCodes || hasFallbackZips)) return 'complete';
    if (hasZipCodes || hasFallbackZips) return 'partial';
    return 'incomplete';
  };

  const handleUseFallbackZips = () => {
    if (geography.city && MAJOR_CITY_ZIPS[geography.city]) {
      const fallbackZips = MAJOR_CITY_ZIPS[geography.city];
      updateFormData({ 
        geography: { 
          ...geography, 
          zip_codes: fallbackZips 
        } 
      });
    }
  };

  const geographyStatus = getGeographyStatus();

  return (
    <div>
      <h2 className="text-xl font-semibold text-gray-900 mb-4">Review & Finish</h2>
      <p className="text-gray-600 mb-6">Confirm the details for your assessment. Verify the geographic area is correct before proceeding.</p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-6">
          <Card className="bg-gray-50/50 border-gray-200">
            <CardHeader><CardTitle className="text-base">Final Details</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="title">Assessment Title *</Label>
                <Input 
                  id="title" 
                  placeholder="e.g., Houston, Texas Health Analysis 2024"
                  value={title}
                  onChange={(e) => updateFormData({ title: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="description">Description (Optional)</Label>
                <Textarea 
                  id="description" 
                  placeholder="A brief summary of this assessment's goals."
                  value={description}
                  onChange={(e) => updateFormData({ description: e.target.value })}
                />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="bg-gray-50/50 border-gray-200">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">Configuration Summary</CardTitle>
                {geographyStatus === 'incomplete' && (
                  <Badge variant="destructive">Needs Review</Badge>
                )}
                {geographyStatus === 'partial' && (
                  <Badge variant="outline">Partial Info</Badge>
                )}
                {geographyStatus === 'complete' && (
                  <Badge className="bg-green-100 text-green-800 border-green-200">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Ready
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent className="space-y-4 text-sm">
              
              {/* Geographic Area Section */}
              <div className="border rounded-lg p-4 bg-white">
                <div className="flex items-start justify-between mb-2">
                  <h4 className="font-semibold text-gray-700 flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    Geographic Area
                  </h4>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setShowGeographyEdit(!showGeographyEdit)}
                    className="h-6 px-2 text-xs"
                  >
                    <Edit className="w-3 h-3 mr-1" />
                    Edit
                  </Button>
                </div>
                
                <div className="space-y-2">
                  <p className="font-medium text-gray-900">{getGeographyDescription()}</p>
                  
                  {geography.zip_codes && geography.zip_codes.length > 0 && (
                    <div>
                      <p className="text-gray-600 text-xs mb-1">ZIP Codes ({geography.zip_codes.length})</p>
                      <div className="flex flex-wrap gap-1">
                        {geography.zip_codes.slice(0, 10).map(zip => (
                          <Badge key={zip} variant="secondary" className="text-xs font-mono">
                            {zip}
                          </Badge>
                        ))}
                        {geography.zip_codes.length > 10 && (
                          <Badge variant="outline" className="text-xs">
                            +{geography.zip_codes.length - 10} more
                          </Badge>
                        )}
                      </div>
                    </div>
                  )}
                  
                  {/* No ZIP codes found but we have fallback options */}
                  {(!geography.zip_codes || geography.zip_codes.length === 0) && geography.city && MAJOR_CITY_ZIPS[geography.city] && (
                    <Alert className="mt-2">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription className="text-xs">
                        <div className="flex items-center justify-between">
                          <span>No ZIP codes found. Use {MAJOR_CITY_ZIPS[geography.city].length} default ZIP codes for {geography.city}?</span>
                          <Button 
                            size="sm" 
                            onClick={handleUseFallbackZips}
                            className="ml-2 h-6 text-xs"
                          >
                            <Plus className="w-3 h-3 mr-1" />
                            Add Default ZIPs
                          </Button>
                        </div>
                      </AlertDescription>
                    </Alert>
                  )}
                  
                  {(!geography.city && !geography.state) && (!geography.zip_codes || geography.zip_codes.length === 0) && (
                    <Alert className="mt-2">
                      <AlertCircle className="h-4 w-4" />
                      <AlertDescription className="text-xs">
                        No geographic information found. Please add city/state information or ZIP codes manually.
                      </AlertDescription>
                    </Alert>
                  )}
                </div>
                
                {showGeographyEdit && (
                  <div className="mt-4 pt-4 border-t space-y-3 bg-gray-50 -m-4 p-4 rounded-b-lg">
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <Label className="text-xs">State</Label>
                        <Input 
                          value={geography.state || ''} 
                          onChange={(e) => updateFormData({ 
                            geography: { ...geography, state: e.target.value }
                          })}
                          className="h-8 text-sm"
                          placeholder="e.g., Texas"
                        />
                      </div>
                      <div>
                        <Label className="text-xs">City</Label>
                        <Input 
                          value={geography.city || ''} 
                          onChange={(e) => updateFormData({ 
                            geography: { ...geography, city: e.target.value }
                          })}
                          className="h-8 text-sm"
                          placeholder="e.g., Houston"
                        />
                      </div>
                    </div>
                    <div>
                      <Label className="text-xs">County (Optional)</Label>
                      <Input 
                        value={geography.county || ''} 
                        onChange={(e) => updateFormData({ 
                          geography: { ...geography, county: e.target.value }
                        })}
                        className="h-8 text-sm"
                        placeholder="e.g., Harris County"
                      />
                    </div>
                    <Button 
                      size="sm" 
                      onClick={() => setShowGeographyEdit(false)}
                      className="w-full h-7"
                    >
                      Save Changes
                    </Button>
                  </div>
                )}
              </div>

              <div>
                <h4 className="font-semibold text-gray-700 mb-1">Data Sources</h4>
                <div className="flex flex-wrap gap-1">
                  {data_sources.slice(0, 3).map(s => <Badge key={s} variant="outline" className="text-xs">{s}</Badge>)}
                  {data_sources.length > 3 && <Badge variant="outline" className="text-xs">+{data_sources.length - 3} more</Badge>}
                </div>
              </div>

              <div>
                <h4 className="font-semibold text-gray-700 mb-1">Dashboard Components</h4>
                <div className="flex flex-wrap gap-1">
                  {elements_included.slice(0, 4).map(e => <Badge key={e} variant="outline" className="text-xs">{e.replace(/_/g, ' ')}</Badge>)}
                  {elements_included.length > 4 && <Badge variant="outline" className="text-xs">+{elements_included.length - 4} more</Badge>}
                </div>
              </div>
            </CardContent>
          </Card>

          {geographyStatus !== 'complete' && (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                <strong>Please review your geographic area.</strong> 
                {!geography.state && " Add the state name."}
                {!geography.city && " Add the primary city."}
                {(!geography.zip_codes || geography.zip_codes.length === 0) && " No ZIP codes were found."}
                {geography.city && MAJOR_CITY_ZIPS[geography.city] && " You can use default ZIP codes for this city."}
              </AlertDescription>
            </Alert>
          )}
        </div>
      </div>
    </div>
  );
}