import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Building, Loader2, CheckCircle, AlertTriangle, Search, Plus, Trash2, MapPin } from 'lucide-react';
import { toast } from 'sonner';
import { base44 } from '@/api/base44Client';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

// Helper function to format organization type display
const formatOrgType = (type) => {
  const typeMap = {
    'fqhc': 'FQHC',
    'hospital': 'Hospital',
    'clinic': 'Clinic',
    'urgent_care': 'Urgent Care',
    'safety_net': 'Safety Net',
    'other': 'Other'
  };
  return typeMap[type] || type?.replace(/_/g, ' ') || 'N/A';
};

export default function Step3LoadCompetitors({ formData, updateFormData, assessmentId, onSaveProgress }) {
  const [isSearching, setIsSearching] = useState(false);
  const [isSearchingHrsa, setIsSearchingHrsa] = useState(false);
  const [isEnriching, setIsEnriching] = useState(false);
  const [newOrgName, setNewOrgName] = useState('');
  const [newOrgType, setNewOrgType] = useState('clinic');

  const organizations = formData.organizations || [];
  const competitorsLoaded = formData.processed_data?.competitors_loaded || false;
  const totalSites = organizations.reduce((sum, org) => sum + (org.sites?.length || 0), organizations.length);

  const handleSearchCompetitors = async () => {
    if (!formData.geography?.city || !formData.geography?.state || !formData.geography?.latitude || !formData.geography?.longitude) {
      toast.error("Geographic coordinates are required. Please complete Step 1 first.");
      return;
    }

    setIsSearching(true);
    const timeoutId = setTimeout(() => {
      toast.info("This is taking longer than expected. Please keep waiting or try again later.", { id: 'search-timeout' });
    }, 30000);
    
    toast.loading("Searching OpenStreetMap for healthcare facilities in your area...", { id: 'search-competitors' });

    try {
      const response = await base44.functions.invoke('findHealthcareFacilities', {
        latitude: formData.geography.latitude,
        longitude: formData.geography.longitude,
        radiusMiles: formData.geography.radius_miles || 50,
        facilityTypes: ['hospital', 'clinic', 'urgent_care']
      });

      if (response?.data?.success && response.data?.facilities) {
        const facilities = response.data.facilities;
        
        if (facilities.length === 0) {
          toast.info("No healthcare facilities found in the search area.", { id: 'search-competitors' });
          return;
        }

        const currentOrgNames = new Set(organizations.map(o => o.name?.toLowerCase()).filter(Boolean));
        
        const newOrgs = facilities
          .filter(facility => facility.name && !currentOrgNames.has(facility.name.toLowerCase()))
          .map(facility => ({
            id: `osm_${Math.random().toString(36).substr(2, 9)}`,
            name: facility.name,
            type: facility.type,
            address: facility.address || '',
            city: facility.city || formData.geography.city,
            state: facility.state || formData.geography.state,
            zip_code: facility.zip_code || '',
            coordinates: facility.latitude && facility.longitude ? {
              latitude: facility.latitude,
              longitude: facility.longitude
            } : null,
            source: 'OpenStreetMap',
            distance_miles: facility.distance ? facility.distance.toFixed(1) : null
          }));

        if (newOrgs.length > 0) {
          const updatedOrgs = [...organizations, ...newOrgs];
          updateFormData({ 
            organizations: updatedOrgs,
            processed_data: {
              ...formData.processed_data,
              competitors_loaded: true
            }
          });
          toast.success(`Found ${newOrgs.length} new competitors!`, { id: 'search-competitors' });
          
          if (onSaveProgress) {
            setTimeout(() => onSaveProgress(), 500);
          }
        } else {
          toast.info(`Found ${facilities.length} facilities, but they're already in your list.`, { id: 'search-competitors' });
        }
      } else {
        throw new Error(response?.data?.error || 'Unexpected response from search');
      }
    } catch (error) {
      console.error("Error searching competitors:", error);
      
      let errorMessage = error.message || 'Unknown error';
      
      if (errorMessage.includes('Network Error') || errorMessage.includes('Cannot connect')) {
        errorMessage = 'Network connection failed. Please check your internet and try again.';
      } else if (errorMessage.includes('temporarily unavailable')) {
        errorMessage = 'Service temporarily unavailable. Please try again in a few minutes.';
      } else if (errorMessage.includes('timeout')) {
        errorMessage = 'Search timed out. Try reducing the search radius.';
      }
      
      toast.error(`Failed to search: ${errorMessage}`, { id: 'search-competitors', duration: 6000 });
    } finally {
      clearTimeout(timeoutId);
      setIsSearching(false);
    }
  };

  const handleSearchHrsa = async () => {
    if (!formData.geography?.latitude || !formData.geography?.longitude) {
      toast.error("Geographic coordinates are required. Please complete Step 1 first.");
      return;
    }

    setIsSearchingHrsa(true);
    const timeoutId = setTimeout(() => {
      toast.info("HRSA data loading is taking longer than expected. Please wait...", { id: 'hrsa-timeout' });
    }, 30000);
    
    toast.loading("Fetching FQHC data from HRSA Health Center directory...", { id: 'search-hrsa' });

    try {
      const response = await base44.functions.invoke('getHrsaHealthCenters', {
        method: 'aroundLocation',
        latitude: formData.geography.latitude,
        longitude: formData.geography.longitude,
        radiusMiles: formData.geography.radius_miles || 50
      });

      if (response?.data?.success && response.data?.sites) {
        const sites = response.data.sites;
        
        if (sites.length === 0) {
          toast.info("No HRSA health centers found in the search area.", { id: 'search-hrsa' });
          return;
        }

        const currentOrgNames = new Set(organizations.map(o => o.name?.toLowerCase()).filter(Boolean));
        
        const newOrgs = sites
          .filter(site => site.name && !currentOrgNames.has(site.name.toLowerCase()))
          .map(site => ({
            id: site.id,
            name: site.name,
            type: site.type,
            address: site.address,
            city: site.city,
            state: site.state,
            zip_code: site.zip_code,
            coordinates: site.coordinates,
            phone: site.phone,
            sites: site.site_type === 'Service Delivery' ? [{
              name: site.name,
              address: site.address,
              city: site.city,
              state: site.state,
              zip_code: site.zip_code,
              coordinates: site.coordinates,
              type: site.site_type
            }] : [],
            source: 'HRSA Health Center Data',
            distance_miles: site.distance ? parseFloat(site.distance).toFixed(1) : null
          }));

        if (newOrgs.length > 0) {
          const updatedOrgs = [...organizations, ...newOrgs];
          updateFormData({ 
            organizations: updatedOrgs,
            processed_data: {
              ...formData.processed_data,
              competitors_loaded: true
            }
          });
          toast.success(`Found ${newOrgs.length} HRSA health centers!`, { id: 'search-hrsa' });
          
          if (onSaveProgress) {
            setTimeout(() => onSaveProgress(), 500);
          }
        } else {
          toast.info(`Found ${sites.length} HRSA sites, but they're already in your list.`, { id: 'search-hrsa' });
        }
      } else {
        throw new Error(response?.data?.error || 'Unexpected response from HRSA');
      }
    } catch (error) {
      console.error("Error searching HRSA health centers:", error);
      toast.error(`Failed to load HRSA data: ${error.message}`, { id: 'search-hrsa', duration: 6000 });
    } finally {
      clearTimeout(timeoutId);
      setIsSearchingHrsa(false);
    }
  };

  const handleEnrichLocations = async () => {
    if (organizations.length === 0) {
      toast.error("No competitors to enrich. Add some first.");
      return;
    }

    setIsEnriching(true);
    const enrichToastId = 'enrich-locations';
    const timeoutId = setTimeout(() => {
      toast.info("Location enrichment is taking longer than usual. This is normal for large datasets.", { id: 'enrich-timeout' });
    }, 30000);
    
    toast.loading(`Enriching ${organizations.length} organizations with site location data...`, { id: enrichToastId });

    try {
      const response = await base44.functions.invoke('enrichCompetitorLocations', {
        organizations: organizations,
        state: formData.geography?.state || 'Arkansas'
      });

      if (response?.data?.success && response.data?.organizations) {
        updateFormData({ 
          organizations: response.data.organizations,
          processed_data: {
            ...formData.processed_data,
            competitors_loaded: true
          }
        });
        toast.success(
          `${response.data.message}! Found ${response.data.totalSitesFound || 0} total locations.`,
          { id: enrichToastId, duration: 5000 }
        );
        
        if (onSaveProgress) {
          setTimeout(() => onSaveProgress(), 500);
        }
      } else {
        throw new Error(response?.data?.error || 'Failed to enrich locations');
      }

    } catch (error) {
      console.error("Error enriching competitor locations:", error);
      
      let errorMessage = error.message || 'Unknown error occurred';
      
      if (errorMessage.includes('Network Error') || errorMessage.includes('Cannot connect')) {
        errorMessage = 'Network connection failed. Please try again.';
      } else if (errorMessage.includes('Rate limit')) {
        errorMessage = 'Too many requests. Please wait and try again.';
      }

      toast.error(
        `Failed to enrich: ${errorMessage}`,
        { id: enrichToastId, duration: 8000 }
      );
    } finally {
      clearTimeout(timeoutId);
      setIsEnriching(false);
    }
  };

  const handleAddManualOrg = () => {
    if (!newOrgName.trim()) {
      toast.error("Organization name is required.");
      return;
    }

    const newOrg = {
      id: `manual_${Date.now()}`,
      name: newOrgName.trim(),
      type: newOrgType,
      address: '',
      city: formData.geography?.city || '',
      state: formData.geography?.state || '',
      source: 'Manual Entry'
    };

    const updatedOrgs = [...organizations, newOrg];
    updateFormData({ 
      organizations: updatedOrgs,
      processed_data: {
        ...formData.processed_data,
        competitors_loaded: true
      }
    });
    setNewOrgName('');
    toast.success(`${newOrg.name} added.`);
    
    if (onSaveProgress) {
      setTimeout(() => onSaveProgress(), 500);
    }
  };

  const handleRemoveOrg = (orgId) => {
    const updatedOrgs = organizations.filter(o => o.id !== orgId);
    updateFormData({ organizations: updatedOrgs });
    toast.info("Organization removed.");
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-gray-900">Load Competitor Locations</h2>
        <p className="text-gray-600 mt-1">
          Find healthcare organizations in your service area to understand the competitive landscape.
        </p>
      </div>

      {/* Status Card */}
      <Card className={competitorsLoaded ? "bg-emerald-50 border-emerald-200" : "bg-blue-50 border-blue-200"}>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            {competitorsLoaded ? (
              <>
                <CheckCircle className="w-5 h-5 text-emerald-600" />
                <span className="text-emerald-900">Competitors Loaded</span>
              </>
            ) : (
              <>
                <AlertTriangle className="w-5 h-5 text-blue-600" />
                <span className="text-blue-900">No Competitors Loaded Yet</span>
              </>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {competitorsLoaded ? (
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Badge className="bg-emerald-100 text-emerald-800 border-emerald-200">
                  {organizations.length} organizations
                </Badge>
                <Badge variant="outline">
                  {totalSites} total locations
                </Badge>
              </div>
              <p className="text-sm text-emerald-700">
                Competitor data loaded. You can add more or proceed to the next step.
              </p>
            </div>
          ) : (
            <p className="text-sm text-blue-700">
              Use the search feature to automatically find competitors, or add them manually.
            </p>
          )}
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Button
          onClick={handleSearchCompetitors}
          disabled={isSearching || !formData.geography?.city}
          size="lg"
          className="bg-blue-600 hover:bg-blue-700"
        >
          {isSearching ? (
            <>
              <Loader2 className="w-5 h-5 mr-2 animate-spin" />
              Searching...
            </>
          ) : competitorsLoaded && organizations.some(o => o.source === 'OpenStreetMap') ? (
            <>
              <CheckCircle className="w-5 h-5 mr-2 text-green-300" />
              Search OSM
            </>
          ) : (
            <>
              <Search className="w-5 h-5 mr-2" />
              Search OSM
            </>
          )}
        </Button>

        <Button
          onClick={handleSearchHrsa}
          disabled={isSearchingHrsa || !formData.geography?.latitude}
          size="lg"
          className="bg-emerald-600 hover:bg-emerald-700"
        >
          {isSearchingHrsa ? (
            <>
              <Loader2 className="w-5 h-5 mr-2 animate-spin" />
              Loading...
            </>
          ) : competitorsLoaded && organizations.some(o => o.source === 'HRSA Health Center Data') ? (
            <>
              <CheckCircle className="w-5 h-5 mr-2 text-green-300" />
              Load FQHCs (HRSA)
            </>
          ) : (
            <>
              <Building className="w-5 h-5 mr-2" />
              Load FQHCs (HRSA)
            </>
          )}
        </Button>

        <Button
          onClick={handleEnrichLocations}
          disabled={isEnriching || organizations.length === 0}
          size="lg"
          variant="outline"
        >
          {isEnriching ? (
            <>
              <Loader2 className="w-5 h-5 mr-2 animate-spin" />
              Finding Locations...
            </>
          ) : (
            <>
              <MapPin className="w-5 h-5 mr-2" />
              Fetch Site Locations
            </>
          )}
        </Button>
      </div>

      {/* Manual Add */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Add Organization Manually</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            <Input
              placeholder="Organization Name"
              value={newOrgName}
              onChange={(e) => setNewOrgName(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleAddManualOrg()}
              className="flex-1"
            />
            <select
              value={newOrgType}
              onChange={(e) => setNewOrgType(e.target.value)}
              className="border border-gray-300 rounded-md px-3 py-2 text-sm"
            >
              <option value="clinic">Clinic</option>
              <option value="fqhc">FQHC</option>
              <option value="hospital">Hospital</option>
              <option value="urgent_care">Urgent Care</option>
              <option value="safety_net">Safety Net</option>
              <option value="other">Other</option>
            </select>
            <Button onClick={handleAddManualOrg}>
              <Plus className="w-4 h-4 mr-2" />
              Add
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Organizations Table */}
      {organizations.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">
              Loaded Organizations ({organizations.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="border rounded-lg overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>Sites</TableHead>
                    <TableHead>Source</TableHead>
                    <TableHead className="text-right">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {organizations.map((org) => (
                    <TableRow key={org.id}>
                      <TableCell className="font-medium">{org.name}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="capitalize">
                          {formatOrgType(org.type)}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm">{org.city}, {org.state}</TableCell>
                      <TableCell>
                        {org.sites && org.sites.length > 0 ? (
                          <Badge variant="secondary">{org.sites.length} sites</Badge>
                        ) : (
                          <span className="text-gray-400 text-sm">1 location</span>
                        )}
                      </TableCell>
                      <TableCell className="text-xs">{org.source || 'N/A'}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon" onClick={() => handleRemoveOrg(org.id)}>
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}