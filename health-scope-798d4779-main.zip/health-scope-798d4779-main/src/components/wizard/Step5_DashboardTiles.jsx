// Renamed from Step3_DashboardTiles.jsx
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Map, BarChart3, Users, Building, MessageSquare } from 'lucide-react';

const availableElements = [
  { id: 'map', name: 'Interactive Service Area Map', icon: Map, description: 'Visualize ZIP codes and competitor locations' },
  { id: 'population_demographics', name: 'Population & Demographics', icon: Users, description: 'Charts showing population and demographic data' },
  { id: 'community_needs', name: 'Community Health Needs', icon: BarChart3, description: 'Poverty, uninsured rates, and health indicators' },
  { id: 'competitors', name: 'Competitor Analysis', icon: Building, description: 'List and analysis of healthcare organizations' },
  { id: 'ai_chat', name: 'AI Assistant Chat', icon: MessageSquare, description: 'Interactive AI to answer questions about your data' },
];

export default function Step5DashboardTiles({ formData, updateFormData }) {
  const toggleElement = (elementId) => {
    const currentElements = formData.elements_included || [];
    const updatedElements = currentElements.includes(elementId)
      ? currentElements.filter(e => e !== elementId)
      : [...currentElements, elementId];
    
    updateFormData({ elements_included: updatedElements });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-gray-900">Configure Dashboard Elements</h2>
        <p className="text-gray-600 mt-1">Select which components to include in your assessment dashboard.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {availableElements.map(element => {
          const Icon = element.icon;
          const isSelected = (formData.elements_included || []).includes(element.id);
          
          return (
            <Card 
              key={element.id}
              className={`cursor-pointer transition-all ${
                isSelected ? 'ring-2 ring-emerald-500 bg-emerald-50' : 'hover:border-gray-300'
              }`}
              onClick={() => toggleElement(element.id)}
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3">
                    <div className={`p-2 rounded-lg ${isSelected ? 'bg-emerald-100' : 'bg-gray-100'}`}>
                      <Icon className={`w-5 h-5 ${isSelected ? 'text-emerald-600' : 'text-gray-600'}`} />
                    </div>
                    <div>
                      <CardTitle className="text-base">{element.name}</CardTitle>
                      <p className="text-sm text-gray-600 mt-1">{element.description}</p>
                    </div>
                  </div>
                  <Switch
                    checked={isSelected}
                    onCheckedChange={() => toggleElement(element.id)}
                    className="ml-2"
                  />
                </div>
              </CardHeader>
            </Card>
          );
        })}
      </div>

      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="pt-6">
          <p className="text-sm text-blue-800">
            <strong>Tip:</strong> You can always customize these elements later from the dashboard settings.
            We recommend including all elements for a comprehensive assessment.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}