import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { MapIcon, Loader2, CheckCircle, AlertTriangle, Sparkles, Eye, ChevronRight, Trash2, Plus } from 'lucide-react';
import { toast } from 'sonner';
import { base44 } from '@/api/base44Client';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { MapContainer, TileLayer, GeoJSON, Marker } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

export default function Step2_LoadBoundaries({ formData, updateFormData, assessmentId, onSaveProgress }) {
  const [reviewPhase, setReviewPhase] = useState('initial');
  const [isPreprocessing, setIsPreprocessing] = useState(false);
  const [preprocessedGeoJSON, setPreprocessedGeoJSON] = useState(
    formData.processed_data?.trimmed_geojson || null
  );
  const [loadedZctaLabels, setLoadedZctaLabels] = useState([]);
  const [manualZctaInput, setManualZctaInput] = useState('');

  // FIXED: Use zip_codes instead of zcta_codes for consistency
  const zctaCodes = formData.geography?.zip_codes || formData.geography?.zcta_codes || [];
  const hasPreprocessedData = preprocessedGeoJSON?.features?.length > 0;
  const boundariesLoaded = formData.processed_data?.boundaries_loaded || false;

  useEffect(() => {
    if (formData.processed_data?.trimmed_geojson) {
      setPreprocessedGeoJSON(formData.processed_data.trimmed_geojson);
      setReviewPhase('loaded');
    }
  }, [formData.processed_data?.trimmed_geojson]);

  useEffect(() => {
    if (!preprocessedGeoJSON?.features || preprocessedGeoJSON.features.length === 0) {
      setLoadedZctaLabels([]);
      return;
    }

    const labels = [];
    preprocessedGeoJSON.features.forEach(feature => {
      if (!feature.geometry) return;

      try {
        const geoJsonLayer = L.geoJSON(feature.geometry);
        const bounds = geoJsonLayer.getBounds();
        if (bounds && bounds.isValid && bounds.isValid()) {
          const center = bounds.getCenter();
          const zcta = feature.properties.zcta5 || feature.properties.ZCTA5CE10;
          
          labels.push({
            zcta: zcta,
            lat: center.lat,
            lng: center.lng
          });
        }
      } catch (error) {
        console.warn(`Failed to get centroid:`, error);
      }
    });

    setLoadedZctaLabels(labels);
  }, [preprocessedGeoJSON]);

  const handlePreprocessBoundaries = async () => {
    // If no ZCTAs yet and we have location, use TIGERweb directly
    if (zctaCodes.length === 0 && formData.geography?.city && formData.geography?.state && formData.geography?.radius_miles) {
      const city = formData.geography.city;
      const state = formData.geography.state;
      const radiusMiles = parseInt(formData.geography.radius_miles) || 50;

      setIsPreprocessing(true);
      toast.loading("Finding ZCTAs and boundaries...", { id: 'zcta-search', duration: 30000, position: 'top-center' });

      try {
        const response = await base44.functions.invoke('findZipCodesInRadius', {
          city,
          state,
          radiusMiles
        });

        if (response?.data?.success && response.data.zipCodes?.length > 0) {
          const foundZctas = response.data.zipCodes;
          const geojson = response.data.geojson;
          
          // FIXED: Save to both zip_codes and zcta_codes for backwards compatibility
          updateFormData({
            geography: {
              ...formData.geography,
              zip_codes: foundZctas,
              zcta_codes: foundZctas,
              latitude: response.data.center?.latitude,
              longitude: response.data.center?.longitude
            },
            processed_data: {
              ...formData.processed_data,
              zip_codes: foundZctas, // ADDED: Also save in processed_data
              trimmed_geojson: geojson,
              boundaries_loaded: true,
              geojson_metadata: {
                created_at: new Date().toISOString(),
                zcta_count: geojson.features.length,
                source: response.data.source || 'US Census TIGERweb',
                zcta_codes_found: foundZctas,
                zcta_codes_missing: []
              }
            }
          });

          setPreprocessedGeoJSON(geojson);
          setReviewPhase('loaded');
          
          toast.success(`✓ Loaded ${foundZctas.length} ZCTAs!`, { 
            id: 'zcta-search', 
            duration: 5000,
            position: 'top-center'
          });

          if (onSaveProgress) {
            setTimeout(() => onSaveProgress(), 500);
          }
        } else {
          throw new Error(response?.data?.error || 'No ZCTAs found');
        }
      } catch (error) {
        console.error('ZCTA search error:', error);
        const errorMessage = error.message || 'Unknown error';
        const isServerError = errorMessage.includes('500') || errorMessage.includes('502') || errorMessage.includes('timeout');
        
        toast.error(
          isServerError 
            ? `Census TIGERweb service unavailable. Try again in a moment or load state data first.`
            : `Search failed: ${errorMessage}`, 
          { 
            id: 'zcta-search', 
            duration: 10000,
            position: 'top-center'
          }
        );
        
        // Show alert to load state data
        if (isServerError && formData.geography?.state) {
          setTimeout(() => {
            toast.info(
              `Tip: Load ${formData.geography.state} state data in Admin → Data Loader, then try again`,
              { duration: 8000, position: 'top-center' }
            );
          }, 1000);
        }
      } finally {
        setIsPreprocessing(false);
      }
      return;
    }

    // If we already have ZCTAs, try database first, fallback to TIGERweb
    if (zctaCodes.length > 0) {
      setIsPreprocessing(true);
      const loadingToastId = 'preprocessing-step2';
      toast.loading(`Loading ${zctaCodes.length} ZCTA boundaries...`, {
        id: loadingToastId,
        duration: 60000,
        position: 'top-center'
      });

      try {
        // Try getCountyPack first for cached boundaries
        const zctasParam = zctaCodes.join(',');
        const response = await fetch(
          `${window.location.origin}/.netlify/functions/getCountyPack?zctas=${encodeURIComponent(zctasParam)}`,
          {
            method: 'GET',
            credentials: 'include'
          }
        );

        if (response.ok) {
          const geojson = await response.json();

          if (geojson?.features && geojson.features.length > 0) {
            setPreprocessedGeoJSON(geojson);
            setReviewPhase('loaded');
            
            const foundZctas = geojson.features.map(f => f.properties.zcta5);
            const missingZctas = zctaCodes.filter(z => !foundZctas.includes(z));
            
            // FIXED: Save to both locations
            updateFormData({
              geography: {
                ...formData.geography,
                zip_codes: foundZctas,
                zcta_codes: foundZctas
              },
              processed_data: {
                ...formData.processed_data,
                zip_codes: foundZctas, // ADDED
                trimmed_geojson: geojson,
                boundaries_loaded: true,
                geojson_metadata: {
                  created_at: new Date().toISOString(),
                  zcta_count: geojson.features.length,
                  source: 'Database (ZctaBoundary entity)',
                  zcta_codes_found: foundZctas,
                  zcta_codes_missing: missingZctas
                }
              }
            });

            if (missingZctas.length > 0) {
              toast.warning(
                `Loaded ${geojson.features.length}/${zctaCodes.length} from database. ${missingZctas.length} missing.`,
                { id: loadingToastId, duration: 8000, position: 'top-center' }
              );
            } else {
              toast.success(
                `✓ All ${geojson.features.length} boundaries loaded!`,
                { id: loadingToastId, duration: 5000, position: 'top-center' }
              );
            }

            if (onSaveProgress) {
              setTimeout(() => onSaveProgress(), 500);
            }
            setIsPreprocessing(false);
            return;
          }
        }

        // Fallback: if database fails or returns nothing, use TIGERweb
        toast.loading("Database incomplete, fetching from TIGERweb...", { id: loadingToastId, position: 'top-center' });
        
        if (!formData.geography?.latitude || !formData.geography?.longitude) {
          throw new Error("Coordinates required for TIGERweb fallback. Go back to Step 1.");
        }

        const tigerResponse = await base44.functions.invoke('findZipCodesInRadius', {
          city: formData.geography.city,
          state: formData.geography.state,
          radiusMiles: formData.geography.radius_miles || 50
        });

        if (tigerResponse?.data?.success && tigerResponse.data.geojson) {
          const geojson = tigerResponse.data.geojson;
          const foundZctas = tigerResponse.data.zipCodes;
          
          setPreprocessedGeoJSON(geojson);
          setReviewPhase('loaded');
          
          // FIXED: Save to both locations
          updateFormData({
            geography: {
              ...formData.geography,
              zip_codes: foundZctas,
              zcta_codes: foundZctas
            },
            processed_data: {
              ...formData.processed_data,
              zip_codes: foundZctas, // ADDED
              trimmed_geojson: geojson,
              boundaries_loaded: true,
              geojson_metadata: {
                created_at: new Date().toISOString(),
                zcta_count: geojson.features.length,
                source: 'US Census TIGERweb (fallback)',
                zcta_codes_found: foundZctas,
                zcta_codes_missing: []
              }
            }
          });

          toast.success(
            `✓ Loaded ${geojson.features.length} boundaries from TIGERweb!`,
            { id: loadingToastId, duration: 5000, position: 'top-center' }
          );

          if (onSaveProgress) {
            setTimeout(() => onSaveProgress(), 500);
          }
        } else {
          throw new Error('Both database and TIGERweb failed');
        }

      } catch (error) {
        console.error('Error loading boundaries:', error);
        const errorMessage = error.message || 'Unknown error';
        const isServerError = errorMessage.includes('500') || errorMessage.includes('502') || errorMessage.includes('timeout');
        
        toast.error(
          isServerError 
            ? `Service unavailable - try loading state data in Admin → Data Loader first`
            : `Failed: ${errorMessage}`,
          { id: loadingToastId, duration: 10000, position: 'top-center' }
        );
      } finally {
        setIsPreprocessing(false);
      }
      return;
    }

    toast.error("Please go back to Step 1 and define your geographic area.");
  };

  const handleRemoveMissingZctas = () => {
    const zctaCodesMissing = formData.processed_data?.geojson_metadata?.zcta_codes_missing || [];

    if (!zctaCodesMissing || zctaCodesMissing.length === 0) {
      toast.info("No missing ZCTAs to remove.");
      return;
    }

    const countBefore = zctaCodes.length;
    const newZctaCodes = zctaCodes.filter(zcta => !zctaCodesMissing.includes(zcta));
    
    // FIXED: Update both fields
    updateFormData({
      geography: {
        ...formData.geography,
        zip_codes: newZctaCodes,
        zcta_codes: newZctaCodes
      }
    });

    toast.success(`Removed ${countBefore - newZctaCodes.length} ZCTAs. ${newZctaCodes.length} remaining.`);
    
    setReviewPhase('initial');
    setPreprocessedGeoJSON(null);
    updateFormData({
      processed_data: {
        ...formData.processed_data,
        zip_codes: null, // ADDED
        trimmed_geojson: null,
        boundaries_loaded: false,
        geojson_metadata: null
      }
    });

    if (onSaveProgress) {
      setTimeout(() => onSaveProgress(), 500);
    }
  };

  const handleAddManualZcta = () => {
    const zcta = manualZctaInput.trim();
    
    if (!/^\d{5}$/.test(zcta)) {
      toast.error("Please enter a valid 5-digit ZCTA code.");
      return;
    }
    
    if (zctaCodes.includes(zcta)) {
      toast.info(`ZCTA ${zcta} already in list.`);
      setManualZctaInput('');
      return;
    }
    
    const newZctaCodes = [...zctaCodes, zcta].sort();
    
    // FIXED: Update both fields
    updateFormData({
      geography: {
        ...formData.geography,
        zip_codes: newZctaCodes,
        zcta_codes: newZctaCodes
      }
    });
    
    toast.success(`ZCTA ${zcta} added!`);
    setManualZctaInput('');
    
    setReviewPhase('initial');
    setPreprocessedGeoJSON(null);
    updateFormData({
      processed_data: {
        ...formData.processed_data,
        zip_codes: null, // ADDED
        trimmed_geojson: null,
        boundaries_loaded: false
      }
    });

    if (onSaveProgress) {
      setTimeout(() => onSaveProgress(), 500);
    }
  };

  const getFeatureStyle = () => {
    return {
      color: '#10b981',
      weight: 2,
      opacity: 0.7,
      fillColor: '#34d399',
      fillOpacity: 0.2
    };
  };

  const centerLat = formData.geography?.latitude || 39.8283;
  const centerLng = formData.geography?.longitude || -98.5795;

  const zctaCodesFound = formData.processed_data?.geojson_metadata?.zcta_codes_found || [];
  const zctaCodesMissing = formData.processed_data?.geojson_metadata?.zcta_codes_missing || [];
  const hasMissingZctas = zctaCodesMissing.length > 0;
  const hasLocationInfo = formData.geography?.city && formData.geography?.state;

  const createLoadedZctaIcon = (zcta) => {
    return L.divIcon({
      html: `<div style="background: rgba(16, 185, 129, 0.9); color: white; padding: 3px 7px; border-radius: 4px; font-size: 12px; font-weight: bold; border: 2px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3); white-space: nowrap;">${zcta}</div>`,
      className: '',
      iconSize: [null, null],
      iconAnchor: [20, 10]
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-gray-900">Load ZCTA Boundaries</h2>
        <p className="text-gray-600 mt-1">
          {zctaCodes.length > 0 
            ? `Load geographic boundaries for your ${zctaCodes.length} selected ZCTAs.`
            : hasLocationInfo 
              ? `We'll find ZCTAs in ${formData.geography.city}, ${formData.geography.state} and load their boundaries.`
              : 'Define your geographic area in Step 1 first.'
          }
        </p>
      </div>

      {reviewPhase === 'initial' && !boundariesLoaded && (
        <>
          {zctaCodes.length > 0 ? (
            <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Eye className="w-5 h-5 text-blue-600" />
                  <span className="text-blue-900">Ready to Load</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-blue-800 mb-3">
                    Selected <strong>{zctaCodes.length} ZCTAs</strong>
                  </p>
                  
                  <div className="bg-white rounded-lg p-3 border border-blue-200 max-h-32 overflow-y-auto">
                    <div className="flex flex-wrap gap-1.5">
                      {zctaCodes.slice(0, 30).map(zcta => (
                        <Badge key={zcta} variant="secondary" className="text-xs">
                          {zcta}
                        </Badge>
                      ))}
                      {zctaCodes.length > 30 && (
                        <Badge variant="outline" className="text-xs">
                          +{zctaCodes.length - 30} more
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>

                <div className="bg-white p-3 rounded-md border border-blue-200">
                  <p className="text-xs text-blue-900 font-medium mb-2">Add ZCTA manually:</p>
                  <div className="flex gap-2">
                    <Input
                      placeholder="Enter 5-digit ZCTA"
                      value={manualZctaInput}
                      onChange={(e) => setManualZctaInput(e.target.value)}
                      maxLength={5}
                      onKeyPress={(e) => e.key === 'Enter' && handleAddManualZcta()}
                      className="flex-1"
                    />
                    <Button
                      size="sm"
                      onClick={handleAddManualZcta}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      <Plus className="w-4 h-4 mr-1" />
                      Add
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : hasLocationInfo ? (
            <Alert className="border-blue-300 bg-blue-50">
              <AlertDescription>
                <p className="font-semibold text-blue-900 mb-2">Ready to find ZCTAs</p>
                <p className="text-sm text-blue-800">
                  Click below to search for ZCTAs within {formData.geography.radius_miles || 50} miles of {formData.geography.city}, {formData.geography.state} and load their boundaries.
                </p>
              </AlertDescription>
            </Alert>
          ) : (
            <Alert className="border-amber-300 bg-amber-50">
              <AlertDescription>
                <p className="font-semibold text-amber-900 mb-2">No geographic area defined</p>
                <p className="text-sm text-amber-800">
                  Please go back to Step 1 and define your geographic area first.
                </p>
              </AlertDescription>
            </Alert>
          )}

          <div className="flex justify-center">
            <Button
              onClick={handlePreprocessBoundaries}
              disabled={isPreprocessing || (!hasLocationInfo && zctaCodes.length === 0)}
              size="lg"
              className="bg-emerald-600 hover:bg-emerald-700 text-lg px-8 py-6"
            >
              {isPreprocessing ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Loading...
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5 mr-2" />
                  {zctaCodes.length > 0 ? `Load ${zctaCodes.length} Boundaries` : 'Find ZCTAs & Load Boundaries'}
                  <ChevronRight className="w-5 h-5 ml-2" />
                </>
              )}
            </Button>
          </div>
        </>
      )}

      {reviewPhase === 'loaded' && hasPreprocessedData && (
        <>
          <Card className={hasMissingZctas ? "bg-amber-50 border-amber-200" : "bg-emerald-50 border-emerald-200"}>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                {hasMissingZctas ? (
                  <>
                    <AlertTriangle className="w-5 h-5 text-amber-600" />
                    <span className="text-amber-900">Partial Coverage</span>
                  </>
                ) : (
                  <>
                    <CheckCircle className="w-5 h-5 text-emerald-600" />
                    <span className="text-emerald-900">All Boundaries Loaded!</span>
                  </>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2 flex-wrap">
                <Badge className="bg-emerald-100 text-emerald-800 border-emerald-200">
                  ✓ {preprocessedGeoJSON.features.length} loaded
                </Badge>
                {hasMissingZctas && (
                  <Badge variant="destructive">
                    {zctaCodesMissing.length} missing
                  </Badge>
                )}
              </div>

              {hasMissingZctas && (
                <div className="bg-amber-100 p-3 rounded-md space-y-2">
                  <p className="text-sm text-amber-900 font-medium">
                    ⚠️ {zctaCodesMissing.length} ZCTAs not found in database
                  </p>
                  <p className="text-xs text-amber-800">
                    Load state data first: <Link to={createPageUrl('InitialDataLoader')} className="underline font-semibold">Go to Data Loader</Link>
                  </p>
                  <Button
                    size="sm"
                    onClick={handleRemoveMissingZctas}
                    variant="destructive"
                    className="mt-2"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Remove Missing
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <MapIcon className="w-5 h-5 text-emerald-600" />
                Coverage Map
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[500px] w-full rounded-lg border-2 border-emerald-200 overflow-hidden">
                <MapContainer
                  center={[centerLat, centerLng]}
                  zoom={9}
                  style={{ height: '100%', width: '100%' }}
                  scrollWheelZoom={true}
                >
                  <TileLayer
                    attribution='&copy; OpenStreetMap'
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                  />
                  <GeoJSON 
                    data={preprocessedGeoJSON} 
                    style={getFeatureStyle}
                    onEachFeature={(feature, layer) => {
                      const zcta = feature.properties.zcta5 || feature.properties.ZCTA5CE10;
                      layer.bindPopup(`<strong>ZCTA ${zcta}</strong>`);
                    }}
                  />
                  <Marker position={[centerLat, centerLng]} />
                  
                  {loadedZctaLabels.map((label, idx) => (
                    <Marker 
                      key={`${label.zcta}-${idx}`}
                      position={[label.lat, label.lng]}
                      icon={createLoadedZctaIcon(label.zcta)}
                    />
                  ))}
                </MapContainer>
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}