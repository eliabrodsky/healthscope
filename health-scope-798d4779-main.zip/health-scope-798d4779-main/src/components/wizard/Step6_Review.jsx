import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { CheckCircle, AlertTriangle, MapPin, Map, Building, Database, Sparkles, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

export default function Step7Review({ formData, updateFormData }) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [suggestedTitle, setSuggestedTitle] = useState('');
  const [suggestedDescription, setSuggestedDescription] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);

  const zipCount = formData.geography?.zip_codes?.length || 0;
  const boundariesLoaded = formData.processed_data?.boundaries_loaded || false;
  const competitorsLoaded = formData.processed_data?.competitors_loaded || false;
  const demographicsLoaded = formData.processed_data?.demographics_loaded || false;
  const orgCount = formData.organizations?.length || 0;

  const handleGenerateSuggestions = async () => {
    setIsGenerating(true);
    toast.loading("AI is generating suggestions...", { id: 'generate-suggestions' });

    try {
      // Build context about the assessment
      const context = {
        location: {
          city: formData.geography?.city,
          state: formData.geography?.state,
          county: formData.geography?.county,
          zipCount: zipCount,
          radius: formData.geography?.radius_miles
        },
        data: {
          boundariesLoaded,
          competitorsCount: orgCount,
          demographicsLoaded,
          elementsIncluded: formData.elements_included || []
        },
        year: new Date().getFullYear()
      };

      const prompt = `You are a healthcare data analyst. Based on the following assessment data, generate a professional title and description:

Location: ${context.location.city}, ${context.location.state}${context.location.county ? `, ${context.location.county} County` : ''}
Coverage: ${context.location.zipCount} ZIP codes${context.location.radius ? ` (${context.location.radius} mile radius)` : ''}
Competitors Analyzed: ${context.data.competitorsCount} healthcare organizations
Demographics Data: ${context.data.demographicsLoaded ? 'Loaded' : 'Not loaded'}
Year: ${context.year}

Generate:
1. A concise, professional title (max 60 characters)
2. A detailed description (2-3 sentences) explaining the assessment's scope, purpose, and key data sources

Return as JSON with keys: "title" and "description"`;

      const response = await base44.integrations.Core.InvokeLLM({
        prompt: prompt,
        response_json_schema: {
          type: "object",
          properties: {
            title: { type: "string" },
            description: { type: "string" }
          }
        }
      });

      if (response && response.title && response.description) {
        setSuggestedTitle(response.title);
        setSuggestedDescription(response.description);
        setShowSuggestions(true);
        toast.success("AI suggestions generated!", { id: 'generate-suggestions' });
      } else {
        throw new Error('Invalid response from AI');
      }

    } catch (error) {
      console.error('Error generating suggestions:', error);
      toast.error("Failed to generate suggestions. Please try again.", { id: 'generate-suggestions' });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleAcceptSuggestions = () => {
    updateFormData({
      title: suggestedTitle,
      description: suggestedDescription
    });
    setShowSuggestions(false);
    toast.success("Suggestions applied!");
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-gray-900">Review & Finalize</h2>
        <p className="text-gray-600 mt-1">
          Review your assessment details before publishing. Add a title and description for your dashboard.
        </p>
      </div>

      {/* Assessment Details */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-base">Assessment Information</CardTitle>
            <Button
              variant="outline"
              size="sm"
              onClick={handleGenerateSuggestions}
              disabled={isGenerating}
              className="border-emerald-300 text-emerald-700 hover:bg-emerald-50"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  AI Suggest
                </>
              )}
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* AI Suggestions Display */}
          {showSuggestions && (
            <div className="bg-gradient-to-br from-emerald-50 to-teal-50 border-2 border-emerald-200 rounded-lg p-4 space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-2">
                  <Sparkles className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="font-semibold text-emerald-900 text-sm mb-2">AI Generated Suggestions</p>
                    <div className="space-y-2">
                      <div>
                        <p className="text-xs text-emerald-700 font-medium mb-1">Title:</p>
                        <p className="text-sm text-gray-900 font-medium">{suggestedTitle}</p>
                      </div>
                      <div>
                        <p className="text-xs text-emerald-700 font-medium mb-1">Description:</p>
                        <p className="text-sm text-gray-700">{suggestedDescription}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex gap-2 pt-2">
                <Button
                  size="sm"
                  onClick={handleAcceptSuggestions}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white"
                >
                  <CheckCircle className="w-4 h-4 mr-1" />
                  Accept Suggestions
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setShowSuggestions(false)}
                  className="border-gray-300"
                >
                  Dismiss
                </Button>
              </div>
            </div>
          )}

          <div>
            <Label htmlFor="title">Title *</Label>
            <Input
              id="title"
              placeholder="e.g., Bogalusa Community Health Assessment 2025"
              value={formData.title || ''}
              onChange={(e) => updateFormData({ title: e.target.value })}
              className="mt-2"
            />
          </div>
          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              placeholder="Describe the purpose and scope of this assessment..."
              value={formData.description || ''}
              onChange={(e) => updateFormData({ description: e.target.value })}
              rows={4}
              className="mt-2"
            />
          </div>
        </CardContent>
      </Card>

      {/* Data Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Data Summary</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-start gap-3">
            <MapPin className="w-5 h-5 text-gray-500 mt-0.5" />
            <div className="flex-1">
              <p className="font-medium">Geographic Area</p>
              <p className="text-sm text-gray-600">
                {formData.geography?.city || 'N/A'}, {formData.geography?.state || 'N/A'}
              </p>
              <div className="flex gap-2 mt-2">
                <Badge variant="secondary">{zipCount} ZIP codes</Badge>
                {formData.geography?.radius_miles && (
                  <Badge variant="outline">{formData.geography.radius_miles} mile radius</Badge>
                )}
              </div>
            </div>
            {zipCount > 0 ? (
              <CheckCircle className="w-5 h-5 text-emerald-600" />
            ) : (
              <AlertTriangle className="w-5 h-5 text-amber-600" />
            )}
          </div>

          <div className="flex items-start gap-3">
            <Map className="w-5 h-5 text-gray-500 mt-0.5" />
            <div className="flex-1">
              <p className="font-medium">ZIP Code Boundaries</p>
              <p className="text-sm text-gray-600">
                {boundariesLoaded ? (
                  <>
                    {formData.processed_data?.trimmed_geojson?.features?.length || 0} boundaries pre-processed and ready
                  </>
                ) : (
                  'Not loaded'
                )}
              </p>
            </div>
            {boundariesLoaded ? (
              <CheckCircle className="w-5 h-5 text-emerald-600" />
            ) : (
              <AlertTriangle className="w-5 h-5 text-amber-600" />
            )}
          </div>

          <div className="flex items-start gap-3">
            <Building className="w-5 h-5 text-gray-500 mt-0.5" />
            <div className="flex-1">
              <p className="font-medium">Competitor Organizations</p>
              <p className="text-sm text-gray-600">
                {competitorsLoaded ? (
                  `${orgCount} organizations loaded`
                ) : (
                  'No competitors loaded'
                )}
              </p>
            </div>
            {competitorsLoaded && orgCount > 0 ? (
              <CheckCircle className="w-5 h-5 text-emerald-600" />
            ) : (
              <AlertTriangle className="w-5 h-5 text-amber-600" />
            )}
          </div>

          <div className="flex items-start gap-3">
            <Database className="w-5 h-5 text-gray-500 mt-0.5" />
            <div className="flex-1">
              <p className="font-medium">Demographics Data</p>
              <p className="text-sm text-gray-600">
                {demographicsLoaded ? (
                  'Census data loaded for selected ZIP codes'
                ) : (
                  'Demographics not loaded'
                )}
              </p>
            </div>
            {demographicsLoaded ? (
              <CheckCircle className="w-5 h-5 text-emerald-600" />
            ) : (
              <AlertTriangle className="w-5 h-5 text-amber-600" />
            )}
          </div>
        </CardContent>
      </Card>

      {/* Warning Card */}
      {(!boundariesLoaded || !demographicsLoaded) && (
        <Card className="bg-amber-50 border-amber-200">
          <CardContent className="pt-6">
            <div className="flex items-start gap-2">
              <AlertTriangle className="w-5 h-5 text-amber-600 mt-0.5" />
              <div>
                <p className="font-medium text-amber-900">Some Data Not Loaded</p>
                <p className="text-sm text-amber-700 mt-1">
                  Your dashboard will have limited functionality without boundaries and demographics data. 
                  Go back to complete those steps for the best experience.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Dashboard Elements */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Dashboard Elements</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {(formData.elements_included || []).map(element => (
              <Badge key={element} variant="secondary" className="capitalize">
                {element.replace(/_/g, ' ')}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}