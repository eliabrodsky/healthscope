import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Map, BarChart, Users, LineChart, PieChart, MessageSquare, CheckSquare } from 'lucide-react';

const availableTiles = [
  { id: 'map', name: 'Geographic Map', icon: Map },
  { id: 'population_demographics', name: 'Population Demographics', icon: Users },
  { id: 'community_needs', name: 'Community Needs', icon: PieChart },
  { id: 'competitors', name: 'Competitor Analysis', icon: BarChart },
  { id: 'population_trend', name: 'Population Growth Chart', icon: LineChart },
  { id: 'ai_chat', name: 'AI Insights Chatbot', icon: MessageSquare },
];

export default function Step3DashboardTiles({ formData, updateFormData }) {
  
  const handleTileToggle = (tileId, checked) => {
    const currentElements = formData.elements_included || [];
    updateFormData({
      elements_included: checked
        ? [...currentElements, tileId]
        : currentElements.filter(id => id !== tileId)
    });
  };

  return (
    <div>
      <h2 className="text-xl font-semibold text-gray-900 mb-4">Customize Your Dashboard</h2>
      <p className="text-gray-600 mb-6">Select the components you want to see on your final dashboard.</p>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {availableTiles.map(tile => {
          const isSelected = formData.elements_included.includes(tile.id);
          return (
            <Card 
              key={tile.id}
              className={`cursor-pointer transition-all duration-200 ${isSelected ? 'ring-2 ring-emerald-500 bg-emerald-50' : 'hover:shadow-md'}`}
              onClick={() => handleTileToggle(tile.id, !isSelected)}
            >
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-4">
                    <div className={`p-3 rounded-lg ${isSelected ? 'bg-emerald-100' : 'bg-gray-100'}`}>
                      <tile.icon className={`w-6 h-6 stroke-1 ${isSelected ? 'text-emerald-600' : 'text-gray-600'}`} />
                    </div>
                    <p className="font-semibold text-gray-800">{tile.name}</p>
                  </div>
                  <Checkbox checked={isSelected} className="mt-1" />
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  );
}