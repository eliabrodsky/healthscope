
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, CheckCircle, Upload, Link, AlertTriangle, Bot, Sparkles, Database, MessageSquare, BookOpen, FileText, Trash2 } from 'lucide-react'; // Added Trash2
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { agentSDK } from '@/agents';
import { UploadFile } from '@/integrations/Core'; // Removed ExtractDataFromUploadedFile
import { toast } from 'sonner'; // Import toast for notifications

const availableAgents = [
  {
    name: 'fqhc_agent',
    title: 'FQHC & UDS Data',
    description: 'Collects data from HRSA on Federally Qualified Health Centers.',
    icon: Database,
    color: 'emerald'
  },
  {
    name: 'hospital_data',
    title: 'Hospital Data',
    description: 'Gathers hospital utilization stats from CDC/NCHS.',
    icon: Bot,
    color: 'blue'
  },
  {
    name: 'population_data',
    title: 'Population Demographics',
    description: 'Retrieves census data on population, income, and insurance.',
    icon: Sparkles,
    color: 'purple'
  }
];

const AgentCollector = ({ agent, geography, onDataCollected, isSelected, onSelectionChange }) => {
  const [status, setStatus] = useState('idle');

  const getColorClasses = (color) => ({
    card: {
      emerald: `bg-emerald-50 border-emerald-200 text-emerald-800 ${isSelected ? 'ring-2 ring-emerald-500' : ''}`,
      blue: `bg-blue-50 border-blue-200 text-blue-800 ${isSelected ? 'ring-2 ring-blue-500' : ''}`,
      purple: `bg-purple-50 border-purple-200 text-purple-800 ${isSelected ? 'ring-2 ring-purple-500' : ''}`,
    }[color] || `bg-gray-50 border-gray-200 ${isSelected ? 'ring-2 ring-gray-500' : ''}`,
    button: {
      emerald: `bg-emerald-600 hover:bg-emerald-700`,
      blue: `bg-blue-600 hover:bg-blue-700`,
      purple: `bg-purple-600 hover:bg-purple-700`,
    }[color] || `bg-gray-800 hover:bg-gray-900`,
  });

  const classes = getColorClasses(agent.color);

  return (
    <div
      className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${classes.card}`}
      onClick={() => onSelectionChange(`Agent: ${agent.title}`, !isSelected)}
    >
      <div className="flex items-start gap-3 mb-3">
        <div className={`p-2 rounded-lg bg-white border border-gray-200`}>
          <agent.icon className="w-4 h-4 text-gray-700" />
        </div>
        <div className="flex-1">
          <h4 className="font-semibold text-gray-900 text-sm">{agent.title}</h4>
          <p className="text-xs text-gray-600 mt-1 leading-relaxed">{agent.description}</p>
        </div>
        {isSelected && <CheckCircle className="w-5 h-5 text-green-600" />}
      </div>
    </div>
  );
};

// Removed UploadedFileItem component

export default function Step2DataSources({ formData, updateFormData }) {
  const [isUploading, setIsUploading] = useState(false);
  // Removed isExtracting state

  const handleArrayChange = (field, value, checked) => {
    const currentItems = formData[field] || [];
    updateFormData({
      [field]: checked
        ? [...currentItems, value]
        : currentItems.filter(item => item !== value)
    });
  };
  
  // Removed extractDataFromFile function
  
  const handleCustomUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setIsUploading(true);
    toast.info(`Uploading ${file.name}...`);

    try {
      // Step 1: Upload the file
      const { file_url } = await UploadFile({ file });
      
      const newFile = {
        name: file.name,
        url: file_url,
        type: file.type,
        size: file.size,
        uploaded_at: new Date().toISOString()
      };

      // Step 2: Add to uploaded files
      const updatedFiles = [...(formData.uploaded_files || []), newFile];
      const updatedSources = [...(formData.data_sources || []), `Custom File: ${file.name}`];
      
      updateFormData({
        uploaded_files: updatedFiles,
        data_sources: updatedSources
      });

      toast.success(`${file.name} uploaded successfully!`);

      // Extraction logic removed
    } catch (error) {
      console.error("File upload failed:", error);
      toast.error(`Upload failed for ${file.name}. Please try again.`);
    } finally {
      setIsUploading(false);
      // Clear file input so the same file can be re-uploaded if needed
      e.target.value = '';
    }
  };

  const handleRemoveFile = (fileToRemove) => {
    const updatedFiles = formData.uploaded_files.filter(f => f.url !== fileToRemove.url);
    const updatedSources = formData.data_sources.filter(s => s !== `Custom File: ${fileToRemove.name}`);
    
    updateFormData({
      uploaded_files: updatedFiles,
      data_sources: updatedSources
    });
    
    toast.info(`Removed ${fileToRemove.name}`);
  };

  const handleAddLink = (e) => {
    e.preventDefault();
    const url = e.target.elements.url.value;
    if (url) {
      handleArrayChange('data_sources', `Custom Link: ${url}`, true);
      e.target.reset();
    }
  };
  
  const handleCustomRequestChange = (e) => {
    updateFormData({ custom_data_request: e.target.value });
  };

  return (
    <div>
      <h2 className="text-xl font-semibold text-gray-900 mb-4">Select Your Data Sources</h2>
      <p className="text-gray-600 mb-6">Choose from standard libraries, use AI agents, or describe exactly what you need.</p>
      
      <div className="space-y-8">
        <div>
          <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center gap-2">
            <Bot className="w-5 h-5 text-purple-600" />
            AI Data Collection Agents
          </h3>
          <p className="text-sm text-gray-600 mb-4">
            Select agents to automatically discover and process relevant health datasets for your assessment.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {availableAgents.map(agent => (
              <AgentCollector
                key={agent.name}
                agent={agent}
                geography={formData.geography}
                isSelected={formData.data_sources.includes(`Agent: ${agent.title}`)}
                onSelectionChange={handleArrayChange.bind(null, 'data_sources')}
              />
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-blue-600" />
            Describe Your Data Needs
          </h3>
          <p className="text-sm text-gray-600 mb-4">
            If you have a specific request, describe it here. Our AI agents will use this to guide their search and file analysis.
          </p>
          <Textarea
            placeholder="e.g., 'I need the latest data on hospital readmission rates for congestive heart failure, and any available information on local food deserts...'"
            value={formData.custom_data_request || ''}
            onChange={handleCustomRequestChange}
            rows={4}
            className="bg-white"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="bg-gray-50/50 border-gray-200">
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-gray-600" />
                Custom Data Sources
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <input 
                  id="file-upload" 
                  type="file" 
                  className="hidden" 
                  onChange={handleCustomUpload} 
                  disabled={isUploading}
                  accept=".csv,.xlsx,.pdf,.txt"
                />
                <Button
                  onClick={() => document.getElementById('file-upload').click()}
                  variant="outline" 
                  className="w-full bg-white" 
                  disabled={isUploading}
                >
                  {isUploading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Uploading...
                    </>
                  ) : (
                    <>
                      <Upload className="w-4 h-4 mr-2" />
                      Upload Report or CSV
                    </>
                  )}
                </Button>
              </div>

              {/* Display uploaded files */}
              {formData.uploaded_files?.length > 0 && (
                <div className="space-y-2">
                  <h4 className="text-sm font-medium text-gray-700">Uploaded Files</h4>
                  {formData.uploaded_files.map((file, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-white rounded-lg border">
                      <div className="flex items-center gap-3">
                        <FileText className="w-4 h-4 text-blue-600" />
                        <p className="font-medium text-gray-900 text-sm">{file.name}</p>
                      </div>
                      <Button variant="ghost" size="sm" onClick={() => handleRemoveFile(file)}>
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}

              <form onSubmit={handleAddLink} className="space-y-2">
                <label className="text-sm font-medium">Add from link</label>
                <div className="flex gap-2">
                  <Input name="url" type="url" placeholder="https://..." required className="bg-white" />
                  <Button type="submit" variant="outline" className="bg-white"><Link className="w-4 h-4" /></Button>
                </div>
              </form>
            </CardContent>
          </Card>
            
          <Card className="bg-emerald-50 border-emerald-200">
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2 text-emerald-800">
                <CheckCircle className="w-5 h-5"/> Selected Sources
              </CardTitle>
            </CardHeader>
            <CardContent>
              {formData.data_sources.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {formData.data_sources.map((s, index) => (
                    <Badge key={index} variant="secondary" className="text-emerald-700 bg-white border border-emerald-200">
                      {s}
                    </Badge>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-emerald-600">Select data sources to begin.</p>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Removed isExtracting Alert */}
      </div>
    </div>
  );
}
