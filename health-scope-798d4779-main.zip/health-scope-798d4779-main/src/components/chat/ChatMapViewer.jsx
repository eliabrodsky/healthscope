import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Circle, useMap } from 'react-leaflet';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { X, MapPin, Building2, Users, DollarSign, Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// Component to update map view when center changes
function MapUpdater({ center, zoom }) {
  const map = useMap();
  useEffect(() => {
    if (center) {
      map.setView(center, zoom || 9);
    }
  }, [center, zoom, map]);
  return null;
}

const facilityIcons = {
  fqhc: new L.Icon({
    iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-green.png',
    shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
  }),
  hospital: new L.Icon({
    iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-red.png',
    shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
  }),
  clinic: new L.Icon({
    iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-blue.png',
    shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
  })
};

export default function ChatMapViewer({ mapData, onClose }) {
  if (!mapData) return null;

  // Default to US center if no center provided
  const center = mapData.center 
    ? [mapData.center.lat, mapData.center.lng] 
    : [33.8, -91.5]; // Default to Arkansas area

  const hasValidCenter = mapData.center?.lat && mapData.center?.lng;

  const getColor = (value, metric) => {
    if (metric === 'poverty_rate' || metric === 'uninsured_rate') {
      // Higher is worse - red scale
      if (value > 30) return '#dc2626';
      if (value > 20) return '#f97316';
      if (value > 10) return '#facc15';
      return '#22c55e';
    } else if (metric === 'median_income') {
      // Higher is better - green scale
      if (value > 75000) return '#22c55e';
      if (value > 50000) return '#84cc16';
      if (value > 35000) return '#facc15';
      return '#f97316';
    } else {
      // Population - blue scale
      if (value > 50000) return '#1e40af';
      if (value > 20000) return '#3b82f6';
      if (value > 10000) return '#60a5fa';
      return '#93c5fd';
    }
  };

  return (
    <Card className="mt-4 border-2 border-emerald-200">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <MapPin className="w-5 h-5 text-emerald-600" />
            {mapData.title || 'Map View'}
          </CardTitle>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>
        
        {/* Summary Stats for demographic maps */}
        {mapData.summaryStats && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-3">
            <div className="bg-blue-50 p-2 rounded-lg text-center">
              <Users className="w-4 h-4 mx-auto text-blue-600 mb-1" />
              <p className="text-xs text-gray-600">Population</p>
              <p className="font-semibold text-sm">{mapData.summaryStats.total_population?.toLocaleString()}</p>
            </div>
            <div className="bg-red-50 p-2 rounded-lg text-center">
              <Heart className="w-4 h-4 mx-auto text-red-600 mb-1" />
              <p className="text-xs text-gray-600">Poverty Rate</p>
              <p className="font-semibold text-sm">{mapData.summaryStats.avg_poverty_rate}%</p>
            </div>
            <div className="bg-amber-50 p-2 rounded-lg text-center">
              <Users className="w-4 h-4 mx-auto text-amber-600 mb-1" />
              <p className="text-xs text-gray-600">Uninsured</p>
              <p className="font-semibold text-sm">{mapData.summaryStats.avg_uninsured_rate}%</p>
            </div>
            <div className="bg-green-50 p-2 rounded-lg text-center">
              <DollarSign className="w-4 h-4 mx-auto text-green-600 mb-1" />
              <p className="text-xs text-gray-600">Median Income</p>
              <p className="font-semibold text-sm">${mapData.summaryStats.avg_median_income?.toLocaleString()}</p>
            </div>
          </div>
        )}
        
        {mapData.type === 'competitor_map' && mapData.markers?.length > 0 && (
          <div className="flex gap-2 mt-2 flex-wrap">
            <Badge className="bg-green-100 text-green-700">
              <Building2 className="w-3 h-3 mr-1" />
              FQHC: {mapData.markers.filter(m => m.type === 'fqhc').length}
            </Badge>
            <Badge className="bg-red-100 text-red-700">
              Hospital: {mapData.markers.filter(m => m.type === 'hospital').length}
            </Badge>
            <Badge className="bg-blue-100 text-blue-700">
              Clinic: {mapData.markers.filter(m => m.type === 'clinic').length}
            </Badge>
          </div>
        )}
      </CardHeader>
      <CardContent>
        <div className="h-[400px] rounded-lg overflow-hidden border">
          <MapContainer 
            center={center} 
            zoom={9} 
            style={{ height: '100%', width: '100%' }}
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            
            {/* Update map view when center changes */}
            {hasValidCenter && <MapUpdater center={center} zoom={9} />}
            
            {/* Radius circle */}
            {mapData.radiusMeters && hasValidCenter && (
              <Circle
                center={center}
                radius={mapData.radiusMeters}
                pathOptions={{ color: '#10b981', fillColor: '#10b981', fillOpacity: 0.1 }}
              />
            )}

            {/* Markers for competitors/facilities */}
            {mapData.markers?.filter(m => m.lat && m.lng).map((marker, idx) => (
              <Marker 
                key={idx} 
                position={[marker.lat, marker.lng]}
                icon={facilityIcons[marker.type] || new L.Icon.Default()}
              >
                <Popup>
                  <div className="p-2">
                    <h4 className="font-semibold">{marker.name}</h4>
                    <p className="text-sm text-gray-600 capitalize">{marker.type}</p>
                    <p className="text-xs text-gray-500">{marker.address}</p>
                    <p className="text-xs text-gray-500">{marker.city}, {marker.state}</p>
                  </div>
                </Popup>
              </Marker>
            ))}

            {/* Center marker */}
            {hasValidCenter && (
              <Marker position={center}>
                <Popup>Assessment Center</Popup>
              </Marker>
            )}
          </MapContainer>
        </div>
        
        {/* List facilities without coordinates */}
        {mapData.markers?.some(m => m.needsGeocoding) && (
          <div className="mt-3 p-3 bg-amber-50 rounded-lg border border-amber-200">
            <p className="text-sm font-medium text-amber-800 mb-2">Facilities (coordinates pending):</p>
            <div className="grid gap-1 max-h-32 overflow-y-auto">
              {mapData.markers.filter(m => m.needsGeocoding).map((m, idx) => (
                <p key={idx} className="text-xs text-amber-700">
                  • {m.name} - {m.city}, {m.state}
                </p>
              ))}
            </div>
          </div>
        )}

        {/* Top ZIP codes table */}
        {mapData.topZips?.length > 0 && (
          <div className="mt-3 p-3 bg-gray-50 rounded-lg">
            <p className="text-sm font-medium text-gray-700 mb-2">
              Top ZIP Codes by {mapData.metric?.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
            </p>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-1 px-2">ZIP</th>
                    <th className="text-right py-1 px-2">Population</th>
                    <th className="text-right py-1 px-2">Poverty %</th>
                    <th className="text-right py-1 px-2">Uninsured %</th>
                    <th className="text-right py-1 px-2">Income</th>
                  </tr>
                </thead>
                <tbody>
                  {mapData.topZips.map((zip, idx) => (
                    <tr key={idx} className="border-b border-gray-100">
                      <td className="py-1 px-2 font-medium">{zip.zcta}</td>
                      <td className="text-right py-1 px-2">{zip.population?.toLocaleString()}</td>
                      <td className="text-right py-1 px-2">{zip.poverty_rate?.toFixed(1)}%</td>
                      <td className="text-right py-1 px-2">{zip.uninsured_rate?.toFixed(1)}%</td>
                      <td className="text-right py-1 px-2">${zip.median_income?.toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
        
        {/* No data warning */}
        {!mapData.dataLoaded && mapData.type !== 'competitor_map' && (
          <div className="mt-3 p-3 bg-amber-50 rounded-lg border border-amber-200">
            <p className="text-sm text-amber-800">
              {mapData.noDataMessage || 'No demographic data found for this assessment area. Please load demographics in the Assessment wizard first.'}
            </p>
          </div>
        )}
        
        {/* Debug info for troubleshooting */}
        {mapData.summaryStats?.zip_count === 0 && (
          <div className="mt-2 text-xs text-gray-500">
            Assessment area: {mapData.center ? `${mapData.center.lat.toFixed(2)}, ${mapData.center.lng.toFixed(2)}` : 'No coordinates'}
          </div>
        )}
      </CardContent>
    </Card>
  );
}