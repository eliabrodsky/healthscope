import React from 'react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { AlertTriangle, Coins } from 'lucide-react';

export default function GooglePlacesWarningDialog({ open, onOpenChange, onConfirm, tokenCost = 5 }) {
  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-500" />
            Google Places API - Token Cost
          </AlertDialogTitle>
          <AlertDialogDescription className="space-y-3">
            <p>
              This feature uses the Google Places API, which is a <strong>premium data source</strong>.
            </p>
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 flex items-center gap-3">
              <Coins className="w-8 h-8 text-amber-600" />
              <div>
                <p className="font-semibold text-amber-900">Cost: {tokenCost} tokens per search</p>
                <p className="text-sm text-amber-700">Tokens will be deducted from your account balance</p>
              </div>
            </div>
            <p className="text-sm text-gray-600">
              Each search returns up to 20 results within your specified radius. Additional enrichment 
              (phone, website, hours) costs 2 tokens per place.
            </p>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction 
            onClick={onConfirm}
            className="bg-emerald-600 hover:bg-emerald-700"
          >
            I Understand - Proceed
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}