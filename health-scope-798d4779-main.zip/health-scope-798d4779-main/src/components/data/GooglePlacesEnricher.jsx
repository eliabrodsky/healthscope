import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Search, 
  Loader2, 
  Building2, 
  GraduationCap, 
  Heart, 
  MapPin,
  CheckCircle,
  AlertCircle,
  Coins,
  RefreshCw
} from 'lucide-react';
import { toast } from 'sonner';

export default function GooglePlacesEnricher({ 
  latitude, 
  longitude, 
  onResultsFound,
  onEnrichComplete
}) {
  const [searchType, setSearchType] = useState('healthcare');
  const [customQuery, setCustomQuery] = useState('');
  const [radiusMiles, setRadiusMiles] = useState(10);
  const [isSearching, setIsSearching] = useState(false);
  const [results, setResults] = useState([]);
  const [selectedForEnrich, setSelectedForEnrich] = useState(new Set());
  const [isEnriching, setIsEnriching] = useState(false);

  const searchTypes = [
    { value: 'healthcare', label: 'Healthcare Facilities', icon: Building2 },
    { value: 'schools', label: 'Schools & Education', icon: GraduationCap },
    { value: 'nonprofits', label: 'Non-profits', icon: Heart },
    { value: 'general', label: 'Custom Search', icon: Search }
  ];

  const handleSearch = async () => {
    if (!latitude || !longitude) {
      toast.error('Location coordinates required');
      return;
    }

    setIsSearching(true);
    try {
      const response = await base44.functions.invoke('googlePlacesSearch', {
        searchType,
        query: searchType === 'general' ? customQuery : undefined,
        latitude,
        longitude,
        radiusMiles,
        action: 'search'
      });

      if (response.data.error) {
        if (response.data.error === 'Insufficient tokens') {
          toast.error(`Need ${response.data.required} tokens. You have ${response.data.balance}.`);
        } else {
          toast.error(response.data.error);
        }
        return;
      }

      setResults(response.data.results || []);
      toast.success(`Found ${response.data.count} places. Charged ${response.data.tokens_charged} tokens.`);
      
      if (onResultsFound) {
        onResultsFound(response.data.results);
      }
    } catch (error) {
      console.error('Search error:', error);
      toast.error('Failed to search places');
    } finally {
      setIsSearching(false);
    }
  };

  const handleEnrichSelected = async () => {
    if (selectedForEnrich.size === 0) {
      toast.error('Select places to enrich');
      return;
    }

    setIsEnriching(true);
    const enrichedResults = [];

    for (const placeId of selectedForEnrich) {
      try {
        const response = await base44.functions.invoke('googlePlacesSearch', {
          placeId,
          action: 'details'
        });

        if (response.data.results?.[0]) {
          enrichedResults.push(response.data.results[0]);
        }
      } catch (error) {
        console.error('Enrich error:', error);
      }
    }

    setIsEnriching(false);
    toast.success(`Enriched ${enrichedResults.length} places`);
    
    if (onEnrichComplete) {
      onEnrichComplete(enrichedResults);
    }
  };

  const toggleSelect = (placeId) => {
    const newSelected = new Set(selectedForEnrich);
    if (newSelected.has(placeId)) {
      newSelected.delete(placeId);
    } else {
      newSelected.add(placeId);
    }
    setSelectedForEnrich(newSelected);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Search className="w-5 h-5 text-emerald-600" />
          Google Places Search
          <Badge variant="outline" className="ml-auto">
            <Coins className="w-3 h-3 mr-1" />
            5 tokens/search
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Search Controls */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Select value={searchType} onValueChange={setSearchType}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {searchTypes.map(type => (
                <SelectItem key={type.value} value={type.value}>
                  <div className="flex items-center gap-2">
                    <type.icon className="w-4 h-4" />
                    {type.label}
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {searchType === 'general' && (
            <Input
              placeholder="Enter search query..."
              value={customQuery}
              onChange={(e) => setCustomQuery(e.target.value)}
            />
          )}

          <div className="flex gap-2">
            <Input
              type="number"
              value={radiusMiles}
              onChange={(e) => setRadiusMiles(Number(e.target.value))}
              min={1}
              max={50}
              className="w-24"
            />
            <span className="text-sm text-gray-500 self-center">miles</span>
          </div>
        </div>

        <Button 
          onClick={handleSearch} 
          disabled={isSearching}
          className="bg-emerald-600 hover:bg-emerald-700"
        >
          {isSearching ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Searching...
            </>
          ) : (
            <>
              <Search className="w-4 h-4 mr-2" />
              Search Places
            </>
          )}
        </Button>

        {/* Results */}
        {results.length > 0 && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-sm text-gray-600">{results.length} places found</p>
              {selectedForEnrich.size > 0 && (
                <Button 
                  size="sm" 
                  onClick={handleEnrichSelected}
                  disabled={isEnriching}
                  variant="outline"
                >
                  {isEnriching ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <RefreshCw className="w-4 h-4 mr-2" />
                  )}
                  Enrich {selectedForEnrich.size} Selected
                </Button>
              )}
            </div>

            <div className="max-h-96 overflow-y-auto space-y-2">
              {results.map((place) => (
                <div 
                  key={place.place_id}
                  onClick={() => toggleSelect(place.place_id)}
                  className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                    selectedForEnrich.has(place.place_id) 
                      ? 'border-emerald-500 bg-emerald-50' 
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900">{place.name}</h4>
                      <p className="text-sm text-gray-600 flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {place.address}
                      </p>
                      <div className="flex gap-2 mt-2">
                        {place.rating && (
                          <Badge variant="outline" className="text-xs">
                            ⭐ {place.rating} ({place.total_ratings})
                          </Badge>
                        )}
                        {place.business_status === 'OPERATIONAL' ? (
                          <Badge className="bg-green-100 text-green-700 text-xs">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Open
                          </Badge>
                        ) : place.business_status === 'CLOSED_PERMANENTLY' && (
                          <Badge className="bg-red-100 text-red-700 text-xs">
                            <AlertCircle className="w-3 h-3 mr-1" />
                            Closed
                          </Badge>
                        )}
                      </div>
                    </div>
                    {selectedForEnrich.has(place.place_id) && (
                      <CheckCircle className="w-5 h-5 text-emerald-600" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}