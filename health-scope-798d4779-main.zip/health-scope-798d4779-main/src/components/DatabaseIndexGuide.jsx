import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
    Database, 
    Copy, 
    CheckCircle, 
    AlertTriangle, 
    ChevronDown, 
    ChevronUp,
    ExternalLink 
} from 'lucide-react';
import { toast } from 'sonner';

export default function DatabaseIndexGuide({ stateAbbr, stateName }) {
    const [isExpanded, setIsExpanded] = useState(false);
    const [copiedIndex, setCopiedIndex] = useState(false);
    const [copiedCommand, setCopiedCommand] = useState(false);

    const mongoIndexCode = `{
  "state_abbr": 1,
  "zcta5": 1
}`;

    const resetCommand = `await base44.functions.invoke('resetStateCache', {
    stateAbbr: '${stateAbbr}',
    stateName: '${stateName || stateAbbr}'
});`;

    const copyToClipboard = async (text, type) => {
        try {
            await navigator.clipboard.writeText(text);
            if (type === 'index') {
                setCopiedIndex(true);
                setTimeout(() => setCopiedIndex(false), 2000);
            } else {
                setCopiedCommand(true);
                setTimeout(() => setCopiedCommand(false), 2000);
            }
            toast.success('Copied to clipboard!');
        } catch (error) {
            toast.error('Failed to copy');
        }
    };

    return (
        <Card className="border-red-200 bg-red-50">
            <CardHeader>
                <div className="flex items-start justify-between">
                    <div>
                        <CardTitle className="flex items-center gap-2 text-red-900">
                            <AlertTriangle className="w-5 h-5" />
                            Database Timeout - Indexes Required
                        </CardTitle>
                        <p className="text-sm text-red-700 mt-2">
                            Your database needs indexes to handle ZCTA queries efficiently.
                        </p>
                    </div>
                    <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setIsExpanded(!isExpanded)}
                        className="text-red-700 hover:text-red-900"
                    >
                        {isExpanded ? (
                            <>
                                <ChevronUp className="w-4 h-4 mr-1" />
                                Hide
                            </>
                        ) : (
                            <>
                                <ChevronDown className="w-4 h-4 mr-1" />
                                Show Solutions
                            </>
                        )}
                    </Button>
                </div>
            </CardHeader>
            
            {isExpanded && (
                <CardContent className="space-y-4">
                    {/* Solution 1: Add Index */}
                    <div className="bg-white rounded-lg p-4 border border-red-200">
                        <div className="flex items-center gap-2 mb-3">
                            <CheckCircle className="w-5 h-5 text-emerald-600" />
                            <h3 className="font-semibold text-gray-900">
                                Solution 1: Add Database Index (Recommended)
                            </h3>
                        </div>
                        
                        <Alert className="mb-3">
                            <Database className="w-4 h-4" />
                            <AlertDescription>
                                <strong>Best long-term fix:</strong> After adding the index, all queries will be instant (milliseconds instead of 20+ seconds).
                            </AlertDescription>
                        </Alert>

                        <div className="space-y-3">
                            <div>
                                <p className="text-sm text-gray-700 font-medium mb-2">
                                    For MongoDB Atlas:
                                </p>
                                <ol className="text-sm text-gray-600 space-y-1 ml-4 list-decimal">
                                    <li>Open your MongoDB Atlas console</li>
                                    <li>Navigate to your cluster → Browse Collections</li>
                                    <li>Find the <code className="bg-gray-100 px-1 py-0.5 rounded">ZctaBoundary</code> collection</li>
                                    <li>Go to <strong>Indexes</strong> tab</li>
                                    <li>Click <strong>Create Index</strong></li>
                                    <li>Paste this index definition:</li>
                                </ol>
                            </div>

                            <div className="relative">
                                <pre className="bg-gray-900 text-gray-100 p-3 rounded-md text-xs overflow-x-auto">
                                    {mongoIndexCode}
                                </pre>
                                <Button
                                    size="sm"
                                    variant="ghost"
                                    className="absolute top-2 right-2 bg-gray-800 hover:bg-gray-700 text-white"
                                    onClick={() => copyToClipboard(mongoIndexCode, 'index')}
                                >
                                    {copiedIndex ? (
                                        <>
                                            <CheckCircle className="w-3 h-3 mr-1" />
                                            Copied!
                                        </>
                                    ) : (
                                        <>
                                            <Copy className="w-3 h-3 mr-1" />
                                            Copy
                                        </>
                                    )}
                                </Button>
                            </div>

                            <div className="text-xs text-gray-500">
                                Name it: <code className="bg-gray-100 px-1 py-0.5 rounded">idx_state_zcta</code>
                            </div>

                            <div className="bg-emerald-50 p-3 rounded-md border border-emerald-200">
                                <p className="text-sm text-emerald-900 font-medium">✅ After adding index:</p>
                                <ul className="text-sm text-emerald-800 mt-1 space-y-1 ml-4 list-disc">
                                    <li>Cache warming: <strong>Instant</strong> (milliseconds)</li>
                                    <li>Demographics loading: <strong>Fast & reliable</strong></li>
                                    <li>No more timeouts!</li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    {/* Solution 2: Reload Boundaries */}
                    <div className="bg-white rounded-lg p-4 border border-amber-200">
                        <div className="flex items-center gap-2 mb-3">
                            <CheckCircle className="w-5 h-5 text-amber-600" />
                            <h3 className="font-semibold text-gray-900">
                                Solution 2: Reload Boundaries (Workaround)
                            </h3>
                        </div>
                        
                        <Alert className="mb-3 bg-amber-50 border-amber-200">
                            <AlertTriangle className="w-4 h-4 text-amber-600" />
                            <AlertDescription className="text-amber-900">
                                <strong>Quick workaround:</strong> The boundary loader builds the ZCTA cache without database queries.
                            </AlertDescription>
                        </Alert>

                        <div className="space-y-3">
                            <ol className="text-sm text-gray-600 space-y-2 ml-4 list-decimal">
                                <li>
                                    <strong>First, reset the corrupted cache:</strong>
                                    <div className="relative mt-2">
                                        <pre className="bg-gray-900 text-gray-100 p-3 rounded-md text-xs overflow-x-auto">
                                            {resetCommand}
                                        </pre>
                                        <Button
                                            size="sm"
                                            variant="ghost"
                                            className="absolute top-2 right-2 bg-gray-800 hover:bg-gray-700 text-white"
                                            onClick={() => copyToClipboard(resetCommand, 'command')}
                                        >
                                            {copiedCommand ? (
                                                <>
                                                    <CheckCircle className="w-3 h-3 mr-1" />
                                                    Copied!
                                                </>
                                            ) : (
                                                <>
                                                    <Copy className="w-3 h-3 mr-1" />
                                                    Copy
                                                </>
                                            )}
                                        </Button>
                                    </div>
                                    <p className="text-xs text-gray-500 mt-1 ml-4">
                                        (Paste in browser console on this page)
                                    </p>
                                </li>
                                <li>Click <strong>"Reload"</strong> for <strong>{stateName || stateAbbr} Boundaries</strong></li>
                                <li>Wait for completion (~30-60 seconds)</li>
                                <li>Click <strong>"Load"</strong> for <strong>Demographics</strong></li>
                            </ol>

                            <div className="bg-blue-50 p-3 rounded-md border border-blue-200">
                                <p className="text-sm text-blue-900 font-medium">📍 How it works:</p>
                                <ul className="text-sm text-blue-800 mt-1 space-y-1 ml-4 list-disc">
                                    <li>Processes GeoJSON file directly (no DB queries)</li>
                                    <li>Builds clean ZCTA cache as it inserts</li>
                                    <li>Sets <code className="bg-blue-100 px-1 py-0.5 rounded">zcta_cache_ready: true</code> when done</li>
                                    <li>Demographics uses this cache (no warming needed!)</li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    {/* Why This Happens */}
                    <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                        <h3 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
                            <Database className="w-4 h-4" />
                            Why This Happens
                        </h3>
                        <div className="space-y-2 text-sm text-gray-600">
                            <div>
                                <strong className="text-red-600">Without Index:</strong>
                                <p className="ml-4 text-xs bg-red-50 p-2 rounded mt-1 border border-red-100">
                                    Query: Find all ZctaBoundary where state_abbr = '{stateAbbr}'<br/>
                                    MongoDB: Scans <strong>ALL 50,000+ records</strong> → 20+ seconds → <strong className="text-red-600">TIMEOUT</strong>
                                </p>
                            </div>
                            <div>
                                <strong className="text-emerald-600">With Index:</strong>
                                <p className="ml-4 text-xs bg-emerald-50 p-2 rounded mt-1 border border-emerald-100">
                                    Query: Find all ZctaBoundary where state_abbr = '{stateAbbr}'<br/>
                                    MongoDB: Index lookup → 793 records in <strong className="text-emerald-600">50ms</strong> → <strong className="text-emerald-600">SUCCESS</strong>
                                </p>
                            </div>
                        </div>
                    </div>

                    {/* Documentation Link */}
                    <div className="flex justify-center pt-2">
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={() => window.open('https://www.mongodb.com/docs/manual/indexes/', '_blank')}
                            className="gap-2"
                        >
                            <ExternalLink className="w-4 h-4" />
                            MongoDB Index Documentation
                        </Button>
                    </div>
                </CardContent>
            )}
        </Card>
    );
}